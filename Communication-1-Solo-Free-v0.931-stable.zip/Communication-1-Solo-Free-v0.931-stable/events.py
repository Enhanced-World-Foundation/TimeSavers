# ============================================================================
#  events.py  —  EVENT BUS ekosystemu (na bibliotece blinker, open-source)
# ============================================================================
#  CO TO JEST (po ludzku):
#  Centralny "głośnik". Agent krzyczy "MAIL_CRITICAL!" i NIE wie kto słucha.
#  Słuchacze (panel, Telegram, Discord, wirtualny kompan, push na Androida)
#  sami się podpinają. Dodajesz nowy interfejs BEZ dotykania logiki agentów.
#
#  DLACZEGO blinker a nie własny kod:
#  - sprawdzona biblioteka (używa jej Flask), zero utrzymania z naszej strony
#  - słabe referencje: słuchacz który zniknie nie zostawia wycieku
#
#  ZDARZENia (nazwy jako stałe — nie literały, żeby nie było literówek):
#    REPORT_READY      raport gotowy         → panel odświeża, kanały wysyłają
#    MAIL_CRITICAL     P1! wykryty           → companion 😨, push, alarm
#    AI_LIMIT_REACHED  wyczerpany budżet TPM → panel pokazuje "⏳ w kolejce"
#    NEW_GRANT         grant znaleziony      → (Grant Watcher, przyszłość)
#    AGENT_START/DONE  cykl życia agenta     → HQ, scheduler, logi
#    DRAFT_READY       draft do akceptacji   → panel pokazuje przycisk
#
#  UŻYCIE:
#    from events import bus, REPORT_READY
#    bus.emit(REPORT_READY, agent="reporter", report=txt)     # nadawca
#    @bus.on(REPORT_READY)                                     # słuchacz
#    def _(sender, **kw): ...
# ============================================================================

try:
    from blinker import signal
    _HAS_BLINKER = True
except Exception:
    _HAS_BLINKER = False   # awaryjnie: gdyby blinker nie był zainstalowany

# ── Nazwy zdarzeń (stałe) ───────────────────────────────────────────────────
REPORT_READY     = "REPORT_READY"
MAIL_CRITICAL    = "MAIL_CRITICAL"
AI_LIMIT_REACHED = "AI_LIMIT_REACHED"
NEW_GRANT        = "NEW_GRANT"
AGENT_START      = "AGENT_START"
AGENT_DONE       = "AGENT_DONE"
DRAFT_READY      = "DRAFT_READY"

ALL_EVENTS = [REPORT_READY, MAIL_CRITICAL, AI_LIMIT_REACHED, NEW_GRANT,
              AGENT_START, AGENT_DONE, DRAFT_READY]


class _Bus:
    """Cienka nakładka na blinker. Gdyby blinkera brakło — działa jako no-op,
    więc agent nigdy się nie wywali przez brak biblioteki."""

    def emit(self, event, sender=None, **data):
        """Wyślij zdarzenie. sender = kto (nazwa agenta), data = dowolne pola."""
        if _HAS_BLINKER:
            signal(event).send(sender, **data)

    def on(self, event):
        """Dekorator: podepnij funkcję pod zdarzenie.
        Funkcja dostaje (sender, **data)."""
        def deco(fn):
            if _HAS_BLINKER:
                # connect_via + weak=False: słuchacz żyje póki żyje program
                signal(event).connect(fn, weak=False)
            return fn
        return deco

    def connect(self, event, fn):
        """Wariant bez dekoratora (podepnij funkcję programowo)."""
        if _HAS_BLINKER:
            signal(event).connect(fn, weak=False)


# Jedna wspólna instancja dla całego ekosystemu
bus = _Bus()
