# ============================================================================
#  help_texts.py — WSZYSTKIE teksty pomocy w jednym miejscu
# ============================================================================
# file-version: 0.930 | engine: 0.930 | updated: 2026-09-04
#  Dwa poziomy, bo to dwie rozne osoby:
#
#    "tip"  — RADA. Jak tego uzyc, zeby bylo dobrze. Dla kazdego.
#             Odpowiada na: "co mam tu wpisac i po co?"
#
#    "tech" — MECHANIKA. Co sie dzieje pod spodem, jak to wplywa na wynik.
#             Odpowiada na: "jak to dziala i co dokladnie zmieni?"
#
#  Nie dubluja sie: tip mowi CO ZROBIC, tech mowi CO SIE STANIE.
#
#  Packi transl/<tool>.<lang>.transl.<version>.json moga nadpisac sekcje help.
#  Wbudowane HELP pozostaje bezpiecznym fallbackiem per klucz i poziom.
# ============================================================================

import language_packs as _LP

_PACK_VERSION = None


def configure(engine_version):
    global _PACK_VERSION
    _PACK_VERSION = str(engine_version or "")


HELP = {

"en": {

# ── PERSONALISATION ──────────────────────────────────────────────────────
"a-goal": {
    "tip": "Write it like you'd explain the job to a colleague in one breath.\n"
           "→ Click the box\n"
           "→ Type one sentence: what should this tool do for you?\n"
           "→ Example: \"Watch my three inboxes and tell me what actually needs me today.\"\n"
           "Vague goal → vague report.",
    "tech": "Sent to the AI as context on every run. It does not directly set a priority. In Classic+AI mode "
            "it may inform the AI correction; deterministic Rules remain the safety rails.",
},
"a-priority": {
    "tip": "Only matters if you run several a-tools.\n"
           "→ 1 = this tool's mail gets the AI's attention first\n"
           "→ 3 = normal (leave it here if you have one tool)\n"
           "→ 5 = lowest, gets AI attention last",
    "tech": "Feeds the queue: queue = mail_priority + (mailbox−3)×0.4 + (agent−3)×0.3. "
            "An agent at 1 pulls ~0.6 ahead of one at 3 — enough to break ties, not enough "
            "to jump a priority level.",
},
"a-character": {
    "tip": "The voice of every summary.\n"
           "→ \"Calm, no scare tactics\" → gentle, factual\n"
           "→ \"Blunt, get to the point\" → short, direct\n"
           "If serious mail makes you anxious, say so here — it will soften the wording.",
    "tech": "Passed as the LLM system prompt. Affects wording only — never which mails are "
            "picked or how they're ranked.",
},
"a-focus": {
    "tip": "Name the senders you'd hate to miss.\n"
           "→ Type them comma-separated: real people, your bank, your university, clients\n"
           "→ Everything else sinks below them in the report",
    "tech": "Injected into the AI prompt as 'what matters'. With AI OFF it has no effect — "
            "use the watchlist instead, which the script reads directly.",
},
"a-exclude": {
    "tip": "The cheapest win in this tool.\n"
           "→ Type anything you never read: newsletter, noreply, facebook, promo\n"
           "→ Comma-separated\n"
           "→ These are dropped BEFORE the AI sees them, so they cost you nothing",
    "tech": "Matched against sender+subject, case-insensitive, before batching. Excluded mail "
            "never enters the token budget and never appears in the report.",
},
"a-watch": {
    "tip": "Your never-miss list. THE most useful field here.\n"
           "→ Type words that always mean \"stop and look\"\n"
           "→ Example: tax office, bailiff, ELSA, name of your client\n"
           "→ Works even with AI turned OFF — the script reads this directly",
    "tech": "Read by the SCRIPT, not the AI. A hit uses the configurable watchlist priority "
            "(default P1), marks the mail important and pulls it into the AI queue. This is explicit user intent; "
            "USER_CONTEXT/project relevance is a separate, softer boost.",
},
"a-lang": {
    "tip": "The language of the report YOU read.\n"
           "→ The panel stays English\n"
           "→ Set English if you're recording a demo video",
    "tech": "Selects the label set and tells the LLM which language to summarize in. "
            "Adding a language = one dict in operational.py.",
},
"l-preset": {
    "tip": "Start with Groq — free and fast enough.\n"
           "→ Pick \"Groq\" from the list\n"
           "→ Go to console.groq.com, create a key (starts with gsk_)\n"
           "→ Paste it below → press Test\n"
           "Want total privacy? Pick Ollama: the model runs on your machine, nothing leaves it.",
    "tech": "Fills provider/base_url/model. Any OpenAI-compatible endpoint works. Never "
            "overwrites an existing key.",
},
"s-inbox": {
    "tip": "One line per mailbox:\n"
           "→ host | login | password | priority\n"
           "→ Gmail: imap.gmail.com | you@gmail.com | APP-PASSWORD | 3\n"
           "   (App Password = 16 chars, needs 2FA on. Your normal password will NOT work.)\n"
           "→ o2.pl: poczta.o2.pl | login-WITHOUT-@o2.pl | password | 3",
    "tech": "Standard IMAP4_SSL. Priority 1-5 shifts that mailbox's mail in the AI queue by "
            "(priority−3)×0.4. Work inbox at 1 gets read first.",
},
"o-ailevel": {
    "tip": "Start with OFF. Honestly.\n"
           "→ OFF = script only. Instant, free, still sorts and tags everything.\n"
           "→ Free tier = AI writes summaries (pauses to respect the 8000 tok/min limit)\n"
           "→ Deep = paid key or local model, no limits\n"
           "Turn AI on when you want summaries written for you — not before.",
    "tech": "OFF skips every LLM call. Free tier batches to fit Groq's limit and sleeps 63s "
            "between batches. Paid/local removes the pause and the 12-summary cap.",
},
"o-selmode": {
    "tip": "→ \"Important ones\" = the rules decide. Predictable, cheaper.\n"
           "→ \"AI picks\" = AI reads the subject list first and chooses. Smarter, one extra call.",
    "tech": "AI-picks sends sender+subject of every candidate, gets back indices, and only those "
            "get a full summary. It also lets the AI fix tags on what it read.",
},
"o-aipri": {
    "tip": "Turn this on ONLY after you fill in 👤 My profile.\n"
           "→ Then the AI can spot that a mail about YOUR project isn't routine\n"
           "→ Without a profile it has nothing to judge against",
    "tech": "Classic mode: the deterministic script sets the base P, then AI may propose a correction using "
            "your profile. Global and message-specific Rules are safety rails (floors/ceilings, ad/noise limits, P1! policy). "
            "The accepted or blocked decision is recorded for Why this priority and debug logs.",
},
"o-aiext": {
    "tip": "Use Model 4 when you want a different decision philosophy: AI extracts facts, then deterministic rules calculate P.",
    "tech": "Model 4 does not directly accept an AI priority. AI returns structured facts; m4_priority applies priority_rules.json. "
            "If facts cannot be parsed or no M4 rule matches, Classic script P remains final. An AI context-based advisory P may be shown, but never changes the result.",
},
"o-always": {
    "tip": "P1/P1! are always summarized when AI is on. Enable this if you also want P2 summaries.",
    "tech": "Works on free/fast as well as Deep. For old profiles Deep defaults this ON; once you explicitly untick it, false overrides Deep.",
},
"o-depth": {
    "tip": "→ Auto = 1 line for simple mail, up to 4 for complex. Right for almost everyone.\n"
           "→ Short = skim mode\n"
           "→ Detailed = long mails you actually need to understand (costs ~2x the tokens)",
    "tech": "Sets max_tokens and the instruction sent with each batch.",
},
"o-bg": {
    "tip": "Leave OFF unless you're drowning.\n"
           "→ 12 summaries is already more than most people read\n"
           "→ Turning it ON with a free key WILL hit the rate limit",
    "tech": "Lifts the 12-per-run cap. Mail over the cap queues in overflow.json and gets "
            "summarized next run, oldest first — nothing is lost either way.",
},
"o-autocal": {
    "tip": "→ OFF (default) = you stay in charge. Add what you want with the 🔔 button in the report.\n"
           "→ ON = deadlines from genuinely urgent mail (P1/P1!) land in the calendar by themselves",
    "tech": "Only P1/P1! with a parsed deadline are added, deduplicated by (agent,title,date). "
            "Demo mode never writes to the calendar.",
},
"sc-sched": {
    "tip": "Two runs a day is the sweet spot.\n"
           "→ Type: 08:00, 18:00\n"
           "→ More than that and you're back to checking mail constantly — which is what this "
           "tool was meant to end.",
    "tech": "The profile publishes its wake slots to ecosystem.json. The always-on Wake manager follows them even with Chrome/panel closed; APScheduler is an in-process persistent mirror when available. RSS feeds may publish additional per-feed hours.",
},
"sc-catch": {
    "tip": "Leave this ON.\n"
           "→ It means closing your laptop doesn't cost you a report",
    "tech": "On start, compares now() to lastrun.txt. If more than 86400/times_per_day has "
            "passed, it runs once immediately.",
},
"profile": {
    "tip": "This is the difference between a tool that guesses and one that knows you.\n"
           "→ Click 👤 My profile in the header\n"
           "→ Name your projects EXACTLY as they appear in your inbox\n"
           "→ Five minutes here beats every other setting combined",
    "tech": "Sections tagged [USER]/[SCRIPT]/[AI]/[FIX], scoped (all)/(kind:X)/(tool:NAME). "
            "AI writes only to [AI]. Free tier sends ~900 chars ([USER] first); paid/local "
            "sends the whole file.",
},
"tags": {
    "tip": "If a tag or handling rule is wrong, fix it once.\n"
           "→ Click ✎ on that mail or open Rules\n"
           "→ Match the sender email, subject/body word or tag\n"
           "→ Optionally set a tag, priority floor/ceiling, always-show, scope and stop\n"
           "→ Use ↑/↓ to change precedence",
    "tech": "Tag rules and message rules use the same custom-rule engine. Fields are match, where "
            "(from/source/subject/body/tag/all), tag, scope, min_priority (floor), max_priority (ceiling), show and stop. "
            "Rules are scanned in saved order until tag dependencies reach a stable state. Each rule matches at most once; "
            "tags/show are additive, later matched explicit floor/ceiling values override earlier ones, and stop ends evaluation "
            "when that rule matches. A where=tag rule therefore works whether its tag came from classification or another rule.",
},

},  # end "en"

"pl": {

"a-goal": {
    "tip": "Napisz to tak, jakbys tlumaczyl kolezance na jednym oddechu, co ma robic.\n"
           "→ Kliknij w pole\n"
           "→ Wpisz jedno zdanie: co to narzedzie ma dla Ciebie robic?\n"
           "→ Przyklad: \"Pilnuj trzech skrzynek i mow mi, co naprawde wymaga mnie dzisiaj.\"\n"
           "Mglisty cel → mglisty raport.",
    "tech": "Wysylane do AI jako kontekst przy kazdym runie. Nie ustawia bezposrednio priorytetu. "
            "W trybie Classic+AI moze wplynac na propozycje korekty AI; deterministyczne Rules pozostaja ograniczeniami.",
},
"a-priority": {
    "tip": "Ma znaczenie tylko, gdy masz kilka a-tooli.\n"
           "→ 1 = poczta tego narzedzia idzie do AI pierwsza\n"
           "→ 3 = normalnie (zostaw, jesli masz jedno narzedzie)\n"
           "→ 5 = najnizej, AI zajmie sie nia na koncu",
    "tech": "Wchodzi do kolejki: kolejka = priorytet_maila + (skrzynka−3)×0.4 + (agent−3)×0.3. "
            "Agent z 1 wyprzedza tego z 3 o ~0.6 — wystarczy na rozstrzygniecie remisu, "
            "za malo, by przeskoczyc poziom priorytetu.",
},
"a-character": {
    "tip": "Glos kazdego streszczenia.\n"
           "→ \"Spokojnie, bez straszenia\" → lagodnie, rzeczowo\n"
           "→ \"Konkretnie, do rzeczy\" → krotko, wprost\n"
           "Jesli powazna poczta Cie stresuje, napisz to tutaj — zlagodzi ton.",
    "tech": "Przekazywane jako prompt systemowy do LLM. Wplywa tylko na styl — nigdy na to, "
            "ktore maile sa wybrane ani jak sa uszeregowane.",
},
"a-focus": {
    "tip": "Wymien nadawcow, ktorych nie chcesz przegapic.\n"
           "→ Wpisz po przecinku: realni ludzie, Twoj bank, uczelnia, klienci\n"
           "→ Cala reszta spada w raporcie ponizej nich",
    "tech": "Wstrzykiwane do promptu AI jako 'co sie liczy'. Z AI WYLACZONYM nie dziala — "
            "uzyj wtedy listy obserwowanych slow, ktora czyta sam skrypt.",
},
"a-exclude": {
    "tip": "Najtansza wygrana w tym narzedziu.\n"
           "→ Wpisz to, czego nigdy nie czytasz: newsletter, noreply, facebook, promo\n"
           "→ Po przecinku\n"
           "→ Te maile odpadaja ZANIM zobaczy je AI, wiec nic Cie nie kosztuja",
    "tech": "Dopasowanie do nadawcy+tematu, bez rozroznienia wielkosci liter, przed batchowaniem. "
            "Odsiane maile nigdy nie wchodza do budzetu tokenow ani do raportu.",
},
"a-watch": {
    "tip": "Twoja lista 'nigdy nie przegap'. NAJBARDZIEJ przydatne pole tutaj.\n"
           "→ Wpisz slowa, ktore zawsze znacza 'zatrzymaj sie i spojrz'\n"
           "→ Przyklad: urzad skarbowy, komornik, ELSA, nazwisko klienta\n"
           "→ Dziala nawet z AI WYLACZONYM — skrypt czyta to bezposrednio",
    "tech": "Czytane przez SKRYPT, nie AI. Trafienie nadaje skonfigurowany priorytet watchlisty "
            "(domyslnie P1), oznacza mail jako wazny i wciaga go do kolejki AI. To jawna intencja usera; "
            "USER_CONTEXT/projekty sa osobnym, lagodniejszym sygnalem.",
},
"a-lang": {
    "tip": "Jezyk raportu, ktory czytasz TY.\n"
           "→ Panel zostaje po angielsku\n"
           "→ Ustaw angielski, jesli nagrywasz demo",
    "tech": "Wybiera zestaw etykiet i mowi LLM, w jakim jezyku streszczac. "
            "Dodanie jezyka = jeden slownik w operational.py.",
},
"l-preset": {
    "tip": "Zacznij od Groq — darmowy i wystarczajaco szybki.\n"
           "→ Wybierz \"Groq\" z listy\n"
           "→ Wejdz na console.groq.com, zaloz klucz (zaczyna sie od gsk_)\n"
           "→ Wklej go nizej → nacisnij Test\n"
           "Chcesz pelnej prywatnosci? Wybierz Ollama: model dziala na Twoim komputerze, nic go nie opuszcza.",
    "tech": "Wypelnia provider/base_url/model. Dziala kazdy endpoint zgodny z OpenAI. "
            "Nigdy nie nadpisuje istniejacego klucza.",
},
"s-inbox": {
    "tip": "Jedna linia na skrzynke:\n"
           "→ host | login | haslo | priorytet\n"
           "→ Gmail: imap.gmail.com | ty@gmail.com | HASLO-APLIKACJI | 3\n"
           "   (Haslo aplikacji = 16 znakow, wymaga wlaczonego 2FA. Zwykle haslo NIE zadziala.)\n"
           "→ o2.pl: poczta.o2.pl | login-BEZ-@o2.pl | haslo | 3",
    "tech": "Standardowe IMAP4_SSL. Priorytet 1-5 przesuwa poczte tej skrzynki w kolejce AI o "
            "(priorytet−3)×0.4. Skrzynka firmowa na 1 jest czytana pierwsza.",
},
"o-ailevel": {
    "tip": "Zacznij od WYLACZONE. Serio.\n"
           "→ WYL = sam skrypt. Natychmiast, za darmo, dalej sortuje i taguje wszystko.\n"
           "→ Darmowy tier = AI pisze streszczenia (z pauzami, by zmiescic sie w 8000 tok/min)\n"
           "→ Deep = platny klucz albo model lokalny, bez limitow\n"
           "Wlacz AI, gdy chcesz gotowe streszczenia — nie wczesniej.",
    "tech": "WYL pomija kazde wywolanie LLM. Darmowy tier batchuje pod limit Groqa i spi 63s "
            "miedzy batchami. Platny/lokalny znosi pauze i limit 12 streszczen.",
},
"o-selmode": {
    "tip": "→ \"Wazne\" = decyduja reguly. Przewidywalnie, taniej.\n"
           "→ \"AI wybiera\" = AI najpierw czyta liste tematow i wybiera. Madrzej, jedno wywolanie wiecej.",
    "tech": "AI-wybiera wysyla nadawce+temat kazdego kandydata, dostaje z powrotem indeksy i tylko "
            "te dostaja pelne streszczenie. Pozwala tez AI poprawic tagi na tym, co przeczytalo.",
},
"o-aipri": {
    "tip": "Wlacz to DOPIERO po wypelnieniu 👤 Mojego profilu.\n"
           "→ Wtedy AI moze zauwazyc, ze mail o TWOIM projekcie nie jest rutynowy\n"
           "→ Bez profilu nie ma czego z czym porownac",
    "tech": "Tryb Classic: skrypt deterministyczny ustala bazowe P, a AI moze zaproponowac korekte "
            "na podstawie profilu. Globalne i wiadomosciowe Rules pozostaja safety rails (floor/ceiling, limity noise/ads, polityka P1!). "
            "Przyjeta lub zablokowana decyzja trafia do Why this priority i logu debug.",
},
"o-aiext": {
    "tip": "Uzyj Modelu 4, gdy chcesz innej filozofii decyzji: AI wyciaga fakty, potem deterministyczne reguly licza P.",
    "tech": "Model 4 nie przyjmuje bezposrednio priorytetu od AI. AI zwraca fakty strukturalne; m4_priority stosuje priority_rules.json. "
            "Gdy faktow nie da sie uzyc albo zadna regula M4 nie pasuje, finalne zostaje P skryptu Classic. AI advisory P jest tylko informacja.",
},
"o-always": {
    "tip": "P1/P1! sa zawsze streszczane, gdy AI jest wlaczone. Wlacz to, jesli chcesz tez P2.",
    "tech": "Dziala rowniez w free/fast. Dla starych profili Deep domyslnie wlacza P2; gdy jawnie odznaczysz, false nadpisuje Deep.",
},
"o-depth": {
    "tip": "→ Auto = 1 linia dla prostych, do 4 dla zlozonych. Dobre dla prawie kazdego.\n"
           "→ Krotkie = tryb przegladania\n"
           "→ Szczegolowe = dlugie maile, ktore naprawde musisz zrozumiec (kosztuje ~2x tokenow)",
    "tech": "Ustawia max_tokens i instrukcje wysylana z kazdym batchem.",
},
"o-bg": {
    "tip": "Zostaw WYLACZONE, chyba ze toniesz.\n"
           "→ 12 streszczen to juz wiecej, niz wiekszosc ludzi czyta\n"
           "→ Wlaczenie tego z darmowym kluczem UDERZY w limit",
    "tech": "Znosi limit 12 na run. Poczta ponad limit ladu je w overflow.json i dostaje "
            "streszczenie w nastepnym runie, od najstarszych — tak czy siak nic nie ginie.",
},
"o-autocal": {
    "tip": "→ WYL (domyslnie) = Ty decydujesz. Dodajesz co chcesz przyciskiem 🔔 w raporcie.\n"
           "→ WL = terminy z naprawde pilnej poczty (P1/P1!) same trafiaja do kalendarza",
    "tech": "Dodawane sa tylko P1/P1! z rozpoznanym terminem, z deduplikacja po (agent,tytul,data). "
            "Tryb demo nigdy nie pisze do kalendarza.",
},
"sc-sched": {
    "tip": "Dwa runy dziennie to zloty srodek.\n"
           "→ Wpisz: 08:00, 18:00\n"
           "→ Wiecej i wracasz do ciaglego sprawdzania poczty — a to wlasnie to narzedzie "
           "mialo zakonczyc.",
    "tech": "Profil publikuje godziny do ecosystem.json. Stale dzialajacy Wake pilnuje ich takze po zamknieciu Chrome/panelu; APScheduler jest trwalym lustrem w procesie, gdy jest dostepny. RSS moze miec dodatkowe godziny per feed.",
},
"sc-catch": {
    "tip": "Zostaw to WLACZONE.\n"
           "→ Dzieki temu zamkniecie laptopa nie kosztuje Cie raportu",
    "tech": "Przy starcie porownuje now() z lastrun.txt. Jesli minelo wiecej niz "
            "86400/razy_dziennie, odpala sie raz od razu.",
},
"profile": {
    "tip": "To roznica miedzy narzedziem, ktore zgaduje, a takim, ktore Cie zna.\n"
           "→ Kliknij 👤 Moj profil w naglowku\n"
           "→ Nazwij swoje projekty DOKLADNIE tak, jak wystepuja w skrzynce\n"
           "→ Piec minut tutaj bije kazde inne ustawienie razem wziete",
    "tech": "Sekcje oznaczone [USER]/[SCRIPT]/[AI]/[FIX], zakres (all)/(kind:X)/(tool:NAZWA). "
            "AI pisze tylko do [AI]. Darmowy tier wysyla ~900 znakow ([USER] najpierw); "
            "platny/lokalny wysyla caly plik.",
},
"tags": {
    "tip": "Jesli tag albo sposob obslugi jest zly, popraw go raz.\n"
           "→ Kliknij ✎ przy mailu albo otworz Rules\n"
           "→ Dopasuj email nadawcy, slowo z tematu/tresci albo tag\n"
           "→ Opcjonalnie ustaw tag, floor/ceiling P, always-show, scope i stop\n"
           "→ Kolejnosc zmieniasz przyciskami ↑/↓",
    "tech": "Tag rules i message rules korzystaja z tego samego silnika. Pola: match, where "
            "(from/source/subject/body/tag/all), tag, scope, min_priority (floor), max_priority (ceiling), show i stop. "
            "Reguly sa sprawdzane w zapisanej kolejnosci az zaleznosci tagow osiagna stabilny stan. Kazda regula trafia najwyzej raz; "
            "tagi/show sie sumuja, pozniej trafione jawne floor/ceiling nadpisuja wczesniejsze, a stop konczy ocene po trafieniu. "
            "Regula where=tag dziala wiec niezaleznie od tego, czy tag powstal z klasyfikacji czy z innej reguly.",
},

},  # end "pl"

}



def get(key, level="tip", lang="en"):
    """Zwraca tekst pomocy. level: 'tip' (rada) | 'tech' (mechanika)."""
    item = all_for(lang).get(key)
    if not item:
        return ""
    return item.get(level, "")


def all_for(lang="en"):
    """English base plus locale values, merged per key and per hint level."""
    base = {key: dict(value) if isinstance(value, dict) else value
            for key, value in HELP["en"].items()}
    def merge(values):
        for key, value in (values or {}).items():
            if isinstance(value, dict) and isinstance(base.get(key), dict):
                base[key].update(value)
            else:
                base[key] = value
    if _PACK_VERSION:
        merge(_LP.section("en", _PACK_VERSION, "help"))
    merge(HELP.get(lang) or {})
    if _PACK_VERSION:
        merge(_LP.section(lang, _PACK_VERSION, "help"))
    return base
