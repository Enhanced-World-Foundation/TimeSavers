#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Headless A-Tool runner used by the single ecosystem Wake manager.

It deliberately has no dependency on panel.py for doing work.  panel.py is an
optional browser UI only: when the shared Wake preference requests it, an
already-open panel is reused or started after the run.
"""
from __future__ import annotations
import release_guard as _release_guard
_release_guard.enforce(__file__)

import argparse
import json
import os
import socket
import subprocess
import sys
import time
import urllib.request
import webbrowser

HERE = os.path.dirname(os.path.abspath(__file__))


def _status_path(agent, home):
    import hashlib
    tool_id=str(os.environ.get("ECO_TOOL_ID","") or "").strip()
    profile_id=str(os.environ.get("ECO_PROFILE_ID","") or agent).strip()
    if tool_id:
        token=hashlib.sha256(f"{tool_id}::{profile_id}".encode("utf-8","ignore")).hexdigest()[:24]
        return os.path.join(home,"data","run_status",token+".json")
    return os.path.join(home,"data",f"{agent}_run_status.json")

def _write_status(agent, home, state, **extra):
    try:
        os.makedirs(os.path.dirname(_status_path(agent,home)),exist_ok=True)
        path=_status_path(agent,home); tmp=f"{path}.{os.getpid()}.{time.time_ns()}.tmp"
        data={"agent":str(agent),"source":"wake","state":str(state),"updated_at":time.time(),
              "job_id":str(os.environ.get("ECO_WAKE_JOB_ID","") or ""),**extra}
        with open(tmp,"w",encoding="utf-8") as f: json.dump(data,f,ensure_ascii=False,indent=2)
        try:
            if os.name=="posix": os.chmod(tmp,0o600)
        except Exception: pass
        os.replace(tmp,path)
    except Exception:
        pass


def _read_json(path, default):
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return default


def _panel_port():
    meta = _read_json(os.path.join(HERE, "atool.json"), {})
    try:
        return int(meta.get("port") or 8800)
    except Exception:
        return 8800


def _panel_alive(port):
    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{port}/api/agents", timeout=1.2) as r:
            return 200 <= int(getattr(r, "status", 200)) < 500
    except Exception:
        try:
            with socket.create_connection(("127.0.0.1", port), timeout=0.5):
                return True
        except Exception:
            return False


def _open_optional_panel():
    # Central Wake r14+ owns generic post-run UI/notification actions after it
    # observes successful process completion. Keep this compatibility path for
    # a runner invoked outside the central manager.
    if str(os.environ.get("ECO_WAKE_CENTRAL_AFTER", "")).strip().lower() in ("1", "true", "yes", "on"):
        return
    try:
        import engine as E
        prefs = _read_json(os.path.join(E.HOME, "scheduler_prefs.json"), {})
    except Exception:
        prefs = {}
    mode = str(os.environ.get("ECO_WAKE_UI_AFTER", "inherit") or "inherit").lower()
    if mode == "never":
        return
    if mode != "open" and not prefs.get("wake_browser"):
        return
    port = _panel_port()
    if not _panel_alive(port):
        panel = os.path.join(HERE, "panel.py")
        if os.path.isfile(panel):
            try:
                subprocess.Popen([sys.executable, panel, "--no-open"], cwd=HERE,
                                 stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                                 stdin=subprocess.DEVNULL, shell=False)
                for _ in range(40):
                    if _panel_alive(port):
                        break
                    time.sleep(0.15)
            except Exception:
                return
    if _panel_alive(port):
        try:
            webbrowser.open(f"http://localhost:{port}")
        except Exception:
            pass


def run(agent, slot="", reason="wake", offline=False):
    import engine as E
    agent=str(agent)
    _write_status(agent,E.HOME,"running",pid=os.getpid(),slot=str(slot or ""),reason=str(reason or "wake"),started_at=time.time())
    E.log(agent,f"WAKE RUN START reason={reason or 'wake'} slot={slot or '-'} pid={os.getpid()}")
    _prof_dir = os.path.join(E.HOME, "profiles")
    try:
        _allowed = [x[:-5] for x in sorted(os.listdir(_prof_dir)) if x.endswith(".json")][:1]
    except Exception:
        _allowed = []
    if _allowed and agent not in _allowed:
        E.log(agent, "SKIP (Solo Free): only one configured Communication profile is available")
        _write_status(agent,E.HOME,"skipped",pid=os.getpid(),message="Solo Free one-profile limit",finished_at=time.time())
        return 4
    profile_path = os.path.join(E.HOME, "profiles", agent + ".json")
    if not os.path.isfile(profile_path):
        E.log(agent, f"WAKE runner: profile not found: {profile_path}")
        _write_status(agent,E.HOME,"error",pid=os.getpid(),error="profile not found",finished_at=time.time())
        return 2
    try:
        import secret_store as _ss
        prof = _ss.load_profile_file(profile_path)
    except Exception:
        prof = _read_json(profile_path, None)
    if not isinstance(prof, dict):
        E.log(agent, "WAKE runner: invalid profile JSON")
        _write_status(agent,E.HOME,"error",pid=os.getpid(),error="invalid profile JSON",finished_at=time.time())
        return 2

    tool_id = "this"
    claimed = False
    try:
        import atool_sync
        meta = _read_json(os.path.join(HERE, "atool.json"), {})
        tool_id = meta.get("id") or "this"
        if not atool_sync.claim_eco_slot(tool_id, "wake"):
            held = (atool_sync.eco_slot_status(tool_id) or {}).get("tool", "?")
            E.log(agent, f"SKIP (wake): ecosystem run slot held by '{held}'")
            _write_status(agent,E.HOME,"skipped",pid=os.getpid(),message=f"run slot held by {held}",finished_at=time.time())
            return 3
        claimed = True
    except Exception:
        pass

    try:
        E.OFFLINE = bool(offline)
        prof["_run_context"] = {"source": "wake", "slot": str(slot or ""), "reason": str(reason or "wake")}
        (E.run_collector if prof.get("kind") == "collector" else E.run_reporter)(prof)
        try:
            data_dir = os.path.join(E.HOME, "data")
            os.makedirs(data_dir, exist_ok=True)
            with open(os.path.join(data_dir, f"{agent}_lastrun.txt"), "w", encoding="utf-8") as f:
                f.write(str(time.time()))
        except Exception:
            pass
        report_path=os.path.join(E.HOME,"data",f"{agent}_report.json")
        E.log(agent,f"WAKE RUN DONE report={'updated' if os.path.exists(report_path) else 'no report file'}")
        _write_status(agent,E.HOME,"done",pid=os.getpid(),finished_at=time.time(),report_path=report_path if os.path.exists(report_path) else "",message="run completed")
        _open_optional_panel()
        return 0
    except Exception as exc:
        E.log(agent, f"WAKE runner error: {exc}")
        _write_status(agent,E.HOME,"error",pid=os.getpid(),finished_at=time.time(),error=str(exc))
        return 1
    finally:
        E.OFFLINE = False
        if claimed:
            try:
                import atool_sync
                atool_sync.release_eco_slot(tool_id)
            except Exception:
                pass


def main(argv=None):
    ap = argparse.ArgumentParser(description="Headless A-Tool Wake runner")
    ap.add_argument("--agent", required=True)
    ap.add_argument("--slot", default=os.environ.get("ECO_RUN_SLOT", ""))
    ap.add_argument("--reason", default=os.environ.get("ECO_WAKE_REASON", "wake"))
    ap.add_argument("--offline", action="store_true")
    ns = ap.parse_args(argv)
    return run(ns.agent, ns.slot, ns.reason, ns.offline)


if __name__ == "__main__":
    raise SystemExit(main())
