# ============================================================================
#  opportunities.py — GDZIE SIE ZGLOSIC I CO TAM WPISAC
# ============================================================================
#  PO CO: masz listę platform (gig, fora, granty, sklepy), ale pisanie profilu
#  pod każdą od zera zajmuje godziny. Ten moduł bierze TWÓJ profil
#  (USER_CONTEXT — jedno źródło prawdy) i generuje gotowy tekst pod każdą
#  platformę, dopasowany do tego, czego ona szuka.
#
#  CZEGO NIE ROBI — i dlaczego:
#  NIE zakłada kont automatycznie. Platformy typu DataAnnotation/Outlier mają
#  captcha, weryfikację tożsamości i testy kwalifikacyjne. Bot je obleje, a
#  konto dostanie bana zanim cokolwiek zarobisz. Rejestrację robisz sam —
#  ale masz gotowy tekst, kolejność i wiedzę, co podkreślić.
#
#  GENERYCZNE: platformy siedzą w platforms.json (dane, nie kod).
#  Dodajesz wiersz w JSON → pojawia się w narzędziu. Zero zmian tutaj.
# ============================================================================

import os, json, time

HERE = os.path.dirname(os.path.abspath(__file__))
SOURCE = os.path.join(HERE, "platforms.json")


def _home():
    import engine as E
    return E.HOME


def STATUS_PATH():
    return os.path.join(_home(), "opportunities_status.json")


def load_platforms():
    """Wczytuje plik zrodlowy. User moze go edytowac — to zwykly JSON."""
    try:
        return json.load(open(SOURCE, encoding="utf-8"))
    except Exception:
        return {}


def load_status():
    """Co juz zrobiles: not_started / applied / accepted / rejected / skipped."""
    try:
        p = STATUS_PATH()
        return json.load(open(p, encoding="utf-8")) if os.path.exists(p) else {}
    except Exception:
        return {}


def save_status(name, state, note=""):
    st = load_status()
    st[name] = {"state": state, "note": note[:300], "when": time.strftime("%Y-%m-%d")}
    try:
        json.dump(st, open(STATUS_PATH(), "w", encoding="utf-8"),
                  ensure_ascii=False, indent=1)
        return True
    except Exception:
        return False


SIGNUP_PATH = None      # ustawiane leniwie (potrzebuje engine.HOME)


def signup_path():
    return os.path.join(_home(), "signup_kit.json")


DEFAULT_SIGNUP = {
    "full_name": "",
    "email": "",
    "email_alias_pattern": "",   # np. "karol+{platform}@gmail.com" — alias per platforma
    "phone": "",
    "country": "",
    "city": "",
    "timezone": "",
    "languages": "",            # "Polish (native), English (fluent), German (B1)"
    "payout": "",               # PayPal / Wise / IBAN
    "linkedin": "",
    "github": "",
    "website": "",
    "headline": "",             # jedna linia o sobie — pole "title"/"headline"
    "skills": "",               # przecinkami
    "availability": "",         # "15-20 h/week, evenings CET"
}


def load_signup():
    try:
        p = signup_path()
        d = dict(DEFAULT_SIGNUP)
        if os.path.exists(p):
            d.update(json.load(open(p, encoding="utf-8")) or {})
        return d
    except Exception:
        return dict(DEFAULT_SIGNUP)


def save_signup(kit):
    try:
        os.makedirs(_home(), exist_ok=True)
        clean = {k: str(v)[:300] for k, v in (kit or {}).items() if k in DEFAULT_SIGNUP}
        json.dump(clean, open(signup_path(), "w", encoding="utf-8"),
                  ensure_ascii=False, indent=1)
        return True
    except Exception:
        return False


def signup_sheet(platform):
    """Gotowy zestaw pod KONKRETNA platforme — kopiujesz pole po polu.
    Signup nie da sie zbotowac (captcha, weryfikacja), ale 70% czasu to
    przepisywanie tych samych danych. To usuwamy."""
    k = load_signup()
    name = platform.get("name", "")
    slug = "".join(c for c in name.lower() if c.isalnum())[:14]
    # alias per platforma — widzisz kto sprzedal Twoj adres, mozesz filtrowac
    email = k["email"]
    if k.get("email_alias_pattern") and "{platform}" in k["email_alias_pattern"]:
        email = k["email_alias_pattern"].replace("{platform}", slug)
    elif "@" in email and "+" not in email.split("@")[0]:
        user, dom = email.split("@", 1)
        email = f"{user}+{slug}@{dom}"

    rows = [
        ("Email to use here", email,
         "An alias — mail still lands in your inbox, but you can see who sold your address."),
        ("Full name", k["full_name"], ""),
        ("Phone", k["phone"], ""),
        ("Country / City", f"{k['country']} / {k['city']}".strip(" /"), ""),
        ("Time zone", k["timezone"], ""),
        ("Languages", k["languages"], "Language pairs are the whole product on TELUS/Appen/Welocalize."),
        ("Payout", k["payout"], ""),
        ("Headline", k["headline"], "The one-line 'title' field."),
        ("Skills", k["skills"], ""),
        ("Availability", k["availability"], ""),
        ("LinkedIn", k["linkedin"], ""),
        ("GitHub", k["github"], ""),
        ("Website", k["website"], ""),
    ]
    return {"platform": name, "url": platform.get("url", ""),
            "needs": platform.get("needs", []),
            "rows": [{"label": a, "value": b, "hint": c} for a, b, c in rows if b or c]}


def _facts_from_profile():
    """Wyciaga z USER_CONTEXT to, co platformy pytaja: kim jestes, co umiesz,
    jakie jezyki, gdzie mieszkasz. Jedno zrodlo prawdy — nie przepisujesz."""
    import engine as E
    txt = E.load_user_context() or ""
    return txt.strip()


def draft_application(platform, llm=None, ask_llm=None, extra=""):
    """Pisze tekst zgloszenia pod KONKRETNA platforme.
    Bez AI: skleja szablon z twojego profilu (dziala od reki, za darmo).
    Z AI: pisze pelny, dopasowany tekst."""
    facts = _facts_from_profile()
    hint = platform.get("profile_hint", "")
    needs = ", ".join(platform.get("needs", []))
    name = platform.get("name", "")

    if not (llm and ask_llm and (llm.get("api_key") or llm.get("provider") == "ollama")):
        # BEZ AI — uczciwy szkielet, ktory sam dokonczysz
        return (f"# {name}\n"
                f"URL: {platform.get('url','')}\n"
                f"Pay: {platform.get('pay','?')}\n"
                f"They ask for: {needs or '—'}\n\n"
                f"## What to emphasise\n{hint or '—'}\n\n"
                f"## Your facts (from your profile)\n{facts[:800]}\n\n"
                f"## Notes\n{platform.get('notes','')}\n\n"
                f"(Turn AI on in Keys to have this written out as a finished application text.)")

    prompt = (
        f"Write a short, honest application/profile text for this platform.\n\n"
        f"PLATFORM: {name}\n"
        f"What they want: {needs}\n"
        f"What to emphasise: {hint}\n\n"
        f"ABOUT THE APPLICANT (their own words — use ONLY what is here, invent nothing):\n"
        f"{facts[:1800]}\n\n"
        f"{('EXTRA INSTRUCTION: ' + extra) if extra else ''}\n\n"
        f"Rules:\n"
        f"- 120-180 words. Plain, direct, no corporate filler, no 'passionate about'.\n"
        f"- Lead with the single most relevant thing for THIS platform.\n"
        f"- Never invent a degree, employer, certificate or year of experience.\n"
        f"- If they want languages, state them plainly.\n"
        f"- End with one concrete sentence about what they get from you.\n"
        f"Return the text only."
    )
    out = ask_llm(prompt, llm, max_tokens=420)
    if not out or out.startswith("[BLAD"):
        return draft_application(platform)          # fallback: szkielet
    return out.strip()


def signup_kit(profile_text="", email="", name="", location="", links=""):
    """PÓŁAUTOMATYCZNE ZAKŁADANIE KONT — bez bota, bez bana.

    Boty przegrywają z captchą i weryfikacją tożsamości. Ale 90% czasu przy
    rejestracji to PRZEPISYWANIE TYCH SAMYCH DANYCH. To można wyeliminować
    legalnie: menedżer haseł (Bitwarden — darmowy, open source) wypełnia
    formularze jednym kliknięciem.

    Ta funkcja generuje gotowy plik do zaimportowania. Potem:
      1. Otwierasz platformę
      2. Klikasz ikonę Bitwarden → pola wypełnione
      3. Ty rozwiązujesz captcha i klikasz "zarejestruj"

    ~30 sekund na platformę zamiast 5 minut. 26 platform = 15 min zamiast 2h.
    """
    plats = rank_for_me()
    lines = []
    lines.append("# SIGNUP KIT — semi-automatic account creation\n")
    lines.append("## How to use this (15 minutes for all platforms)\n")
    lines.append("1. Install Bitwarden (free, open source): https://bitwarden.com")
    lines.append("2. Bitwarden → Settings → Import data → choose 'Bitwarden (csv)'")
    lines.append("3. Paste the CSV below (the section marked CSV)")
    lines.append("4. Also add your Identity (Bitwarden → + → Identity) with the fields below")
    lines.append("5. For each platform: open it, click the Bitwarden icon in the field,")
    lines.append("   pick your identity — every field fills at once.")
    lines.append("6. You solve the captcha and press Register. That part stays human —")
    lines.append("   automating it gets you banned before you earn anything.\n")

    lines.append("## Your identity (put this in Bitwarden once)\n")
    lines.append(f"Full name     : {name or '(fill in)'}")
    lines.append(f"Email         : {email or '(fill in)'}")
    lines.append(f"Location      : {location or '(fill in)'}")
    lines.append(f"Links         : {links or '(fill in)'}")
    lines.append("Password      : let Bitwarden generate a unique one per site\n")

    lines.append("## Bio / 'About you' — paste per platform\n")
    lines.append("Most platforms ask for a short bio. Here it is, ready:\n")
    bio = (profile_text or "").strip()
    lines.append("```")
    lines.append(bio[:600] if bio else "(fill in your User profile first — 👤 My profile)")
    lines.append("```\n")

    lines.append("## Order of attack (highest pay, lowest barrier first)\n")
    for i, p in enumerate(plats[:14], 1):
        needs = ", ".join(p.get("needs", [])) or "—"
        lines.append(f"{i:>2}. {p['name']:<26} {p.get('pay',''):<14} → {p['url']}")
        lines.append(f"    asks for: {needs}")
        if p.get("profile_hint"):
            lines.append(f"    emphasise: {p['profile_hint'][:110]}")
        lines.append("")

    lines.append("## CSV for Bitwarden (paste into Import)\n")
    lines.append("```csv")
    lines.append("folder,favorite,type,name,notes,fields,login_uri,login_username,login_password,login_totp")
    for p in plats:
        note = (p.get("notes", "") or "").replace('"', "'")[:90]
        lines.append(f'A-Tools signup,,login,{p["name"]},"{note}",,{p["url"]},{email},,')
    lines.append("```\n")
    lines.append("Bitwarden will generate a strong unique password for each when you register.")
    return "\n".join(lines)


def rank_for_me(cat_key=None):
    """Kolejnosc zgloszen: najpierw najwyzej platne i najlatwiejsze.
    Prosty, przewidywalny scoring — bez AI."""
    data = load_platforms()
    st = load_status()
    rows = []
    for key, cat in data.items():
        if key.startswith("_"):
            continue
        if cat_key and key != cat_key:
            continue
        for it in cat.get("items", []):
            pay = it.get("pay", "")
            # wyciagnij gorna stawke, jesli jest
            import re
            nums = [int(n) for n in re.findall(r"\$(\d+)", pay)]
            top = max(nums) if nums else 0
            barrier = len(it.get("needs", []))
            score = top - barrier * 2
            rows.append({**it, "category": key, "cat_label": cat.get("label", key),
                         "score": score,
                         "status": (st.get(it["name"], {}) or {}).get("state", "not_started")})
    rows.sort(key=lambda r: -r["score"])
    return rows
