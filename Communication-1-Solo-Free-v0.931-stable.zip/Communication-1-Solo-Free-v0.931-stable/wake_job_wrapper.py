#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Persist an A-Tool child exit code for Wake job recovery.

The manager may restart or a one-shot scan may exit before the launched A-Tool.
This tiny wrapper makes completion observable on the next manager tick without
using a shell and without trusting stdout text.
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
import time


def _atomic_json(path, data):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp=f"{path}.{os.getpid()}.{time.time_ns()}.tmp"
    with open(tmp,"w",encoding="utf-8") as f:
        json.dump(data,f,ensure_ascii=False,indent=2)
        f.flush()
        try: os.fsync(f.fileno())
        except Exception: pass
    try:
        if os.name=="posix": os.chmod(tmp,0o600)
    except Exception: pass
    os.replace(tmp,path)


def main(argv=None):
    args=list(sys.argv[1:] if argv is None else argv)
    if len(args)<2:
        print("usage: wake_job_wrapper.py RESULT_PATH COMMAND [ARGS...]",file=sys.stderr)
        return 64
    result_path=args[0]; command=args[1:]; started=time.time()
    rc=127; error=""
    try:
        rc=int(subprocess.call(command,shell=False))
    except Exception as exc:
        error=f"{type(exc).__name__}: {exc}"
    finished=time.time()
    try:
        _atomic_json(result_path,{"returncode":rc,"error":error,"started_at":started,
                                  "finished_at":finished,"pid":os.getpid()})
    except Exception as exc:
        print(f"Wake result write failed: {exc}",file=sys.stderr)
    return rc


if __name__=="__main__":
    raise SystemExit(main())
