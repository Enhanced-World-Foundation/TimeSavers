#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Native control center for the single Time Savers Wake manager.

This UI is deliberately independent from every A-Tool's panel.py.  It edits the
shared Wake manager settings, central per-tool schedule overrides and displays
both shared calendars.  It never runs its own scheduler loop.
"""
from __future__ import annotations

import datetime
import json
import os
import subprocess
import sys
import webbrowser
try:
    from wake_i18n import t as T
except Exception:
    def T(_k, fallback=None, **kwargs):
        try: return str(fallback if fallback is not None else _k).format(**kwargs)
        except Exception: return str(fallback if fallback is not None else _k)


def _fmt_bool(v):
    return T("on","ON") if bool(v) else T("off","OFF")


def _read_json(path, default):
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return default


def _ui_lock_acquire(wake):
    path = os.path.join(wake.ECO_DIR, "wake_ui.lock")
    os.makedirs(wake.ECO_DIR, exist_ok=True)
    try:
        os.mkdir(path)
        try:
            if os.name == "posix": os.chmod(path, 0o700)
        except Exception: pass
        owner_path=os.path.join(path, "owner.json")
        with open(owner_path, "w", encoding="utf-8") as f:
            json.dump({"pid": os.getpid(), "started": datetime.datetime.now().isoformat()}, f)
        try:
            if os.name == "posix": os.chmod(owner_path, 0o600)
        except Exception: pass
        return path
    except FileExistsError:
        owner = _read_json(os.path.join(path, "owner.json"), {})
        if wake._pid_alive(owner.get("pid")):
            # Ask the existing Tk window to come to the foreground instead of
            # silently refusing a second click on "Wake settings / calendars".
            try:
                with open(os.path.join(path, "focus.request"), "w", encoding="utf-8") as f:
                    json.dump({"requested_at": datetime.datetime.now().isoformat()}, f)
            except Exception:
                pass
            return None
        try:
            import shutil
            shutil.rmtree(path)
            os.mkdir(path)
            with open(os.path.join(path, "owner.json"), "w", encoding="utf-8") as f:
                json.dump({"pid": os.getpid(), "started": datetime.datetime.now().isoformat()}, f)
            return path
        except Exception:
            return None
    except Exception:
        return None


def _ui_lock_release(path):
    if not path:
        return
    try:
        import shutil
        shutil.rmtree(path)
    except Exception:
        pass


def run_window(wake_module=None, ensure_manager=True):
    wake = wake_module
    if wake is None:
        import wake as wake

    if ensure_manager:
        wake.ensure_background_process(with_tray=True)

    try:
        import tkinter as tk
        from tkinter import ttk, messagebox, filedialog
    except Exception as e:
        wake._log(f"Wake UI requires Tk: {e}")
        return False

    lock_path = _ui_lock_acquire(wake)
    if lock_path is None:
        wake._log("Wake control center is already open")
        return False

    root = tk.Tk()
    root.title(T("window_title","Time Savers — Wake Control Center"))
    root.geometry("920x650")
    root.minsize(820, 560)

    style = ttk.Style(root)
    try:
        if "clam" in style.theme_names():
            style.theme_use("clam")
    except Exception:
        pass

    top = ttk.Frame(root, padding=(10, 8))
    top.pack(fill="x")
    ttk.Label(top, text="Time Savers Wake", font=("Segoe UI", 13, "bold")).pack(side="left")
    status_var = tk.StringVar(value=T("loading","Loading…"))
    ttk.Label(top, textvariable=status_var).pack(side="right")

    notebook = ttk.Notebook(root)
    notebook.pack(fill="both", expand=True, padx=10, pady=(0, 10))

    overview = ttk.Frame(notebook, padding=10)
    tools_tab = ttk.Frame(notebook, padding=10)
    cal_tab = ttk.Frame(notebook, padding=10)
    settings_tab = ttk.Frame(notebook, padding=10)
    log_tab = ttk.Frame(notebook, padding=10)
    notebook.add(overview, text=T("overview","Overview"))
    notebook.add(tools_tab, text=T("tools","A-Tools & schedules"))
    notebook.add(cal_tab, text=T("calendars","Calendars"))
    notebook.add(settings_tab, text=T("settings","Wake settings"))
    notebook.add(log_tab, text=T("log","Log"))

    # ---------------- overview ----------------
    ov_text = tk.Text(overview, height=19, wrap="word")
    ov_text.pack(fill="both", expand=True)
    ov_buttons = ttk.Frame(overview)
    ov_buttons.pack(fill="x", pady=(8, 0))

    # ---------------- tools ----------------
    tools_pane = ttk.Panedwindow(tools_tab, orient="horizontal")
    tools_pane.pack(fill="both", expand=True)
    tools_left = ttk.Frame(tools_pane)
    tools_right = ttk.Frame(tools_pane, padding=(12, 0, 0, 0))
    tools_pane.add(tools_left, weight=3)
    tools_pane.add(tools_right, weight=2)

    tool_tree = ttk.Treeview(tools_left, columns=("enabled", "runs", "source", "compat", "trust"), show="headings", height=16)
    tool_tree.heading("enabled", text=T("wake_column","Wake"))
    tool_tree.heading("runs", text=T("effective_schedule","Effective schedule"))
    tool_tree.heading("source", text=T("source","Source"))
    tool_tree.heading("compat", text=T("execution","Execution"))
    tool_tree.heading("trust", text=T("trust","Trust"))
    tool_tree.column("enabled", width=60, anchor="center")
    tool_tree.column("runs", width=240)
    tool_tree.column("source", width=90, anchor="center")
    tool_tree.column("compat", width=125, anchor="center")
    tool_tree.column("trust", width=80, anchor="center")
    tool_tree.pack(fill="both", expand=True)

    selected_tool = tk.StringVar(value="")
    tv_enabled = tk.BooleanVar(value=True)
    tv_runs = tk.StringVar(value="")
    tv_once_date = tk.StringVar(value="")
    tv_once_time = tk.StringVar(value="")
    tv_active_from = tk.StringVar(value="")
    tv_active_until = tk.StringVar(value="")
    tv_catchup = tk.BooleanVar(value=True)
    tv_net = tk.BooleanVar(value=False)
    tv_retry = tk.BooleanVar(value=False)
    tv_when_online = tk.BooleanVar(value=False)
    tv_cooldown = tk.StringVar(value="3600")
    tv_ui_after = tk.StringVar(value="inherit")
    tv_notify_after = tk.StringVar(value="inherit")
    tv_run_on_start = tk.BooleanVar(value=False)
    tv_run_on_start_min = tk.StringVar(value="5")
    tool_info = tk.StringVar(value=T("select_tool","Select an A-Tool / preset / task"))

    ttk.Label(tools_right, textvariable=tool_info, font=("Segoe UI", 10, "bold"), wraplength=320).pack(anchor="w", pady=(0, 8))
    ttk.Checkbutton(tools_right, text=T("may_run","Wake may run this A-Tool"), variable=tv_enabled).pack(anchor="w")
    ttk.Label(tools_right, text=T("daily_times","Daily times (HH:MM, comma-separated)")).pack(anchor="w", pady=(8, 2))
    ttk.Entry(tools_right, textvariable=tv_runs).pack(fill="x")
    row_once = ttk.Frame(tools_right); row_once.pack(fill="x", pady=(8, 0))
    ttk.Label(row_once, text=T("once_date","Run once date")).grid(row=0, column=0, sticky="w")
    ttk.Label(row_once, text=T("time","time")).grid(row=0, column=1, sticky="w", padx=(8,0))
    ttk.Entry(row_once, textvariable=tv_once_date, width=14).grid(row=1, column=0, sticky="w")
    ttk.Entry(row_once, textvariable=tv_once_time, width=8).grid(row=1, column=1, sticky="w", padx=(8,0))
    row_start = ttk.Frame(tools_right); row_start.pack(fill="x", pady=(8, 0))
    ttk.Checkbutton(row_start, text=T("run_on_start_edit","Run when Wake / system session starts"), variable=tv_run_on_start).pack(side="left")
    ttk.Label(row_start, text=T("guard_min","guard min")).pack(side="left", padx=(8,3))
    ttk.Entry(row_start, textvariable=tv_run_on_start_min, width=6).pack(side="left")
    row_active = ttk.Frame(tools_right); row_active.pack(fill="x", pady=(8, 0))
    ttk.Label(row_active, text=T("active_from","Active from")).grid(row=0, column=0, sticky="w")
    ttk.Label(row_active, text=T("until","until")).grid(row=0, column=1, sticky="w", padx=(8,0))
    ttk.Entry(row_active, textvariable=tv_active_from, width=14).grid(row=1, column=0, sticky="w")
    ttk.Entry(row_active, textvariable=tv_active_until, width=14).grid(row=1, column=1, sticky="w", padx=(8,0))
    ttk.Checkbutton(tools_right, text=T("catchup","Catch up missed scheduled / one-time runs"), variable=tv_catchup).pack(anchor="w", pady=(8,0))
    ttk.Checkbutton(tools_right, text=T("network_required","Network required"), variable=tv_net).pack(anchor="w")
    ttk.Checkbutton(tools_right, text=T("retry_network","Retry when network returns"), variable=tv_retry).pack(anchor="w")
    ttk.Checkbutton(tools_right, text=T("run_when_online","Run when network becomes available"), variable=tv_when_online).pack(anchor="w")
    cd = ttk.Frame(tools_right); cd.pack(fill="x", pady=(6,0))
    ttk.Label(cd, text=T("cooldown","Online cooldown (s)")).pack(side="left")
    ttk.Entry(cd, textvariable=tv_cooldown, width=10).pack(side="left", padx=(8,0))
    uim = ttk.Frame(tools_right); uim.pack(fill="x", pady=(6,0))
    ttk.Label(uim, text=T("ui_after","UI after background run")).pack(side="left")
    ttk.Combobox(uim, textvariable=tv_ui_after, values=("inherit","never","open"), state="readonly", width=10).pack(side="left", padx=(8,0))
    ttk.Label(tools_right, text=T("ui_after_help","inherit = shared Wake setting; never = headless only; open = reuse/start this A-Tool UI"), wraplength=320).pack(anchor="w")
    nim = ttk.Frame(tools_right); nim.pack(fill="x", pady=(6,0))
    ttk.Label(nim, text=T("notify_after","Notification after background run")).pack(side="left")
    ttk.Combobox(nim, textvariable=tv_notify_after, values=("inherit","never","notify"), state="readonly", width=10).pack(side="left", padx=(8,0))
    ttk.Label(tools_right, text=T("notify_after_help","inherit = shared Wake setting; never = no completion push; notify = desktop push after this entry finishes"), wraplength=320).pack(anchor="w")
    tool_status = tk.StringVar(value="")
    ttk.Label(tools_right, textvariable=tool_status, wraplength=320).pack(anchor="w", pady=(8, 0))
    ttk.Label(tools_right, text=T("published_effective","Published by A-Tool / effective in Wake"), font=("Segoe UI",9,"bold")).pack(anchor="w", pady=(8,2))
    tool_contract = tk.Text(tools_right, height=8, wrap="word")
    tool_contract.pack(fill="both", expand=True)
    tool_contract.config(state="disabled")

    # ---------------- calendars ----------------
    cal_note = ttk.Label(cal_tab, text=T("calendar_note","Main calendar = deadlines/notes from all A-Tools. Wake calendar = effective Wake schedules + popup."))
    cal_note.pack(anchor="w", pady=(0, 8))
    cal_nb = ttk.Notebook(cal_tab)
    cal_nb.pack(fill="both", expand=True)
    main_cal_frame = ttk.Frame(cal_nb, padding=6)
    wake_cal_frame = ttk.Frame(cal_nb, padding=6)
    cal_nb.add(main_cal_frame, text=T("main_calendar","Main calendar"))
    cal_nb.add(wake_cal_frame, text=T("wake_calendar","Wake calendar"))
    main_tree = ttk.Treeview(main_cal_frame, columns=("date","time","tool","title"), show="headings")
    for c,t,w in (("date",T("date","Date"),100),("time",T("time","Time"),70),("tool","A-Tool",140),("title",T("title","Title"),460)):
        main_tree.heading(c,text=t); main_tree.column(c,width=w)
    main_tree.pack(fill="both",expand=True)
    wake_tree = ttk.Treeview(wake_cal_frame, columns=("kind","when","tool","detail"), show="headings")
    for c,t,w in (("kind",T("type","Type"),90),("when",T("when","When"),160),("tool","A-Tool",160),("detail",T("details","Details"),350)):
        wake_tree.heading(c,text=t); wake_tree.column(c,width=w)
    wake_tree.pack(fill="both",expand=True)
    main_cal_buttons = ttk.Frame(main_cal_frame); main_cal_buttons.pack(fill="x", pady=(6,0))
    # callbacks are bound below after helper definitions

    # ---------------- settings ----------------
    cfg = wake._config(); prefs = wake._load_prefs(); pop = cfg.get("popup") or {}; net = cfg.get("network") or {}
    sv_interval = tk.StringVar(value=str(cfg.get("check_interval_s",30)))
    sv_window = tk.StringVar(value=str(cfg.get("schedule_window_min",5)))
    sv_parallel = tk.StringVar(value=str(cfg.get("max_parallel_jobs",4)))
    sv_browser = tk.BooleanVar(value=bool(prefs.get("wake_browser",False)))
    sv_notify = tk.BooleanVar(value=bool(prefs.get("notify_runs",True)))
    sv_retry = tk.BooleanVar(value=bool(net.get("retry_pending_when_online",True)))
    sv_autostart = tk.BooleanVar(value=bool(prefs.get("autostart",True)))
    sv_popup = tk.BooleanVar(value=bool(pop.get("enabled",True)))
    popup_info = tk.StringVar(value=T("loading","Loading…"))
    sett_status = tk.StringVar(value="")

    sf = ttk.LabelFrame(settings_tab, text=T("wake_manager","Wake manager"), padding=10); sf.pack(fill="x")
    def add_labeled(parent, label, var, row, width=12):
        ttk.Label(parent,text=label).grid(row=row,column=0,sticky="w",pady=3)
        ttk.Entry(parent,textvariable=var,width=width).grid(row=row,column=1,sticky="w",padx=(10,0),pady=3)
    add_labeled(sf,T("check_interval","Check interval (seconds)"),sv_interval,0)
    add_labeled(sf,T("due_window","Schedule due window (minutes)"),sv_window,1)
    add_labeled(sf,T("parallel_limit","Parallel independent A-Tools (1–32)"),sv_parallel,2)
    ttk.Checkbutton(sf,text=T("retry_pending","Retry pending network work when online"),variable=sv_retry).grid(row=3,column=0,columnspan=2,sticky="w",pady=3)
    ttk.Checkbutton(sf,text=T("open_ui_after","Open/raise A-Tool UI after a background run"),variable=sv_browser).grid(row=4,column=0,columnspan=2,sticky="w",pady=3)
    ttk.Checkbutton(sf,text=T("notify_runs","Desktop notification after a background run"),variable=sv_notify).grid(row=5,column=0,columnspan=2,sticky="w",pady=3)
    ttk.Checkbutton(sf,text=T("start_system","Start Wake with system"),variable=sv_autostart).grid(row=6,column=0,columnspan=2,sticky="w",pady=3)
    ttk.Label(sf,text=T("single_manager_help","Wake is the single always-on background manager. Closing this settings window does not stop it."), wraplength=650).grid(row=7,column=0,columnspan=2,sticky="w",pady=(6,0))

    pf = ttk.LabelFrame(settings_tab, text=T("shared_popup","Shared popup — winner controls timing"), padding=10); pf.pack(fill="x",pady=(10,0))
    ttk.Checkbutton(pf,text=T("enable_popup","Enable shared popup"),variable=sv_popup).grid(row=0,column=0,columnspan=2,sticky="w",pady=3)
    ttk.Label(pf,textvariable=popup_info,justify="left",wraplength=680).grid(row=1,column=0,columnspan=2,sticky="w",pady=(6,0))
    ttk.Label(pf,text=T("popup_help","Timing is read from the newest registered popup release. Wake only shows the next scheduled time; it does not overwrite that release policy."),wraplength=680).grid(row=2,column=0,columnspan=2,sticky="w",pady=(6,0))
    ttk.Label(settings_tab,textvariable=sett_status).pack(anchor="w",pady=(8,0))

    # ---------------- log ----------------
    log_controls = ttk.Frame(log_tab)
    log_controls.pack(fill="x", pady=(0, 6))
    log_view_mode = tk.StringVar(value="current")
    log_text = tk.Text(log_tab, wrap="none")
    log_text.pack(fill="both", expand=True)

    def current_tool_row():
        tid = selected_tool.get()
        return next((r for r in wake.list_tool_schedules() if str(r.get("id")) == tid), None)

    def _run_status_line(row):
        rs=(row or {}).get("run_status") or {}
        if not rs:
            return T("run_status_idle","Last Wake run: no run recorded yet.")
        state=str(rs.get("state") or "idle")
        when=rs.get("finished_at") or rs.get("started_at") or rs.get("queued_at") or rs.get("updated_at") or "—"
        msg=rs.get("error") or rs.get("message") or ""
        report=rs.get("report_path") or ""
        pid=rs.get("pid") or "—"
        extra=(f" · PID {pid}" if state in ("queued","starting","running") else "")
        if report: extra += f" · report={report}"
        if msg: extra += f" · {msg}"
        return T("run_status_line","Wake run: {state} · {when}{extra}",state=state,when=when,extra=extra)

    def refresh_tool_editor(*_):
        sel = tool_tree.selection()
        if not sel:
            return
        tid = sel[0]
        selected_tool.set(tid)
        row = current_tool_row()
        if not row:
            return
        eff = row.get("effective") or {}; ov = row.get("override") or {}; pub = row.get("published") or {}
        tv_enabled.set(bool(eff.get("_wake_enabled",True)))
        tv_runs.set(", ".join(eff.get("runs") or []))
        tv_once_date.set(str(eff.get("once_date") or "")); tv_once_time.set(str(eff.get("once_time") or ""))
        tv_active_from.set(str(eff.get("active_from") or "")); tv_active_until.set(str(eff.get("active_until") or ""))
        tv_catchup.set(bool(eff.get("catchup",True))); tv_net.set(bool(eff.get("network_required",False)))
        tv_retry.set(bool(eff.get("retry_when_online",False))); tv_when_online.set(bool(eff.get("when_online",False)))
        tv_cooldown.set(str(eff.get("online_cooldown_s") or 3600))
        tv_ui_after.set(str(eff.get("ui_after_run") or "inherit"))
        tv_notify_after.set(str(eff.get("notify_after_run") or "inherit"))
        tv_run_on_start.set(bool(eff.get("run_on_start",False)))
        tv_run_on_start_min.set(str(eff.get("run_on_start_min") if eff.get("run_on_start_min") is not None else 5))
        src = T("source_override","Wake override") if ov else T("source_published","A-Tool published")
        tool_info.set(f"{row.get('name')} ({tid})\n{src} · {T('execution_label','execution')}={row.get('compatibility') or T('unknown','unknown')} · {T('trust_label','trust')}={row.get('trust') or T('unknown','unknown')} · {T('path','path')}={row.get('path') or '-'}\n{_run_status_line(row)}")
        launch = pub.get("launch") or {}
        _core = {"runs","ai_mode","active_from","active_until","folder","install_path","main","main_sha256","published","profile_id","entry_id","entry_kind","display_name","launch","once_date","once_time","catchup","run_on_start","run_on_start_min","scheduled","background","network_required","retry_when_online","when_online","online_cooldown_s","ui_after_run","notify_after_run"}
        _extras = {k:v for k,v in pub.items() if k not in _core and not str(k).startswith("_")}
        lines = [
            T("atool_published","A-Tool published:"),
            f"  entry={row.get('entry_id') or '—'} · kind={row.get('entry_kind') or 'task'} · name={row.get('entry_label') or row.get('name') or '—'}",
            f"  {T('run_on_start','run_on_start')}={bool(pub.get('run_on_start'))} · {T('guard','guard')}={pub.get('run_on_start_min',5)} min",
            f"  Wake runs={', '.join(pub.get('runs') or []) or '—'} · once={pub.get('once_date') or '—'} {pub.get('once_time') or ''} · active={pub.get('active_from') or '—'} → {pub.get('active_until') or '—'}",
            f"  catchup={bool(pub.get('catchup',True))} · network={bool(pub.get('network_required'))} · retry-online={bool(pub.get('retry_when_online'))} · when-online={bool(pub.get('when_online'))}",
            f"  runner={launch.get('entry') or launch.get('entrypoints') or pub.get('main') or '—'} · compatibility={row.get('compatibility') or 'unknown'}",
        ]
        if _extras:
            lines.append("  metadata=" + json.dumps(_extras, ensure_ascii=False, sort_keys=True)[:900])
        lines += [
            T("effective_in_wake","Effective in Wake:"),
            f"  enabled={eff.get('_wake_enabled',True)} · runs={', '.join(eff.get('runs') or []) or '—'} · source={'override' if ov else 'published'}",
            f"  run-on-start={bool(eff.get('run_on_start'))} · guard={eff.get('run_on_start_min',5)} min · catchup={bool(eff.get('catchup',True))} · network={bool(eff.get('network_required'))} · retry={bool(eff.get('retry_when_online'))}",
            T("run_status_heading","Run status:"),
            f"  {_run_status_line(row)}",
        ]
        tool_contract.config(state="normal"); tool_contract.delete("1.0","end"); tool_contract.insert("1.0","\n".join(lines)); tool_contract.config(state="disabled")
        tool_status.set("")

    tool_tree.bind("<<TreeviewSelect>>", refresh_tool_editor)

    def save_tool():
        tid = selected_tool.get()
        if not tid:
            messagebox.showinfo("Wake", T("select_first","Select an A-Tool first.")); return
        try:
            wake.update_tool_schedule(tid, {
                "enabled":tv_enabled.get(), "runs":tv_runs.get(),
                "once_date":tv_once_date.get(), "once_time":tv_once_time.get(),
                "active_from":tv_active_from.get(), "active_until":tv_active_until.get(),
                "catchup":tv_catchup.get(), "network_required":tv_net.get(),
                "retry_when_online":tv_retry.get(), "when_online":tv_when_online.get(),
                "online_cooldown_s":tv_cooldown.get(), "ui_after_run":tv_ui_after.get(),
                "notify_after_run":tv_notify_after.get(),
                "run_on_start":tv_run_on_start.get(), "run_on_start_min":tv_run_on_start_min.get(),
            })
            tool_status.set(T("saved_override","Saved as central Wake override."))
            refresh_all(keep_tool=tid)
        except Exception as e:
            messagebox.showerror(T("schedule_title","Wake schedule"), str(e))

    def reset_tool():
        tid = selected_tool.get()
        if not tid: return
        if not messagebox.askyesno(T("schedule_title","Wake schedule"), T("reset_confirm","Return this A-Tool to the schedule it publishes itself?")):
            return
        try:
            wake.update_tool_schedule(tid,{"reset":True})
            refresh_all(keep_tool=tid)
        except Exception as e:
            messagebox.showerror(T("schedule_title","Wake schedule"),str(e))

    def run_selected():
        tid=selected_tool.get()
        if not tid: return
        ok=wake.run_tool_now(tid)
        tool_status.set(T("run_queued","Headless run queued in the single Wake manager. Status will update here automatically.") if ok else T("run_failed","Could not queue run; see Wake log."))
        if ok:
            refresh_all(keep_tool=tid)
            root.after(700, lambda: refresh_all(keep_tool=tid) if root.winfo_exists() else None)
            root.after(1800, lambda: refresh_all(keep_tool=tid) if root.winfo_exists() else None)

    def open_selected_ui():
        tid=selected_tool.get()
        if not tid: return
        ok,msg=wake.open_tool_ui(tid, start_if_needed=True)
        tool_status.set((T("opened_ui","Opened/reused A-Tool UI: ") if ok else T("open_failed","Could not open A-Tool UI: "))+str(msg))

    trb=ttk.Frame(tools_right); trb.pack(fill="x",pady=(10,0))
    ttk.Button(trb,text=T("save_override","Save Wake override"),command=save_tool).pack(side="left")
    ttk.Button(trb,text=T("use_published","Use A-Tool published schedule"),command=reset_tool).pack(side="left",padx=(6,0))
    ttk.Button(trb,text=T("queue_run","Queue headless run"),command=run_selected).pack(side="left",padx=(6,0))
    ttk.Button(trb,text=T("open_reuse","Open / reuse A-Tool UI"),command=open_selected_ui).pack(side="left",padx=(6,0))

    def save_settings():
        try:
            wake.update_settings({
                "check_interval_s":sv_interval.get(), "schedule_window_min":sv_window.get(),
                "max_parallel_jobs":sv_parallel.get(),
                "retry_pending_when_online":sv_retry.get(), "wake_browser":sv_browser.get(),
                "notify_runs":sv_notify.get(), "popup_enabled":sv_popup.get(),
            })
            p=wake._load_prefs(); p["autostart"]=sv_autostart.get(); wake._save_prefs(p)
            ok,where=wake.install_autostart(enable=sv_autostart.get())
            sett_status.set(T("saved","Saved.") if ok else T("autostart_error","Saved settings, autostart error: {error}",error=where))
            refresh_all()
        except Exception as e:
            messagebox.showerror(T("wake_settings_title","Wake settings"),str(e))

    sb=ttk.Frame(settings_tab); sb.pack(fill="x",pady=(10,0))
    ttk.Button(sb,text=T("save_settings","Save Wake settings"),command=save_settings).pack(side="left")
    ttk.Label(sb,text=T("single_process_note","Scheduling/execution stays in the one background Wake process.")).pack(side="left",padx=(10,0))

    def selected_main_index():
        sel=main_tree.selection()
        if not sel: return None
        try: return int(str(sel[0]).lstrip("m"))
        except Exception: return None

    def edit_calendar_item(index=None):
        rows=wake.calendar_items()
        existing=rows[index] if index is not None and 0 <= index < len(rows) else {}
        win=tk.Toplevel(root); win.title(T("calendar_item","Calendar item")); win.transient(root); win.grab_set(); win.resizable(False,False)
        frame=ttk.Frame(win,padding=12); frame.pack(fill="both",expand=True)
        v_agent=tk.StringVar(value=str(existing.get("agent") or "Wake")); v_kind=tk.StringVar(value=str(existing.get("kind") or "event"))
        v_title=tk.StringVar(value=str(existing.get("title") or "")); v_when=tk.StringVar(value=str(existing.get("when") or "")); v_time=tk.StringVar(value=str(existing.get("time") or ""))
        fields=((T("agent_source","A-Tool / source"),v_agent),(T("title","Title"),v_title),(T("date_format","Date (YYYY-MM-DD or DD.MM.YYYY)"),v_when),(T("time_hhmm","Time HH:MM"),v_time))
        row=0
        ttk.Label(frame,text=T("kind","Kind")).grid(row=row,column=0,sticky="w",pady=3); ttk.Combobox(frame,textvariable=v_kind,values=("deadline","event","task","note"),state="readonly",width=18).grid(row=row,column=1,sticky="ew",pady=3); row+=1
        for label,var in fields:
            ttk.Label(frame,text=label).grid(row=row,column=0,sticky="w",pady=3); ttk.Entry(frame,textvariable=var,width=44).grid(row=row,column=1,sticky="ew",pady=3); row+=1
        ttk.Label(frame,text=T("note","Note")).grid(row=row,column=0,sticky="nw",pady=3); note=tk.Text(frame,width=44,height=5,wrap="word"); note.grid(row=row,column=1,sticky="ew",pady=3); note.insert("1.0",str(existing.get("note") or "")); row+=1
        status=tk.StringVar(value=""); ttk.Label(frame,textvariable=status).grid(row=row,column=0,columnspan=2,sticky="w",pady=(4,0)); row+=1
        def save():
            try:
                wake.calendar_upsert(index,{"agent":v_agent.get(),"kind":v_kind.get(),"title":v_title.get(),"when":v_when.get(),"time":v_time.get(),"note":note.get("1.0","end").strip(),"lead_days":existing.get("lead_days",[1]),"remind_2h":existing.get("remind_2h",True),"added":existing.get("added")})
                win.destroy(); refresh_all()
            except Exception as e: status.set(str(e))
        bf=ttk.Frame(frame); bf.grid(row=row,column=0,columnspan=2,sticky="e",pady=(8,0)); ttk.Button(bf,text=T("cancel","Cancel"),command=win.destroy).pack(side="right"); ttk.Button(bf,text=T("save","Save"),command=save).pack(side="right",padx=(0,6))
        frame.columnconfigure(1,weight=1); win.wait_window()

    def delete_calendar_item():
        idx=selected_main_index()
        if idx is None: return
        if messagebox.askyesno(T("calendar","Calendar"),T("delete_calendar","Delete the selected calendar item?")):
            wake.calendar_delete(idx); refresh_all()

    def edit_selected_calendar_item():
        idx=selected_main_index()
        if idx is None:
            messagebox.showinfo(T("calendar","Calendar"),T("select_calendar","Select an item to edit first."))
            return
        edit_calendar_item(idx)

    ttk.Button(main_cal_buttons,text=T("add_event","Add event / deadline"),command=lambda:edit_calendar_item(None)).pack(side="left")
    ttk.Button(main_cal_buttons,text=T("edit_selected","Edit selected"),command=edit_selected_calendar_item).pack(side="left",padx=(6,0))
    ttk.Button(main_cal_buttons,text=T("delete_selected","Delete selected"),command=delete_calendar_item).pack(side="left",padx=(6,0))

    def export_main():
        # Keep this independent of hq/panel: create a simple standards-compliant ICS directly.
        dest=filedialog.asksaveasfilename(title=T("export_main_title","Export main calendar"),defaultextension=".ics",initialfile="timesavers-main.ics")
        if not dest: return
        cal=_read_json(wake.CALENDAR,[])
        lines=["BEGIN:VCALENDAR","VERSION:2.0","PRODID:-//Time Savers//Main Calendar//EN"]
        for i,c in enumerate(cal if isinstance(cal,list) else []):
            when=str(c.get("when") or "").strip(); tm=str(c.get("time") or "09:00").strip()
            dt=""
            for fmt in ("%Y-%m-%d","%d.%m.%Y","%d.%m.%y"):
                try:
                    d=datetime.datetime.strptime(when,fmt).date(); hh,mm=map(int,tm.split(":")[:2]); dt=datetime.datetime.combine(d,datetime.time(hh,mm)).strftime("%Y%m%dT%H%M%S"); break
                except Exception: pass
            if not dt: continue
            title=str(c.get("title") or T("calendar_item_default","Calendar item")).replace("\\","\\\\").replace(",","\\,").replace(";","\\;")
            lines += ["BEGIN:VEVENT",f"UID:main-{i}-{dt}@timesavers",f"DTSTART:{dt}",f"SUMMARY:{title}","END:VEVENT"]
        lines.append("END:VCALENDAR")
        with open(dest,"w",encoding="utf-8",newline="") as f: f.write("\r\n".join(lines)+"\r\n")

    def export_wake():
        dest=filedialog.asksaveasfilename(title=T("export_wake_title","Export Wake calendar"),defaultextension=".ics",initialfile="timesavers-wake.ics")
        if not dest: return
        wake.export_wake_ics(dest)

    cb=ttk.Frame(cal_tab); cb.pack(fill="x",pady=(8,0))
    ttk.Button(cb,text=T("export_main","Export main .ics"),command=export_main).pack(side="left")
    ttk.Button(cb,text=T("export_wake","Export Wake .ics"),command=export_wake).pack(side="left",padx=(6,0))

    def open_log_file():
        if os.path.exists(wake.LOG):
            try: webbrowser.open("file://"+wake.LOG)
            except Exception: pass

    ttk.Button(ov_buttons,text=T("refresh","Refresh"),command=lambda:refresh_all()).pack(side="left")
    ttk.Button(ov_buttons,text=T("open_log","Open log file"),command=open_log_file).pack(side="left",padx=(6,0))

    def refresh_all(keep_tool=None):
        st=wake.status(); running=st.get("running")
        status_var.set(f"{T('running','RUNNING') if running else T('stopped','STOPPED')} · PID {st.get('pid') or '-'} · {st.get('mode') or '-'} · {st.get('tray_backend') or '-'}")
        np=st.get("next_popup") or {}; cal=st.get("calendar") or {}; au=st.get("autostart") or {}; ps=st.get("popup") or {}
        rows=wake.list_tool_schedules()
        pol=ps.get("policy") or {}
        if ps.get("registered"):
            popup_info.set(
                f"{T('winner','Winner')}: {ps.get('tool')} · popup v{ps.get('version')} · {T('published','published')} {ps.get('published') or '—'}\n"
                f"{T('next','Next')}: {ps.get('next_at') or T('not_scheduled','not scheduled')} · {T('shown_times','shown {count} time(s)',count=ps.get('shown_count',0))}\n"
                + T("policy_line","Policy: first {first} min · next random {minh} h – {maxh} h · visible {visible} s", first=int(pol.get('initial_delay_s',0)//60), minh=pol.get('min_delay_s',0)//3600, maxh=pol.get('max_delay_s',0)//3600, visible=pol.get('visible_s','—')))
        else:
            popup_info.set(T("no_popup","No valid popup release is registered."))
        _next_cal = cal.get("next") or {}
        text=[
            f"{T('wake_manager_status','Wake manager')}: {T('running','RUNNING') if running else T('stopped','STOPPED')} · PID {st.get('pid') or '-'} · {T('mode','mode')}={st.get('mode') or '-'}",
            f"{T('tray_backend','Tray backend')}: {st.get('tray_backend') or '-'}",
            f"{T('autostart','Autostart')}: {_fmt_bool(au.get('enabled'))} · {T('installed','installed')}={_fmt_bool(au.get('installed'))}",
            f"{T('registered_tools','Registered A-Tools')}: {len(rows)}",
            T('popup_status_line','Shared popup: winner={winner} v{version} · next {next}', winner=ps.get('tool') or '—', version=ps.get('version') or '—', next=ps.get('next_at') or np.get('at') or T('not_scheduled','not scheduled')),
            T('calendar_status_line','Main calendar: {count} upcoming', count=cal.get('upcoming',0)) + ((" · "+T('next_item','next {at} — {title}',at=_next_cal.get('at'),title=_next_cal.get('title'))) if _next_cal else ""),
            "",
            T("wake_only","Wake is the only background scheduler. This window is only a control UI; it does not start a second scheduler."),
            T("publish_help","A-Tools publish schedules into the shared ecosystem; Wake overrides below are central and survive without any panel.py."),
        ]
        ov_text.config(state="normal"); ov_text.delete("1.0","end"); ov_text.insert("1.0","\n".join(text)); ov_text.config(state="disabled")

        tool_tree.delete(*tool_tree.get_children())
        for r in rows:
            eff=r.get("effective") or {}; ov=r.get("override") or {}
            sched=", ".join(eff.get("runs") or []) or "—"
            if eff.get("once_date"): sched += f" · {T('once','once')} {eff.get('once_date')} {eff.get('once_time') or ''}"
            tool_tree.insert("", "end", iid=str(r.get("id")), values=(T("on","ON") if eff.get("_wake_enabled",True) else T("off","OFF"),sched,T("override","override") if ov else T("published","published"),r.get("compatibility") or "—",r.get("trust") or "—"))
        target=keep_tool or selected_tool.get()
        if target and tool_tree.exists(target):
            tool_tree.selection_set(target); tool_tree.focus(target); refresh_tool_editor()

        main_tree.delete(*main_tree.get_children())
        calrows=_read_json(wake.CALENDAR,[])
        for i,c in enumerate(calrows if isinstance(calrows,list) else []):
            main_tree.insert("","end",iid=f"m{i}",values=(c.get("when") or "",c.get("time") or "",c.get("agent") or "",c.get("title") or ""))
        wake_tree.delete(*wake_tree.get_children())
        for r in rows:
            eff=r.get("effective") or {}
            if eff.get("_wake_enabled") is False: continue
            for hhmm in eff.get("runs") or []:
                wake_tree.insert("","end",values=(T("daily","daily"),hhmm,r.get("name") or r.get("id"),T("central_override","central override") if r.get("override") else T("atool_published_source","A-Tool published")))
            if eff.get("once_date"):
                wake_tree.insert("","end",values=(T("once","once"),f"{eff.get('once_date')} {eff.get('once_time') or ''}",r.get("name") or r.get("id"),T("one_time_run","one-time Wake run")))
        if np.get("at"):
            wake_tree.insert("","end",values=(T("popup","popup"),np.get("at"),"Wake",T("shared_popup_short","shared popup")))
        try:
            log_path = wake.SESSION_LOG if log_view_mode.get() == "current" else wake.LOG
            limit = 120000 if log_view_mode.get() == "current" else 50000
            content=open(log_path,encoding="utf-8",errors="replace").read()[-limit:] if os.path.exists(log_path) else T("no_log","No Wake log yet.")
        except Exception as e: content=str(e)
        log_text.delete("1.0","end"); log_text.insert("1.0",content); log_text.see("end")

    ttk.Radiobutton(log_controls, text=T("current_session","Current session"), variable=log_view_mode,
                    value="current", command=lambda: refresh_all()).pack(side="left")
    ttk.Radiobutton(log_controls, text=T("history","History"), variable=log_view_mode,
                    value="history", command=lambda: refresh_all()).pack(side="left", padx=(10,0))
    ttk.Label(log_controls, text=T("history_hint","History is rotated; current session resets on every Wake start.")).pack(side="left", padx=(14,0))

    def _poll_run_status():
        try:
            if not root.winfo_exists(): return
            focus_req = os.path.join(lock_path, "focus.request")
            if os.path.exists(focus_req):
                try: os.remove(focus_req)
                except Exception: pass
                try:
                    root.deiconify(); root.lift(); root.focus_force()
                    root.attributes("-topmost", True)
                    root.after(180, lambda: root.attributes("-topmost", False))
                except Exception:
                    pass
            tid=selected_tool.get()
            if tid and tool_tree.exists(tid):
                refresh_tool_editor()
        except Exception:
            pass
        try:
            if root.winfo_exists(): root.after(1200,_poll_run_status)
        except Exception:
            pass

    def close():
        _ui_lock_release(lock_path)
        root.destroy()
    root.protocol("WM_DELETE_WINDOW",close)
    refresh_all()
    root.after(1200,_poll_run_status)
    root.mainloop()
    return True


def main():
    import wake
    run_window(wake_module=wake, ensure_manager=True)


if __name__ == "__main__":
    main()
