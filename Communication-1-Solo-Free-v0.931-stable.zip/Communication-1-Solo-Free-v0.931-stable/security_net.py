#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Outbound URL safety helpers for user/import-controlled network sources."""
from __future__ import annotations

import ipaddress
import os
import socket
import urllib.parse
import urllib.request

_BLOCKED_HOSTS = {"localhost", "localhost.localdomain", "metadata.google.internal"}
_BLOCKED_METADATA = {
    ipaddress.ip_address("169.254.169.254"),  # AWS/Azure/GCP style metadata endpoint
    ipaddress.ip_address("100.100.100.200"), # Alibaba metadata
}


def _allow_private_env() -> bool:
    return str(os.environ.get("L4M_ALLOW_PRIVATE_SOURCES", "")).strip().lower() in ("1", "true", "yes", "on")


def validate_http_url(url: str, *, allow_private: bool = False, resolve: bool = True) -> str:
    """Return normalized http(s) URL or raise ValueError.

    By default rejects credentials in URL and local/private/link-local/metadata targets.
    Explicit local integrations can opt in with allow_private=True or the environment
    switch L4M_ALLOW_PRIVATE_SOURCES=1.  This guard is for user/import-controlled URLs;
    controlled runtime endpoints such as local Ollama are not routed through it.
    """
    raw = str(url or "").strip()
    try:
        p = urllib.parse.urlsplit(raw)
    except Exception:
        raise ValueError("invalid URL")
    if p.scheme.lower() not in ("http", "https"):
        raise ValueError("only http/https URLs are allowed")
    if not p.hostname:
        raise ValueError("URL has no host")
    if p.username is not None or p.password is not None:
        raise ValueError("credentials in URLs are not allowed")
    host = p.hostname.rstrip(".").lower()
    if host in _BLOCKED_HOSTS or host.endswith(".localhost"):
        if not (allow_private or _allow_private_env()):
            raise ValueError("local/private network URL blocked")
    allow_private = bool(allow_private or _allow_private_env())
    if resolve:
        try:
            infos = socket.getaddrinfo(host, p.port or (443 if p.scheme.lower() == "https" else 80), type=socket.SOCK_STREAM)
        except socket.gaierror as ex:
            raise ValueError(f"cannot resolve URL host: {ex}")
        seen = set()
        for info in infos:
            addr = info[4][0].split("%", 1)[0]
            if addr in seen:
                continue
            seen.add(addr)
            try:
                ip = ipaddress.ip_address(addr)
            except ValueError:
                continue
            blocked = (
                ip in _BLOCKED_METADATA or ip.is_loopback or ip.is_link_local or
                ip.is_multicast or ip.is_unspecified or ip.is_reserved or ip.is_private
            )
            if blocked and not allow_private:
                raise ValueError("local/private network URL blocked")
    # Drop fragment because it is client-side only and should never affect the request.
    return urllib.parse.urlunsplit((p.scheme.lower(), p.netloc, p.path or "/", p.query, ""))


class SafeRedirectHandler(urllib.request.HTTPRedirectHandler):
    """Re-check every redirect target using the same SSRF policy."""
    def __init__(self, allow_private: bool = False):
        super().__init__()
        self.allow_private = bool(allow_private)

    def redirect_request(self, req, fp, code, msg, headers, newurl):
        safe = validate_http_url(newurl, allow_private=self.allow_private, resolve=True)
        return super().redirect_request(req, fp, code, msg, headers, safe)


def open_public_url(url: str, *, timeout: float = 20, max_bytes: int = 5_000_000,
                    headers=None, allow_private: bool = False):
    """Open a validated user-controlled URL with validated redirects and byte cap.

    Returns (bytes, final_url, headers). Caller handles decoding/parsing.
    """
    safe = validate_http_url(url, allow_private=allow_private, resolve=True)
    opener = urllib.request.build_opener(SafeRedirectHandler(allow_private=allow_private))
    req = urllib.request.Request(safe, headers=dict(headers or {}))
    with opener.open(req, timeout=timeout) as r:
        final = validate_http_url(r.geturl(), allow_private=allow_private, resolve=True)
        data = r.read(int(max_bytes) + 1)
        if len(data) > int(max_bytes):
            raise ValueError("response too large")
        return data, final, r.headers
