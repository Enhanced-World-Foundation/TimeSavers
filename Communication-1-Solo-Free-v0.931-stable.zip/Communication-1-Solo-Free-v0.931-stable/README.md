# Communication A-Tool 0.931b Beta

Local-first email + RSS triage, prioritisation, summaries, drafts, rules and background scheduling.

**Languages:** English UI/documentation + Polish UI/documentation.  
**AI:** optional. The deterministic script works without an AI key.  
**Background:** Wake can run saved presets on schedule even when Chrome is closed.

Polish guide: [README-PL.md](README-PL.md)  
License: [LICENCE_AGREEMENT.txt](LICENCE_AGREEMENT.txt)

---

## 1. What it does

Communication A-Tool reads the mailboxes and RSS/Atom feeds you configure and creates one report that helps answer:

- what needs attention now;
- what can wait;
- what is noise/promo/social;
- what tags and deadlines were detected;
- why a priority/tag was chosen;
- whether you want a detailed summary, draft reply, reminder or rule correction.

The core classification/rule path works without AI. Optional AI can add summaries, drafts, fact extraction, priority/tag review and multilingual rule assistance.

A saved configuration is a **preset/profile** inside the Communication A-Tool. The complete distributable ZIP/application is the **A-Tool**.

---

# 2. Quick start

## Step 1 — start the panel

From the product directory:

```bash
python3 panel.py
```

Developer/diagnostic UI:

```bash
python3 panel.py --d
```
<!-- FIRST_AGENTSYSTEM_RUN_NOTE -->
**First launch with no existing `~/agentsystem`:** ordinary `python3 panel.py` automatically reveals the setup/diagnostic controls available in `--d`, so the complete setup is discoverable without knowing the flag. Later ordinary launches return to the normal UI; `--d` remains available explicitly.


The browser panel normally opens on `http://127.0.0.1:8800`.

## Step 2 — create a preset/profile

1. Choose **Templates → inbox_reporter**.
2. Give the configuration a name, for example `Personal mail` or `Company`.
3. Click **Save**.

Edition preset/profile policy:
- **Solo Free** — hard maximum of 1 configured preset/profile.
- **Solo** — the normal UI creates up to 2 configured presets/profiles; manually copied additional profile files may still be discovered/run. This is a product/UI limit, not a security boundary.
- **Template Generator / Developer** — no Solo preset-count cap.

Communication executes **one preset/run at a time**; another run must wait rather than execute concurrently.

## Step 3 — add an email account

Open **Keys & IMAP** and add a mailbox.

Typical Gmail setup:

- host: `imap.gmail.com`
- login: your Gmail address
- password: a Google **App Password**, not your normal Google password

Use **Test** before saving.

## Step 4 — optional AI

You can start with AI disabled.

If you want AI summaries/drafts/review:

1. choose a provider/model;
2. enter the API key, or select a supported local endpoint such as Ollama;
3. use the connection test;
4. choose the AI level in **Outputs**.

Cloud providers receive only the content required for the AI operation you enabled. Local Ollama keeps inference on your machine.

## Step 5 — personalise what matters

Open **Personalization** and set, only where useful:

- goal;
- report tone;
- focus/context;
- exclusions;
- explicit watchlist / never-miss terms;
- language override.

For deeper context use **My profile / USER_CONTEXT**; see section 8.

## Step 6 — run

Click **Run**.

The report shows priorities, sender/source, message meaning, tags, available actions and optional explanations.

## Step 7 — background schedule

Open **Schedule** and configure the times, optional catch-up and run-on-start behaviour. Saving the preset publishes the schedule to the central Wake manager.

Closing Chrome does not stop Wake.

---

# 3. Main UI — what each area is for

## Templates / saved presets

**Templates** are starting patterns such as `inbox_reporter`. A template becomes a saved preset/profile after you configure it, add a name and save.

Saved presets keep their own mailbox/source/output/schedule configuration.

## Personalization

Use this tab for meaning and user intent, not technical engine limits.

- **Goal** — overall job of this preset.
- **Report tone** — writing style only; it should not directly change classification.
- **Focus** — context used mainly by AI; it is not a deterministic priority rule.
- **Exclusions** — terms filtered before AI/reporting when they match the configured exclusion logic.
- **Watchlist** — explicit deterministic never-miss terms. The priority applied to a watchlist hit is configured in Engine behaviour.
- **Language override** — optional language for this preset.

## Keys & IMAP

Contains AI provider settings, API keys and mailbox credentials.

Passwords/API keys are not meant to be stored directly in the normal profile JSON. See Privacy & Security below.

## Sources

Configures RSS/Atom sources. A feed may have its own priority, schedule, readable name, category, item limit, fixed tags and include/exclude filters.

A manual Run reads all enabled sources. Wake scheduled runs can read only sources due for that slot.

## Schedule

Configures execution timing published to Wake:

- recurring time slots;
- one-off run;
- catch-up after a missed slot;
- run on start;
- run-on-start guard interval;
- network/retry behaviour where supported.

## Outputs

Controls the report/AI layer, including AI level, summary behaviour, priority model, tag review, message scan scope, folders and delivery/output settings.

## About & Help / Advanced

Contains help, diagnostics and management functions such as USER_CONTEXT, Rules, Tags, Engine behaviour, Calendar, Wake, backups/exports, settings snapshot and test tools.

---

# 4. Priorities

Priorities run from highest to lowest:

- **P1!** — critical, verified high-severity/direct case;
- **P1** — urgent/direct action;
- **P2** — important, needs attention;
- **P3** — normal relevant message;
- **P4** — low importance;
- **P5** — routine/noise/promo-type content.

The deterministic classifier creates the baseline. Depending on the selected priority model, AI may review the result or extract structured facts used by deterministic Model 4 rules.

A failed/unusable Model 4 response falls back to the Classic deterministic result instead of inventing a priority. Concrete Model 4 lifecycle claims such as paid/payment due/invoice/statement/order/shipment/application status are accepted only when independently supported by the message text; unsupported lifecycle states are discarded before Model 4 priority/tag rules run. Model 4 also may not downgrade a direct/personal Classic P3 message to P4/P5 unless the message itself contains verified low-value/promotional evidence. Ordinary newsletters default to P4; stronger lifecycle/action/user-rule evidence can still raise them, while confirmed promotions remain P5.

Automated recruiting/application-status messages are treated as system/application updates rather than `from a person`; a concrete accepted/interview/action state remains more specific.

---

# 5. Rules and Tags — practical guide

**Tags** and **Rules** are two views of the same ordered exact/custom message-rule list.

- **Tags view** focuses on the tag catalog and rules that create/use tags. General rules are folded below.
- **Rules view** focuses on general rules that change priority/visibility without creating a tag. Tag rules are folded below.
- **Engine behaviour** is separate. Global limits such as AI correction range, watchlist priority and noise ceilings are settings, not message rules.

Built-in semantic classification/tagging runs before exact/custom message rules.

## Rule fields

### Match

A literal cue that starts the rule: word, phrase, email address, domain or tag.

### Where

Where the cue is searched:

- **sender / From** — sender identity;
- **source / feed** — source identifier, useful for RSS;
- **subject** — subject/title;
- **body** — message body;
- **existing tag** — matches a tag already assigned by the classifier or an earlier rule;
- **all text fields** — broad text search.

### ANY / ALL

- **ANY** — any one listed cue is enough;
- **ALL** — every listed cue must match.

Prefer ALL when a single broad word would match too much.

### Tag

Adds the selected/custom label. A rule can also react to an existing tag by using **Where = tag**.

### Priority floor

The final priority may not become **less important** than this value.

Example: `floor P2` allows P1!/P1/P2 but blocks P3/P4/P5.

### Priority ceiling

The final priority may not become **more important** than this value.

Example: `ceiling P3` allows P3/P4/P5 but blocks P1!/P1/P2.

Set floor and ceiling to the same P only when you intentionally want an exact priority lock.

### Always show

Keeps a matching item visible instead of hiding it as noise. It does **not** by itself raise the priority.

### Stop

`Stop` means:

> after this rule matches, do not evaluate any later exact/custom message rule for this message.

It does **not**:

- undo the built-in classifier;
- remove tags/actions already produced;
- stop the whole Communication run;
- automatically stop AI processing.

Earlier matching rules remain applied. Therefore order matters when Stop is used.

### Scope

- `all` — all A-Tools/presets where this rule layer is used;
- `kind:reporter` — reporter-type A-Tools;
- `tool:NAME` — only the named saved preset/profile.

### Order

Rules are evaluated in saved order. Tags and Always show accumulate. Later matching floor/ceiling values can replace earlier bounds. A matching Stop prevents later exact/custom rules from running.

### Test

Read-only preview against the last report. It does not save the rule, fetch mail or change a message.

## Rule languages

Canonical match text remains exactly what you entered. Optional translated variants are stored separately. Email addresses, URLs, paths, filenames, model IDs, amounts, dates, references and other identifiers should not be translated.

## Factory rules

Factory exact/custom rules are a small baseline shipped with the product; most normal multilingual recognition belongs to the built-in classifier instead.

In normal UI they are read-only. Under:

```bash
python3 panel.py --d
```

use **Edit factory rules (--d)** to create a local factory override. The override is stored in AgentSystem, not by rewriting the source file. **Restore source factory** removes the override and returns to the factory rules shipped with that version.

---

# 6. Report actions

Depending on message/source and edition, the report may expose actions such as:

- copy message/report data;
- detailed summary;
- draft reply;
- reminder/calendar action;
- open in webmail/source;
- Why priority & tags;
- AI re-check;
- create/fix a rule;
- always/never summarize sender;
- hide/unhide.

Automatic summaries and manual detailed summaries are separate: the manual action can generate a more detailed cached summary even when a short automatic summary already exists.

---

# 7. Wake — background execution

Wake is the shared background manager.

When Wake is running it owns recurring schedules and run-on-start execution so multiple local scheduler loops do not compete.

Wake supports, depending on the published A-Tool entry:

- recurring runs;
- catch-up after missed slots;
- run on Wake/PC start;
- panel-start request;
- one-off run;
- manual headless run;
- network retry;
- optional UI open/reuse after a background run.

A Communication silent/headless run writes the report to local AgentSystem data. Opening the preset later can load the latest saved result without repeating the mail run.

If a communicator/output channel is configured, the background run uses the same output pipeline.

---

# 8. USER_CONTEXT / My Profile

USER_CONTEXT is for reusable information about you and your projects that helps the AI understand relevance.

Good content:

- projects/companies you actually work on;
- important organisations/clients;
- roles and responsibilities;
- recurring topics where context changes importance;
- explicit facts that are stable enough to reuse.

Do not use USER_CONTEXT as a replacement for a deterministic never-miss rule. For something that must always trigger predictably, use Watchlist or an exact Rule.

The profile can contain scoped sections such as global, reporter-kind or one specific tool/preset. AI-related profile builders should show you the proposed data before you apply it.

---

# 9. Email and RSS details

## Email

IMAP is used to read configured mailboxes. The exact server/login/password requirements depend on your provider. Providers such as Gmail commonly require an App Password when 2FA is enabled.

## RSS/Atom

One feed can contain optional fields such as:

```text
URL|priority|times|name|category|max_items|on/off|tags|include|exclude
```

Only URL is required.

Example:

```text
https://example.org/feed.xml|2|08:00,18:00|Example|news|30|on|project|release;update|sponsored
```

---

# 10. Privacy, data and security

## Local data

The application stores working data in the local AgentSystem directory, normally:

```text
~/agentsystem/
```

This can include profiles, report/cache data, rules, scheduler/Wake state, logs, USER_CONTEXT and local secrets metadata.

Report/body caches may contain email content. Treat your operating-system account and backups accordingly.

## Passwords and API keys

Secrets are handled separately from normal profile fields. Supported systems may use OS-protected secret storage such as Windows DPAPI, macOS Keychain or Linux Secret Service. If a protected backend is unavailable, a private-file fallback may be used; check diagnostics if encrypted-at-rest storage matters to you.

Do not expose secrets in screen recordings. Use demo/test data where appropriate.

## Browser binding

The normal panel is intended for local access and binds to localhost by default. Do not expose it to a public network unless you understand and deliberately configure the network/security implications.

## Cloud AI

If you select a cloud LLM provider, the content needed for the enabled AI task is sent to that provider. If you need inference to remain local, configure a local provider such as Ollama.

## Signed releases

Official publication builds may use an Ed25519-signed manifest for integrity/provenance. This can detect modified/mixed/unknown packages according to the trust configuration.

It is **not** protection against malware already running under your own user account. Software running with the same user permissions can potentially modify files owned by that user. Do not market or interpret the release as “tamper-proof”.

---

# 11. Safe configuration tips

- Start with AI off and verify deterministic results first.
- Use narrow exact rules before broad keywords.
- Prefer `ALL` for several cues that must occur together.
- Use **Test** before saving a broad/high-impact rule.
- Use Watchlist for explicit never-miss terms.
- Use USER_CONTEXT for softer semantic relevance.
- Use Floor/Ceiling rather than forcing an exact P unless you really need an exact lock.
- Use Stop only when you deliberately want to block every later exact/custom rule after the match.
- Keep Wake catch-up enabled if missed reports matter.
- Keep secret storage and AgentSystem backups protected by your OS account.

---

# 12. Diagnostics and `--d`

Start:

```bash
python3 panel.py --d
```

Diagnostic/developer UI may include additional tools such as:

- Multi-run Matrix;
- run-specific Log/Debug views;
- selected-copy diagnostics;
- all rule-language fields at once;
- factory exact/custom rule editor;
- fuller settings/trace views.

`--d` is a diagnostics/development UI mode. It is not intended as a security bypass.

## Multi-run Matrix

The Matrix runs a small set of engine/configuration combinations on the same sample so you can compare classification behaviour quickly. It is not a full end-to-end test of Wake, communicators, every report action or every external provider.

Use the separate feature/test buttons for those areas.

---

# 13. Troubleshooting

## Panel does not open

```bash
python3 panel.py
```

Check the terminal for the actual error. Do not run multiple conflicting copies on the same port.

## Wake does not run scheduled work

Open Wake settings/status and check:

- Wake process is running;
- Start with system state;
- the saved preset published a schedule;
- effective Wake schedule/override;
- current-session Wake log;
- network state if the job requires network access.

## Nothing appears in the report

Check:

- scan scope/folders;
- already-reported memory;
- exclusions;
- hidden/noise rows;
- whether the source actually contains new eligible items.

Use **Reset memory** only when you intentionally want to inspect already-reported items again.

## AI works inconsistently

Check provider/model/key, rate limits and structured-output parsing. Deterministic fallback is expected when a Model 4 fact response is not usable.

---

# 14. Technical reference

Main components:

- `panel.py` — local browser UI/API;
- `engine.py` — mail/RSS processing, classification, AI and report pipeline;
- `operational.py` — built-in categories/tags/presets/default policy data;
- `secret_store.py` — secret backend abstraction;
- `wake.py` — shared background execution manager;
- `wake_ui.py` — Wake control UI;
- `scheduler.py` — compatibility fallback when central Wake is unavailable;
- `hq.py` — shared ecosystem buffer/queue layer;
- `tags_custom.json` — user exact/custom rules;
- `factory_rules_override.json` — optional local factory-rule override created from `--d`;
- `USER_CONTEXT.md` — reusable user/project context;
- `~/agentsystem/data/` — reports/cache/runtime data.

The rule pipeline keeps built-in semantic classification separate from exact/custom rules. This is intentional: the factory exact-rule list should stay small while multilingual semantic recognition lives in the deterministic classifier/tag policy.

---

# 15. License

Use/distribution rights depend on the edition and grant you received. Read:

[LICENCE_AGREEMENT.txt](LICENCE_AGREEMENT.txt)

Do not redistribute a paid/non-redistributable build unless your license explicitly allows it.

---

# 16. Beta note

0.931b is a beta release. Core mail processing and Wake scheduling have been used in real runs, but not every combination of provider, RSS source, OS integration, communicator and AI model can be guaranteed to have been exercised on every release.

If something looks wrong, preserve the relevant current-session log and the **Why priority & tags** trace before changing rules. That makes classification bugs much easier to reproduce.


<!-- WAKE_COMPLETION_POLICY_NOTE -->
## Wake completion behaviour
Wake keeps execution separate from presentation. Globally and per Wake entry you can choose whether a successful background run stays silent or opens/raises the A-Tool UI, and independently whether it produces a desktop completion notification. Per-entry `inherit` uses the shared Wake setting.

Rules may react to tags: `Where = tag` matches an existing tag. Such a rule may add another tag, apply a priority floor/ceiling, keep the row visible, or stop later exact/custom rules. The rule engine resolves tag dependencies until stable.

Model 4 does **not** freely invent semantic tag categories. It extracts a fixed structured fact schema and maps supported states to known tags; explicit amount/deadline facts may create dynamic fact tags. Classic AI tag review is restricted to the built-in tag catalog. Custom tags remain an explicit user-rule feature.
