# ============================================================================
#  hq.py  —  GUZIK / BUTTON  ·  HQ współpracy między-agentowej
# ============================================================================
#  CO TO JEST (po ludzku):
#  To jest "centrala" (HQ) dla WSZYSTKICH twoich agentów-narzędzi.
#  Jeden agent czy dziesięć — wszystkie gadają przez TEN JEDEN plik.
#
#  DLACZEGO OSOBNO (nie w engine.py / operational.py):
#  - operational.py = ustawienia i tagi KONKRETNEGO agenta (kopiują się per-agent)
#  - hq.py          = wspólna infrastruktura (JEDEN na cały system, nie kopiuje się)
#
#  Scenariusz który to obsługuje:
#    1. Kupujesz/masz 1 agent (Reporter). hq.py obsługuje go trywialnie.
#    2. Dokupujesz 2. agent (np. Grant Watcher). Oba piszą do jednego bufora.
#    3. Generujesz kolejne 2. Wszystkie w jednej kolejce, jeden priorytet.
#
#  KLUCZOWA ZASADA STABILNOŚCI (twoje wymaganie):
#  Ten plik będzie w PRZYSZŁOŚCI updatowany (nowe funkcje HQ). Update NIE MOŻE
#  wywalić starych agentów. Dlatego:
#    - stary format wpisów w buforze zostaje wspierany na zawsze (pole "v")
#    - nowe funkcje dodajemy jako NOWE funkcje, nie zmieniamy sygnatur starych
#    - placeholdery poniżej rezerwują miejsce, ale nic jeszcze nie robią
#
#  CO JEST TERAZ (Produkt 1 realnie używa):
#    - buffer_append / buffer_read  → współdzielony bufor eventów (mail/social/task)
#    - overflow queue               → maile które nie zmieściły się w budżecie AI runu
#
#  CO JEST PLACEHOLDEREM (Guzik / Produkt 4 — later, NIE budujemy dziś):
#    - dystrybucja tokenów między agentami (wspólny budżet TPM)
#    - kolizje czasowe (dwa agenty odpalają się naraz)
#    - powiadomienia cross-agent (jeden agent alarmuje drugiego)
#    - wagi/scheduling w kolejce
# ============================================================================

import os, json, time
from datetime import datetime, timezone

# Event bus — agenty emitują zdarzenia (REPORT_READY, MAIL_CRITICAL...), słuchacze reagują.
from events import bus, MAIL_CRITICAL, AI_LIMIT_REACHED

# Loguru — ładne, kolorowe logi bez własnego kodu. Awaryjnie zwykły print.
try:
    from loguru import logger as _loguru
    _HAS_LOGURU = True
except Exception:
    _HAS_LOGURU = False

# Wspólny katalog danych — TEN SAM co engine.py (przez ENGINE_HOME lub ~/agentsystem)
HOME = os.path.expanduser(os.environ.get("ENGINE_HOME", "~/agentsystem"))

# Wersja formatu bufora. Rośnie tylko gdy zmieni się STRUKTURA wpisu.
# Stare wpisy z niższym "v" muszą być czytane zawsze (wsteczna zgodność).
BUFFER_FORMAT_VERSION = 1
_HQ_LOG_READY = False


# ── drobne pomocnicze (własne, by hq.py nie zależał od engine.py) ───────────
def _now():
    return datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M")

def _hq_log(msg):
    """Log HQ privately; configure the Loguru file sink only once."""
    global _HQ_LOG_READY
    try:
        log_dir = os.path.join(HOME, "logs")
        log_path = os.path.join(log_dir, "hq.log")
        os.makedirs(log_dir, exist_ok=True)
        if os.name == "posix":
            try: os.chmod(log_dir, 0o700)
            except Exception: pass
        if _HAS_LOGURU:
            if not _HQ_LOG_READY:
                _loguru.add(log_path, rotation="1 MB", level="INFO", enqueue=True, catch=True)
                _HQ_LOG_READY = True
            _loguru.info(f"hq: {msg}")
        else:
            line = f"[{_now()}] hq: {msg}"
            with open(log_path, "a", encoding="utf-8") as f:
                f.write(line + "\n")
        if os.name == "posix" and os.path.exists(log_path):
            try: os.chmod(log_path, 0o600)
            except Exception: pass
    except Exception:
        pass


# ============================================================================
#  1. WSPÓLNY BUFOR — STRIPPED FROM SOLO FREE
# ============================================================================
# Cross-tool action/event cooperation is not packaged in Solo Free.
# These no-op signatures remain only because the core engine emits optional
# events through the same API; they do not write/read a shared buffer.
def buffer_append(agent_name, kind, data, priority=5):
    return False

def buffer_read(kind=None, agent=None):
    return []

def buffer_clear(kind=None, agent=None):
    return 0


# ============================================================================
#  2. KOLEJKA NADMIARU  (per-agent: maile które nie zmieściły się w budżecie AI)
# ============================================================================
#  Po co: w trybie live streszczamy max N ważnych maili (np. 12). Reszta czeka.
#  Trzymamy ich Message-ID; następny run bierze je PIERWSZE (już czekały).
#  Osobno per-agent, bo każdy agent ma swoją skrzynkę i swój nadmiar.
# ----------------------------------------------------------------------------
def _overflow_path(name):
    return os.path.join(HOME, "data", f"{name}_overflow.json")


def overflow_load(name):
    """Wczytaj listę Message-ID czekających z poprzedniego runu (lub [])."""
    p = _overflow_path(name)
    try:
        if os.path.exists(p):
            return json.load(open(p, encoding="utf-8"))
    except Exception:
        pass
    return []


def overflow_save(name, mids):
    """Zapisz listę Message-ID do obsłużenia w następnym runie.
    Deduplikuje z zachowaniem kolejności (starsze pierwsze)."""
    try:
        data_dir = os.path.join(HOME, "data")
        os.makedirs(data_dir, exist_ok=True)
        if os.name == "posix":
            try: os.chmod(data_dir, 0o700)
            except Exception: pass
        path = _overflow_path(name)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(list(dict.fromkeys(mids)), f)
        if os.name == "posix":
            try: os.chmod(path, 0o600)
            except Exception: pass
    except Exception:
        pass


def overflow_add(name, mid):
    """Dorzuć pojedynczy Message-ID do kolejki (nie kasując istniejących)."""
    cur = overflow_load(name)
    if mid and mid not in cur:
        cur.append(mid)
        overflow_save(name, cur)


# ============================================================================
#  3. PLACEHOLDERY FRAMEWORKU  (Guzik / Produkt 4 — NIE budujemy dziś)
# ============================================================================
#  Rezerwują miejsce w architekturze. Każdy zwraca bezpieczną wartość domyślną,
#  więc agenty mogą już je wołać (no-op) i nic się nie psuje. Gdy przyjdzie czas
#  Guzika, wypełniamy CIAŁA tych funkcji — sygnatury zostają, nic nie trzeba
#  zmieniać u agentów które już je wołają. To jest ta "stabilność updatu".
# ----------------------------------------------------------------------------

def token_budget_request(agent_name, want_tokens, priority=3):
    """[PLACEHOLDER→częściowo aktywny] Wspólny budżet TPM dzielony między agentami.
    Gdy 2+ agentów naraz uderza w ten sam klucz (Groq 8000 TPM) albo auto-schedule
    się zderzają przez limity/opóźnienia free-API — o kolejności decyduje PRIORYTET
    (niższa liczba = ważniejszy; łączy priorytet agenta i priorytet skrzynki/maila).
    TERAZ: zwraca całość (1 agent). Przy wielu — kolejność wg priority w buforze."""
    _hq_log(f"budget request: {agent_name} chce {want_tokens} tok (priority={priority})")
    return want_tokens


def claim_run_slot(agent_name):
    """[PLACEHOLDER] Kolizje czasowe — dwa agenty naraz.
    Docelowo: HQ pozwala odpalić się jednemu naraz (albo N równolegle wg reguł),
    resztę wstrzymuje, by nie zderzyły się na IMAP/API.
    TERAZ: zawsze zgoda (True) — brak kolizji przy jednym agencie."""
    return True


def release_run_slot(agent_name):
    """[PLACEHOLDER] Zwolnij slot po zakończeniu runu. TERAZ: no-op."""
    return None


def notify_cross_agent(from_agent, to_agent, message, priority=3):
    """[PLACEHOLDER] Powiadomienia między agentami.
    Docelowo: jeden agent alarmuje drugiego (np. Grant Watcher znalazł deadline
    → mówi Reporterowi "dorzuć to do najbliższego raportu").
    TERAZ: zapisuje jako zwykły event w buforze — działa, ale bez routingu."""
    buffer_append(from_agent, "event",
                  {"to": to_agent, "message": message}, priority=priority)


def list_agents():
    """[PLACEHOLDER] Katalog aktywnych agentów (dla widoku multi-agent w panelu).
    Docelowo: skanuje profiles/ i zwraca typy + status, deduplikując rodzaje.
    TERAZ: czyta nazwy z katalogu profili jeśli istnieje, inaczej []."""
    pdir = os.path.join(HOME, "profiles")
    if not os.path.isdir(pdir):
        return []
    out = []
    for fn in os.listdir(pdir):
        if fn.endswith(".json"):
            out.append(fn[:-5])
    return sorted(out)


# ============================================================================
#  4. KALENDARZ + POWIADOMIENIA (wspólne dla agentów)
# ============================================================================
#  Po co: KAŻDY agent może dopisać deadline / notatkę / wydarzenie / planowaną
#  czynność do jednego wspólnego kalendarza. Reporter dopisze termin płatności,
#  Grant Watcher deadline naboru, Ty ręcznie notatkę. Panel/companion czyta.
#  Plik: ~/agentsystem/calendar.json (lista wpisów).
# ----------------------------------------------------------------------------
CALENDAR_PATH = os.path.join(HOME, "calendar.json")

def _write_calendar(cal):
    os.makedirs(HOME, exist_ok=True)
    if os.name == "posix":
        try: os.chmod(HOME, 0o700)
        except Exception: pass
    with open(CALENDAR_PATH, "w", encoding="utf-8") as f:
        json.dump(cal, f, ensure_ascii=False)
    if os.name == "posix":
        try: os.chmod(CALENDAR_PATH, 0o600)
        except Exception: pass


def calendar_add(agent, kind, title, when="", note="", time="", lead_days=None, remind_2h=True):
    """Dopisz wpis do wspólnego kalendarza.
      kind: 'deadline' | 'note' | 'event' | 'task'
      when: data (np. '15.07.2026'), time: godzina (np. '09:00')
      lead_days: [30, 1, 0] — ile dni przed przypomnieć; remind_2h: 2h przed
    Deduplikuje po (agent, title, when). Zwraca True gdy dodano; przy duplikacie
    lub bledzie rzuca/oznacza powod — panel pokaze konkret zamiast gluchego 'odrzucono'."""
    if not (title or "").strip():
        raise ValueError("title is empty")
    cal = calendar_list()
    key = (agent, title, when)
    if any((c.get("agent"), c.get("title"), c.get("when")) == key for c in cal):
        raise ValueError("already in the calendar (same agent, title and date)")
    cal.append({"agent": agent, "kind": kind, "title": title[:200],
                "when": when, "time": time, "note": note[:300],
                "lead_days": lead_days if lead_days is not None else [1],
                "remind_2h": bool(remind_2h),
                "added": _now()})
    _write_calendar(cal)
    return True

def calendar_list(upcoming_only=False):
    """Zwraca wpisy kalendarza. upcoming_only=True → tylko z datą (deadliny/eventy)."""
    try:
        cal = json.load(open(CALENDAR_PATH, encoding="utf-8")) if os.path.exists(CALENDAR_PATH) else []
    except Exception:
        cal = []
    if upcoming_only:
        cal = [c for c in cal if c.get("when")]
    return cal

def calendar_clear(agent=None):
    """Wyczyść kalendarz (całość lub danego agenta)."""
    if agent is None:
        try: _write_calendar([]); return
        except Exception: return
    cal = [c for c in calendar_list() if c.get("agent") != agent]
    try: _write_calendar(cal)
    except Exception: pass

def calendar_check_reminders(days_before=1):
    """Sprawdza kalendarz i zwraca wpisy z deadline za 'days_before' dni (do powiadomienia).
    Wywoływane przez scheduler raz dziennie. Domyślnie: dzień przed."""
    import datetime, re as _re
    out = []
    today = datetime.date.today()
    for c in calendar_list(upcoming_only=True):
        w = c.get("when", "")
        m = _re.match(r"(\d{1,2})\.(\d{1,2})(?:\.(\d{4}))?", w)
        if not m:
            continue
        try:
            dd, mm = int(m.group(1)), int(m.group(2))
            yy = int(m.group(3)) if m.group(3) else today.year
            due = datetime.date(yy, mm, dd)
        except Exception:
            continue
        delta = (due - today).days
        if 0 <= delta <= days_before:
            out.append({**c, "days_left": delta})
    return out


def calendar_notify_due(days_before=1):
    """Wysyła powiadomienie desktop dla nadchodzących deadlinów. Zwraca liczbę."""
    due = calendar_check_reminders(days_before)
    for c in due:
        when = "today" if c["days_left"] == 0 else "tomorrow"
        notify_desktop(f"📅 Reminder ({when})", f"{c.get('title','')} — {c.get('when','')}")
    return len(due)


def notify_desktop(title, message):
    """Desktop notification. Installation is owned by system_setup.py, never here."""
    title, message = str(title)[:60], str(message)[:200]
    try:
        from notifypy import Notify
        n = Notify(); n.title = title; n.message = message; n.application_name = "Time Savers"
        n.send(block=False); return True
    except Exception:
        pass
    try:
        import subprocess, sys as _sys, shutil as _sh
        if _sys.platform == "darwin" and _sh.which("osascript"):
            esc=lambda x:x.replace('\\','\\\\').replace('"','\\"')
            subprocess.Popen(["osascript","-e",f'display notification "{esc(message)}" with title "{esc(title)}"'],
                             stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL); return True
        if _sys.platform.startswith("linux") and _sh.which("notify-send"):
            subprocess.Popen(["notify-send",title,message],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL); return True
        if _sys.platform.startswith("win"):
            _psq=lambda x:str(x).replace("'", "''")
            ps=("Add-Type -AssemblyName PresentationFramework;"
                f"[System.Windows.MessageBox]::Show('{_psq(message)}','{_psq(title)}') | Out-Null")
            subprocess.Popen(["powershell","-NoProfile","-WindowStyle","Hidden","-Command",ps],
                             stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL); return True
    except Exception:
        pass
    _hq_log(f"[notify-failed] title={title!r} message_chars={len(message)}")
    return False


# ============================================================================
#  KONIEC hq.py
#  Przy dodawaniu nowych funkcji HQ: DODAWAJ nowe, nie zmieniaj sygnatur starych.
#  To gwarantuje że agenty zbudowane dziś zadziałają po każdym przyszłym updacie.
# ============================================================================


# ============================================================================
#  4. EVENT BUS  (warstwa zdarzeń — agent emituje, nie wie kto słucha)
# ============================================================================
#  DLACZEGO: zamiast agent → wie o buforze/Discordzie/panelu, agent tylko woła
#  emit("MAIL_CRITICAL", data). Kto słucha (panel, Telegram, Companion, PWA) —
#  podpina się przez on(...) BEZ zmiany kodu agenta. To fundament pod przyszłe
#  interfejsy: dodajesz nowy odbiornik, agenci się nie zmieniają.
#
#  IMPLEMENTACJA: używa 'blinker' (MIT, dojrzały) JEŚLI zainstalowany.
#  Jeśli nie ma blinkera — własny mini-dispatcher (zero zależności, ten sam API).
#  Nie wymuszamy pip install: laik odpala bez niczego, ekspert może dodać blinker.
#
#  STANDARDOWE ZDARZENIA (nazwy — trzymaj się ich by odbiorniki działały):
#    REPORT_READY      — raport gotowy (data = ścieżka/treść)
#    MAIL_CRITICAL     — pojawił się krytyczny mail (P1!)
#    AI_LIMIT_REACHED  — wyczerpany budżet tokenów/min
#    NEW_GRANT         — grant_watcher znalazł nabór (przyszłość)
#    RUN_STARTED / RUN_DONE — agent zaczął/skończył run
# ----------------------------------------------------------------------------
try:
    from blinker import signal as _bl_signal   # blinker jeśli dostępny
    _HAS_BLINKER = True
except Exception:
    _HAS_BLINKER = False
    _bl_signal = None

# Własny fallback: prosty słownik nazwa→lista funkcji. Ten sam efekt co blinker.
_FALLBACK_LISTENERS = {}


def on(event_name, callback):
    """Podepnij odbiornik pod zdarzenie. callback(sender, **data).
    Przykład: hq.on('MAIL_CRITICAL', lambda sender, **d: powiadom_telegram(d))"""
    if _HAS_BLINKER:
        _bl_signal(event_name).connect(callback, weak=False)
    else:
        _FALLBACK_LISTENERS.setdefault(event_name, []).append(callback)


def emit(event_name, sender="hq", **data):
    """Wyemituj zdarzenie do WSZYSTKICH podpiętych odbiorników.
    Agent nie wie i nie musi wiedzieć kto słucha. Błąd w jednym odbiorniku
    nie wywala pozostałych ani agenta."""
    _hq_log(f"emit {event_name} (sender={sender})")
    if _HAS_BLINKER:
        try:
            _bl_signal(event_name).send(sender, **data)
        except Exception as e:
            _hq_log(f"emit {event_name} blinker error: {e}")
    else:
        for cb in _FALLBACK_LISTENERS.get(event_name, []):
            try:
                cb(sender, **data)
            except Exception as e:
                _hq_log(f"listener error on {event_name}: {e}")


def emit_and_buffer(event_name, agent_name, kind, data, priority=5):
    """Wygoda: jednocześnie zapisz do bufora (trwałe) I wyemituj zdarzenie (live).
    Bufor = pamięć między runami; event = natychmiastowa reakcja odbiorników."""
    buffer_append(agent_name, kind, data, priority=priority)
    emit(event_name, sender=agent_name, kind=kind, data=data, priority=priority)


def export_ics(path=None):
    """Eksportuj kalendarz do pliku .ics — otwiera sie w Kalendarzu Windows/Mac/Linux,
    Google Calendar, Outlooku itd. Laczy nasz kalendarz z systemowym bez API.
    Zwraca sciezke pliku albo None."""
    import os
    try:
        cal = calendar_list()
    except Exception:
        cal = []
    if path is None:
        base = os.path.expanduser("~/agentsystem/data")
        os.makedirs(base, exist_ok=True)
        path = os.path.join(base, "timesavers.ics")

    def _dt(when, tm):
        # "15.08.2026" + "09:00" -> "20260815T090000"
        try:
            d = when.replace("-", ".").split(".")
            if len(d[0]) == 4:            # YYYY.MM.DD
                y, mo, da = d[0], d[1], d[2]
            else:                          # DD.MM.YYYY
                da, mo, y = d[0], d[1], d[2]
            hh, mm = (tm if (tm and ":" in tm) else "09:00").split(":")[:2]
            return f"{int(y):04d}{int(mo):02d}{int(da):02d}T{int(hh):02d}{int(mm):02d}00"
        except Exception:
            return ""

    lines = ["BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//TimeSavers//Communication#1//EN"]
    for i, c in enumerate(cal):
        dt = _dt(c.get("when", ""), c.get("time", ""))
        if not dt:
            continue
        lines += ["BEGIN:VEVENT", f"UID:ts-{i}-{dt}@timesavers",
                  f"DTSTART:{dt}", f"SUMMARY:{(c.get('title','') or '')[:200]}",
                  f"DESCRIPTION:{(c.get('note','') or '')[:300]}"]
        if c.get("remind_2h"):
            lines += ["BEGIN:VALARM", "TRIGGER:-PT2H", "ACTION:DISPLAY",
                      "DESCRIPTION:Reminder", "END:VALARM"]
        lines.append("END:VEVENT")
    lines.append("END:VCALENDAR")
    try:
        open(path, "w", encoding="utf-8").write("\r\n".join(lines))
        return path
    except Exception:
        return None
