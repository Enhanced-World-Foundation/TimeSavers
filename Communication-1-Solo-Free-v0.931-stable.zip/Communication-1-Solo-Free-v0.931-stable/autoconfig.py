# ============================================================================
#  autoconfig.py  —  warstwa AUTO / AI konfiguracji profilu agenta
# ============================================================================
#  Po co: kupujący nie chce ręcznie wypełniać 10 pól. Daje TEKST o sobie
#  (albo link do swojej strony), a my proponujemy gotową konfigurację:
#  watchlist, exclude, focus, character, priorytety skrzynek.
#
#  ZASADA BEZPIECZEŃSTWA (Twoje wymaganie):
#  AI nigdy nie nadpisuje profilu po cichu. Flow zawsze:
#    1. PROPOZYCJA  — AI/skrypt czyta wejście i proponuje pola
#    2. CZYTANIE    — user widzi propozycję (co się zmieni)
#    3. BACKUP      — zapisujemy kopię obecnego profilu przed zmianą
#    4. ZATWIERDZENIE — user klika "Apply" (albo edytuje i dopiero apply)
#    5. REALIZACJA  — dopiero teraz zapis do profilu
#
#  Dwa tryby:
#    - skryptowy (bez AI): szybkie heurystyki (słowa-klucze z tekstu → focus/watchlist)
#    - AI: model czyta tekst/link i proponuje pełniejszą konfigurację (JSON)
# ============================================================================

import os, json, re, time
import security_net as SNET

HOME = os.path.expanduser(os.environ.get("ENGINE_HOME", "~/agentsystem"))


def _backup_profile(name):
    """Kopia profilu przed zmianą — do data/backups/{name}_{ts}.json. Zwraca ścieżkę."""
    src = os.path.join(HOME, "profiles", f"{name}.json")
    if not os.path.exists(src):
        return ""
    bdir = os.path.join(HOME, "data", "backups")
    os.makedirs(bdir, exist_ok=True)
    ts = time.strftime("%Y%m%d-%H%M%S")
    dst = os.path.join(bdir, f"{name}_{ts}.json")
    try:
        import shutil; shutil.copy2(src, dst)
        return dst
    except Exception:
        return ""


def script_suggest(user_text, links="", files_text="", log=None, uploads=None):
    """Tryb SKRYPTOWY (bez AI): szybkie heurystyki z tekstu o userze.
    Wyłuskuje możliwe słowa do focus/watchlist/exclude — proste, deterministyczne.
    Linki/pliki/wgrane pliki sa POBIERANE tym samym fetch_materials co w AI, zeby
    source-report (_sources) byl uczciwy takze bez AI — user widzi, ze LinkedIn
    sie nie wczytal, a jego PDF owszem."""
    materials, src_report = fetch_materials(links, files_text, log=log, uploads=uploads)
    t = ((user_text or "") + " " + materials).lower()
    sug = {"focus": "", "watchlist": "", "exclude": "", "character": ""}
    # focus: wykryj branżę/rolę
    hints = []
    if re.search(r"prawn|lawyer|kancelari|legal", t): hints.append("courts, authorities, clients, deadlines")
    if re.search(r"firm|business|company|founder|startup", t): hints.append("clients, invoices, partners, banks")
    if re.search(r"nauk|research|uczeln|univers|phd", t): hints.append("universities, conferences, grants, collaborators")
    if re.search(r"freelanc|gig|kontrakt", t): hints.append("clients, contracts, payments, deadlines")
    sug["focus"] = "; ".join(hints) or "emails from real people, partners, banks/authorities"
    # watchlist: instytucje/pieniądze
    wl = []
    for kw, tag in [("podatk", "tax office"), ("komornik", "enforcement"), ("faktur", "invoice"),
                    ("deadline", "deadline"), ("umow", "contract"), ("grant", "grant")]:
        if kw in t: wl.append(tag)
    sug["watchlist"] = ", ".join(wl)
    # exclude: typowy szum
    sug["exclude"] = "newsletter, noreply, facebook, promotions"
    sug["character"] = "calm, no scare tactics; serious matters framed as things to handle"
    sug["_sources"] = src_report          # co realnie udalo sie przeczytac (tez bez AI)
    return sug


def fetch_materials(links="", files_text="", log=None, uploads=None):
    """Zbiera MATERIALY o userze: pobiera tresc podanych linkow + doklada
    wklejony tekst + WGRANE PLIKI (PDF/DOCX/ODT/RTF/TXT). Zwraca (tekst, raport_zrodel).

    Dotad link byl przekazywany do AI jako GOLY URL — model nie widzial, co jest
    na stronie, i zgadywal z samego adresu. Teraz strona jest pobierana i
    zamieniana na tekst tym samym helperem, ktorym engine czysci maile HTML.
    Wgrane pliki ida przez file_parsers.parse_uploads (miekki import bibliotek).

    Nie ma limitu znakow: jesli materialow jest duzo, dzielimy je na porcje
    (patrz ai_suggest) — a nie ucinamy w polowie zdania.
    """
    import urllib.request
    try:
        import engine as _E
        _to_text = _E._html_to_text
    except Exception:
        def _to_text(h):
            return re.sub(r"<[^>]+>", " ", h)

    chunks, report = [], []
    if files_text and files_text.strip():
        chunks.append(files_text.strip())
        report.append(f"pasted text: {len(files_text.strip())} chars")

    # WGRANE PLIKI: PDF/DOCX/ODT/RTF/TXT -> tekst (osobny modul, miekki import)
    if uploads:
        try:
            import file_parsers as _FP
            up_text, up_report = _FP.parse_uploads(uploads)
            if up_text:
                chunks.append(up_text)
            report.extend(up_report)
            if log:
                for r in up_report:
                    log(f"autoconfig: {r}")
        except Exception as ex:
            report.append(f"uploaded files: parser error ({str(ex)[:60]})")

    for raw in re.split(r"[\s,;]+", links or ""):
        url = raw.strip()
        if not url:
            continue
        if not url.startswith(("http://", "https://")):
            url = "https://" + url
        try:
            data, final_url, hdrs = SNET.open_public_url(
                url, timeout=20, max_bytes=3_000_000,
                headers={"User-Agent": "Mozilla/5.0 (Locally4Me a-tool profile builder)"},
                allow_private=False)
            ctype = (hdrs.get("Content-Type") or "").lower()
            url = final_url
            enc = "utf-8"
            m = re.search(r"charset=([\w-]+)", ctype)
            if m:
                enc = m.group(1)
            body = data.decode(enc, "ignore")
            # PDF/DOCX to binaria — nie zgadujemy tekstu, mowimy wprost
            if "pdf" in ctype or body[:4] == "%PDF":
                report.append(f"{url}: PDF — save it as .txt or .md and paste the text instead")
                continue
            text = _to_text(body) if ("html" in ctype or "<html" in body[:400].lower()) else body
            text = re.sub(r"\n{3,}", "\n\n", text).strip()
            if text:
                chunks.append(f"--- from {url} ---\n{text}")
                report.append(f"{url}: {len(text)} chars read")
            else:
                report.append(f"{url}: nothing readable (JavaScript-only page?)")
        except Exception as ex:
            report.append(f"{url}: could not read ({str(ex)[:60]})")
        if log:
            log(f"autoconfig: {report[-1] if report else url}")

    return ("\n\n".join(chunks), report)


def ai_suggest(user_text, llm, ask_llm_fn, links="", files_text="", log=None, uploads=None):
    """Tryb AI: model czyta tekst/materialy o userze i proponuje konfigurację (JSON).
    ask_llm_fn = funkcja engine.ask_llm (wstrzykiwana, by autoconfig nie zależał od engine).

    Kolejnosc: opis wlasny usera + pobrana tresc linkow + wklejone pliki + wgrane pliki.
    Duze wejscie NIE jest ucinane — najpierw skracamy je map-reduce (kazda porcja
    streszczana osobno), potem z tego streszczenia budujemy konfiguracje.
    """
    materials, src_report = fetch_materials(links, files_text, log=log, uploads=uploads)
    full = "\n\n".join(x for x in [(user_text or "").strip(), materials] if x)
    if not full.strip():
        return None

    # MAP-REDUCE dla duzych materialow: zamiast uciac na 2000 znakach,
    # streszczamy po kawalku i dopiero streszczenie idzie do konfiguratora.
    LIMIT = 6000
    if len(full) > LIMIT:
        parts = [full[i:i + LIMIT] for i in range(0, len(full), LIMIT)][:8]
        notes = []
        for idx, part in enumerate(parts, 1):
            p = ("Summarise the FACTS about this person or business: who they are, what they do, "
                 "companies, projects, priorities, what they want to achieve, what they do NOT care about. "
                 "Bullet points, no filler.\n\n" + part)
            r = ask_llm_fn(p, llm, max_tokens=400)
            if r and not r.startswith("[BLAD"):
                notes.append(r.strip())
            if log:
                log(f"autoconfig: condensed part {idx}/{len(parts)}")
        if notes:
            full = "\n".join(notes)

    prompt = (
        "You configure an email-triage assistant for a user. Based on the text about them below, "
        "propose settings. Return ONLY a JSON object, no prose, with keys: "
        '"focus" (what senders/topics matter to them), '
        '"watchlist" (comma-separated always-urgent words), '
        '"exclude" (comma-separated noise to drop), '
        '"character" (tone for the report). '
        "Base it ONLY on the text. Keep each field short.\n\nTEXT ABOUT USER:\n" + full)
    r = ask_llm_fn(prompt, llm, max_tokens=400)
    if not r or r.startswith("[BLAD"):
        return None
    # wytnij JSON
    m = re.search(r"\{.*\}", r, re.DOTALL)
    if not m:
        return None
    try:
        d = json.loads(m.group(0))
        out = {k: str(d.get(k, ""))[:300] for k in ("focus", "watchlist", "exclude", "character")}
        out["_sources"] = src_report          # co realnie udalo sie przeczytac
        return out
    except Exception:
        return None


def apply_suggestion(name, suggestion, fields=None):
    """REALIZACJA: zapisuje zatwierdzone pola do profilu — PO backupie.
    fields = lista pól do zastosowania (None = wszystkie z suggestion).
    Zwraca (ok, backup_path, applied_fields)."""
    ppath = os.path.join(HOME, "profiles", f"{name}.json")
    if not os.path.exists(ppath):
        return False, "", []
    backup = _backup_profile(name)   # BACKUP przed zmianą
    try:
        prof = json.load(open(ppath, encoding="utf-8"))
    except Exception:
        return False, backup, []
    ag = prof.setdefault("agent", {})
    applied = []
    for k in (fields or ["focus", "watchlist", "exclude", "character"]):
        v = suggestion.get(k)
        if v:
            ag[k] = v
            applied.append(k)
    try:
        tmp = ppath + ".tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(prof, fh, indent=2, ensure_ascii=False)
            fh.flush()
            try: os.fsync(fh.fileno())
            except Exception: pass
        if os.name == "posix":
            try: os.chmod(tmp, 0o600)
            except Exception: pass
        os.replace(tmp, ppath)
        if os.name == "posix":
            try: os.chmod(ppath, 0o600)
            except Exception: pass
        return True, backup, applied
    except Exception:
        try:
            if os.path.exists(ppath + ".tmp"): os.remove(ppath + ".tmp")
        except Exception: pass
        return False, backup, applied


def restore_backup(backup_path, name):
    """Restore only this profile's own JSON backup from ~/agentsystem/data/backups.

    backup_path can be an absolute path returned by apply_suggestion(), but it must
    resolve inside the controlled backup directory and match the requested profile.
    """
    safe_name = str(name or "").strip()
    if not re.fullmatch(r"[A-Za-z0-9_. -]{1,80}", safe_name) or ".." in safe_name:
        return False
    bdir = os.path.realpath(os.path.join(HOME, "data", "backups"))
    src = os.path.realpath(str(backup_path or ""))
    try:
        if os.path.commonpath([bdir, src]) != bdir:
            return False
    except Exception:
        return False
    if not os.path.isfile(src) or not os.path.basename(src).startswith(safe_name + "_") or not src.endswith(".json"):
        return False
    pdir = os.path.realpath(os.path.join(HOME, "profiles"))
    os.makedirs(pdir, exist_ok=True)
    ppath = os.path.join(pdir, safe_name + ".json")
    try:
        import shutil
        tmp = ppath + ".restore.tmp"
        shutil.copy2(src, tmp)
        if os.name == "posix":
            os.chmod(tmp, 0o600)
        os.replace(tmp, ppath)
        return True
    except Exception:
        try:
            if os.path.exists(ppath + ".restore.tmp"):
                os.remove(ppath + ".restore.tmp")
        except Exception:
            pass
        return False
