#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""wake.py — always-on lightweight ecosystem wake manager.

Responsibilities (kept outside the browser panel):
  * watch published schedules and wake A-Tools / console 1-Clicks;
  * retry resumable downloaders when the network returns;
  * own the shared desktop popup schedule;
  * expose a native tray/control window;
  * autostart with the OS (default on, user can disable it);
  * export a *wake schedule* calendar, separate from the main deadline calendar.

Security: only registered sibling tools are executed, no shell strings from JSON,
entrypoints are path-validated and optional published SHA-256 pins are checked.
"""
from __future__ import annotations
import datetime
import hashlib
import json
import os
import random
import re
import shutil
import socket
import subprocess
import sys
import threading
import time

# Monotonic system-Wake contract version. Increment only when the central Wake runtime changes.
WAKE_RELEASE = 14
WAKE_SCHEMA = 2

HERE = os.path.dirname(os.path.abspath(__file__))
PARENT = os.path.dirname(HERE)
SAFE_NAME = re.compile(r"^[A-Za-z0-9 _.#()\-]+$")


def _eco_data_dir():
    try:
        import atool_sync as _as
        return _as.eco_dir()
    except Exception:
        d = os.path.expanduser(os.environ.get("ENGINE_HOME", "~/agentsystem"))
        os.makedirs(d, exist_ok=True)
        return d


ECO_DIR = _eco_data_dir()
ECO = os.path.join(ECO_DIR, "ecosystem.json")
STATE = os.path.join(ECO_DIR, "wake_state.json")
APPROVED = os.path.join(ECO_DIR, "wake_approved.json")
CONFIG = os.path.join(ECO_DIR, "wake_config.json")
NEXT_POPUP = os.path.join(ECO_DIR, "next_popup.json")
LOG = os.path.join(ECO_DIR, "logs", "wake.log")
SESSION_LOG = os.path.join(ECO_DIR, "logs", "wake-current.log")
PROCESS_LOG = os.path.join(ECO_DIR, "logs", "wake-process.log")
TOOL_PROCESS_LOG = os.path.join(ECO_DIR, "logs", "wake-tools.log")
PID_FILE = os.path.join(ECO_DIR, "wake.pid.json")
HEARTBEAT_FILE = os.path.join(ECO_DIR, "wake.heartbeat.json")
INSTANCE_LOCK = os.path.join(ECO_DIR, "wake.instance.lock")
POPUP_LOCK = os.path.join(ECO_DIR, "wake_popup.lock")
CALENDAR = os.path.join(os.path.expanduser(os.environ.get("ENGINE_HOME", "~/agentsystem")), "calendar.json")
COMMAND_DIR = os.path.join(ECO_DIR, "wake_commands")
JOB_RESULT_DIR = os.path.join(ECO_DIR, "wake_job_results")

# Popen handles owned by this manager process. Durable job metadata is stored in
# wake_state.json, so a manager restart can recover a child it did not spawn.
_JOB_PROCESSES = {}
_LOG_LAST = {}

DEFAULT_CONFIG = {
    # check_interval_s remains a compatibility ceiling. The manager now sleeps
    # dynamically until the nearest job/schedule/popup and polls commands often.
    "check_interval_s": 30,
    "command_poll_s": 1,
    "schedule_window_min": 5,
    "catchup_max_days": 7,
    "catchup_max_jobs_per_schedule": 16,
    "job_retry_base_s": 15,
    "job_retry_max_s": 900,
    "job_max_attempts": 5,
    "job_history_days": 30,
    "max_parallel_jobs": 4,
    "autostart": True,
    "wake_browser": False,
    "notify_runs": True,
    "popup": {
        "enabled": True,
        "initial_delay_s": 6 * 60,
        "min_delay_s": 4 * 60 * 60,
        "max_delay_s": 5 * 24 * 60 * 60,
        "visible_s": 25,
    },
    "network": {"retry_pending_when_online": True, "probe_timeout_s": 3},
}


def _deep_merge(base, override):
    out = dict(base)
    for k, v in (override or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = _deep_merge(out[k], v)
        else:
            out[k] = v
    return out


def _load_json(path, default):
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return default


def _atomic_json(path, data):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    # Private temp name per writer. A shared "<file>.tmp" makes concurrent
    # writers destroy each other's temp file and lose the write entirely.
    tmp = f"{path}.{os.getpid()}.{threading.get_ident():x}.{random.randint(0, 0xffffff):06x}.tmp"
    try:
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
            f.flush()
            try: os.fsync(f.fileno())
            except Exception: pass
        try:
            if os.name == "posix": os.chmod(tmp, 0o600)
        except Exception:
            pass
        os.replace(tmp, path)
    except Exception:
        try:
            if os.path.exists(tmp): os.remove(tmp)
        except Exception:
            pass
        raise


def _config():
    raw = _load_json(CONFIG, {})
    cfg = _deep_merge(DEFAULT_CONFIG, raw if isinstance(raw, dict) else {})
    if not os.path.exists(CONFIG):
        try:
            _atomic_json(CONFIG, cfg)
        except Exception:
            pass
    return cfg


def _rotate_log(path, max_bytes=2_000_000, backups=3):
    """Bound log growth without touching current output on ordinary starts."""
    try:
        if not os.path.isfile(path) or os.path.getsize(path) <= int(max_bytes):
            return
        for idx in range(int(backups), 0, -1):
            src = f"{path}.{idx}"
            dst = f"{path}.{idx + 1}"
            if idx == int(backups) and os.path.exists(src):
                os.remove(src)
            elif os.path.exists(src):
                os.replace(src, dst)
        os.replace(path, path + ".1")
    except Exception:
        pass


def _begin_session_log(mode):
    """Start a fresh human-facing log for this persistent Wake session.

    wake.log remains the bounded history. wake-current.log is replaced on each
    real daemon/tray start so the control center never mixes current failures
    with days-old releases. External CLI/control processes only append; they do
    not truncate the active manager's session log.
    """
    try:
        os.makedirs(os.path.dirname(SESSION_LOG), exist_ok=True)
        line = (f"[{datetime.datetime.now().isoformat(timespec='seconds')}] "
                f"=== WAKE SESSION START release={WAKE_RELEASE} mode={mode} pid={os.getpid()} ===")
        with open(SESSION_LOG, "w", encoding="utf-8") as f:
            f.write(line + "\n")
        try:
            if os.name == "posix": os.chmod(SESSION_LOG, 0o600)
        except Exception:
            pass
    except Exception:
        pass


def _log(msg, dedupe_key=None, dedupe_s=0):
    """Write one bounded event log; optionally suppress repeated identical states."""
    now = time.time()
    key = str(dedupe_key or "")
    if key and dedupe_s:
        previous = _LOG_LAST.get(key)
        if previous and previous[0] == str(msg) and now - previous[1] < float(dedupe_s):
            return
        _LOG_LAST[key] = (str(msg), now)
    line = f"[{datetime.datetime.now().isoformat(timespec='seconds')}] {msg}"
    print(line)
    try:
        os.makedirs(os.path.dirname(LOG), exist_ok=True)
        try:
            if os.name == "posix": os.chmod(os.path.dirname(LOG), 0o700)
        except Exception: pass
        _rotate_log(LOG)
        with open(LOG, "a", encoding="utf-8") as f:
            f.write(line + "\n")
        # Human-facing current session log: intentionally small and replaced on
        # each persistent Wake start. The full bounded history stays in wake.log.
        with open(SESSION_LOG, "a", encoding="utf-8") as f:
            f.write(line + "\n")
        try:
            if os.name == "posix":
                os.chmod(LOG, 0o600)
                os.chmod(SESSION_LOG, 0o600)
        except Exception: pass
    except Exception:
        pass


def _run_status_path(agent, tool_id="", profile_id=""):
    agent=str(agent or "").strip(); tool_id=str(tool_id or "").strip()
    profile_id=str(profile_id or agent).strip()
    if tool_id:
        token=hashlib.sha256(f"{tool_id}::{profile_id}".encode("utf-8","ignore")).hexdigest()[:24]
        return os.path.join(ECO_DIR,"data","run_status",token+".json")
    if not agent or not SAFE_NAME.fullmatch(agent): return None
    return os.path.join(ECO_DIR,"data",f"{agent}_run_status.json")

def _write_run_status(agent,state,**extra):
    path=_run_status_path(agent,extra.get("tool_id"),extra.get("profile_id"))
    if not path: return
    data={"agent":str(agent),"source":"wake","state":str(state),"updated_at":time.time(),**extra}
    try: _atomic_json(path,data)
    except Exception: pass


def _sha256(path):
    try:
        h = hashlib.sha256()
        with open(path, "rb") as f:
            for chunk in iter(lambda: f.read(1024 * 1024), b""):
                h.update(chunk)
        return h.hexdigest()
    except Exception:
        return None


def _safe_dir(name=None, install_path=None):
    """Resolve a registered A-Tool directory without assuming it is Wake's sibling."""
    if install_path:
        try:
            full = os.path.realpath(os.path.expanduser(str(install_path)))
            if os.path.isdir(full):
                return full
        except Exception:
            return None
    if not name or not isinstance(name, str) or not SAFE_NAME.match(name):
        return None
    if ".." in name or "/" in name or "\\" in name:
        return None
    full = os.path.realpath(os.path.join(PARENT, name))
    if os.path.isdir(full) and os.path.dirname(full) == os.path.realpath(PARENT):
        return full
    if os.path.basename(HERE) == name and os.path.isdir(HERE):
        return os.path.realpath(HERE)
    return None


def _tool_dir(tool_id, sched=None):
    rec = _tool_record(tool_id) or {}
    sched = sched or rec.get("schedule_live") or {}
    return _safe_dir(sched.get("folder") or rec.get("path"), rec.get("install_path"))


def _safe_file(tool_dir, name, allowed_ext=None):
    if not name or not isinstance(name, str) or "/" in name or "\\" in name or ".." in name:
        return None
    if not SAFE_NAME.match(name):
        return None
    if allowed_ext and os.path.splitext(name)[1].lower() not in allowed_ext:
        return None
    p = os.path.join(tool_dir, name)
    return p if os.path.isfile(p) else None


def _tool_record(tool_id):
    eco = _load_json(ECO, {"atools": []})
    for a in eco.get("atools", []):
        if a.get("id") == tool_id:
            return a
    return None


def _valid_hhmm(value):
    try:
        hh, mm = str(value or "").strip().split(":")[:2]
        hh, mm = int(hh), int(mm)
        if 0 <= hh <= 23 and 0 <= mm <= 59:
            return f"{hh:02d}:{mm:02d}"
    except Exception:
        pass
    return None


def queue_command(kind, tool_id=None, payload=None):
    """Queue a one-shot command for the single persistent Wake manager.

    Native wake_ui.py is a control surface only; it never becomes a second
    scheduler/executor.  Unique files make enqueue atomic across processes.
    """
    kind = str(kind or "").strip()
    if kind not in {"run_tool", "run_due", "panel_start"}:
        raise ValueError("unsupported Wake command")
    os.makedirs(COMMAND_DIR, exist_ok=True)
    token = f"{time.time_ns()}-{os.getpid()}-{random.randint(1000,9999)}"
    dest = os.path.join(COMMAND_DIR, token + ".json")
    tmp = f"{dest}.{os.getpid()}.tmp"
    data = {"kind": kind, "tool_id": str(tool_id or ""), "payload": payload or {}, "queued_at": time.time()}
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False)
    os.replace(tmp, dest)
    return token


def _process_commands(limit=25):
    """Drain control commands inside the one persistent manager process."""
    if not os.path.isdir(COMMAND_DIR):
        return 0
    done = 0
    for name in sorted(os.listdir(COMMAND_DIR))[:max(1, int(limit))]:
        if not name.endswith(".json"):
            continue
        path = os.path.join(COMMAND_DIR, name)
        try:
            cmd = _load_json(path, {})
            kind = cmd.get("kind")
            if kind == "run_tool":
                tid=str(cmd.get("tool_id") or ""); profile_id=str((cmd.get("payload") or {}).get("profile_id") or ""); rec=_tool_record(tid)
                if rec:
                    schedule_id=_schedule_id(tid,profile_id)
                    sched=effective_schedule(rec,profile_id or None)
                    state=_load_json(STATE,{})
                    _enqueue_job(state, tid, profile_id, sched, "manual", None,
                                 "manual-wake-ui", unique=str(cmd.get("queued_at") or name))
                    _atomic_json(STATE,state)
            elif kind == "run_due":
                run_due_once(manager_session=_manager_session_id(), drain=False)
            elif kind == "panel_start":
                tid=str(cmd.get("tool_id") or ""); profile_id=str((cmd.get("payload") or {}).get("profile_id") or ""); rec=_tool_record(tid)
                if rec:
                    sched=effective_schedule(rec,profile_id or None)
                    state=_load_json(STATE,{})
                    _revive_resolved_blocked_jobs(state,tid,profile_id,sched)
                    _enqueue_run_on_start(state,tid,profile_id,sched,
                                          unique=str(cmd.get("queued_at") or name),
                                          source="panel-start")
                    _atomic_json(STATE,state)
            done += 1
        except Exception as e:
            _log(f"Wake command failed ({name}): {e}")
        finally:
            try: os.remove(path)
            except Exception: pass
    return done


def request_due_scan():
    """Ask the persistent manager to rescan schedules; never run a second executor."""
    st=status()
    if not st.get("running"):
        ok,_why=ensure_background_process(with_tray=True)
        if not ok:
            return False
    try:
        queue_command("run_due")
        return True
    except Exception as e:
        _log(f"manual due scan queue failed: {e}")
        return False


def _manager_session_id():
    state=_load_json(STATE,{})
    ms=state.get("manager_session") if isinstance(state.get("manager_session"),dict) else {}
    return str(ms.get("id") or "") or None


def _start_manager_session(mode):
    """Create one run-on-start session id for this persistent Wake process."""
    sid = f"{int(time.time())}-{os.getpid()}-{str(mode or 'wake')}"
    state = _load_json(STATE, {})
    state["manager_session"] = {"id": sid, "mode": str(mode or "wake"), "started": time.time()}
    _atomic_json(STATE, state)
    return sid


def _schedule_overrides():
    raw=(_config().get("tool_schedule_overrides") or {})
    return raw if isinstance(raw,dict) else {}

def _published_schedules(record):
    record=record or {}; mp=record.get("schedules_live")
    if isinstance(mp,dict) and mp:
        return {str(k):dict(v) for k,v in mp.items() if isinstance(v,dict)}
    legacy=record.get("schedule_live")
    if isinstance(legacy,dict) and legacy:
        key=str(legacy.get("entry_id") or legacy.get("preset_id") or legacy.get("profile_id") or legacy.get("agent") or "__default__"); return {key:dict(legacy)}
    return {}

def _schedule_id(tool_id,profile_id=None):
    p=str(profile_id or "").strip()
    # Legacy single schedule remains addressable by plain tool id. Named profiles
    # use tool::profile, so old callers/UI do not break during schedules_live migration.
    return str(tool_id) if p in ("", "__default__") else f"{tool_id}::{p}"

def _split_schedule_id(value):
    value=str(value or ""); return value.split("::",1) if "::" in value else (value,"")

def effective_schedule(record,profile_id=None):
    record=record or {}; tool_id=str(record.get("id") or ""); mp=_published_schedules(record)
    if profile_id is None:
        if len(mp)==1: profile_id=next(iter(mp))
        elif isinstance(record.get("schedule_live"),dict): profile_id=str(record.get("schedule_live",{}).get("profile_id") or record.get("schedule_live",{}).get("agent") or "")
    profile_id=str(profile_id or "").strip(); published=dict(mp.get(profile_id) or (record.get("schedule_live") or {} if not profile_id else {}))
    sid=_schedule_id(tool_id,profile_id); ovs=_schedule_overrides(); ov=ovs.get(sid) or (ovs.get(tool_id) if not profile_id or profile_id=="__default__" else {}) or {}
    if not isinstance(ov,dict): ov={}
    out=dict(published)
    for key in ("runs","once_date","once_time","active_from","active_until","catchup","network_required","retry_when_online","when_online","online_cooldown_s","ui_after_run","notify_after_run","run_on_start","run_on_start_min"):
        if key in ov: out[key]=ov[key]
    out["_wake_enabled"]=bool(ov.get("enabled",True)); out["_override_active"]=bool(ov); out["_profile_id"]=profile_id; out["_schedule_id"]=sid
    return out

def _read_run_status_for_agent(agent,tool_id="",profile_id=""):
    path=_run_status_path(agent,tool_id,profile_id)
    return _load_json(path,{}) if path else {}


def _next_run_for_schedule(sched, now=None):
    now=now or datetime.datetime.now(); candidates=[]
    for offset in range(0,32):
        day=now.date()+datetime.timedelta(days=offset)
        if not _active_today(sched,day): continue
        for raw in sched.get("runs") or []:
            hhmm=_valid_hhmm(raw)
            if not hhmm: continue
            hh,mm=map(int,hhmm.split(":")); dt=datetime.datetime.combine(day,datetime.time(hh,mm))
            if dt>now: candidates.append(dt)
        if candidates and offset>0: break
    try:
        od=str(sched.get("once_date") or ""); ot=_valid_hhmm(sched.get("once_time") or "08:00") or "08:00"
        if od:
            hh,mm=map(int,ot.split(":")); dt=datetime.datetime.combine(datetime.date.fromisoformat(od),datetime.time(hh,mm))
            if dt>now: candidates.append(dt)
    except Exception: pass
    return min(candidates) if candidates else None

def _entry_label(sched, fallback=""):
    sched=sched or {}
    return str(sched.get("display_name") or sched.get("agent") or sched.get("entry_id") or sched.get("profile_id") or fallback or "").strip()


def _ui_contract(rec, sched=None):
    rec=rec or {}; sched=sched or {}; ui={}
    if isinstance(rec.get("ui"),dict): ui.update(rec.get("ui") or {})
    if isinstance(sched.get("ui"),dict): ui.update(sched.get("ui") or {})
    if not ui.get("port") and rec.get("port"): ui["port"]=rec.get("port")
    if not ui.get("main"):
        ui["main"]=sched.get("main") or rec.get("main") or "panel.py"
    ui.setdefault("health_path", "/")
    ui.setdefault("url", "")
    return ui


def _ui_contract_ready(tool_dir, rec, sched):
    if not tool_dir: return False
    ui=_ui_contract(rec,sched)
    try: port=int(ui.get("port") or 0)
    except Exception: port=0
    if port<=0: return False
    if isinstance(ui.get("launch"),dict):
        try: return bool(_resolve_launch(tool_dir,{"launch":ui.get("launch")}))
        except Exception: return False
    main=str(ui.get("main") or "")
    if not main: return False
    if main.lower().endswith(".py"):
        return bool(_safe_file(tool_dir,main,allowed_ext={".py"}))
    return bool(_safe_file(tool_dir,main,allowed_ext={".exe"} if sys.platform.startswith("win") else {""}))


def list_tool_schedules():
    eco=_load_json(ECO,{"atools":[]}); rows=[]; ovs=_schedule_overrides(); state=_load_json(STATE,{})
    active_jobs=(job_status(state).get("active") or [])
    for rec in eco.get("atools",[]):
        if not isinstance(rec,dict) or not rec.get("id"): continue
        tool_id=str(rec.get("id")); mp=_published_schedules(rec); items=list(mp.items()) if mp else [("",{})]
        for entry_id,pub in items:
            sid=_schedule_id(tool_id,entry_id); eff=effective_schedule(rec,entry_id or None) if pub else {"_wake_enabled":True,"_override_active":False,"_profile_id":"","_schedule_id":sid}
            tool_dir=_safe_dir(rec.get("path"),rec.get("install_path")); launch_ready=False; launch_error=None
            try: launch_ready=bool(_resolve_launch(tool_dir,eff)) if tool_dir and isinstance(eff.get("launch"),dict) else False
            except Exception as e: launch_error=str(e)
            ui_ready=_ui_contract_ready(tool_dir,rec,pub or eff)
            compat="headless-ready" if launch_ready else ("ui-only" if ui_ready else ("no-schedule" if not pub else "runner-missing"))
            neutral_id=str(entry_id or pub.get("entry_id") or pub.get("preset_id") or pub.get("profile_id") or pub.get("agent") or "")
            entry_kind=str(pub.get("entry_kind") or ("profile" if pub.get("agent") else "task"))
            entry_label=_entry_label(pub,neutral_id)
            base_name=rec.get("name") or tool_id; display=f"{base_name} / {entry_label}" if entry_label else base_name
            next_dt=_next_run_for_schedule(eff) if eff.get("_wake_enabled",True) else None
            sjobs=[j for j in active_jobs if j.get("schedule_id")==sid]
            rows.append({"id":sid,"tool_id":tool_id,"profile_id":neutral_id,"entry_id":neutral_id,"entry_kind":entry_kind,"entry_label":entry_label,"name":display,"tool_name":base_name,"path":rec.get("path"),"install_path":rec.get("install_path"),"port":(_ui_contract(rec,pub or eff).get("port") or rec.get("port")),"trust":rec.get("trust"),"published":pub,"effective":eff,"override":ovs.get(sid) or (ovs.get(tool_id) if not entry_id or entry_id=="__default__" else {}) or {},"compatibility":compat,"headless_ready":launch_ready,"ui_ready":ui_ready,"launch_error":launch_error,"run_status":_read_run_status_for_agent(entry_label or neutral_id,tool_id,entry_id) if (entry_label or neutral_id) else {},"next_run_at":next_dt.isoformat(timespec="minutes") if next_dt else None,"jobs":sjobs})
    return rows


def update_tool_schedule(tool_id, data):
    """Persist a central Wake override for one tool/profile schedule."""
    schedule_id=str(tool_id or "").strip(); base_tool,profile_id=_split_schedule_id(schedule_id)
    if not base_tool or not _tool_record(base_tool): raise ValueError("unknown A-Tool")
    tool_id=_schedule_id(base_tool,profile_id); data=data or {}; cfg=_config(); ovs=cfg.setdefault("tool_schedule_overrides",{})
    if data.get("reset"):
        ovs.pop(tool_id, None)
        _atomic_json(CONFIG, cfg)
        return next((r for r in list_tool_schedules() if r.get("id") == tool_id), None)
    ov = dict(ovs.get(tool_id) or {})
    if "enabled" in data:
        ov["enabled"] = bool(data.get("enabled"))
    if "runs" in data:
        raw = data.get("runs")
        if isinstance(raw, str):
            raw = re.split(r"[,;\s]+", raw.strip()) if raw.strip() else []
        vals = []
        for item in (raw or []):
            v = _valid_hhmm(item)
            if not v:
                raise ValueError(f"invalid time: {item}")
            if v not in vals:
                vals.append(v)
        ov["runs"] = vals
    for key in ("once_date", "active_from", "active_until"):
        if key in data:
            val = str(data.get(key) or "").strip()
            if val:
                try:
                    datetime.date.fromisoformat(val)
                except Exception:
                    raise ValueError(f"{key} must be YYYY-MM-DD")
            ov[key] = val or None
    if "once_time" in data:
        val = str(data.get("once_time") or "").strip()
        if val:
            val = _valid_hhmm(val)
            if not val:
                raise ValueError("once_time must be HH:MM")
        ov["once_time"] = val or None
    for key in ("catchup", "network_required", "retry_when_online", "when_online", "run_on_start"):
        if key in data:
            ov[key] = bool(data.get(key))
    if "run_on_start_min" in data:
        try:
            ov["run_on_start_min"] = max(0, min(1440, float(data.get("run_on_start_min") or 0)))
        except Exception:
            raise ValueError("run_on_start_min must be a number")
    if "ui_after_run" in data:
        mode = str(data.get("ui_after_run") or "inherit").strip().lower()
        if mode not in ("inherit", "never", "open"):
            raise ValueError("ui_after_run must be inherit, never or open")
        ov["ui_after_run"] = mode
    if "notify_after_run" in data:
        mode = str(data.get("notify_after_run") or "inherit").strip().lower()
        if mode not in ("inherit", "never", "notify"):
            raise ValueError("notify_after_run must be inherit, never or notify")
        ov["notify_after_run"] = mode
    if "online_cooldown_s" in data:
        try:
            ov["online_cooldown_s"] = max(60, min(86400 * 30, int(data.get("online_cooldown_s") or 3600)))
        except Exception:
            raise ValueError("online_cooldown_s must be a number")
    ovs[tool_id] = ov
    _atomic_json(CONFIG, cfg)
    return next((r for r in list_tool_schedules() if r.get("id") == tool_id), None)


def run_tool_now(tool_id):
    """Request a manual headless run for one profile through the persistent Wake manager."""
    schedule_id=str(tool_id or ""); base_tool,profile_id=_split_schedule_id(schedule_id); rec=_tool_record(base_tool)
    if not rec: return False
    st = status()
    if not st.get("running"):
        ok, _ = ensure_background_process(with_tray=True)
        if not ok:
            return False
    try:
        sched=effective_schedule(rec,profile_id or None); agent=_entry_label(sched,profile_id or base_tool)
        _write_run_status(agent,"queued",tool_id=base_tool,profile_id=profile_id,reason="manual-wake-ui",queued_at=time.time())
        queue_command("run_tool", base_tool, {"profile_id": profile_id})
        _log(f"QUEUE '{schedule_id}' entry='{agent}' reason=manual-wake-ui")
        return True
    except Exception as e:
        _log(f"manual Wake run queue failed for '{tool_id}': {e}")
        return False


def request_panel_start(tool_id, profile_id=""):
    """Tell the persistent Wake manager that this A-Tool panel has started.

    run_on_start therefore has two explicit sources: a new Wake/OS session and
    an actual panel start. The same last-run guard/coalescing rules prevent a
    duplicate when both happen during boot.
    """
    base_tool, parsed_profile = _split_schedule_id(str(tool_id or ""))
    profile_id = str(profile_id or parsed_profile or "")
    rec = _tool_record(base_tool)
    if not rec:
        return False
    try:
        queue_command("panel_start", base_tool, {"profile_id": profile_id})
        _log(f"PANEL-START QUEUE '{_schedule_id(base_tool, profile_id)}'")
        return True
    except Exception as e:
        _log(f"panel-start queue failed for '{base_tool}': {e}")
        return False


def _tool_ui_alive(port, health_path="/"):
    try:
        import urllib.request
        path=str(health_path or "/").strip() or "/"
        if not path.startswith("/"): path="/"+path
        with urllib.request.urlopen(f"http://127.0.0.1:{int(port)}{path}", timeout=1.0) as r:
            return 200 <= int(getattr(r, "status", 200)) < 500
    except Exception:
        try:
            with socket.create_connection(("127.0.0.1", int(port)), timeout=0.4):
                return True
        except Exception:
            return False


def open_tool_ui(tool_id, start_if_needed=True):
    """Open/reuse a UI using the neutral A-Tool UI contract.

    A-Tools may publish ui.launch / ui.port / ui.health_path / ui.url.  Legacy
    Communication-style panel.py remains the fallback, but Wake does not require it.
    """
    base_tool,entry_id=_split_schedule_id(tool_id); rec=_tool_record(base_tool)
    if not rec: return False,"unknown A-Tool"
    sched=effective_schedule(rec,entry_id or None)
    if str(rec.get("trust") or "pending") != "accepted":
        sig=_release_signature(_tool_dir(base_tool,sched))
        if not sig.get("ok"):
            return False,"A-Tool is not trusted/verified"
    ui=_ui_contract(rec,sched)
    try: port=int(ui.get("port") or 0)
    except Exception: port=0
    if port <= 0: return False, "A-Tool does not publish a UI port"
    health=str(ui.get("health_path") or "/")
    if not _tool_ui_alive(port,health) and start_if_needed:
        tool_dir=_safe_dir(rec.get("path"),rec.get("install_path"))
        if not tool_dir: return False,"A-Tool folder is unavailable"
        try:
            if isinstance(ui.get("launch"),dict):
                argv=_resolve_launch(tool_dir,{"launch":ui.get("launch")})
                if not argv: return False,"A-Tool UI launch contract is unavailable"
            else:
                main=str(ui.get("main") or sched.get("main") or rec.get("main") or "panel.py")
                main_py=_safe_file(tool_dir,main,allowed_ext={".py"})
                if not main_py: return False,"A-Tool UI entry is unavailable"
                args=[str(x) for x in (ui.get("args") or ["--no-open"])]
                argv=[sys.executable,main_py,*args]
            subprocess.Popen(argv,cwd=tool_dir,shell=False,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,stdin=subprocess.DEVNULL)
            for _ in range(35):
                if _tool_ui_alive(port,health): break
                time.sleep(0.15)
        except Exception as e:
            return False,str(e)
    if not _tool_ui_alive(port,health): return False,"A-Tool UI did not become ready"
    url=str(ui.get("url") or f"http://localhost:{port}")
    try:
        import webbrowser; webbrowser.open(url, new=2, autoraise=True); return True,url
    except Exception as e:
        return False,str(e)


def _launch_contract_hash(tool_id, sched):
    rec = _tool_record(tool_id) or {}
    launch = sched.get("launch") if isinstance(sched.get("launch"), dict) else {}
    contract = {
        "tool_id": tool_id,
        "install_path": os.path.realpath(str(rec.get("install_path") or "")) if rec.get("install_path") else "",
        "folder": sched.get("folder") or rec.get("path") or "",
        "main": sched.get("main") or "",
        "main_sha256": sched.get("main_sha256") or "",
        "launch": {
            "type": launch.get("type") or "",
            "entry": launch.get("entry") or "",
            "entrypoints": launch.get("entrypoints") or {},
            "entry_candidates": launch.get("entry_candidates") or {},
            "args": launch.get("args") or [],
            "sha256": launch.get("sha256") or "",
            "self_published": bool(launch.get("self_published")),
        },
    }
    raw = json.dumps(contract, sort_keys=True, separators=(",", ":"), ensure_ascii=True).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()

def _release_signature(tool_dir):
    """Publisher verification for an A-Tool installation directory."""
    if not tool_dir:
        return {"ok": False, "signed": False, "key_id": "", "reason": "no folder"}
    try:
        import importlib.util
        # The verifier and the pinned keys must both come from the CENTRAL Wake.
        # Reading either from the folder under examination lets a hostile A-Tool
        # certify itself, which is not a signature check at all.
        _p = os.path.join(os.path.dirname(os.path.abspath(__file__)), "release_signing.py")
        if not os.path.isfile(_p):
            return {"ok": False, "signed": False, "key_id": "",
                    "reason": "no verifier in the active central Wake"}
        _sp = importlib.util.spec_from_file_location(f"_rsig_{abs(hash(_p)) & 0xffffff:x}", _p)
        _m = importlib.util.module_from_spec(_sp); _sp.loader.exec_module(_m)
        _keys = _m.load_trusted_keys()
        if not _keys:
            return {"ok": False, "signed": False, "key_id": "",
                    "reason": "no publisher key in the central trust store"}
        return _m.verify_release(tool_dir, keys=_keys, strict="code")
    except Exception as ex:
        return {"ok": False, "signed": False, "key_id": "", "reason": f"verifier error: {ex}"}


def _native_self_publish_authorized(rec, sched):
    """Allow native runner pin rotation in source or a verified product.

    Source/product is structural, not a switch: an installation without pinned
    publisher keys is editable; after Builder establishes trust the whole
    package must verify before its runner pin may change.
    """
    root=os.path.join(ECO_DIR,"system","wake")
    trust_path=os.path.join(root,"publisher_keys.json")
    if not os.path.isfile(trust_path):
        return True
    try:
        raw=_load_json(trust_path,{})
        if not isinstance(raw,dict) or not (raw.get("keys") or []):
            return True
    except Exception:
        return False
    try:
        import importlib.util
        paths=[os.path.join(root,"release_signing.py")]
        active=_load_json(os.path.join(root,"active.json"),{})
        if active.get("version_dir"):
            paths.append(os.path.join(root,str(active["version_dir"]).replace("/",os.sep),"release_signing.py"))
        for rp in paths:
            if not os.path.isfile(rp): continue
            spec=importlib.util.spec_from_file_location("_wake_trust",rp)
            mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
            if not mod.load_trusted_keys():
                return True
            break
    except Exception:
        pass
    return bool(_release_signature(_tool_dir(str(rec.get("id") or ""),sched)).get("ok"))


def _is_approved(tool_id, sched):
    """Authorize one published schedule.

    R61-compatible rule for our own native A-Tools: an already trusted A-Tool may
    refresh the pin for its self-published headless runner after an update.  This
    prevents a normal copy/update from permanently disabling Wake just because
    wake_runner.py changed.  Generic/external 1-Click contracts remain pinned and
    still require explicit re-approval after a code/contract change.
    """
    rec=_tool_record(tool_id) or {}; trust=rec.get("trust","pending")
    if trust=="blocked": return False,"trust=blocked"
    if trust!="accepted":
        # A release signed by a pinned publisher key is authenticated; that IS the
        # approval. Without a valid signature the manual pending gate stays.
        _sig=_release_signature(_tool_dir(tool_id, sched))
        if not _sig.get("ok"):
            return False,"trust=pending"
    launch=sched.get("launch") if isinstance(sched.get("launch"),dict) else {}; live=launch.get("sha256") or sched.get("main_sha256")
    if not live: return False,"missing executable SHA"
    profile_id=str(sched.get("_profile_id") or sched.get("profile_id") or sched.get("agent") or ""); pin_id=_schedule_id(tool_id,profile_id); appr=_load_json(APPROVED,{})
    contract=_launch_contract_hash(tool_id,sched); pin=appr.get(pin_id)
    native_self = bool(trust == "accepted" and launch and launch.get("self_published")
                       and _native_self_publish_authorized(rec,sched))

    if pin is None and pin_id!=tool_id and appr.get(tool_id) is not None and len(_published_schedules(rec))<=1:
        pin=appr.pop(tool_id); appr[pin_id]=pin; _atomic_json(APPROVED,appr)

    if pin is None:
        if native_self or (live and not launch):
            appr[pin_id]={"entry_sha256":live,"contract_sha256":contract}; _atomic_json(APPROVED,appr); pin=appr[pin_id]
        else:
            return False,"not approved for wake execution"

    # Legacy string pins are migrated.  A trusted native self-published runner is
    # allowed to rotate its own pin; generic/external launchers are not.
    if isinstance(pin,str):
        if pin!=live and not native_self:
            return False,"published hash changed since approval"
        appr[pin_id]={"entry_sha256":live,"contract_sha256":contract}; _atomic_json(APPROVED,appr); pin=appr[pin_id]

    if not isinstance(pin,dict): return False,"invalid approval record"
    entry_changed = bool(pin.get("entry_sha256") and pin.get("entry_sha256")!=live)
    contract_changed = bool(pin.get("contract_sha256") and pin.get("contract_sha256")!=contract)
    if entry_changed or contract_changed:
        if native_self:
            appr[pin_id]={"entry_sha256":live,"contract_sha256":contract}; _atomic_json(APPROVED,appr)
            _log(f"TRUST REFRESH '{pin_id}': trusted native A-Tool republished its Wake runner")
            return True,""
        if entry_changed: return False,"published hash changed since approval"
        return False,"launch contract changed since approval"
    return True,""

def approve(tool_id):
    base_tool,profile_id=_split_schedule_id(tool_id); rec=_tool_record(base_tool)
    if not rec: raise ValueError(f"unknown tool: {base_tool}")
    schedules=_published_schedules(rec); selected=({profile_id:schedules.get(profile_id)} if profile_id else schedules)
    if not selected: selected={"":rec.get("schedule_live") or {}}
    appr=_load_json(APPROVED,{}); count=0
    for pid,s0 in selected.items():
        if not isinstance(s0,dict) or not s0: continue
        sched=effective_schedule(rec,pid or None); launch=sched.get("launch") if isinstance(sched.get("launch"),dict) else {}; sha=launch.get("sha256") or sched.get("main_sha256")
        if not sha: raise ValueError(f"schedule {pid or base_tool} has no executable SHA")
        sid=_schedule_id(base_tool,pid); appr[sid]={"entry_sha256":sha,"contract_sha256":_launch_contract_hash(base_tool,sched)}; count+=1
    _atomic_json(APPROVED,appr)
    # Approval is itself the state change that resolves trust/contract blocks.
    # Do not require an unrelated code/hash change before a due job can retry.
    state = _load_json(STATE, {})
    changed = False
    tools_state = state.get("tools") if isinstance(state.get("tools"), dict) else {}
    for sid, ts in tools_state.items():
        if not isinstance(ts, dict):
            continue
        if sid == base_tool or sid.startswith(base_tool + "::"):
            if ts.pop("blocked", None) is not None:
                changed = True
    jobs = state.get("jobs") if isinstance(state.get("jobs"), dict) else {}
    for job in jobs.values():
        if not isinstance(job, dict) or job.get("tool_id") != base_tool:
            continue
        if job.get("state") == "blocked":
            job["state"] = "pending"
            job["next_attempt_at"] = time.time()
            job["error"] = ""
            job["updated_at"] = time.time()
            changed = True
    if changed:
        _atomic_json(STATE, state)
    _log(f"APPROVED '{base_tool}' ({count} schedule contract(s) pinned)")


def set_tool_trust(tool_id, trust):
    """Update ecosystem trust from the central Wake UI without importing A-Tool code.

    Central Wake version directories intentionally do not contain atool_sync.py.
    Importing it from whichever working directory opened the UI made approval
    dependent on an arbitrary A-Tool copy and failed for a real autostarted Wake.
    """
    trust=str(trust or "").strip().lower()
    if trust not in ("accepted","pending","blocked"):
        raise ValueError("trust must be accepted, pending or blocked")
    tool_id=str(tool_id or "").strip()
    eco=_load_json(ECO,{"atools":[]})
    changed=False
    for rec in eco.get("atools",[]) if isinstance(eco.get("atools"),list) else []:
        if isinstance(rec,dict) and str(rec.get("id") or "")==tool_id:
            rec["trust"]=trust; changed=True; break
    if not changed:
        return False
    _atomic_json(ECO,eco)
    if trust != "accepted":
        state=_load_json(STATE,{})
        for job in (state.get("jobs") or {}).values() if isinstance(state.get("jobs"),dict) else []:
            if isinstance(job,dict) and job.get("tool_id")==tool_id and job.get("state") in ("pending","retry","running"):
                job["state"]="blocked"; job["error"]="trust="+trust; job["updated_at"]=time.time()
        _atomic_json(STATE,state)
    _log(f"TRUST '{tool_id}' -> {trust}")
    return True


def _active_today(sched, today):
    try:
        af, au = sched.get("active_from"), sched.get("active_until")
        if af and today < datetime.date.fromisoformat(af):
            return False
        if au and today > datetime.date.fromisoformat(au):
            return False
    except Exception:
        pass
    return True


def _slot_due(runs, now, fired):
    window = max(1, int(_config().get("schedule_window_min", 5))) * 60
    for hhmm in runs or []:
        try:
            hh, mm = str(hhmm).split(":")[:2]
            planned = now.replace(hour=int(hh), minute=int(mm), second=0, microsecond=0)
        except Exception:
            continue
        delta = (now - planned).total_seconds()
        if 0 <= delta <= window and str(hhmm) not in fired:
            return str(hhmm)
    return None


def _network_online():
    timeout = float((_config().get("network") or {}).get("probe_timeout_s", 3) or 3)
    # DNS-free probe first; a failed probe does not mutate any downloader state.
    for host, port in (("1.1.1.1", 53), ("8.8.8.8", 53)):
        try:
            with socket.create_connection((host, port), timeout=timeout):
                return True
        except Exception:
            continue
    return False


def _platform_key():
    if sys.platform.startswith("win"):
        return "windows"
    if sys.platform == "darwin":
        return "macos"
    return "linux"


def _publisher_trust_configured():
    """True only after Builder/release provisioning installed real publisher keys.

    Editable source ships with an empty publisher key set. In that state our own
    self-published runner remains editable and must not deadlock development on a
    stale SHA. Generic/third-party launch contracts keep their published pin.
    """
    root = os.path.join(ECO_DIR, "system", "wake")
    paths = [os.path.join(root, "publisher_keys.json"), os.path.join(HERE, "publisher_keys.json")]
    for path in paths:
        try:
            raw = _load_json(path, {})
            if isinstance(raw, dict) and isinstance(raw.get("keys"), list) and raw.get("keys"):
                return True
        except Exception:
            pass
    return False


def _resolve_launch(tool_dir, sched):
    """Return argv for a published launch contract. No shell is ever used."""
    launch = sched.get("launch") if isinstance(sched.get("launch"), dict) else None
    if not launch:
        return None
    kind = str(launch.get("type") or "python").lower()
    entry = launch.get("entry")
    by_os = launch.get("entrypoints") or {}
    if isinstance(by_os, dict) and by_os.get(_platform_key()):
        entry = by_os.get(_platform_key())
    candidates = []
    if entry:
        candidates.append(entry)
    ec = launch.get("entry_candidates")
    if isinstance(ec, dict):
        candidates += list(ec.get(_platform_key()) or [])
    elif isinstance(ec, list):
        candidates += ec
    picked = None
    for c in candidates:
        ext = {".py"} if kind == "python" else ({".exe"} if sys.platform.startswith("win") else {""})
        picked = _safe_file(tool_dir, str(c), allowed_ext=ext)
        if picked:
            break
    if not picked:
        return None
    pub_sha = launch.get("sha256")
    source_editable_native = bool(launch.get("self_published")) and not _publisher_trust_configured()
    if pub_sha and not source_editable_native and _sha256(picked) != pub_sha:
        raise RuntimeError("launch entry hash mismatch")
    args = [str(x) for x in (launch.get("args") or [])]
    if len(args) > 64 or any(len(a) > 4096 or any(ord(ch) < 32 and ch not in "\t" for ch in a) for a in args):
        raise RuntimeError("invalid launch argument")
    if kind == "python":
        return [sys.executable, picked, *args]
    if kind in ("binary", "executable"):
        return [picked, *args]
    raise RuntimeError(f"unsupported launch type: {kind}")


# -------------------------- durable job queue -----------------------------
def _jobs(state):
    jobs=state.get("jobs")
    if not isinstance(jobs,dict):
        jobs={}; state["jobs"]=jobs
    return jobs


def _job_id(schedule_id, kind, occurrence):
    raw=f"{schedule_id}|{kind}|{occurrence}"
    return hashlib.sha256(raw.encode("utf-8","ignore")).hexdigest()[:24]


def _collision_keys(tool_id, profile_id, sched):
    """Resources that may not overlap with another running job.

    A-Tools are independent by default, while presets inside one A-Tool share
    its data and therefore serialize.  Future Ecosystem orchestration can add
    neutral collision_keys without moving AI/data-flow logic into Wake.
    """
    launch=sched.get("launch") if isinstance(sched.get("launch"),dict) else {}
    raw=sched.get("collision_keys") or launch.get("collision_keys") or []
    if isinstance(raw,str): raw=[raw]
    keys={str(x).strip() for x in raw if str(x).strip()}
    if not bool(sched.get("allow_parallel_presets") or launch.get("allow_parallel_presets")):
        keys.add("tool:"+str(tool_id))
    if not keys:
        keys.add("schedule:"+_schedule_id(tool_id,profile_id))
    return sorted(keys)


def _enqueue_job(state, tool_id, profile_id, sched, kind, due_dt, reason,
                 unique=None, slot=None):
    """Insert one idempotent job. Scheduled occurrences never duplicate."""
    schedule_id=_schedule_id(tool_id,profile_id)
    occurrence=(due_dt.isoformat(timespec="minutes") if isinstance(due_dt,datetime.datetime)
                else str(unique or f"{time.time_ns()}-{random.randint(1000,9999)}"))
    jid=_job_id(schedule_id,kind,occurrence)
    jobs=_jobs(state)
    if jid in jobs:
        return False,jobs[jid]
    now=time.time(); agent=_entry_label(sched,profile_id or tool_id)
    job={
        "id":jid,"schedule_id":schedule_id,"tool_id":str(tool_id),
        "profile_id":str(profile_id or ""),"agent":agent,"kind":str(kind),
        "reason":str(reason),"slot":str(slot or (due_dt.strftime("%H:%M") if isinstance(due_dt,datetime.datetime) else "")),
        "due_at":due_dt.timestamp() if isinstance(due_dt,datetime.datetime) else now,
        "occurrence":occurrence,"state":"pending","attempts":0,
        "created_at":now,"updated_at":now,"next_attempt_at":now,
        "launch_key":str((sched.get("launch") or {}).get("sha256") or sched.get("main_sha256") or ""),
        "collision_keys":_collision_keys(tool_id,profile_id,sched),
    }
    jobs[jid]=job
    _write_run_status(agent,"queued",tool_id=tool_id,profile_id=profile_id,
                      reason=reason,slot=job["slot"],job_id=jid,queued_at=now)
    _log(f"JOB QUEUED '{schedule_id}' id={jid} kind={kind} slot={job['slot'] or '-'} reason={reason}")
    return True,job


def _prune_jobs(state):
    jobs=_jobs(state); now=time.time()
    cutoff=now-max(1,int(_config().get("job_history_days",30) or 30))*86400
    terminal={"succeeded","failed","cancelled"}
    for jid,job in list(jobs.items()):
        if not isinstance(job,dict):
            jobs.pop(jid,None); continue
        finished=float(job.get("finished_at") or job.get("updated_at") or now)
        if job.get("state") in terminal and finished < cutoff:
            jobs.pop(jid,None)
    if len(jobs)>1200:
        removable=sorted(((float(j.get("finished_at") or j.get("updated_at") or 0),jid)
                          for jid,j in jobs.items() if isinstance(j,dict) and j.get("state") in terminal))
        for _ts,jid in removable[:max(0,len(jobs)-1000)]: jobs.pop(jid,None)


def _date_range(start_date,end_date):
    cur=start_date
    while cur<=end_date:
        yield cur
        cur+=datetime.timedelta(days=1)


def _launch_contract_ready_now(tool_id, sched):
    """Validate the *current* published executable without starting it."""
    ok, why = _is_approved(tool_id, sched)
    if not ok:
        return False, why
    tool_dir = _tool_dir(tool_id, sched)
    if not tool_dir:
        return False, "unsafe/missing tool folder"
    try:
        launch = sched.get("launch") if isinstance(sched.get("launch"), dict) else None
        if launch:
            if not _resolve_launch(tool_dir, sched):
                return False, "no valid entrypoint for this OS"
        else:
            main_name = sched.get("main") or "panel.py"
            main_py = _safe_file(tool_dir, main_name, allowed_ext={".py"})
            if not main_py:
                return False, "missing/unsafe main .py"
            pub_sha = sched.get("main_sha256")
            if pub_sha and _sha256(main_py) != pub_sha:
                return False, "main hash mismatch"
        return True, ""
    except Exception as e:
        return False, str(e)


def _revive_resolved_blocked_jobs(state, tool_id, profile_id, sched):
    """Self-heal a launch block after the A-Tool republishes a valid contract.

    The common startup race is: central Wake scans an old schedule, blocks it,
    then panel.py publishes the new runner two seconds later.  A valid republish
    must clear that stale block rather than leaving catch-up/run-on-start dead.
    """
    sid = _schedule_id(tool_id, profile_id)
    jobs = _jobs(state)
    blocked = [j for j in jobs.values()
               if isinstance(j, dict) and j.get("schedule_id") == sid and j.get("state") == "blocked"]
    if not blocked:
        return 0
    launch = sched.get("launch") if isinstance(sched.get("launch"), dict) else {}
    current_key = str(launch.get("sha256") or sched.get("main_sha256") or "")
    recoverable = []
    for job in blocked:
        err = str(job.get("error") or "").lower()
        old_key = str(job.get("launch_key") or "")
        if old_key != current_key or "hash mismatch" in err or "published hash changed" in err or "launch contract changed" in err:
            recoverable.append(job)
    if not recoverable:
        return 0
    ready, why = _launch_contract_ready_now(tool_id, sched)
    if not ready:
        return 0
    now = time.time()
    for job in recoverable:
        job.update({"state": "pending", "error": "", "pid": None,
                    "next_attempt_at": now, "updated_at": now,
                    "launch_key": current_key,
                    "collision_keys": _collision_keys(tool_id, profile_id, sched)})
    ts = state.setdefault("tools", {}).setdefault(sid, {})
    ts.pop("blocked", None)
    agent = str(sched.get("agent") or profile_id or tool_id)
    _write_run_status(agent, "queued", tool_id=tool_id, profile_id=profile_id,
                      reason="republished-contract", queued_at=now)
    _log(f"UNBLOCK '{sid}': valid republished launch contract; revived {len(recoverable)} job(s)")
    return len(recoverable)


def _last_run_epoch(state, sid, sched, profile_id):
    ts = state.setdefault("tools", {}).setdefault(sid, {})
    try:
        last = float(ts.get("last_launch_at") or 0)
    except Exception:
        last = 0.0
    agent = str(sched.get("agent") or profile_id or "")
    if agent:
        try:
            lf = os.path.join(ECO_DIR, "data", agent + "_lastrun.txt")
            if os.path.isfile(lf):
                with open(lf, encoding="utf-8") as f:
                    last = max(last, float(f.read().strip() or 0))
        except Exception:
            pass
    return last


def _enqueue_run_on_start(state, tool_id, profile_id, sched, unique, source="wake-start"):
    if not bool(sched.get("run_on_start")):
        return 0
    sid = _schedule_id(tool_id, profile_id)
    # A catch-up/scheduled/manual job for the same profile already satisfies the
    # intent of "run on start"; do not create a second concurrent run.
    for job in _jobs(state).values():
        if (isinstance(job, dict) and job.get("schedule_id") == sid and
                job.get("state") in ("pending", "retry", "running", "blocked")):
            _log(f"RUN-ON-START '{sid}' coalesced with existing {job.get('state')} job",
                 dedupe_key=f"startup-existing:{sid}:{unique}", dedupe_s=86400)
            return 1
    try:
        guard = max(0.0, float(5 if sched.get("run_on_start_min") is None else sched.get("run_on_start_min", 5)))
    except Exception:
        guard = 5.0
    last = _last_run_epoch(state, sid, sched, profile_id)
    if last and time.time() - last < guard * 60:
        _log(f"RUN-ON-START '{sid}' skipped: last run inside {guard:g} min guard",
             dedupe_key=f"startup-guard:{sid}:{unique}", dedupe_s=86400)
        return 0
    ok, _job = _enqueue_job(state, tool_id, profile_id, sched, "startup", None,
                            source, unique=str(unique))
    return int(ok)


def _schedule_jobs_for_profile(state, tool_id, profile_id, sched, now, manager_session=None):
    """Materialize due occurrences since the last scan into the durable queue."""
    sid=_schedule_id(tool_id,profile_id); tools=state.setdefault("tools",{})
    ts=tools.setdefault(sid,{})
    today=now.date(); now_epoch=now.timestamp(); cfg=_config()
    if ts.get("date")!=today.isoformat():
        ts["date"]=today.isoformat(); ts["fired"]=[]
    fired=ts.setdefault("fired",[])
    catchup=bool(sched.get("catchup",True))
    max_days=max(0,min(31,int(cfg.get("catchup_max_days",7) or 7)))
    window=max(1,int(cfg.get("schedule_window_min",5) or 5))*60
    try: last_scan=float(ts.get("last_scan_at") or 0)
    except Exception: last_scan=0
    floor=now_epoch-(max_days*86400 if catchup else window)
    # The first upgraded scan migrates conservatively: catch up today's missed slots, not
    # an arbitrary week predating installation. After this cursor is written,
    # real downtime is recovered up to catchup_max_days.
    first_scan=datetime.datetime.combine(today,datetime.time.min).timestamp()
    scan_from=max(last_scan,floor) if last_scan else max(floor,first_scan)
    start_dt=datetime.datetime.fromtimestamp(scan_from)

    candidates=[]
    for day in _date_range(start_dt.date(),today):
        if not _active_today(sched,day): continue
        for raw in list(dict.fromkeys(sched.get("runs") or [])):
            hhmm=_valid_hhmm(raw)
            if not hhmm: continue
            hh,mm=map(int,hhmm.split(":")); planned=datetime.datetime.combine(day,datetime.time(hh,mm))
            if planned>now: continue
            if planned.timestamp()+0.001<scan_from: continue
            if not catchup and now_epoch-planned.timestamp()>window: continue
            if day==today and hhmm in fired: continue
            candidates.append((planned,hhmm))
    max_jobs=max(1,min(128,int(cfg.get("catchup_max_jobs_per_schedule",16) or 16)))
    if len(candidates)>max_jobs:
        candidates=sorted(candidates,key=lambda x:x[0])[-max_jobs:]
        _log(f"CATCH-UP '{sid}' bounded to newest {max_jobs} occurrence(s)",
             dedupe_key=f"catchup-cap:{sid}",dedupe_s=3600)
    added=0
    for planned,hhmm in sorted(candidates,key=lambda x:x[0]):
        kind="schedule" if (now_epoch-planned.timestamp())<=window else "catchup"
        ok,_job=_enqueue_job(state,tool_id,profile_id,sched,kind,planned,
                             "schedule" if kind=="schedule" else "catch-up",slot=hhmm)
        added+=int(ok)

    once_date=str(sched.get("once_date") or "").strip(); once_time=_valid_hhmm(sched.get("once_time") or "08:00") or "08:00"
    if once_date and not ts.get("once_fired"):
        try:
            od=datetime.date.fromisoformat(once_date); hh,mm=map(int,once_time.split(":")); planned=datetime.datetime.combine(od,datetime.time(hh,mm))
            delta=now_epoch-planned.timestamp()
            if planned<=now and planned.timestamp()+0.001>=floor and (catchup or delta<=window) and _active_today(sched,od):
                ok,_job=_enqueue_job(state,tool_id,profile_id,sched,"once",planned,"one-off",slot=once_time)
                added+=int(ok)
        except Exception:
            pass

    if manager_session and bool(sched.get("run_on_start")) and ts.get("run_on_start_session")!=manager_session:
        ts["run_on_start_session"]=manager_session
        if added:
            _log(f"RUN-ON-START '{sid}' coalesced with an already due occurrence",
                 dedupe_key=f"startup-coalesce:{sid}:{manager_session}",dedupe_s=86400)
            ts["last_scan_at"]=now_epoch
            return added
        added += _enqueue_run_on_start(state, tool_id, profile_id, sched,
                                       unique=manager_session, source="run-on-start")

    if bool(sched.get("when_online")) and not (sched.get("runs") or []):
        cooldown=max(60,int(sched.get("online_cooldown_s") or 3600))
        last=float(ts.get("condition_last") or 0)
        if now_epoch-last>=cooldown:
            bucket=int(now_epoch//cooldown)
            ok,_job=_enqueue_job(state,tool_id,profile_id,sched,"network-condition",None,
                                 "network-condition",unique=str(bucket))
            added+=int(ok)
    ts["last_scan_at"]=now_epoch
    return added


def _job_retry(state, job, error, collision=False):
    cfg=_config(); now=time.time()
    attempts=int(job.get("attempts") or 0)
    if not collision and attempts>=max(1,int(cfg.get("job_max_attempts",5) or 5)):
        job.update({"state":"failed","error":str(error)[:500],"finished_at":now,"updated_at":now})
        _write_run_status(job.get("agent"),"failed",tool_id=job.get("tool_id"),profile_id=job.get("profile_id"),job_id=job.get("id"),error=str(error)[:500],finished_at=now)
        _log(f"JOB FAILED '{job.get('schedule_id')}' id={job.get('id')}: {error}")
        _run_completion_notify(job, success=False, error=error)
        return
    if collision:
        job["collisions"]=int(job.get("collisions") or 0)+1
        delay=max(2,int(cfg.get("job_retry_base_s",15) or 15))
    else:
        base=max(2,int(cfg.get("job_retry_base_s",15) or 15)); cap=max(base,int(cfg.get("job_retry_max_s",900) or 900))
        delay=min(cap,base*(2**max(0,attempts-1)))
    job.update({"state":"retry","error":str(error)[:500],"next_attempt_at":now+delay,
                "updated_at":now,"pid":None})
    _write_run_status(job.get("agent"),"queued",tool_id=job.get("tool_id"),profile_id=job.get("profile_id"),job_id=job.get("id"),
                      reason=job.get("reason"),slot=job.get("slot"),message=f"retry in {delay}s: {error}",queued_at=now)
    _log(f"JOB RETRY '{job.get('schedule_id')}' id={job.get('id')} in {delay}s: {error}",
         dedupe_key=f"job-retry:{job.get('id')}:{error}",dedupe_s=delay)


def _run_completion_notify(job, success=True, error=""):
    """Desktop completion/failure notification owned by central Wake."""
    try:
        base_tool = str(job.get("tool_id") or "")
        profile_id = str(job.get("profile_id") or "")
        rec = _tool_record(base_tool) or {}
        sched = effective_schedule(rec, profile_id or None) if rec else {}
        mode = str(sched.get("notify_after_run") or "inherit").strip().lower()
        prefs = _load_prefs()
        wanted = (mode == "notify") or (mode == "inherit" and bool(prefs.get("notify_runs", True)))
        if mode == "never" or not wanted:
            return False
        label = str(job.get("agent") or _entry_label(sched, profile_id or base_tool) or base_tool)
        trigger = str(job.get("reason") or job.get("kind") or "background")
        slot = str(job.get("slot") or "")
        suffix = f" · {slot}" if slot else ""
        if success:
            title = f"✓ {label}"
            message = f"Background run completed ({trigger}{suffix})."
        else:
            title = f"⚠ {label}"
            message = f"Background run failed ({trigger}{suffix})" + (f": {str(error)[:160]}" if error else ".")
        try:
            import hq
            ok = bool(hq.notify_desktop(title, message))
        except Exception as exc:
            _log(f"run notification failed for '{job.get('schedule_id')}': {exc}")
            return False
        if ok:
            _log(f"RUN NOTIFY '{job.get('schedule_id')}' -> {'success' if success else 'failure'}")
        return ok
    except Exception as exc:
        _log(f"run notification failed: {exc}")
        return False


def _run_completion_ui(job):
    """Open/reuse the generic A-Tool UI after a successful background run."""
    try:
        base_tool = str(job.get("tool_id") or "")
        profile_id = str(job.get("profile_id") or "")
        rec = _tool_record(base_tool) or {}
        sched = effective_schedule(rec, profile_id or None) if rec else {}
        mode = str(sched.get("ui_after_run") or "inherit").strip().lower()
        prefs = _load_prefs()
        wanted = (mode == "open") or (mode == "inherit" and bool(prefs.get("wake_browser", False)))
        if mode == "never" or not wanted:
            return False
        sid = str(job.get("schedule_id") or _schedule_id(base_tool, profile_id))
        ok, why = open_tool_ui(sid, start_if_needed=True)
        _log(f"RUN UI '{sid}' -> {'opened' if ok else 'failed'}{'' if ok else ': ' + str(why)}")
        return bool(ok)
    except Exception as exc:
        _log(f"run UI after completion failed: {exc}")
        return False


def _job_success(state,job):
    now=time.time(); job.update({"state":"succeeded","error":"","finished_at":now,"updated_at":now,"pid":None})
    sid=str(job.get("schedule_id") or ""); ts=state.setdefault("tools",{}).setdefault(sid,{})
    ts["last_launch_at"]=now
    try:
        due=datetime.datetime.fromtimestamp(float(job.get("due_at") or now))
        if due.date()==datetime.date.today() and job.get("slot"):
            fired=ts.setdefault("fired",[])
            if job["slot"] not in fired: fired.append(job["slot"])
    except Exception: pass
    if job.get("kind")=="once": ts["once_fired"]=now
    if job.get("kind")=="network-condition": ts["condition_last"]=now
    ts.pop("pending_network",None); ts.pop("blocked",None)
    _write_run_status(job.get("agent"),"done",tool_id=job.get("tool_id"),profile_id=job.get("profile_id"),job_id=job.get("id"),
                      reason=job.get("reason"),slot=job.get("slot"),finished_at=now,message="run completed")
    _log(f"JOB DONE '{sid}' id={job.get('id')} attempts={job.get('attempts',0)}")
    _run_completion_notify(job, success=True)
    _run_completion_ui(job)


def _reap_jobs(state):
    changed=False
    for jid,job in list(_jobs(state).items()):
        if not isinstance(job,dict) or job.get("state")!="running": continue
        proc=_JOB_PROCESSES.get(jid); rc=None; finished=False
        if proc is not None:
            rc=proc.poll(); finished=rc is not None
        else:
            pid=job.get("pid")
            if _pid_alive(pid): continue
            finished=True
        if not finished: continue
        result_path=os.path.join(JOB_RESULT_DIR,str(jid)+".json")
        result=_load_json(result_path,{})
        if isinstance(result,dict) and result.get("returncode") is not None:
            try: rc=int(result.get("returncode"))
            except Exception: pass
        status=_read_run_status_for_agent(job.get("agent"),job.get("tool_id"),job.get("profile_id"))
        status_matches=(str(status.get("job_id") or "")==str(jid))
        child_state=str(status.get("state") or "").lower() if status_matches else ""
        if rc==0 or child_state in ("done","succeeded","success"):
            _job_success(state,job)
        elif rc==3 or child_state=="skipped":
            _job_retry(state,job,status.get("message") or "ecosystem run slot busy",collision=True)
        else:
            detail=(result.get("error") if isinstance(result,dict) else "") or (status.get("error") if status_matches else "")
            _job_retry(state,job,detail or f"runner exited with code {rc if rc is not None else 'unknown'}")
        try:
            if os.path.exists(result_path): os.remove(result_path)
        except Exception: pass
        _JOB_PROCESSES.pop(jid,None); changed=True
    return changed


def _drain_job_queue(state):
    """Start independent jobs in parallel; colliding jobs remain queued."""
    changed=_reap_jobs(state)
    jobs=_jobs(state)
    running=[j for j in jobs.values() if isinstance(j,dict) and j.get("state")=="running"]
    try: limit=max(1,min(32,int(_config().get("max_parallel_jobs",4) or 4)))
    except Exception: limit=4
    capacity=max(0,limit-len(running))
    if capacity<=0: return changed
    occupied=set()
    for job in running:
        occupied.update(str(x) for x in (job.get("collision_keys") or []) if str(x))
    now=time.time(); ready=[]
    for job in jobs.values():
        if not isinstance(job,dict) or job.get("state") not in ("pending","retry"): continue
        if float(job.get("next_attempt_at") or 0)>now: continue
        ready.append(job)
    if not ready: return changed
    ready.sort(key=lambda j:(float(j.get("due_at") or 0),float(j.get("created_at") or 0)))
    started=0
    for job in ready:
        if started>=capacity: break
        keys=set(str(x) for x in (job.get("collision_keys") or []) if str(x))
        if keys & occupied: continue
        tool_id=str(job.get("tool_id") or ""); profile_id=str(job.get("profile_id") or "")
        rec=_tool_record(tool_id)
        if not rec:
            job.update({"state":"failed","error":"registered A-Tool no longer exists","finished_at":now,"updated_at":now})
            changed=True; continue
        sched=effective_schedule(rec,profile_id or None)
        launch=sched.get("launch") if isinstance(sched.get("launch"),dict) else {}
        needs_net=bool(launch.get("network_required") or sched.get("network_required") or job.get("kind")=="network-condition")
        if needs_net and not _network_online():
            job["state"]="retry"; job["next_attempt_at"]=now+max(15,int((_config().get("network") or {}).get("retry_interval_s",60) or 60)); job["updated_at"]=now
            _log(f"JOB WAITING NETWORK '{job.get('schedule_id')}' id={job.get('id')}",
                 dedupe_key=f"job-offline:{job.get('id')}",dedupe_s=900)
            changed=True; continue
        proc=_launch_tool(tool_id,sched,slot=job.get("slot") or None,reason=job.get("reason") or job.get("kind") or "schedule",
                          return_process=True,job_id=job.get("id"))
        if not proc:
            why=LAST_LAUNCH_ERROR.get("error") or "launch refused"
            if LAST_LAUNCH_ERROR.get("permanent"):
                job.update({"state":"blocked","error":why,"updated_at":now,"pid":None})
                ts=state.setdefault("tools",{}).setdefault(job.get("schedule_id"),{})
                ts["blocked"]={"key":job.get("launch_key") or "","error":why,"at":now,"wake_release":WAKE_RELEASE}
                _write_run_status(job.get("agent"),"blocked",tool_id=tool_id,profile_id=profile_id,job_id=job.get("id"),error=why,finished_at=now)
                _log(f"JOB BLOCKED '{job.get('schedule_id')}' id={job.get('id')}: {why}")
            else:
                _job_retry(state,job,why)
            changed=True; continue
        job["attempts"]=int(job.get("attempts") or 0)+1
        job.update({"state":"running","pid":int(proc.pid),"started_at":now,"updated_at":now,"error":""})
        _JOB_PROCESSES[job["id"]]=proc
        occupied.update(keys); started+=1; changed=True
        _log(f"JOB START '{job.get('schedule_id')}' id={job.get('id')} PID={proc.pid} attempt={job['attempts']}")
    return changed


def job_status(state=None):
    state=state if isinstance(state,dict) else _load_json(STATE,{})
    jobs=[j for j in _jobs(state).values() if isinstance(j,dict)]
    counts={}
    for job in jobs: counts[job.get("state") or "unknown"]=counts.get(job.get("state") or "unknown",0)+1
    active=sorted((j for j in jobs if j.get("state") in ("pending","retry","running","blocked")),
                  key=lambda j:(float(j.get("next_attempt_at") or j.get("due_at") or 0),str(j.get("id"))))
    return {"counts":counts,"active":active[:100],"total":len(jobs)}


_PERMANENT_LAUNCH_MARKERS = (
    "hash mismatch", "published hash changed", "launch contract changed",
    "not approved", "trust=", "missing executable sha", "missing/unsafe",
    "unsafe/missing", "no valid entrypoint", "incomplete",
)
LAST_LAUNCH_ERROR = {"tool_id": "", "error": "", "permanent": False}


def _launch_advice(why):
    """One actionable sentence per deterministic failure."""
    w = str(why or "").lower()
    if "hash mismatch" in w or "published hash changed" in w:
        return ("the A-Tool's own file changed after it registered with Wake — "
                "start that A-Tool once (its panel republishes the schedule) and this clears itself")
    if "launch contract changed" in w:
        return ("the install path or entrypoint changed since approval — "
                "approve this A-Tool again in the Wake UI")
    if "trust=blocked" in w:
        return "this A-Tool is blocked in the Wake UI"
    if "trust=" in w or "not approved" in w:
        return "approve this A-Tool once in the Wake UI"
    if "missing" in w or "unsafe" in w or "entrypoint" in w:
        return "the registered folder or main file is gone — reinstall or re-register the A-Tool"
    return ""


def _note_launch_failure(tool_id, why):
    permanent = any(k in str(why or "").lower() for k in _PERMANENT_LAUNCH_MARKERS)
    LAST_LAUNCH_ERROR.update({"tool_id": tool_id, "error": str(why or ""), "permanent": permanent})
    return permanent


def _launch_tool(tool_id, sched, slot=None, reason="schedule", return_process=False, job_id=None):
    LAST_LAUNCH_ERROR.update({"tool_id": tool_id, "error": "", "permanent": False})
    ok, why = _is_approved(tool_id, sched)
    if not ok:
        _note_launch_failure(tool_id, why)
        _log(f"SKIP '{tool_id}': {why}")
        return False
    tool_dir = _tool_dir(tool_id, sched)
    if not tool_dir:
        why="unsafe/missing tool folder"
        _note_launch_failure(tool_id,why)
        _log(f"SKIP '{tool_id}': {why}")
        return False

    launch = sched.get("launch") if isinstance(sched.get("launch"), dict) else None
    env = dict(os.environ)
    env["ECO_RUN_SOURCE"] = "wake"
    if slot:
        env["ECO_RUN_SLOT"] = str(slot)
    env["ECO_WAKE_REASON"] = reason
    env["ECO_WAKE_UI_AFTER"] = str(sched.get("ui_after_run") or "inherit")
    env["ECO_WAKE_CENTRAL_AFTER"] = "1"
    env["ECO_TOOL_ID"] = str(tool_id)
    env["ECO_PROFILE_ID"] = str(sched.get("_profile_id") or sched.get("profile_id") or sched.get("entry_id") or sched.get("preset_id") or sched.get("agent") or "")
    env["ECO_ENTRY_ID"] = env["ECO_PROFILE_ID"]
    env["ECO_ENTRY_KIND"] = str(sched.get("entry_kind") or ("profile" if sched.get("agent") else "task"))
    if job_id:
        env["ECO_WAKE_JOB_ID"] = str(job_id)
    try:
        if launch:
            argv = _resolve_launch(tool_dir, sched)
            if not argv:
                raise RuntimeError("no valid entrypoint for this OS")
        else:
            # Backward-compatible A-Tool contract: panel.do_run(agent, False, 'wake', slot)
            main_name = sched.get("main") or "panel.py"
            main_py = _safe_file(tool_dir, main_name, allowed_ext={".py"})
            if not main_py:
                raise RuntimeError("missing/unsafe main .py")
            pub_sha = sched.get("main_sha256")
            if pub_sha and _publisher_trust_configured() and _sha256(main_py) != pub_sha:
                raise RuntimeError("main hash mismatch")
            agent = sched.get("agent") or tool_id
            code = (
                "import sys;" + f"sys.path.insert(0,{tool_dir!r});" +
                "import panel;" +
                f"raise SystemExit(panel.do_run({agent!r},False,'wake',{slot!r}) or 0)"
            )
            argv = [sys.executable, "-c", code]
        if job_id:
            wrapper=os.path.join(HERE,"wake_job_wrapper.py")
            if not os.path.isfile(wrapper):
                raise RuntimeError("Wake job wrapper missing")
            os.makedirs(JOB_RESULT_DIR,exist_ok=True)
            result_path=os.path.join(JOB_RESULT_DIR,str(job_id)+".json")
            try:
                if os.path.exists(result_path): os.remove(result_path)
            except Exception: pass
            argv=[sys.executable,wrapper,result_path,*argv]
        agent=_entry_label(sched,tool_id)
        os.makedirs(os.path.dirname(TOOL_PROCESS_LOG),exist_ok=True)
        _rotate_log(TOOL_PROCESS_LOG,max_bytes=4_000_000,backups=3)
        with open(TOOL_PROCESS_LOG,"a",encoding="utf-8") as child_log:
            proc=subprocess.Popen(argv, cwd=tool_dir, env=env, shell=False,
                                  stdout=child_log, stderr=child_log, stdin=subprocess.DEVNULL,
                                  start_new_session=(os.name=="posix"))
        _write_run_status(agent,"starting",tool_id=tool_id,profile_id=env.get("ECO_PROFILE_ID",""),pid=int(proc.pid),slot=str(slot or ""),reason=reason,
                          job_id=str(job_id or ""),started_at=time.time())
        _log(f"WAKE '{tool_id}' agent='{agent}' slot={slot or '-'} reason={reason} -> PID {proc.pid} started")
        return proc if return_process else True
    except Exception as e:
        try: _write_run_status(_entry_label(sched,tool_id),"error",tool_id=tool_id,profile_id=str(sched.get("_profile_id") or sched.get("profile_id") or sched.get("entry_id") or sched.get("preset_id") or sched.get("agent") or ""),reason=reason,
                               job_id=str(job_id or ""),error=str(e),finished_at=time.time())
        except Exception: pass
        _note_launch_failure(tool_id, e)
        _log(f"FAIL '{tool_id}': {e}")
        return False


def run_due_once(now=None, manager_session=None, drain=True):
    """Scan schedules into a durable queue, then let the one manager drain it.

    A due occurrence is not marked fired when Popen succeeds. It is acknowledged
    only after the runner exits successfully; collision exit 3 remains queued.
    """
    now=now or datetime.datetime.now(); eco=_load_json(ECO,{"atools":[]}); state=_load_json(STATE,{})
    tools_state=state.setdefault("tools",{}); added=0
    _reap_jobs(state)
    for rec in eco.get("atools",[]) if isinstance(eco.get("atools"),list) else []:
        if not isinstance(rec,dict): continue
        tool_id=str(rec.get("id") or "")
        if not tool_id: continue
        published=_published_schedules(rec)
        for profile_id in published:
            sid=_schedule_id(tool_id,profile_id); sched=effective_schedule(rec,profile_id)
            if not sched or sched.get("_wake_enabled") is False: continue
            if sid not in tools_state and len(published)==1 and tool_id in tools_state:
                tools_state[sid]=tools_state.pop(tool_id)
            added+=_revive_resolved_blocked_jobs(state,tool_id,profile_id,sched)
            added+=_schedule_jobs_for_profile(state,tool_id,profile_id,sched,now,manager_session)
    if drain:
        _drain_job_queue(state)
    _prune_jobs(state)
    state["last_tick_at"]=time.time()
    _atomic_json(STATE,state)
    return bool(added or any(j.get("state")=="running" for j in _jobs(state).values() if isinstance(j,dict)))


# ------------------------------- popup ------------------------------------
def _popup_candidates():
    eco = _load_json(ECO, {})
    rows = []
    for p in eco.get("popups", []) if isinstance(eco.get("popups"), list) else []:
        if not isinstance(p, dict):
            continue
        folder = p.get("folder")
        owner=_tool_record(str(p.get("tool") or "")) or {}
        td = _safe_dir(folder, owner.get("install_path")) if (folder or owner.get("install_path")) else None
        if not td:
            continue
        mod = _safe_file(td, p.get("module") or "l4m_popup.py", allowed_ext={".py"})
        if not mod:
            continue
        sha = p.get("sha256")
        if sha and _sha256(mod) != sha:
            continue
        try:
            pub_ts = float(p.get("published_ts") or 0)
        except Exception:
            pub_ts = 0.0
        rows.append((int(p.get("version", 0) or 0), pub_ts, p, mod))
    # Popup release version is the explicit family ordering; publication timestamp
    # breaks ties between releases that deliberately share a version. Restarts use
    # the preserved timestamp and therefore never become "newest" by themselves.
    rows.sort(key=lambda x: (x[0], x[1]), reverse=True)
    return rows


def _save_next_popup_at(ts, tool=None):
    try:
        payload = {
            "next": float(ts),
            "at": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(float(ts))),
            "source": "wake.py",
        }
        if tool:
            payload["tool"] = str(tool)
        _atomic_json(NEXT_POPUP, payload)
    except Exception:
        pass


def _popup_lock_acquire(stale_s=180):
    """Small cross-process lock: only one Wake process may display/reschedule a popup."""
    os.makedirs(os.path.dirname(POPUP_LOCK), exist_ok=True)
    for _ in range(2):
        try:
            fd = os.open(POPUP_LOCK, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
            with os.fdopen(fd, "w", encoding="utf-8") as f:
                json.dump({"pid": os.getpid(), "at": time.time()}, f)
            return True
        except FileExistsError:
            try:
                rec = _load_json(POPUP_LOCK, {})
                age = time.time() - float(rec.get("at") or os.path.getmtime(POPUP_LOCK))
                if age > stale_s:
                    os.remove(POPUP_LOCK)
                    continue
            except Exception:
                try:
                    if time.time() - os.path.getmtime(POPUP_LOCK) > stale_s:
                        os.remove(POPUP_LOCK)
                        continue
                except Exception:
                    pass
            return False
        except Exception:
            return False
    return False


def _popup_lock_release():
    try:
        rec = _load_json(POPUP_LOCK, {})
        if int(rec.get("pid", -1)) == os.getpid():
            os.remove(POPUP_LOCK)
    except Exception:
        pass


def _popup_policy(meta):
    """Use the winning A-Tool's published policy; Wake defaults are fallback only."""
    fallback = (_config().get("popup") or {})
    src = (meta or {}).get("policy") if isinstance((meta or {}).get("policy"), dict) else {}
    def _n(key, default):
        try:
            return int(src.get(key, fallback.get(key, default)) or default)
        except Exception:
            return int(default)
    out = {
        "initial_delay_s": max(0, _n("initial_delay_s", 6 * 60)),
        "min_delay_s": max(60, _n("min_delay_s", 4 * 60 * 60)),
        "max_delay_s": max(60, _n("max_delay_s", 5 * 24 * 60 * 60)),
        "visible_s": max(1, _n("visible_s", 25)),
    }
    if out["max_delay_s"] < out["min_delay_s"]:
        out["min_delay_s"], out["max_delay_s"] = out["max_delay_s"], out["min_delay_s"]
    return out


def _update_registered_popup(meta, **fields):
    """Persist timing on the registered popup itself so restart never resets its clock."""
    eco = _load_json(ECO, {})
    rows = eco.get("popups", []) if isinstance(eco.get("popups"), list) else []
    changed = False
    for rec in rows:
        if not isinstance(rec, dict):
            continue
        same = (rec.get("tool") == meta.get("tool") and
                int(rec.get("version", 0) or 0) == int(meta.get("version", 0) or 0) and
                (not meta.get("sha256") or rec.get("sha256") == meta.get("sha256")))
        if same:
            rec.update(fields)
            changed = True
            break
    if changed:
        eco["popups"] = rows
        _atomic_json(ECO, eco)
    return changed


def _mirror_popup_state(meta, next_run_at=None, last_shown=None, shown_count=None):
    state = _load_json(STATE, {})
    ps = state.setdefault("popup", {})
    ps["owner"] = (meta or {}).get("tool")
    ps["version"] = (meta or {}).get("version")
    if next_run_at is not None:
        ps["next_run_at"] = float(next_run_at)
    if last_shown is not None:
        ps["last_shown"] = float(last_shown)
    if shown_count is not None:
        ps["shown_count"] = int(shown_count)
    _atomic_json(STATE, state)
    if next_run_at is not None:
        _save_next_popup_at(next_run_at, tool=(meta or {}).get("tool"))


def popup_status():
    """Return the winning popup release and its real publisher-owned timing."""
    rows = _popup_candidates()
    if not rows:
        return {"registered": False, "enabled": bool((_config().get("popup") or {}).get("enabled", True))}
    _ver, _published, meta, _mod = rows[0]
    policy = _popup_policy(meta)
    try:
        nxt = float(meta.get("next_run_at")) if meta.get("next_run_at") is not None else None
    except Exception:
        nxt = None
    return {
        "registered": True, "enabled": bool((_config().get("popup") or {}).get("enabled", True)),
        "tool": meta.get("tool"), "version": meta.get("version"),
        "published": meta.get("published"), "published_ts": meta.get("published_ts"),
        "sha256": meta.get("sha256"), "next_run_at": nxt,
        "next_at": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(nxt)) if nxt else None,
        "last_shown": meta.get("last_shown"), "shown_count": int(meta.get("shown_count", 0) or 0),
        "policy": policy,
    }


def reconcile_popup_schedule_on_start():
    """Reconcile a stale popup deadline once when the persistent Wake starts.

    A newly published popup gets its own initial delay from atool_sync.  If Wake was
    stopped/broken long enough for that deadline to pass, startup must NOT fire it
    immediately.  Instead a fresh random post-initial interval is chosen.  While
    Wake stays alive, popup_tick() handles an ordinary due deadline normally.
    """
    if not _popup_lock_acquire():
        return False
    try:
        rows = _popup_candidates()
        if not rows:
            return False
        _ver, _published, meta, _mod = rows[0]
        policy = _popup_policy(meta)
        now = time.time()
        try:
            nxt = float(meta.get("next_run_at")) if meta.get("next_run_at") is not None else None
        except Exception:
            nxt = None
        if nxt is None:
            nxt = now + policy["initial_delay_s"]
            _update_registered_popup(meta, next_run_at=nxt)
            _mirror_popup_state(meta, next_run_at=nxt, last_shown=meta.get("last_shown"),
                                shown_count=int(meta.get("shown_count", 0) or 0))
            return True
        if nxt <= now:
            lo, hi = policy["min_delay_s"], policy["max_delay_s"]
            nxt = now + random.randint(lo, hi)
            _update_registered_popup(meta, next_run_at=nxt)
            _mirror_popup_state(meta, next_run_at=nxt, last_shown=meta.get("last_shown"),
                                shown_count=int(meta.get("shown_count", 0) or 0))
            _log("POPUP stale deadline on Wake startup -> rescheduled to " +
                 time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(nxt)))
            return True
        _mirror_popup_state(meta, next_run_at=nxt, last_shown=meta.get("last_shown"),
                            shown_count=int(meta.get("shown_count", 0) or 0))
        return False
    finally:
        _popup_lock_release()


def show_popup_now(force=True, meta=None, mod=None):
    if meta is None or mod is None:
        rows = _popup_candidates()
        if not rows:
            return False, "no registered popup module"
        _ver, _published, meta, mod = rows[0]
    policy = _popup_policy(meta)
    argv = [sys.executable, mod, "--show-now", "--timeout", str(int(policy["visible_s"]))]
    try:
        proc = subprocess.Popen(argv, cwd=os.path.dirname(mod), shell=False,
                                stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        # Popen succeeding means the process STARTED, not that anything appeared on
        # screen. Without a display, without Tk or on an import error the child dies
        # at once — and Wake used to record "shown" and push the next popup 4 h..5 d
        # away. That is why a popup can silently never appear while the log claims it
        # did. Give it a moment and check it is still alive.
        try:
            rc = proc.wait(timeout=1.5)
        except Exception:
            rc = None                     # still running after 1.5 s = actually showing
        if rc is not None and rc != 0:
            try:
                out = (proc.stdout.read() or b"").decode("utf-8", "ignore").strip()[:200]
            except Exception:
                out = ""
            _log(f"POPUP FAIL: '{meta.get('tool')}' exited at once (code {rc}){': ' + out if out else ''}")
            return False, f"popup process exited immediately (code {rc}) {out}".strip()
        _log(f"POPUP v{meta.get('version')} from '{meta.get('tool')}' -> shown ({policy['visible_s']}s)")
        return True, meta.get("tool") or ""
    except Exception as e:
        _log(f"POPUP FAIL: {e}")
        return False, str(e)


def popup_tick(force=False):
    """One owner, one clock. Only Wake executes the winning registered popup."""
    if not force and not bool((_config().get("popup") or {}).get("enabled", True)):
        return False
    if not _popup_lock_acquire():
        return False
    try:
        rows = _popup_candidates()  # reload only after lock: another process may have rescheduled it
        if not rows:
            return False
        _ver, _published, meta, mod = rows[0]
        policy = _popup_policy(meta)
        now = time.time()
        next_run = meta.get("next_run_at")
        try:
            next_run = float(next_run) if next_run is not None else None
        except Exception:
            next_run = None
        if not next_run:
            next_run = now + policy["initial_delay_s"]
            _update_registered_popup(meta, next_run_at=next_run)
            meta["next_run_at"] = next_run
        _mirror_popup_state(meta, next_run_at=next_run,
                            last_shown=meta.get("last_shown"),
                            shown_count=int(meta.get("shown_count", 0) or 0))
        if not force and now < next_run:
            return False
        ok, _why = show_popup_now(force=True, meta=meta, mod=mod)
        if not ok:
            # Back off instead of hammering a display that cannot work, and never
            # leave a past timestamp on screen labelled "next popup".
            fails = int(meta.get("failed_attempts", 0) or 0) + 1
            retry_in = min(6 * 3600, 300 * (2 ** min(fails - 1, 7)))
            retry_at = time.time() + retry_in
            _update_registered_popup(meta, next_run_at=retry_at, failed_attempts=fails,
                                     last_error=str(_why or "")[:200])
            _mirror_popup_state(meta, next_run_at=retry_at,
                                last_shown=meta.get("last_shown"),
                                shown_count=int(meta.get("shown_count", 0) or 0))
            if fails in (1, 3, 6):
                _log(f"POPUP could not be shown ({_why}); retry in {int(retry_in//60)} min "
                     f"(attempt {fails})")
            return False
        lo, hi = policy["min_delay_s"], policy["max_delay_s"]
        shown_at = time.time()
        new_next = shown_at + random.randint(lo, hi)
        count = int(meta.get("shown_count", 0) or 0) + 1
        _update_registered_popup(meta, last_shown=shown_at, shown_count=count, next_run_at=new_next,
                                 failed_attempts=0, last_error="")
        _mirror_popup_state(meta, next_run_at=new_next, last_shown=shown_at, shown_count=count)
        _log("POPUP next -> " + time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(new_next)) +
             f" (random {lo//3600}h..{hi//86400}d)")
        return True
    finally:
        _popup_lock_release()


def calendar_items():
    raw = _load_json(CALENDAR, [])
    return raw if isinstance(raw, list) else []


def calendar_upsert(index, item):
    """Create/update one shared main-calendar item without importing any A-Tool panel."""
    item = dict(item or {})
    title = str(item.get("title") or "").strip()
    if not title:
        raise ValueError("calendar title is required")
    kind = str(item.get("kind") or "event").strip().lower()
    if kind not in ("deadline", "note", "event", "task"):
        raise ValueError("calendar kind must be deadline, note, event or task")
    when = str(item.get("when") or "").strip()
    tm = str(item.get("time") or "").strip()
    if tm and not _valid_hhmm(tm):
        raise ValueError("calendar time must be HH:MM")
    rec = {
        "agent": str(item.get("agent") or "Wake").strip()[:80] or "Wake",
        "kind": kind, "title": title[:200], "when": when, "time": _valid_hhmm(tm) or "",
        "note": str(item.get("note") or "")[:500],
        "lead_days": item.get("lead_days") if isinstance(item.get("lead_days"), list) else [1],
        "remind_2h": bool(item.get("remind_2h", True)),
        "added": item.get("added") or datetime.datetime.now().isoformat(timespec="seconds"),
    }
    rows = calendar_items()
    try:
        idx = int(index) if index is not None else -1
    except Exception:
        idx = -1
    if 0 <= idx < len(rows):
        rec["added"] = rows[idx].get("added") or rec["added"]
        rows[idx] = rec
        out_index = idx
    else:
        rows.append(rec); out_index = len(rows) - 1
    _atomic_json(CALENDAR, rows)
    return out_index, rec


def calendar_delete(index):
    rows = calendar_items()
    try: idx = int(index)
    except Exception: return False
    if not (0 <= idx < len(rows)):
        return False
    rows.pop(idx); _atomic_json(CALENDAR, rows); return True


# --------------------------- main calendar watch ---------------------------
def _calendar_dt(item):
    raw = str(item.get("when") or "").strip()
    d = None
    for fmt in ("%Y-%m-%d", "%d.%m.%Y", "%d/%m/%Y"):
        try:
            d = datetime.datetime.strptime(raw, fmt).date(); break
        except Exception:
            pass
    if d is None:
        # legacy DD.MM without year
        try:
            dd, mm = [int(x) for x in raw.split(".")[:2]]
            d = datetime.date.today().replace(month=mm, day=dd)
        except Exception:
            return None, None
    t = None
    if str(item.get("time") or "").strip():
        try:
            hh, mm = map(int, str(item.get("time")).split(":")[:2]); t = datetime.time(hh, mm)
        except Exception:
            t = None
    return d, t


def _calendar_key(item):
    raw = "|".join(str(item.get(k) or "") for k in ("agent","kind","title","when","time"))
    return hashlib.sha1(raw.encode("utf-8", "ignore")).hexdigest()[:16]


def _calendar_notify(title, message):
    try:
        import hq
        return bool(hq.notify_desktop(title, message))
    except Exception as e:
        _log(f"calendar notify failed: {e}"); return False


def calendar_tick(now=None):
    """Deliver main-calendar reminders outside the browser, once per reminder edge."""
    now = now or datetime.datetime.now()
    cal = _load_json(CALENDAR, [])
    if not isinstance(cal, list): return 0
    state = _load_json(STATE, {})
    fired = state.setdefault("calendar_fired", {})
    # keep state bounded
    cutoff = time.time() - 60 * 86400
    for k in list(fired):
        try:
            if float(fired[k]) < cutoff: fired.pop(k, None)
        except Exception: fired.pop(k, None)
    count = 0
    for item in cal:
        if not isinstance(item, dict): continue
        due, clock = _calendar_dt(item)
        if due is None: continue
        delta = (due - now.date()).days
        base = _calendar_key(item)
        leads = item.get("lead_days", [1])
        if not isinstance(leads, list): leads = [leads]
        try: leads = [int(x) for x in leads]
        except Exception: leads = [1]
        if delta in leads:
            key = f"{base}:day:{delta}"
            if key not in fired:
                when = "today" if delta == 0 else ("tomorrow" if delta == 1 else f"in {delta} days")
                if _calendar_notify(f"📅 Reminder ({when})", f"{item.get('title','')} — {item.get('when','')}"):
                    fired[key] = time.time(); count += 1
        if item.get("remind_2h", True) and clock is not None:
            event_dt = datetime.datetime.combine(due, clock)
            seconds = (event_dt - now).total_seconds()
            key = f"{base}:2h"
            if 0 <= seconds <= 2 * 3600 and key not in fired:
                if _calendar_notify("⏰ Reminder (within 2 hours)", f"{item.get('title','')} — {item.get('time','')}"):
                    fired[key] = time.time(); count += 1
    _atomic_json(STATE, state)
    return count


def calendar_status(now=None):
    now = now or datetime.datetime.now()
    cal = _load_json(CALENDAR, [])
    upcoming=[]
    for item in cal if isinstance(cal,list) else []:
        if not isinstance(item,dict): continue
        d,t=_calendar_dt(item)
        if d is None: continue
        dt=datetime.datetime.combine(d,t or datetime.time(23,59))
        if dt >= now:
            upcoming.append((dt,item))
    upcoming.sort(key=lambda x:x[0])
    nxt=upcoming[0] if upcoming else None
    return {"path": CALENDAR, "items": len(cal) if isinstance(cal,list) else 0,
            "upcoming": len(upcoming),
            "next": ({"at": nxt[0].isoformat(timespec="minutes"), "title": nxt[1].get("title","")} if nxt else None)}


# --------------------------- background process ----------------------------
def _pid_alive(pid):
    try:
        pid = int(pid)
        if pid <= 0: return False
        if sys.platform.startswith("win"):
            r = subprocess.run(["tasklist", "/FI", f"PID eq {pid}"], capture_output=True, text=True)
            return str(pid) in (r.stdout or "")
        # kill(pid, 0) still succeeds for a zombie. On Linux that made a
        # terminated Wake look alive until its parent reaped it, blocking an
        # immediate release switch. Treat Z as dead.
        if sys.platform.startswith("linux"):
            try:
                stat = open(f"/proc/{pid}/stat", encoding="utf-8").read().split()
                if len(stat) > 2 and stat[2] == "Z":
                    try: os.waitpid(pid, os.WNOHANG)
                    except Exception: pass
                    return False
            except FileNotFoundError:
                return False
            except Exception:
                pass
        os.kill(pid, 0)
        return True
    except Exception:
        return False


def status():
    ps = _load_json(PID_FILE, {})
    hb = _load_json(HEARTBEAT_FILE, {})
    st = _load_json(STATE, {})
    cfg = _config()
    prefs = _load_prefs()
    try: heartbeat_fresh=(time.time()-float(hb.get("at") or 0))<max(3.0,float(cfg.get("command_poll_s",1) or 1)*4)
    except Exception: heartbeat_fresh=False
    heartbeat_matches=(hb.get("pid")==ps.get("pid") and hb.get("wake_release")==ps.get("wake_release") and hb.get("runtime_file")==ps.get("runtime_file"))
    return {
        "running": bool(_pid_alive(ps.get("pid")) or (heartbeat_fresh and heartbeat_matches)), "pid": ps.get("pid"),
        "started": ps.get("started"), "mode": ps.get("mode"), "tray_backend": ps.get("tray_backend"),
        "wake_release": ps.get("wake_release"), "runtime_file": ps.get("runtime_file"),
        "heartbeat_at": hb.get("at"),
        "config": cfg, "prefs": prefs,
        "autostart": autostart_status(),
        "state": st, "next_popup": _load_json(NEXT_POPUP, None),
        "popup": popup_status(),
        "calendar": calendar_status(),
        "jobs": job_status(st),
        "pending_commands": len([x for x in os.listdir(COMMAND_DIR) if x.endswith(".json")]) if os.path.isdir(COMMAND_DIR) else 0,
        "tools": list_tool_schedules(),
        "ecosystem": ECO, "log": LOG, "current_log": SESSION_LOG, "process_log": PROCESS_LOG, "tool_process_log": TOOL_PROCESS_LOG,
    }


def _write_pid(mode, tray_backend=None):
    rec = {
        "pid": os.getpid(),
        "started": datetime.datetime.now().isoformat(),
        "mode": mode,
        "wake_release": WAKE_RELEASE,
        "runtime_file": os.path.realpath(__file__),
    }
    if tray_backend:
        rec["tray_backend"] = tray_backend
    _atomic_json(PID_FILE, rec)


def _write_heartbeat():
    _atomic_json(HEARTBEAT_FILE,{"pid":os.getpid(),"wake_release":WAKE_RELEASE,
                                 "runtime_file":os.path.realpath(__file__),"at":time.time()})


def _active_runtime_identity():
    """Return the central Wake release selected by active.json, if available."""
    active_path = os.path.join(ECO_DIR, "system", "wake", "active.json")
    meta = _load_json(active_path, {})
    if not isinstance(meta, dict) or not meta:
        return None, None
    try:
        rel = int(meta.get("wake_release"))
    except Exception:
        rel = None
    version_dir = str(meta.get("version_dir") or "").replace("/", os.sep)
    entry = os.path.realpath(os.path.join(ECO_DIR, "system", "wake", version_dir, "wake.py")) if version_dir else None
    return rel, entry


def _running_runtime_is_active(st):
    """False when an older in-memory Wake survived a central release promotion."""
    active_release, active_entry = _active_runtime_identity()
    if active_release is None or not active_entry:
        return True
    try:
        running_release = int(st.get("wake_release"))
    except Exception:
        running_release = None
    running_file = os.path.realpath(str(st.get("runtime_file") or "")) if st.get("runtime_file") else None
    # Historical PID files have no release/runtime identity: after a central
    # promotion they must be replaced once, otherwise new code never becomes live.
    return running_release == active_release and running_file == active_entry


def _known_wake_paths():
    """Exact wake.py paths published by registered sibling A-Tools plus this copy."""
    out = {os.path.abspath(__file__)}
    eco = _load_json(ECO, {"atools": []})
    for rec in eco.get("atools", []) if isinstance(eco.get("atools"), list) else []:
        if not isinstance(rec, dict):
            continue
        td = _safe_dir(rec.get("path"), rec.get("install_path"))
        if td:
            cand = os.path.join(td, "wake.py")
            if os.path.isfile(cand):
                out.add(os.path.abspath(cand))
    return out


def _looks_like_timesavers_wake(path):
    """Recognise our historical wake.py copies without killing unrelated scripts."""
    try:
        path = os.path.abspath(path)
        if os.path.basename(path).lower() != "wake.py" or not os.path.isfile(path):
            return False
        text = open(path, encoding="utf-8", errors="ignore").read(24000)
        return ("ecosystem wake manager" in text.lower() or "time savers wake" in text.lower()) and "ecosystem.json" in text
    except Exception:
        return False


def _wake_script_from_commandline(args, pid=None):
    try:
        import shlex
        toks = shlex.split(str(args), posix=not sys.platform.startswith("win"))
    except Exception:
        toks = str(args).replace('"', ' ').split()
    for tok in toks:
        if not str(tok).lower().endswith("wake.py"):
            continue
        raw = str(tok)
        if os.path.isabs(raw):
            return os.path.abspath(raw)
        if pid and sys.platform.startswith("linux"):
            try:
                cwd = os.readlink(f"/proc/{int(pid)}/cwd")
                return os.path.abspath(os.path.join(cwd, raw))
            except Exception:
                pass
        return os.path.abspath(raw)
    return None


def _legacy_wake_pids():
    """Find old Time Savers Wake processes that predate the shared singleton lock."""
    paths = _known_wake_paths()
    found = []
    try:
        if sys.platform.startswith("win"):
            ps_script = (
                "Get-CimInstance Win32_Process | "
                "Where-Object {$_.CommandLine -like '*wake.py*'} | "
                "ForEach-Object {[string]$_.ProcessId + [char]9 + $_.CommandLine}"
            )
            cmd = ["powershell", "-NoProfile", "-Command", ps_script]
            text = subprocess.run(cmd, capture_output=True, text=True, timeout=8, check=False).stdout or ""
            rows = []
            for line in text.splitlines():
                try:
                    pid_s, args = line.split("\t", 1); rows.append((int(pid_s), args))
                except Exception:
                    pass
        else:
            text = subprocess.run(["ps", "-eo", "pid=,args="], capture_output=True, text=True, timeout=8, check=False).stdout or ""
            rows = []
            for line in text.splitlines():
                line = line.strip()
                if not line: continue
                try:
                    pid_s, args = line.split(None, 1); rows.append((int(pid_s), args))
                except Exception:
                    pass
        for pid, args in rows:
            if pid == os.getpid() or ("--tray" not in args and "--daemon" not in args):
                continue
            script = _wake_script_from_commandline(args, pid=pid)
            if any(path in args for path in paths) or (script and _looks_like_timesavers_wake(script)):
                found.append(pid)
    except Exception:
        pass
    return sorted(set(found))


def _cleanup_legacy_wake_duplicates():
    """One-time compatibility cleanup for older Wake copies that ignored the lock."""
    killed = []
    for pid in _legacy_wake_pids():
        if _terminate_managed_process(pid):
            killed.append(pid)
    if killed:
        _log("Wake singleton cleanup: stopped legacy duplicate PID(s) " + ", ".join(map(str, killed)))
    return killed


def _instance_lock_owner():
    return _load_json(os.path.join(INSTANCE_LOCK, "owner.json"), {})


def _instance_lock_acquire(mode):
    """Own the one persistent Wake manager slot across tray/daemon modes.

    mkdir is atomic on Windows/Linux/macOS. A stale lock is reclaimed only when
    its recorded PID is no longer alive. This prevents daemon+tray or two tray
    processes from both becoming active owners during concurrent startup.
    """
    os.makedirs(ECO_DIR, exist_ok=True)
    for _ in range(3):
        try:
            os.mkdir(INSTANCE_LOCK)
            try:
                if os.name == "posix": os.chmod(INSTANCE_LOCK, 0o700)
            except Exception: pass
            _atomic_json(os.path.join(INSTANCE_LOCK, "owner.json"), {
                "pid": os.getpid(), "mode": str(mode or "wake"),
                "started": datetime.datetime.now().isoformat(),
            })
            return True, os.getpid()
        except FileExistsError:
            owner = _instance_lock_owner()
            pid = owner.get("pid")
            if _pid_alive(pid):
                return False, pid
            try:
                shutil.rmtree(INSTANCE_LOCK)
            except Exception:
                time.sleep(0.05)
        except Exception as e:
            _log(f"Wake singleton lock failed: {e}")
            return False, None
    owner = _instance_lock_owner()
    return False, owner.get("pid")


def _next_manager_delay():
    """Sleep until the nearest useful event, bounded by command responsiveness."""
    cfg=_config()
    ceiling=max(1.0,float(cfg.get("check_interval_s",30) or 30))
    poll=max(0.25,min(ceiling,float(cfg.get("command_poll_s",1) or 1)))
    if os.path.isdir(COMMAND_DIR):
        try:
            if any(name.endswith(".json") for name in os.listdir(COMMAND_DIR)):
                return 0.05
        except Exception: pass
    now=time.time(); delays=[ceiling,poll]
    state=_load_json(STATE,{})
    for job in _jobs(state).values():
        if not isinstance(job,dict): continue
        if job.get("state")=="running": delays.append(0.5)
        elif job.get("state") in ("pending","retry"):
            delays.append(max(0.05,float(job.get("next_attempt_at") or now)-now))
    for row in list_tool_schedules():
        raw=row.get("next_run_at")
        if raw:
            try: delays.append(max(0.05,datetime.datetime.fromisoformat(raw).timestamp()-now))
            except Exception: pass
    pop=popup_status(); nxt=pop.get("next_run_at")
    if nxt:
        try: delays.append(max(0.05,float(nxt)-now))
        except Exception: pass
    return max(0.05,min(delays))


def _instance_lock_release():
    try:
        owner = _instance_lock_owner()
        if int(owner.get("pid", -1)) == os.getpid():
            shutil.rmtree(INSTANCE_LOCK)
    except Exception:
        pass


def _clear_pid():
    try:
        cur = _load_json(PID_FILE, {})
        if int(cur.get("pid", -1)) == os.getpid():
            os.remove(PID_FILE)
            hb=_load_json(HEARTBEAT_FILE,{})
            if int(hb.get("pid",-1))==os.getpid() and os.path.exists(HEARTBEAT_FILE): os.remove(HEARTBEAT_FILE)
    except Exception:
        pass


def run_forever():
    owned, owner_pid = _instance_lock_acquire("daemon")
    if not owned:
        _log(f"Wake daemon not started: persistent Wake already owned by PID {owner_pid}")
        return
    _cleanup_legacy_wake_duplicates()
    _begin_session_log("daemon")
    _write_pid("daemon")
    _write_heartbeat()
    try:
        try:
            import system_setup
            system_setup.first_run_preflight(auto_install=False, include_system=True)
        except Exception as e:
            _log(f"dependency preflight warning: {e}")
        _ensure_default_autostart()
        reconcile_popup_schedule_on_start()
        session_id = _start_manager_session("daemon")
        _log("wake daemon RUNNING")
        while True:
            try: _write_heartbeat()
            except Exception: pass
            try: _process_commands()
            except Exception as e: _log(f"Wake command queue error: {e}")
            try: run_due_once(manager_session=session_id)
            except Exception as e: _log(f"wake tick error: {e}")
            try: popup_tick()
            except Exception as e: _log(f"popup tick error: {e}")
            try: calendar_tick()
            except Exception as e: _log(f"calendar tick error: {e}")
            time.sleep(_next_manager_delay())
    finally:
        _clear_pid()
        _instance_lock_release()


def _terminate_managed_process(pid):
    try:
        pid = int(pid or 0)
        if pid <= 0 or not _pid_alive(pid):
            return True
        if sys.platform.startswith("win"):
            subprocess.run(["taskkill", "/PID", str(pid), "/T", "/F"],
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=8, check=False)
        else:
            import signal
            os.kill(pid, signal.SIGTERM)
        for _ in range(30):
            if not _pid_alive(pid):
                return True
            time.sleep(0.1)
        return not _pid_alive(pid)
    except Exception as e:
        _log(f"managed process stop failed: {e}")
        return False


def ensure_background_process(with_tray=True):
    st = status()
    requested = "tray" if with_tray else "daemon"
    if st.get("running"):
        # Promotion changes active.json, but an already-running tray keeps old
        # Python code in memory. Replace it automatically instead of reporting
        # a stale process as "background ready".
        if not _running_runtime_is_active(st):
            old_pid = st.get("pid")
            _log(f"Wake release switch: replacing stale PID {old_pid} with active central release")
            if not _terminate_managed_process(old_pid):
                return False, f"could not replace stale Wake PID {old_pid}"
            _clear_pid()
        # A hidden daemon is not a tray. Upgrade it instead of falsely reporting tray readiness.
        elif with_tray and st.get("mode") != "tray":
            old_pid = st.get("pid")
            _log(f"Wake upgrade: {st.get('mode') or 'unknown'} PID {old_pid} -> tray")
            if not _terminate_managed_process(old_pid):
                return False, f"could not replace Wake PID {old_pid} with tray"
            _clear_pid()
        else:
            return True, st.get("pid")
    arg = "--tray" if with_tray else "--daemon"
    kwargs = {}
    if sys.platform.startswith("win"):
        kwargs["creationflags"] = getattr(subprocess, "CREATE_NO_WINDOW", 0) | getattr(subprocess, "DETACHED_PROCESS", 0)
    elif os.name == "posix":
        # Wake is a separate manager and must survive Ctrl+C / terminal exit of panel.py.
        kwargs["start_new_session"] = True
    try:
        os.makedirs(os.path.dirname(LOG), exist_ok=True)
        # _log() already writes structured events to wake.log.  Sending stdout to
        # the same file duplicates every line.  Keep raw interpreter/traceback
        # output in a separate process log instead.
        _rotate_log(PROCESS_LOG, max_bytes=2_000_000, backups=2)
        child_log = open(PROCESS_LOG, "a", encoding="utf-8")
        central_boot = os.path.join(ECO_DIR, "system", "wake", "my_wake.py")
        launch_script = central_boot if os.path.isfile(central_boot) else os.path.abspath(__file__)
        launch_cwd = os.path.dirname(launch_script)
        p = subprocess.Popen([sys.executable, launch_script, arg], cwd=launch_cwd,
                             stdout=child_log, stderr=child_log, stdin=subprocess.DEVNULL,
                             shell=False, **kwargs)
        child_log.close()
        # Imports/tray discovery can take several seconds on a cold Python start.
        # Accept the exact active runtime even when a platform launcher reports a
        # different wrapper PID; never return false while the verified manager is live.
        early_exit=None
        for _ in range(60):
            time.sleep(0.10)
            cur = status()
            if cur.get("running") and _running_runtime_is_active(cur):
                return True, cur.get("pid")
            if p.poll() is not None:
                # Some launchers/wrappers exit after handing off to a different
                # PID. Keep waiting for the verified active runtime instead of
                # returning a false failure while that hand-off is still starting.
                early_exit=p.returncode
        cur = status()
        if cur.get("running"):
            return True, cur.get("pid")
        suffix=f" (starter exit {early_exit})" if early_exit is not None else ""
        return False, f"Wake {requested} did not become ready{suffix}; see {LOG}"
    except Exception as e:
        return False, str(e)


# ------------------------------ autostart ----------------------------------
def _prefs_path():
    return os.path.join(os.path.expanduser(os.environ.get("ENGINE_HOME", "~/agentsystem")), "scheduler_prefs.json")

def _load_prefs():
    p = _load_json(_prefs_path(), {})
    cfg = _config()
    return {"autostart": p.get("autostart", cfg.get("autostart", True)),
            "wake_browser": p.get("wake_browser", cfg.get("wake_browser", False)),
            "notify_runs": p.get("notify_runs", cfg.get("notify_runs", True)),
            "minimized": p.get("minimized", True)}


def _save_prefs(p): _atomic_json(_prefs_path(), p)


def update_settings(data):
    """Update Wake-owned settings only.

    Popup cadence/visibility belong to the winning published popup release.  Wake
    exposes them read-only and may only globally enable/disable popup delivery.
    Legacy timing keys are accepted but intentionally ignored.
    """
    data = data or {}
    cfg = _config()
    prefs = _load_prefs()
    def _ival(key, default, lo, hi):
        try: return max(lo, min(hi, int(data.get(key, default))))
        except Exception: return default
    if "check_interval_s" in data:
        cfg["check_interval_s"] = _ival("check_interval_s", int(cfg.get("check_interval_s",30)), 5, 3600)
    if "schedule_window_min" in data:
        cfg["schedule_window_min"] = _ival("schedule_window_min", int(cfg.get("schedule_window_min",5)), 1, 120)
    if "max_parallel_jobs" in data:
        cfg["max_parallel_jobs"] = _ival("max_parallel_jobs", int(cfg.get("max_parallel_jobs",4)), 1, 32)
    if "retry_pending_when_online" in data:
        cfg.setdefault("network", {})["retry_pending_when_online"] = bool(data.get("retry_pending_when_online"))
    if "wake_browser" in data:
        prefs["wake_browser"] = bool(data.get("wake_browser"))
    if "notify_runs" in data:
        prefs["notify_runs"] = bool(data.get("notify_runs"))
    if "popup_enabled" in data:
        cfg.setdefault("popup", {})["enabled"] = bool(data.get("popup_enabled"))
    _atomic_json(CONFIG, cfg)
    _save_prefs(prefs)
    return status()


def _autostart_target():
    if sys.platform.startswith("win"):
        startup = os.path.join(os.environ.get("APPDATA", ""), r"Microsoft\Windows\Start Menu\Programs\Startup")
        return os.path.join(startup, "TimeSavers-Wake.bat")
    if sys.platform == "darwin":
        return os.path.expanduser("~/Library/LaunchAgents/com.timesavers.wake.plist")
    return os.path.expanduser("~/.config/autostart/timesavers-wake.desktop")


def autostart_status():
    prefs = _load_prefs()
    target = _autostart_target()
    return {
        "enabled": bool(prefs.get("autostart", True)),
        "installed": bool(target and os.path.exists(target)),
        "path": target,
    }


def install_autostart(base_dir=None, enable=True):
    # OS autostart always points at the one stable bootstrap in AgentSystem.
    py = sys.executable
    wake_py = os.path.join(ECO_DIR, "system", "wake", "my_wake.py")
    if enable and not os.path.isfile(wake_py):
        return False, "central Wake bootstrap missing; start an A-Tool once to initialize it"
    try:
        if sys.platform.startswith("win"):
            startup = os.path.join(os.environ.get("APPDATA", ""), r"Microsoft\Windows\Start Menu\Programs\Startup")
            bat = os.path.join(startup, "TimeSavers-Wake.bat")
            if enable:
                os.makedirs(startup, exist_ok=True)
                with open(bat, "w", encoding="utf-8") as f:
                    f.write(f'@echo off\nstart "" "{py}" "{wake_py}" --tray\n')
            elif os.path.exists(bat): os.remove(bat)
            return True, bat
        if sys.platform == "darwin":
            d = os.path.expanduser("~/Library/LaunchAgents"); os.makedirs(d, exist_ok=True)
            plist = os.path.join(d, "com.timesavers.wake.plist")
            if enable:
                data = ('<?xml version="1.0" encoding="UTF-8"?>\n'
                        '<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">\n'
                        '<plist version="1.0"><dict><key>Label</key><string>com.timesavers.wake</string>'
                        f'<key>ProgramArguments</key><array><string>{py}</string><string>{wake_py}</string><string>--tray</string></array>'
                        '<key>RunAtLoad</key><true/><key>KeepAlive</key><true/></dict></plist>')
                open(plist, "w", encoding="utf-8").write(data)
            elif os.path.exists(plist): os.remove(plist)
            return True, plist
        d = os.path.expanduser("~/.config/autostart"); os.makedirs(d, exist_ok=True)
        desktop = os.path.join(d, "timesavers-wake.desktop")
        if enable:
            open(desktop, "w", encoding="utf-8").write(
                "[Desktop Entry]\nType=Application\nName=A-Tools Wake\n"
                f'Exec="{py}" "{wake_py}" --tray\nX-GNOME-Autostart-enabled=true\nTerminal=false\n')
        elif os.path.exists(desktop): os.remove(desktop)
        return True, desktop
    except Exception as e:
        return False, str(e)


def _ensure_default_autostart():
    p = _load_prefs()
    if p.get("autostart", True):
        ok, where = install_autostart(enable=True)
        if ok:
            p["autostart"] = True; _save_prefs(p)
        return ok, where
    return True, "disabled by user"


# ------------------------------- calendars --------------------------------
def _ics_escape(s):
    return str(s or "").replace("\\", "\\\\").replace(";", "\\;").replace(",", "\\,").replace("\n", "\\n")


def export_wake_ics(path=None):
    """Export schedules only. Main deadlines remain hq.export_ics()."""
    eco = _load_json(ECO, {"atools": []})
    path = path or os.path.join(ECO_DIR, "wake-schedule.ics")
    lines = ["BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//A-Tools//Wake Schedule//EN"]
    today = datetime.date.today()
    for a in eco.get("atools", []):
        sl = effective_schedule(a)
        if sl.get("_wake_enabled") is False:
            continue
        for hhmm in sl.get("runs") or []:
            try:
                hh, mm = map(int, str(hhmm).split(":")[:2])
            except Exception: continue
            dt = datetime.datetime.combine(today, datetime.time(hh, mm))
            uid = hashlib.sha1(f"{a.get('id')}|{hhmm}".encode()).hexdigest()[:16]
            lines += ["BEGIN:VEVENT", f"UID:wake-{uid}@timesavers",
                      f"DTSTART:{dt.strftime('%Y%m%dT%H%M%S')}", "RRULE:FREQ=DAILY",
                      f"SUMMARY:{_ics_escape('Wake: '+str(a.get('id') or '?'))}", "END:VEVENT"]
        if sl.get("once_date"):
            try:
                od=datetime.date.fromisoformat(str(sl.get("once_date")))
                hh,mm=map(int,str(sl.get("once_time") or "08:00").split(":")[:2])
                dt=datetime.datetime.combine(od,datetime.time(hh,mm))
                uid=hashlib.sha1(f"{a.get('id')}|once|{od}|{hh}:{mm}".encode()).hexdigest()[:16]
                lines += ["BEGIN:VEVENT", f"UID:wake-once-{uid}@timesavers",
                          f"DTSTART:{dt.strftime('%Y%m%dT%H%M%S')}",
                          f"SUMMARY:{_ics_escape('Wake once: '+str(a.get('id') or '?'))}", "END:VEVENT"]
            except Exception: pass
    np = _load_json(NEXT_POPUP, {})
    if np.get("next"):
        dt = datetime.datetime.fromtimestamp(float(np["next"]))
        lines += ["BEGIN:VEVENT", "UID:wake-popup@timesavers", f"DTSTART:{dt.strftime('%Y%m%dT%H%M%S')}",
                  "SUMMARY:A-Tools popup", "END:VEVENT"]
    lines.append("END:VCALENDAR")
    os.makedirs(os.path.dirname(path), exist_ok=True)
    open(path, "w", encoding="utf-8").write("\r\n".join(lines) + "\r\n")
    return path


# ------------------------------ tray / UI ---------------------------------
def _tool_port(base_dir=None):
    base_dir = base_dir or HERE
    for fn in ("runtime.json", "atool.json"):
        try:
            d = json.load(open(os.path.join(base_dir, fn), encoding="utf-8"))
            p = d.get("port") or d.get("panel_port")
            if p: return int(p)
        except Exception: pass
    return None


def _open_panel_browser(base_dir=None, wake_ui=False):
    p = _tool_port(base_dir)
    if not p:
        return False
    # Wake may outlive the browser panel.  Start the local panel if needed so the
    # tray's "Wake control" works as a real entry point, not a dead bookmark.
    import urllib.request, webbrowser
    url = f"http://localhost:{p}/" + ("?wake=1" if wake_ui else "")
    try:
        urllib.request.urlopen(f"http://localhost:{p}/api/agents", timeout=0.6).read(1)
    except Exception:
        panel_py = os.path.join(base_dir or HERE, "panel.py")
        if os.path.exists(panel_py):
            try:
                subprocess.Popen([sys.executable, panel_py], cwd=os.path.dirname(panel_py),
                                 stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                                 stdin=subprocess.DEVNULL, shell=False)
                for _ in range(15):
                    time.sleep(0.2)
                    try:
                        urllib.request.urlopen(f"http://localhost:{p}/api/agents", timeout=0.5).read(1)
                        break
                    except Exception:
                        pass
            except Exception as e:
                _log(f"panel start from Wake failed: {e}")
    webbrowser.open(url)
    return True


def _open_log(_base_dir=None):
    import webbrowser
    if os.path.exists(LOG): webbrowser.open("file://" + LOG)


def _make_tray_image():
    try:
        from PIL import Image, ImageDraw
        img = Image.new("RGB", (64,64), "white"); d=ImageDraw.Draw(img)
        d.ellipse((7,7,57,57), outline="black", width=4); d.line((32,32,32,17), fill="black", width=4); d.line((32,32,46,39), fill="black", width=4)
        return img
    except Exception: return None


def show_control_panel():
    """Launch Wake's independent native UI; never becomes the scheduler process."""
    try:
        ui_py = os.path.join(HERE, "wake_ui.py")
        subprocess.Popen([sys.executable, ui_py], cwd=HERE,
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                         stdin=subprocess.DEVNULL, shell=False)
        return True
    except Exception as e:
        _log(f"Wake native UI unavailable: {e}")
        return False


def show_tray(base_dir=None):
    """Native tray manager. Linux prefers AppIndicator; visible control window is the fallback."""
    owned, owner_pid = _instance_lock_acquire("tray")
    if not owned:
        _log(f"Wake tray not started: persistent Wake already owned by PID {owner_pid}")
        return
    _cleanup_legacy_wake_duplicates()
    _begin_session_log("tray")
    backend = "native"
    try:
        setup_status = {}
        try:
            import system_setup
            system_setup.first_run_preflight(auto_install=False, include_system=True)
            setup_status = system_setup.status()
        except Exception as e:
            _log(f"dependency preflight warning: {e}")
        if sys.platform.startswith("linux"):
            ls = (setup_status.get("system") or {}) if isinstance(setup_status, dict) else {}
            gx = ls.get("gnome_appindicator_extension") or {}
            if ls.get("gnome") and gx.get("enabled") is False:
                try:
                    import system_setup
                    system_setup._enable_gnome_appindicator_extension()
                    setup_status = system_setup.status()
                    ls = setup_status.get("system") or {}
                    gx = ls.get("gnome_appindicator_extension") or {}
                except Exception:
                    pass
            if ls.get("gnome") and gx.get("enabled") is False:
                backend = "control-window"
                _write_pid("tray", tray_backend=backend)
                _write_heartbeat()
                _ensure_default_autostart()
                reconcile_popup_schedule_on_start()
                session_id = _start_manager_session("tray")
                _log("GNOME AppIndicator extension is not enabled; Wake stays background-active and opens its native control window")
                show_control_panel()
                _daemon_loop_for_tray(session_id)
                return
            if ls.get("appindicator"):
                os.environ["PYSTRAY_BACKEND"] = "appindicator"
                backend = "appindicator"
            else:
                backend = "auto/fallback"
                _log("Linux AppIndicator backend unavailable; Wake will try pystray fallback/control window")
        _write_pid("tray", tray_backend=backend)
        _write_heartbeat()
        _ensure_default_autostart()
        reconcile_popup_schedule_on_start()
        session_id = _start_manager_session("tray")
        threading.Thread(target=_daemon_loop_for_tray, args=(session_id,), daemon=True).start()
        try:
            import pystray
        except Exception as e:
            _log(f"tray import failed ({e}); Wake stays background-active and opens its native control window")
            show_control_panel()
            while True: time.sleep(3600)
        img = _make_tray_image()
        if img is None:
            _log("tray image unavailable; Wake stays background-active and opens its native control window")
            show_control_panel()
            while True: time.sleep(3600)
        bd = base_dir or HERE
        def ctl(_i,_x):
            show_control_panel()
        def quit_(i,_x): i.stop(); _clear_pid()
        def aut(_i,_x):
            p=_load_prefs(); p["autostart"]=not p.get("autostart",True); _save_prefs(p); install_autostart(enable=p["autostart"])
        menu=pystray.Menu(
            pystray.MenuItem("Wake settings / calendars",ctl,default=True),
            pystray.MenuItem("Run due tasks now",lambda i,x:run_due_once()),
            pystray.MenuItem("Wake log",lambda i,x:_open_log()),
            pystray.MenuItem("Start with system",aut,checked=lambda item:_load_prefs().get("autostart",True)),
            pystray.MenuItem("Exit Wake",quit_))
        icon=pystray.Icon("AToolsWake",img,"A-Tools Wake",menu)
        _log(f"tray ACTIVE backend={backend}; wake runs continuously in background")
        icon.run()
    finally:
        _clear_pid()
        _instance_lock_release()


def _daemon_loop_for_tray(session_id):
    while True:
        try: _write_heartbeat()
        except Exception: pass
        try: _process_commands()
        except Exception as e: _log(f"Wake command queue error: {e}")
        try: run_due_once(manager_session=session_id)
        except Exception as e: _log(f"wake tick error: {e}")
        try: popup_tick()
        except Exception as e: _log(f"popup tick error: {e}")
        try: calendar_tick()
        except Exception as e: _log(f"calendar tick error: {e}")
        time.sleep(_next_manager_delay())


def _promote_source_cli_or_fail(args):
    """A source-tree wake.py command always converges to the selected central runtime.

    Previously `python wake.py --panel` could merely discover an old central PID
    and keep using it forever. Promotion still goes through atool_sync's signed/
    developer policy; this function only makes the chosen result unambiguous.
    """
    if not os.path.isfile(os.path.join(HERE,"atool_sync.py")):
        return
    if str(os.environ.get("ATOOL_WAKE_NO_PROMOTE","")).lower() in ("1","true","yes","on"):
        return
    central_root=os.path.realpath(os.path.join(ECO_DIR,"system","wake"))
    try:
        if os.path.commonpath([central_root,os.path.realpath(__file__)])==central_root:
            return
    except Exception: pass
    try:
        import atool_sync
        result=atool_sync.ensure_system_wake()
    except Exception as e:
        raise SystemExit(f"Wake promotion failed: {e}")
    if not result.get("ok"):
        raise SystemExit("Wake promotion failed: "+str(result.get("error") or result))
    if result.get("conflict"):
        raise SystemExit("Wake promotion conflict: "+str(result.get("warning") or result))
    active=result.get("active") if isinstance(result.get("active"),dict) else {}
    if int(active.get("wake_release",-1))!=WAKE_RELEASE or str(active.get("wake_sha256") or "")!=str(_sha256(__file__) or ""):
        raise SystemExit(f"Wake r{WAKE_RELEASE} was not activated: {result.get('reason') or result}")
    boot=os.path.join(central_root,"my_wake.py")
    if not os.path.isfile(boot):
        raise SystemExit("central Wake bootstrap missing after promotion")
    os.execv(sys.executable,[sys.executable,boot,*args])


def _cli():
    args=sys.argv[1:]
    _promote_source_cli_or_fail(args)
    if len(args)>=2 and args[0]=="--approve": approve(args[1]); return
    if len(args)>=2 and args[0]=="--run":
        ok=run_tool_now(args[1]); print("queued" if ok else "failed"); raise SystemExit(0 if ok else 2)
    if "--run-due" in args:
        ok=request_due_scan(); print("queued" if ok else "failed"); raise SystemExit(0 if ok else 2)
    if "--install-autostart" in args:
        ok,msg=install_autostart(enable=True); print(msg); raise SystemExit(0 if ok else 2)
    if "--uninstall-autostart" in args:
        ok,msg=install_autostart(enable=False); print(msg); raise SystemExit(0 if ok else 2)
    if "--once" in args: run_due_once(); popup_tick(); calendar_tick(); return
    if "--popup-now" in args:
        ok,msg=show_popup_now(); print(msg); return
    if "--status" in args: print(json.dumps(status(),indent=2,ensure_ascii=False,default=str)); return
    if "--ics" in args: print(export_wake_ics()); return
    if "--panel" in args:
        ensure_background_process(with_tray=True)
        show_control_panel()
        return
    if "--daemon" in args: run_forever(); return
    # Default and --tray: a native always-on manager, not a one-shot cron helper.
    show_tray()


if __name__ == "__main__":
    _cli()
