# USER CONTEXT — one file, read by every a-tool.
# Sections are marked with tags. Each tag says WHO may write there and WHO reads it.
#
#   [USER]   you wrote it. No a-tool ever changes it. Highest trust.
#   [SCRIPT] filled in automatically by rules (no AI). Safe to edit.
#   [AI]     an a-tool worked it out. Refreshable. Never overwrites [USER].
#   [FIX]    a correction: something [AI] got wrong and you (or a rule) fixed.
#
# Scope tags say WHO the section is for:
#   (all)          every a-tool reads it
#   (kind:X)       only a-tools of that kind — e.g. kind:reporter, kind:collector
#   (tool:NAME)    only that one a-tool preset — e.g. tool:MAiler3
#
# ============================================================================
#  1. GENERAL — about you. Every a-tool reads this.
# ============================================================================

## [USER] (all) Who I am
# Example: your name, role, one line about you

## [USER] (all) Active projects
# Example: ELSA exoskeleton study, Locally4Me
# Add your real project names below. Blank/comment lines are ignored.

## [USER] (all) What I always care about
# Example: people, partners, universities, deadlines, money owed, authorities
# Add real watch terms below. Case is preserved and lowercase is valid.

## [USER] (all) What I want to ignore
# Example: newsletters, promos, social noise

# ============================================================================
#  2. PER KIND — shared by every a-tool of one type.
# ============================================================================

## [USER] (kind:reporter) How I want mail handled
# Example: invoices matter more than meetings; never mark my bank as noise

## [USER] (kind:collector) What a good hit looks like
# Example: a real person with a lab and an email, not a company form

# ============================================================================
#  3. PER SOURCE — why each mailbox/feed exists. This is what the AI needs
#     to judge a mail: the same message means different things in different boxes.
# Divided with tool/source code.
# ============================================================================

## [USER] (all) Purpose of each source
# Example:
# work@company.com   — clients, invoices, contracts. Anything here is business.
# me@gmail.com       — personal + my ELSA study. Study mail is never routine.
# research@x.org     — outreach and grants. Deadlines matter most.

# ============================================================================
#  4. LEARNED — the a-tools write here. You can delete anything; it rebuilds.
# ============================================================================

## [AI] (all) Learned about me
# Empty: fills in as the tools observe your mail

## [FIX] (all) Corrections
# Example: when you fix a tag or priority, record why so the AI stops repeating it
