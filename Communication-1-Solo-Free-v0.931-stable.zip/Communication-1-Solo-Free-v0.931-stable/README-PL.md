# Communication A-Tool 0.931b Beta

Lokalne narzędzie do porządkowania poczty e-mail i RSS: priorytety, tagi, streszczenia, szkice odpowiedzi, reguły i uruchamianie w tle.

**Języki:** polski i angielski interfejs/dokumentacja.  
**AI:** opcjonalne. Deterministyczny skrypt działa bez klucza AI.  
**Praca w tle:** Wake może uruchamiać zapisane presety według harmonogramu nawet przy zamkniętym Chrome.

English guide: [README.md](README.md)  
Licencja: [LICENCE_AGREEMENT.txt](LICENCE_AGREEMENT.txt)

---

## 1. Co robi program

Communication A-Tool czyta skonfigurowane skrzynki pocztowe i kanały RSS/Atom, a następnie tworzy jeden raport odpowiadający przede wszystkim na pytania:

- co wymaga uwagi teraz;
- co może poczekać;
- co jest szumem/reklamą/social;
- jakie tagi i terminy wykryto;
- dlaczego nadano dany priorytet/tag;
- czy chcesz szczegółowe streszczenie, szkic odpowiedzi, przypomnienie lub poprawkę reguły.

Podstawowa klasyfikacja i reguły działają bez AI. Opcjonalne AI może tworzyć streszczenia i szkice, wyciągać fakty, przeglądać priorytet/tagi oraz pomagać przy wielojęzycznych regułach.

Zapisana konfiguracja jest **presetem/profilem** wewnątrz Communication A-Toola. Kompletny dystrybuowalny ZIP/aplikacja to **A-Tool**.

---

# 2. Quick start — krok po kroku

## Krok 1 — uruchom panel

W katalogu produktu:

```bash
python3 panel.py
```

Tryb diagnostyczno-developerski:

```bash
python3 panel.py --d
```
<!-- FIRST_AGENTSYSTEM_RUN_NOTE -->
**Pierwsze uruchomienie bez istniejącego `~/agentsystem`:** zwykłe `python3 panel.py` automatycznie odsłania narzędzia konfiguracji/diagnostyki dostępne w `--d`, aby użytkownik mógł zobaczyć pełny setup bez znajomości flagi. Przy kolejnych zwykłych uruchomieniach wraca normalny UI; `--d` nadal można włączyć ręcznie.


Panel zwykle otwiera się lokalnie pod `http://127.0.0.1:8800`.

## Krok 2 — utwórz preset/profil

1. Wybierz **Templates → inbox_reporter**.
2. Nadaj konfiguracji nazwę, np. `Poczta prywatna` albo `Firma`.
3. Kliknij **Save / Zapisz**.

Polityka presetów/profili:
- **Solo Free** — twarde maksimum 1 skonfigurowanego presetu/profilu.
- **Solo** — normalny UI tworzy maks. 2 skonfigurowane presety/profile; dodatkowe pliki profili skopiowane ręcznie mogą nadal zostać wykryte i uruchomione. To limit produktu/UI, a nie granica bezpieczeństwa.
- **Template Generator / Developer** — bez limitu liczby presetów charakterystycznego dla Solo.

Communication wykonuje **tylko jeden preset/run naraz**; następny run ma czekać zamiast wykonywać się równolegle.

## Krok 3 — dodaj skrzynkę

Otwórz **Klucze i IMAP** i dodaj konto.

Typowy Gmail:

- host: `imap.gmail.com`
- login: pełny adres Gmail
- hasło: **Hasło aplikacji Google**, a nie zwykłe hasło do konta

Przed zapisaniem użyj **Test**.

## Krok 4 — opcjonalne AI

Możesz zacząć z AI wyłączonym.

Jeżeli chcesz streszczenia/szkice/review AI:

1. wybierz dostawcę i model;
2. wpisz klucz API albo wybierz obsługiwany lokalny endpoint, np. Ollama;
3. przetestuj połączenie;
4. wybierz poziom AI w zakładce **Raport i AI / Outputs**.

Dostawca chmurowy otrzymuje treść potrzebną do włączonej operacji AI. Lokalna Ollama pozwala wykonywać inferencję na Twoim komputerze.

## Krok 5 — personalizacja

W **Personalizacji** ustaw tylko to, czego potrzebujesz:

- cel;
- ton raportu;
- focus/kontekst;
- wykluczenia;
- jawna watchlista / frazy „nigdy nie przegap”;
- opcjonalne nadpisanie języka.

Dla bogatszego kontekstu użyj **Mój profil / USER_CONTEXT** — sekcja 8.

## Krok 6 — uruchom

Kliknij **Uruchom**.

Raport pokazuje priorytety, nadawcę/źródło, sens wiadomości, tagi, akcje oraz opcjonalne wyjaśnienia.

## Krok 7 — harmonogram w tle

W **Harmonogramie** ustaw godziny, opcjonalny catch-up i run-on-start. Zapis presetu publikuje plan do centralnego Wake.

Zamknięcie Chrome nie zatrzymuje Wake.

---

# 3. Główne elementy UI

## Templates / zapisane presety

**Template** jest wzorcem startowym, np. `inbox_reporter`. Po konfiguracji, nazwaniu i zapisie staje się zapisanym presetem/profilem.

Każdy zapisany preset może mieć własne źródła, ustawienia raportu i harmonogram.

## Personalizacja

Tu ustawiasz sens i intencję użytkownika, a nie globalne limity silnika.

- **Cel** — główne zadanie tego presetu.
- **Ton raportu** — styl pisania; nie powinien bezpośrednio zmieniać klasyfikacji.
- **Focus** — kontekst głównie dla AI; nie jest deterministyczną regułą priorytetu.
- **Wykluczenia** — odsiew przed AI/raportem zgodnie z logiką pola.
- **Watchlista** — jawne deterministyczne frazy „nigdy nie przegap”. Priorytet watchlisty ustawia się w Zachowaniu silnika.
- **Język** — opcjonalne nadpisanie dla tego presetu.

## Klucze i IMAP

Ustawienia dostawcy AI, kluczy API i skrzynek pocztowych.

Hasła i klucze API nie powinny być przechowywane jako zwykły tekst w normalnym JSON profilu. Szczegóły w sekcji Prywatność i bezpieczeństwo.

## Źródła

Konfiguracja RSS/Atom. Feed może mieć własny priorytet, godziny, nazwę, kategorię, limit elementów, stałe tagi i filtry include/exclude.

Ręczne Run czyta wszystkie aktywne źródła. Automatyczny slot Wake może czytać tylko źródła przypadające na tę godzinę.

## Harmonogram

Publikowane do Wake ustawienia wykonania:

- cykliczne godziny;
- one-off;
- catch-up po pominiętym slocie;
- run on start;
- minimalny odstęp dla run-on-start;
- network/retry tam, gdzie obsługiwane.

## Raport i AI / Outputs

Steruje warstwą raportu i AI: poziom AI, streszczenia, model priorytetu, review tagów, zakres skanowania, foldery i sposób dostarczenia wyniku.

## About & Help / Advanced

Pomoc i narzędzia zarządzające: USER_CONTEXT, Rules, Tags, Zachowanie silnika, Kalendarz, Wake, backup/eksport, snapshot ustawień i testy.

---

# 4. Priorytety

Od najważniejszego do najmniej ważnego:

- **P1!** — krytyczne, zweryfikowane poważne/bezpośrednie zdarzenie;
- **P1** — pilne, wymagające bezpośredniego działania;
- **P2** — ważne, wymaga uwagi;
- **P3** — normalna istotna wiadomość;
- **P4** — mała ważność;
- **P5** — rutyna/szum/reklama.

Klasyfikator deterministyczny tworzy bazę. W zależności od wybranego modelu AI może ją skorygować albo wyciągnąć fakty, z których deterministyczne reguły Modelu 4 liczą P.

Jeśli Model 4 nie zwróci użytecznych faktów, pozostaje deterministyczny wynik Classic zamiast zgadywania priorytetu. Konkretne stany lifecycle z Model 4, np. paid/payment due/invoice/statement/order/shipment/status aplikacji, są przyjmowane tylko wtedy, gdy treść wiadomości niezależnie je potwierdza; niepotwierdzony stan jest odrzucany zanim reguły priorytetu/tagów Model 4 zadziałają. Model 4 nie może też obniżyć bezpośredniej/osobistej wiadomości Classic P3 do P4/P5, jeśli sama wiadomość nie ma zweryfikowanego sygnału niskiej wartości/promocji. Zwykły newsletter ma domyślnie P4; mocniejszy sygnał lifecycle/akcji/reguły użytkownika nadal może go podnieść, a potwierdzona promocja pozostaje P5.

Automatyczne wiadomości rekrutacyjne/status aplikacji są traktowane jako system/application update, a nie `from a person`; konkretny stan typu przyjęcie/interview/wymagana akcja pozostaje bardziej szczegółowy.

---

# 5. Rules i Tags — jak to naprawdę działa

**Tags** i **Rules** to dwa widoki tej samej uporządkowanej listy dokładnych/własnych reguł wiadomości.

- **Tags** skupia się na katalogu tagów i regułach, które tworzą/używają tagów. Reguły ogólne są zwinięte niżej.
- **Rules** skupia się na regułach ogólnych, które zmieniają priorytet/widoczność bez tworzenia tagu. Reguły tagów są zwinięte niżej.
- **Zachowanie silnika** to osobne ustawienia. Limity korekty AI, priorytet watchlisty i noise ceiling nie są regułami wiadomości.

Wbudowana klasyfikacja semantyczna i standardowe tagi powstają wcześniej. Dopiero potem działają exact/custom rules.

## Pola reguły

### Dopasowanie

Dosłowna przesłanka uruchamiająca regułę: słowo, fraza, adres e-mail, domena albo tag.

### Gdzie szukać

- **nadawca / From** — tożsamość nadawcy;
- **źródło / feed** — źródło, szczególnie przy RSS;
- **temat** — subject/title;
- **treść** — body;
- **istniejący tag** — tag nadany przez classifier albo wcześniejszą regułę;
- **wszystkie pola tekstowe** — szerokie wyszukiwanie.

### ANY / ALL

- **ANY** — wystarczy jeden warunek;
- **ALL** — wszystkie warunki muszą pasować.

Dla szerokich słów lepiej używać ALL z kilkoma przesłankami.

### Tag

Dodaje etykietę. Reguła może też reagować na istniejący tag przez **Gdzie = tag**.

### Podłoga priorytetu

Końcowy priorytet nie może stać się **mniej ważny** niż wskazany.

Przykład: `podłoga P2` dopuszcza P1!/P1/P2, ale blokuje P3/P4/P5.

### Sufit priorytetu

Końcowy priorytet nie może stać się **ważniejszy** niż wskazany.

Przykład: `sufit P3` dopuszcza P3/P4/P5, ale blokuje P1!/P1/P2.

Ustaw oba na to samo P tylko wtedy, gdy naprawdę chcesz zablokować wynik dokładnie na jednym poziomie.

### Zawsze pokazuj

Wiadomość nie zostanie ukryta jako szum. Samo ustawienie **nie podnosi priorytetu**.

### Stop

`Stop` oznacza dokładnie:

> po trafieniu tej reguły nie sprawdzaj żadnej późniejszej exact/custom rule dla tej wiadomości.

Stop **nie**:

- cofa wyniku wbudowanego classifiera;
- usuwa tagów/akcji już zastosowanych;
- zatrzymuje całego runu Communication;
- automatycznie zatrzymuje AI.

Wcześniejsze dopasowane reguły pozostają aktywne. Dlatego przy Stop kolejność ma znaczenie.

### Zakres

- `all` — wszystkie A-Toole/presety, gdzie używany jest ten layer;
- `kind:reporter` — wszystkie reportery;
- `tool:NAZWA` — tylko wskazany zapisany preset/profil.

### Kolejność

Reguły są sprawdzane w zapisanej kolejności. Tagi i Zawsze pokazuj sumują się. Późniejsza pasująca podłoga/sufit może zastąpić wcześniejsze ograniczenie. Trafiony Stop blokuje wszystkie późniejsze exact/custom rules.

### Test

Podgląd tylko do odczytu na ostatnim raporcie. Nie zapisuje reguły, nie pobiera poczty i nie modyfikuje wiadomości.

## Języki reguł

Źródłowe dopasowanie pozostaje dokładnie tym, co wpisałeś. Opcjonalne tłumaczenia są przechowywane osobno. Adresów e-mail, URL-i, ścieżek, nazw plików, model IDs, kwot, dat, numerów spraw i innych identyfikatorów nie powinno się tłumaczyć.

## Reguły fabryczne

Fabryczne exact/custom rules są małą bazą dostarczoną z produktem. Większość normalnego wielojęzycznego rozpoznawania należy do built-in classifier/tag policy, a nie do wielkiej listy hardkodowanych nadawców.

W zwykłym UI factory rules są tylko do odczytu. Po uruchomieniu:

```bash
python3 panel.py --d
```

pojawia się **Edytuj reguły fabryczne (--d)**. Zapis tworzy lokalne nadpisanie w AgentSystem i **nie przepisuje `operational.py`**. **Przywróć fabrykę ze źródła** usuwa override i wraca do reguł dostarczonych z tą wersją.

---

# 6. Akcje w raporcie

W zależności od wiadomości i edycji raport może oferować m.in.:

- kopiowanie danych;
- szczegółowe streszczenie;
- szkic odpowiedzi;
- przypomnienie/kalendarz;
- otwarcie webmaila/źródła;
- Why priority & tags;
- AI re-check;
- utworzenie/poprawkę reguły;
- always/never summarize dla nadawcy;
- hide/unhide.

Automatyczne krótkie streszczenie i ręczne Detailed Summary są osobnymi akcjami. Ręczny przycisk może wygenerować dłuższe streszczenie nawet wtedy, gdy krótkie AI summary już istnieje.

---

# 7. Wake — praca w tle

Wake jest wspólnym background managerem.

Gdy działa, przejmuje cykliczne harmonogramy i run-on-start, żeby kilka lokalnych schedulerów nie konkurowało ze sobą.

W zależności od opublikowanego entry Wake obsługuje:

- cykliczne runy;
- catch-up;
- start z Wake/PC;
- request przy starcie panelu;
- one-off;
- ręczny headless run;
- retry po powrocie sieci;
- opcjonalne otwarcie/reuse UI po background runie.

Silent/headless run Communication zapisuje wynik lokalnie w AgentSystem. Po późniejszym wejściu do presetu panel może pokazać ostatni zapisany wynik bez ponownego pobierania poczty.

Jeśli skonfigurowany jest kanał komunikatora/output, background run używa tego samego pipeline dostarczania raportu.

---

# 8. USER_CONTEXT / Mój profil

USER_CONTEXT przechowuje stabilny kontekst o Tobie i projektach, który pomaga AI rozumieć znaczenie wiadomości.

Dobre informacje:

- projekty/firmy, nad którymi faktycznie pracujesz;
- ważne organizacje i klienci;
- role i obowiązki;
- tematy, gdzie kontekst zmienia ocenę ważności;
- stabilne fakty, które warto wielokrotnie wykorzystywać.

USER_CONTEXT nie zastępuje deterministycznej reguły „nigdy nie przegap”. Jeśli coś ma zawsze działać przewidywalnie, użyj Watchlist albo dokładnej Rule.

Kontekst może być zakresowany globalnie, do rodzaju A-Toola albo jednego presetu/profilu. Builder profilu powinien pokazać proponowane dane przed zastosowaniem.

---

# 9. Email i RSS

## Email

Skrzynki są czytane przez IMAP. Wymagania host/login/hasło zależą od dostawcy. Gmail zwykle wymaga Hasła aplikacji przy włączonym 2FA.

## RSS/Atom

Feed może mieć format:

```text
URL|priority|times|name|category|max_items|on/off|tags|include|exclude
```

Wymagany jest tylko URL.

Przykład:

```text
https://example.org/feed.xml|2|08:00,18:00|Example|news|30|on|project|release;update|sponsored
```

---

# 10. Prywatność, dane i bezpieczeństwo

## Dane lokalne

Program przechowuje dane robocze w lokalnym AgentSystem, zwykle:

```text
~/agentsystem/
```

Mogą tam być profile, raporty/cache, reguły, stan Wake/schedulera, logi, USER_CONTEXT i metadane sekretów.

Cache report/body może zawierać treść wiadomości. Zabezpiecz konto systemowe i backupy odpowiednio do wrażliwości poczty.

## Hasła i klucze API

Sekrety są oddzielone od zwykłego JSON profilu. System może używać backendów chronionych przez OS, np. Windows DPAPI, macOS Keychain lub Linux Secret Service. Jeśli bezpieczny backend nie jest dostępny, możliwy jest prywatny fallback plikowy; sprawdź diagnostykę, jeśli wymagasz szyfrowania at-rest.

Nie pokazuj sekretów na nagraniach. Do demo używaj danych testowych/demo.

## Panel lokalny

Normalny panel jest przeznaczony do lokalnego użycia i domyślnie nasłuchuje na localhost. Nie wystawiaj go publicznie do sieci bez świadomej konfiguracji bezpieczeństwa.

## Chmurowe AI

Jeśli wybierzesz chmurowego dostawcę LLM, treść potrzebna do włączonej operacji AI jest wysyłana do tego dostawcy. Jeśli inferencja ma zostać lokalna, skonfiguruj lokalny endpoint, np. Ollama.

## Podpisane release'y

Oficjalny build może używać manifestu podpisanego Ed25519 do integralności/provenance. Może to wykrywać zmodyfikowane, pomieszane lub nieznane paczki zgodnie z konfiguracją trust.

To **nie chroni przed malware już działającym na Twoim koncie użytkownika**. Kod z tymi samymi uprawnieniami może potencjalnie zmieniać pliki należące do tego użytkownika. Nie należy opisywać tego jako „tamper-proof”.

---

# 11. Praktyczne wskazówki ustawień

- Zacznij z AI wyłączonym i sprawdź deterministic result.
- Twórz wąskie reguły zamiast jednego bardzo szerokiego słowa.
- Dla kilku wymaganych przesłanek używaj ALL.
- Przed zapisem szerokiej reguły użyj Test.
- Jawne „nigdy nie przegap” → Watchlist.
- Miękki kontekst znaczeniowy → USER_CONTEXT.
- Zamiast blokować dokładnie P użyj Floor/Ceiling, jeśli wystarczy zakres.
- Stop stosuj tylko wtedy, gdy naprawdę chcesz wyłączyć wszystkie późniejsze exact/custom rules po trafieniu.
- Jeśli zależy Ci na pominiętych raportach, zostaw catch-up.
- Chroń AgentSystem i backupy przez konto/permissions systemu.

---

# 12. Diagnostyka i `--d`

Uruchom:

```bash
python3 panel.py --d
```

Dodatkowe narzędzia mogą obejmować:

- Multi-run Matrix;
- osobne Log/Debug dla runów;
- diagnostyczne kopiowanie zaznaczonych rekordów;
- widok wszystkich języków reguł;
- edytor factory exact/custom rules;
- pełniejsze snapshoty/trace ustawień.

`--d` jest trybem diagnostyczno-developerskim UI, a nie security bypass.

## Multi-run Matrix

Matrix wykonuje mały zestaw kombinacji engine/config na tej samej próbce, żeby szybko porównać zachowanie klasyfikacji. Nie jest pełnym testem end-to-end Wake, komunikatorów, każdego przycisku raportu ani każdego dostawcy zewnętrznego.

Do tych obszarów używaj osobnych testów funkcji.

---

# 13. Rozwiązywanie problemów

## Panel się nie otwiera

```bash
python3 panel.py
```

Sprawdź rzeczywisty błąd w terminalu. Nie uruchamiaj kilku konfliktujących kopii na tym samym porcie.

## Wake nie wykonuje harmonogramu

Sprawdź:

- czy proces Wake działa;
- Start with system;
- czy preset opublikował schedule;
- Effective Wake schedule/override;
- Current session log;
- sieć, jeśli job jej wymaga.

## Raport jest pusty

Sprawdź:

- scan scope i foldery;
- pamięć already-reported;
- exclusions;
- hidden/noise rows;
- czy źródło faktycznie ma nowe kwalifikujące się dane.

Reset memory używaj tylko wtedy, gdy świadomie chcesz ponownie obejrzeć już zaraportowane wiadomości.

## AI zachowuje się niestabilnie

Sprawdź model/provider/key, limity i parsowanie structured output. Fallback do deterministic Classic jest prawidłowy, gdy Model 4 nie zwróci użytecznych faktów.

---

# 14. Referencja techniczna

Główne elementy:

- `panel.py` — lokalny browser UI/API;
- `engine.py` — mail/RSS, klasyfikacja, AI i pipeline raportu;
- `operational.py` — kategorie/tagi/presety/default policy;
- `secret_store.py` — warstwa sekretów;
- `wake.py` — wspólny background manager;
- `wake_ui.py` — UI Wake;
- `scheduler.py` — fallback kompatybilności, gdy centralny Wake nie działa;
- `hq.py` — wspólny bufor/kolejka ekosystemu;
- `tags_custom.json` — własne exact/custom rules użytkownika;
- `factory_rules_override.json` — opcjonalne lokalne nadpisanie reguł fabrycznych tworzone z `--d`;
- `USER_CONTEXT.md` — trwały kontekst użytkownika/projektów;
- `~/agentsystem/data/` — raporty/cache/runtime data.

Built-in semantic classifier jest celowo oddzielony od exact/custom rule layer. Dzięki temu factory exact rules mogą pozostać małe, a rozpoznawanie wielojęzycznych typów wiadomości nie musi być ogromną listą wyjątków nadawców.

---

# 15. Licencja

Prawa użycia i dystrybucji zależą od edycji oraz przyznanej licencji. Przeczytaj:

[LICENCE_AGREEMENT.txt](LICENCE_AGREEMENT.txt)

Nie redystrybuuj płatnej/nieredystrybuowalnej wersji, jeśli Twoja licencja wyraźnie na to nie pozwala.

---

# 16. Informacja Beta

0.931b jest wydaniem beta. Core mail processing i Wake scheduling były używane w realnych runach, ale nie da się zagwarantować, że każda kombinacja providera, RSS, integracji OS, komunikatora i modelu AI została sprawdzona w każdym wydaniu.

Jeśli klasyfikacja wygląda źle, przed zmianą reguł zachowaj odpowiedni fragment bieżącego logu oraz **Why priority & tags**. To znacznie ułatwia odtworzenie błędu.


<!-- WAKE_COMPLETION_POLICY_NOTE -->
## Zachowanie Wake po zakończeniu runu
Wake rozdziela wykonanie od prezentacji. Globalnie i osobno dla każdego wpisu Wake można wybrać, czy poprawnie zakończony run w tle ma pozostać cichy czy otworzyć/podnieść UI A-Toola oraz niezależnie, czy ma pojawić się systemowe powiadomienie o zakończeniu. `inherit` używa wspólnego ustawienia Wake.

Reguły mogą reagować na tagi: `Where = tag` dopasowuje istniejący tag. Taka reguła może dodać kolejny tag, ustawić floor/ceiling, wymusić widoczność albo zatrzymać późniejsze exact/custom rules. Silnik rozwiązuje zależności tagów aż do stabilnego stanu.

Model 4 **nie tworzy dowolnie nowych kategorii tagów semantycznych**. Wyciąga ustalony zestaw faktów strukturalnych i mapuje obsługiwane stany na znane tagi; z jawnego faktu może powstać dynamiczny tag kwoty lub terminu. Classic AI przy korekcie tagów może wybierać tylko z wbudowanego katalogu. Własne tagi pozostają świadomą funkcją reguł użytkownika.
