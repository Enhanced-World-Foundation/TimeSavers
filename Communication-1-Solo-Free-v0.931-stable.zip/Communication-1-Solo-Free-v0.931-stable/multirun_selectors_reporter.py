# ============================================================================
#  multirun_selectors_reporter.py
#  ----------------------------------------------------------------------------
#  LISTA SELEKTOROW dla Inbox Reportera — TYLKO dane, zero logiki.
#
#  Silnik multi-runu (multirun.py) NIC nie wie o poczcie. Bierze te liste
#  jako wejscie i sam uklada kombinacje. Inny a-tool podaje wlasny plik
#  o TAKIM SAMYM ksztalcie i uzywa tego samego silnika bez jednej linii zmiany.
#
#  KSZTALT:
#    ENGINE   — glowny selektor silnika. To on wyznacza BAZE runow
#               (jeden run na kazda opcje). Zwykle 3 opcje = 3 runy bazowe.
#    OTHERS   — pozostale selektory. NIE mnozymy ich kartezjansko przez base;
#               silnik rozdziela ich opcje MIEDZY runy bazowe rotacyjnie,
#               zeby w minimalnej liczbie runow dotknac jak najwiecej ustawien.
#
#  Kazda opcja ma:
#    key    — identyfikator techniczny
#    label  — krotka nazwa do UI
#    desc   — JEDNO zdanie: co ta opcja robi (widoczne w UI, przy kombinacji)
#    out    — co wstrzyknac do profile["outputs"] dla tej opcji
# ============================================================================

# --- GLOWNY selektor: silnik AI. Wyznacza liczbe runow bazowych. -----------
ENGINE = {
    "key": "engine",
    "label": "AI engine",
    "options": [
        {"key": "script", "label": "Script-only",
         "desc": "No AI at all. Rules alone pick, tag and rank — free, instant, and the baseline everything else is compared against.",
         "out": {"ai_level": "off", "ai_select_mode": "script",
                 "ai_priority": False, "summary_depth": "auto"}},
        {"key": "ai_free", "label": "AI-free (hybrid)",
         "desc": "AI writes summaries and corrects tags and priority (with guard rails) — works on the free tier.",
         "out": {"ai_level": "fast", "ai_select_mode": "ai",
                 "ai_priority": True, "summary_depth": "auto"}},
        {"key": "ai_deep", "label": "AI-deep",
         "desc": "Full user context, longer summaries, no 12-mail cap — needs a paid key or a local model.",
         "out": {"ai_level": "deep", "ai_select_mode": "ai", "ai_priority": True,
                 "summary_depth": "detailed", "background": True, "max_summaries": 999}},
    ],
}

# --- POZOSTALE selektory: rozdzielane rotacyjnie miedzy runy bazowe. --------
OTHERS = [
    {"key": "depth", "label": "Folder depth",
     "options": [
         {"key": "default", "label": "depth: default",
          "desc": "Standard folder depth.",
          "out": {"folder_depth": "default"}},
         {"key": "max", "label": "depth: max",
          "desc": "Maximum depth — walks every subfolder of the mailbox.",
          "out": {"folder_depth": "max"}},
     ]},
    {"key": "newsletter", "label": "Newsletters",
     "options": [
         {"key": "off", "label": "newsletter: off",
          "desc": "Newsletters skipped.", "out": {"scan_newsletter": False}},
         {"key": "on", "label": "+ newsletter",
          "desc": "Newsletters included in scope.", "out": {"scan_newsletter": True}},
     ]},
    {"key": "ads", "label": "Ads / promo",
     "options": [
         {"key": "off", "label": "ads: off",
          "desc": "Ads and promotions skipped.", "out": {"scan_promo": False}},
         {"key": "on", "label": "+ ads",
          "desc": "Promotions folder included in scope.", "out": {"scan_promo": True}},
     ]},
    {"key": "spam", "label": "Spam",
     "options": [
         {"key": "off", "label": "spam: off",
          "desc": "Spam folder skipped.", "out": {"scan_spam": False}},
         {"key": "on", "label": "+ spam",
          "desc": "Spam folder included in scope.", "out": {"scan_spam": True}},
     ]},
    {"key": "watchlist", "label": "Watchlist",
     "options": [
         {"key": "on", "label": "watchlist: on",
          "desc": "Watchlist active (default).", "out": {"watchlist": True}},
         {"key": "off", "label": "watchlist OFF",
          "desc": "Watchlist off — shows how much priority the watchlist alone was contributing.",
          "out": {"watchlist": False}},
     ]},
    {"key": "deadline", "label": "Deadline detect",
     "options": [
         {"key": "on", "label": "deadline: on",
          "desc": "Deadline detection active (default).", "out": {"deadline_detect": True}},
         {"key": "off", "label": "deadline OFF",
          "desc": "Deadline detection off.", "out": {"deadline_detect": False}},
     ]},
    {"key": "grouping", "label": "Group by case",
     "options": [
         {"key": "on", "label": "grouping: on",
          "desc": "Grouping by case active (default).", "out": {"group_by_case": True}},
         {"key": "off", "label": "grouping OFF",
          "desc": "Grouping by case off — every mail stands on its own.",
          "out": {"group_by_case": False}},
     ]},
    # --- FLAGI + WYWOLYWANIE AGENTA PRZEZ AGENTA (punkt 5, osobny mechanizm) --
    # To NIE jest zwykly przelacznik zakresu. To flaga sterujaca tym, czy jeden
    # a-tool moze wywolac funkcje/inny a-tool w trakcie runu. Silnik traktuje
    # opcje z "invoke" specjalnie: nie miesza jej do rotacji zakresu, tylko
    # nakladamy ja na baze jako dodatkowy wymiar (patrz multirun.run_matrix).
    {"key": "agent_invoke", "label": "Agent → agent", "invoke": True,
     "options": [
         {"key": "off", "label": "solo",
          "desc": "The agent works alone — it never calls other agents or their functions.",
          "out": {"allow_agent_calls": False}},
         {"key": "on", "label": "+ call other agents",
          "desc": "The agent may call another a-tool's function during the run (a separate mechanism, not an ordinary scope switch).",
          "out": {"allow_agent_calls": True}},
     ]},
]


def selectors():
    """Zwraca (ENGINE, OTHERS). Inny a-tool ma wystawic funkcje o tej samej nazwie."""
    return ENGINE, OTHERS
