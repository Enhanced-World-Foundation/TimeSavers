#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Shared first-run dependency preflight for A-Tools + wake.

No dependency is silently assumed.  The status API and first-run setup use this
single module, so the browser panel, native wake UI and release tests report the
same truth.
"""
from __future__ import annotations
import argparse
import importlib
import importlib.util
import json
import os
import shutil
import subprocess
import sys
import time
import secret_store as SECRET_STORE

HOME = os.path.expanduser(os.environ.get("ENGINE_HOME", "~/agentsystem"))
STATE_PATH = os.path.join(HOME, "dependency_state.json")
LOG_PATH = os.path.join(HOME, "logs", "dependency_setup.log")
SETUP_LOCK = os.path.join(HOME, "dependency_setup.lock")
# Bump only when the dependency contract changes and a new automatic install pass
# should be allowed. Ordinary starts never re-prompt for the same unresolved set.
REQUIREMENTS_VERSION = 3

# (import name, pip package, purpose, required-for)
PYTHON_DEPS = [
    ("apscheduler", "apscheduler", "scheduled jobs", "scheduler"),
    ("sqlalchemy", "sqlalchemy", "persistent scheduled-job storage", "scheduler persistence"),
    ("pystray", "pystray", "system tray icon", "wake tray"),
    ("PIL", "pillow", "tray icon rendering", "wake tray"),
    ("notifypy", "notify-py", "desktop notifications fallback", "notifications"),
]

# Native packages are capability-driven.  Do not install a whole distro bundle
# merely because one optional native feature is missing.  This mapping is also
# used to render an exact manual command when privilege escalation is unavailable.
LINUX_NATIVE_PACKAGES = {
    "apt": {
        "tkinter": ["python3-tk"],
        "gi": ["python3-gi"],
        "appindicator": ["gir1.2-ayatanaappindicator3-0.1"],
        "notify_send": ["libnotify-bin"],
        "gnome_extension": ["gnome-shell-extension-appindicator"],
    },
    "dnf": {
        "tkinter": ["python3-tkinter"],
        "gi": ["python3-gobject"],
        "appindicator": ["libappindicator-gtk3"],
        "notify_send": ["libnotify"],
        "gnome_extension": ["gnome-shell-extension-appindicator"],
    },
    "pacman": {
        "tkinter": ["tk"],
        "gi": ["python-gobject"],
        "appindicator": ["libappindicator-gtk3"],
        "notify_send": ["libnotify"],
        "gnome_extension": [],
    },
}

def _load_state():
    try:
        with open(STATE_PATH, "r", encoding="utf-8") as f:
            raw = json.load(f)
            return raw if isinstance(raw, dict) else {}
    except Exception:
        return {}


def _save_state(data):
    try:
        os.makedirs(os.path.dirname(STATE_PATH), exist_ok=True)
        tmp = STATE_PATH + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        try:
            if os.name == "posix": os.chmod(tmp, 0o600)
        except Exception: pass
        os.replace(tmp, STATE_PATH)
    except Exception:
        pass


def _missing_signature(st):
    return {
        "python": sorted(str(x) for x in (st.get("missing_python") or [])),
        "system": sorted(str(x) for x in (st.get("missing_system") or [])),
    }


def _setup_lock_acquire(stale_s=900):
    os.makedirs(HOME, exist_ok=True)
    for _ in range(2):
        try:
            os.mkdir(SETUP_LOCK)
            try:
                if os.name == "posix": os.chmod(SETUP_LOCK, 0o700)
            except Exception: pass
            owner_path=os.path.join(SETUP_LOCK, "owner.json")
            with open(owner_path, "w", encoding="utf-8") as f:
                json.dump({"pid": os.getpid(), "at": time.time()}, f)
            try:
                if os.name == "posix": os.chmod(owner_path, 0o600)
            except Exception: pass
            return True
        except FileExistsError:
            try:
                owner = json.load(open(os.path.join(SETUP_LOCK, "owner.json"), encoding="utf-8"))
                age = time.time() - float(owner.get("at") or 0)
                if age > stale_s:
                    shutil.rmtree(SETUP_LOCK, ignore_errors=True)
                    continue
            except Exception:
                try:
                    if time.time() - os.path.getmtime(SETUP_LOCK) > stale_s:
                        shutil.rmtree(SETUP_LOCK, ignore_errors=True)
                        continue
                except Exception:
                    pass
            return False
        except Exception:
            return False
    return False


def _setup_lock_release():
    try:
        owner = json.load(open(os.path.join(SETUP_LOCK, "owner.json"), encoding="utf-8"))
        if int(owner.get("pid", -1)) == os.getpid():
            shutil.rmtree(SETUP_LOCK, ignore_errors=True)
    except Exception:
        pass



def _log(msg):
    try:
        os.makedirs(os.path.dirname(LOG_PATH), exist_ok=True)
        with open(LOG_PATH, "a", encoding="utf-8") as f:
            f.write(time.strftime("[%Y-%m-%d %H:%M:%S] ") + str(msg) + "\n")
    except Exception:
        pass


def _has(mod):
    try:
        return importlib.util.find_spec(mod) is not None
    except Exception:
        return False


def _cmd_exists(name):
    return bool(shutil.which(name))


def _gnome_appindicator_extension_state():
    desktop = " ".join(filter(None, [os.environ.get("XDG_CURRENT_DESKTOP"), os.environ.get("DESKTOP_SESSION")])).lower()
    if "gnome" not in desktop:
        return {"gnome": False, "installed": None, "enabled": None, "uuid": None}
    exe = shutil.which("gnome-extensions")
    uuid = "appindicatorsupport@rgcjonas.gmail.com"
    if not exe:
        return {"gnome": True, "installed": False, "enabled": False, "uuid": uuid}
    try:
        p = subprocess.run([exe, "info", uuid], stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                           text=True, timeout=5, check=False)
        text = (p.stdout or "").lower()
        installed = p.returncode == 0 and "state:" in text
        enabled = installed and ("state: enabled" in text or "state: active" in text)
        return {"gnome": True, "installed": installed, "enabled": enabled, "uuid": uuid}
    except Exception:
        return {"gnome": True, "installed": None, "enabled": None, "uuid": uuid}


def _enable_gnome_appindicator_extension():
    st = _gnome_appindicator_extension_state()
    if not st.get("gnome") or not st.get("uuid"):
        return True, "not GNOME"
    exe = shutil.which("gnome-extensions")
    if not exe:
        return False, "gnome-extensions command unavailable"
    try:
        p = subprocess.run([exe, "enable", st["uuid"]], stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                           text=True, timeout=8, check=False)
        return p.returncode == 0, (p.stdout or "").strip()
    except Exception as e:
        return False, str(e)


def _probe_gi_namespace(namespace, version="0.1"):
    """Return True only when GI can actually load the requested namespace."""
    if not _has("gi"):
        return False
    try:
        import gi  # type: ignore
        gi.require_version(namespace, version)
        repo = importlib.import_module("gi.repository")
        getattr(repo, namespace)
        return True
    except Exception:
        return False


def _linux_missing_capabilities(system):
    missing = []
    if not system.get("tkinter"):
        missing.append("tkinter")
    if not system.get("gi"):
        missing.append("gi")
    if not system.get("appindicator"):
        missing.append("appindicator")
    if not system.get("notify_send"):
        missing.append("notify_send")
    gx = system.get("gnome_appindicator_extension") or {}
    if system.get("gnome") and gx.get("installed") is False:
        missing.append("gnome_extension")
    elif system.get("gnome") and gx.get("installed") is True and gx.get("enabled") is False:
        # No package is needed, but first-run must enable the already-installed extension.
        missing.append("gnome_extension_enable")
    return missing


def _linux_package_plan(system):
    pm = system.get("package_manager")
    caps = _linux_missing_capabilities(system)
    table = LINUX_NATIVE_PACKAGES.get(pm, {})
    pkgs = []
    for cap in caps:
        for pkg in table.get(cap, []):
            if pkg and pkg not in pkgs:
                pkgs.append(pkg)
    if pm == "apt" and pkgs:
        manual = "sudo apt-get update && sudo apt-get install -y " + " ".join(pkgs)
    elif pm == "dnf" and pkgs:
        manual = "sudo dnf install -y " + " ".join(pkgs)
    elif pm == "pacman" and pkgs:
        manual = "sudo pacman -S --needed " + " ".join(pkgs)
    else:
        manual = ""
    return {"capabilities": caps, "packages": pkgs, "manual_command": manual}


def _linux_system_status():
    """Truthful capability status plus the minimal native package plan."""
    out = {
        "platform": "linux",
        "tkinter": _has("tkinter"),
        "gi": _has("gi"),
        "appindicator": False,
        "notify_send": _cmd_exists("notify-send"),
        "package_manager": None,
        "recommended_packages": [],
        "manual_install_command": "",
    }
    gx = _gnome_appindicator_extension_state()
    out["desktop"] = " ".join(filter(None, [os.environ.get("XDG_CURRENT_DESKTOP"), os.environ.get("DESKTOP_SESSION")]))
    out["gnome"] = bool(gx.get("gnome"))
    out["gnome_appindicator_extension"] = gx
    # Fedora's libappindicator-gtk3 ships AppIndicator3-0.1.typelib; Ayatana is
    # preferred where distributions provide it.  Probe the namespace, not just gi.
    out["appindicator"] = (
        _probe_gi_namespace("AyatanaAppIndicator3") or
        _probe_gi_namespace("AppIndicator3")
    )
    if _cmd_exists("apt-get"):
        out["package_manager"] = "apt"
    elif _cmd_exists("dnf"):
        out["package_manager"] = "dnf"
    elif _cmd_exists("pacman"):
        out["package_manager"] = "pacman"
    plan = _linux_package_plan(out)
    out["missing_capabilities"] = plan["capabilities"]
    out["recommended_packages"] = plan["packages"]
    out["manual_install_command"] = plan["manual_command"]
    return out

def _secret_store_status():
    st = dict(SECRET_STORE.backend_status())
    st["recommended_command"] = ""
    if st.get("fallback") and sys.platform.startswith("linux"):
        pm = _linux_system_status().get("package_manager")
        if pm == "dnf":
            st["recommended_command"] = "sudo dnf install -y libsecret"
        elif pm == "apt":
            st["recommended_command"] = "sudo apt-get update && sudo apt-get install -y libsecret-tools"
        elif pm == "pacman":
            st["recommended_command"] = "sudo pacman -S --needed libsecret"
    return st

def status():
    py = []
    missing = []
    for mod, pip, purpose, required_for in PYTHON_DEPS:
        present = _has(mod)
        rec = {"module": mod, "package": pip, "purpose": purpose,
               "required_for": required_for, "present": present}
        py.append(rec)
        if not present:
            missing.append(pip)
    system = {"platform": sys.platform}
    if sys.platform.startswith("linux"):
        system = _linux_system_status()
    elif sys.platform.startswith("win"):
        system.update({"tkinter": _has("tkinter"), "tray_native": True})
    elif sys.platform == "darwin":
        system.update({"tkinter": _has("tkinter"), "tray_native": True,
                       "notification_backend": bool(_cmd_exists("osascript"))})
    missing_system = []
    if sys.platform.startswith("linux"):
        labels = {
            "tkinter": "Tk native UI",
            "gi": "Python GI",
            "appindicator": "tray AppIndicator",
            "notify_send": "native notifications",
            "gnome_extension": "GNOME AppIndicator extension",
            "gnome_extension_enable": "GNOME AppIndicator extension disabled",
        }
        missing_system.extend(labels.get(x, x) for x in (system.get("missing_capabilities") or []))
    elif sys.platform.startswith("win"):
        if not system.get("tkinter"): missing_system.append("Tk native UI (Python Tcl/Tk component)")
    elif sys.platform == "darwin":
        if not system.get("tkinter"): missing_system.append("Tk native UI")
        if not system.get("notification_backend"): missing_system.append("macOS notification backend")
    return {
        "python": py,
        "missing_python": sorted(set(missing)),
        "missing_system": missing_system,
        "system": system,
        "state_path": STATE_PATH,
        "log_path": LOG_PATH,
        "requirements_version": REQUIREMENTS_VERSION,
        "setup_state": _load_state(),
        "secret_store": _secret_store_status(),
    }


def _pip_install(packages):
    if not packages:
        return True, "nothing to install"
    cmds = [
        [sys.executable, "-m", "pip", "install", "--user", *packages],
        [sys.executable, "-m", "pip", "install", "--user", "--break-system-packages", *packages],
    ]
    last = ""
    for cmd in cmds:
        _log("RUN " + " ".join(cmd))
        try:
            p = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                               text=True, timeout=300, check=False)
            last = (p.stdout or "")[-5000:]
            _log(last)
            if p.returncode == 0:
                return True, last
        except Exception as e:
            last = str(e)
            _log("ERROR " + last)
    return False, last


def _linux_install_system(pkgs):
    if not pkgs:
        return True, "nothing to install"
    st = _linux_system_status()
    pm = st.get("package_manager")
    if not pm:
        return False, "No supported Linux package manager detected."
    prefix = []
    if hasattr(os, "geteuid") and os.geteuid() != 0:
        if shutil.which("pkexec"):
            # Desktop first-run: let PolicyKit show a native admin prompt.
            prefix = ["pkexec"]
        elif shutil.which("sudo") and getattr(sys.stdin, "isatty", lambda: False)():
            prefix = ["sudo"]
        else:
            return False, "System packages need administrator approval (pkexec or an interactive sudo terminal)."
    if pm == "apt":
        cmds = [prefix + ["apt-get", "update"], prefix + ["apt-get", "install", "-y", *pkgs]]
    elif pm == "dnf":
        cmds = [prefix + ["dnf", "install", "-y", *pkgs]]
    else:
        cmds = [prefix + ["pacman", "-S", "--noconfirm", "--needed", *pkgs]]
    output = []
    for cmd in cmds:
        _log("RUN " + " ".join(cmd))
        try:
            # Keep stdin attached: sudo may legitimately need the user's password on first run.
            p = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                               text=True, timeout=600, check=False)
            output.append(p.stdout or "")
            _log((p.stdout or "")[-5000:])
            if p.returncode != 0:
                return False, "\n".join(output)[-5000:]
        except Exception as e:
            _log("ERROR " + str(e))
            return False, str(e)
    return True, "\n".join(output)[-5000:]


def _mac_install_system():
    """Best-effort native Tk repair on source/.py installs. Packaged builds should bundle it."""
    st = status().get("system", {})
    if st.get("tkinter"):
        return True, "macOS native dependencies already present", []
    brew = shutil.which("brew")
    if not brew:
        return False, "Tk is missing and Homebrew is unavailable; install Python with Tcl/Tk or use the packaged build.", []
    formula = f"python-tk@{sys.version_info.major}.{sys.version_info.minor}"
    cmd = [brew, "install", formula]
    _log("RUN " + " ".join(cmd))
    try:
        p = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, timeout=600, check=False)
        _log((p.stdout or "")[-5000:])
        return p.returncode == 0, (p.stdout or "")[-5000:], [formula]
    except Exception as e:
        _log("ERROR " + str(e)); return False, str(e), [formula]


def install_missing(include_system=True):
    """Install only what status() proves missing. Returns a full before/after report."""
    before = status()
    result = {"before": before, "python": None, "system": None}
    ok_py, msg_py = _pip_install(before["missing_python"])
    result["python"] = {"ok": ok_py, "message": msg_py,
                        "requested": before["missing_python"]}

    if include_system and sys.platform.startswith("linux"):
        ss = before["system"]
        # Install the distro bundle only when a native capability is actually missing.
        needs = bool(before.get("missing_system"))
        if needs:
            plan = _linux_package_plan(ss)
            pkgs = list(plan.get("packages") or [])
            ok_sys, msg_sys = _linux_install_system(pkgs)
            ext_ok, ext_msg = (True, "not GNOME")
            if ss.get("gnome"):
                ext_ok, ext_msg = _enable_gnome_appindicator_extension()
                if not ext_ok:
                    msg_sys = (msg_sys + "\nGNOME extension: " + ext_msg).strip()
            result["system"] = {
                "ok": ok_sys and ext_ok,
                "message": msg_sys,
                "requested": pkgs,
                "manual_command": plan.get("manual_command", ""),
                "gnome_extension_enabled": ext_ok,
            }
        else:
            result["system"] = {"ok": True, "message": "native Linux dependencies already present", "requested": []}
    elif include_system and sys.platform == "darwin" and before.get("missing_system"):
        ok_sys, msg_sys, req = _mac_install_system()
        result["system"] = {"ok": ok_sys, "message": msg_sys, "requested": req}
    result["after"] = status()
    result["ok"] = not result["after"]["missing_python"] and not result["after"].get("missing_system")
    _save_state({
        "requirements_version": REQUIREMENTS_VERSION,
        "auto_install_attempted": True,
        "attempt_state": "completed" if bool(result.get("ok")) else "failed",
        "attempted_at": time.time(),
        "missing_before": _missing_signature(before),
        "missing_after": _missing_signature(result.get("after") or {}),
        "ok": bool(result.get("ok")),
        "result": result,
    })
    return result


def first_run_preflight(auto_install=True, include_system=True):
    """Idempotent first-run/update dependency setup.

    Automatic privilege prompts are allowed once per REQUIREMENTS_VERSION and
    missing-set.  A later normal start only re-checks and reports status.  Bump
    REQUIREMENTS_VERSION when an update genuinely adds/changes requirements;
    manual ``system_setup.py --install`` always retries on explicit user request.
    """
    st = status()
    missing = bool(st.get("missing_python") or st.get("missing_system"))
    if not missing:
        prev = _load_state()
        if prev.get("requirements_version") != REQUIREMENTS_VERSION or not prev.get("ok"):
            _save_state({
                "requirements_version": REQUIREMENTS_VERSION, "ok": True,
                "completed_at": time.time(), "auto_install_attempted": bool(prev.get("auto_install_attempted")),
                "missing_after": _missing_signature(st),
            })
        return {"ok": True, "changed": False, "status": st, "first_run": False}

    prev = _load_state()
    sig = _missing_signature(st)
    # Automatic privilege escalation is a true first-run/update action: once per
    # dependency contract version, not once per changing missing-set.  A partial
    # install can legitimately change the probe result; that must not trigger a
    # fresh sudo/pkexec password prompt on the next ordinary start.  Explicit
    # ``system_setup.py --install`` remains the user's retry path.
    already_attempted = (
        prev.get("requirements_version") == REQUIREMENTS_VERSION and
        bool(prev.get("auto_install_attempted"))
    )
    if already_attempted:
        # Do not ask for the same sudo/pkexec password on every panel/Wake start.
        # The user can retry explicitly with system_setup.py --install.
        return {
            "ok": False, "changed": False, "status": st, "first_run": False,
            "deferred": True,
            "warning": "Dependencies are still missing; automatic setup was already attempted for this release. Run system_setup.py --install to retry.",
        }

    warning = "Missing components required by Wake/Scheduler/Tray/desktop notifications were detected."
    if not auto_install:
        return {"ok": False, "changed": False, "status": st, "warning": warning, "first_run": True}
    if not _setup_lock_acquire():
        return {"ok": False, "changed": False, "status": st, "pending": True,
                "warning": "Another dependency setup is already running."}
    try:
        # Re-check under the lock: panel.py and Wake may start almost together.
        st = status()
        if not st.get("missing_python") and not st.get("missing_system"):
            return {"ok": True, "changed": False, "status": st}
        # Persist the attempt BEFORE any sudo/pkexec prompt. If the user cancels
        # authentication or the process is interrupted, the next ordinary start
        # must not immediately ask again for the same release.
        _save_state({
            "requirements_version": REQUIREMENTS_VERSION,
            "auto_install_attempted": True,
            "attempt_state": "started",
            "attempted_at": time.time(),
            "missing_before": _missing_signature(st),
            "ok": False,
        })
        print("[First run] Missing dependencies detected; requesting setup once for this release.")
        if st.get("missing_python"):
            print("[First run] Python packages:", ", ".join(st["missing_python"]))
        if st.get("missing_system"):
            print("[First run] Native/system:", ", ".join(st.get("missing_system") or []))
            manual = (st.get("system") or {}).get("manual_install_command")
            if manual:
                print("[First run] Manual fallback:", manual)
        res = install_missing(include_system=include_system)
        res.update({"changed": True, "warning": warning, "first_run": True})
        return res
    finally:
        _setup_lock_release()


def install_secret_store_backend():
    """Explicit hardening only; never runs from automatic first-run."""
    before = _secret_store_status()
    if not before.get("fallback"):
        return {"ok": True, "changed": False, "before": before, "after": before}
    if not sys.platform.startswith("linux"):
        return {"ok": False, "changed": False, "before": before,
                "error": "No additional secret-store package is required on this OS."}
    pm = _linux_system_status().get("package_manager")
    pkg = {"dnf": ["libsecret"], "apt": ["libsecret-tools"], "pacman": ["libsecret"]}.get(pm, [])
    if not pkg:
        return {"ok": False, "changed": False, "before": before,
                "error": "Unsupported package manager for Secret Service hardening."}
    ok, msg = _linux_install_system(pkg)
    after = _secret_store_status()
    return {"ok": bool(ok and not after.get("fallback")), "changed": bool(ok),
            "before": before, "after": after, "requested": pkg, "message": msg}

def _cli(argv=None):
    parser = argparse.ArgumentParser(description="A-Tool first-run dependency check/install")
    parser.add_argument("--check", action="store_true", help="check only (default)")
    parser.add_argument("--install", action="store_true", help="install missing dependencies, then verify")
    parser.add_argument("--no-system", action="store_true", help="do not install native OS packages")
    parser.add_argument("--json", action="store_true", help="print machine-readable result")
    parser.add_argument("--harden-secrets", action="store_true", help="explicitly install the OS Secret Service helper on Linux")
    args = parser.parse_args(argv)
    result = install_secret_store_backend() if args.harden_secrets else (install_missing(include_system=not args.no_system) if args.install else status())
    st = result.get("after") if (args.install or args.harden_secrets) else result
    if args.json:
        print(json.dumps(result, indent=2, ensure_ascii=False))
    else:
        print("Dependency status:", "OK" if not st.get("missing_python") and not st.get("missing_system") else "MISSING")
        if st.get("missing_python"):
            print("  Python :", ", ".join(st["missing_python"]))
        if st.get("missing_system"):
            print("  Native :", ", ".join(st["missing_system"]))
        sysst = st.get("system") or {}
        if sysst.get("package_manager"):
            print("  Manager:", sysst.get("package_manager"))
        if sysst.get("manual_install_command"):
            print("  Manual :", sysst.get("manual_install_command"))
        gx = sysst.get("gnome_appindicator_extension") or {}
        if sysst.get("gnome"):
            print("  GNOME AppIndicator: installed=%s enabled=%s" % (gx.get("installed"), gx.get("enabled")))
        sec = st.get("secret_store") or (result.get("after") or {})
        if isinstance(sec, dict) and sec.get("backend"):
            print("  Secrets:", sec.get("backend"), "(OS protected)" if sec.get("os_protected") else "(private-file fallback)")
            if sec.get("recommended_command"):
                print("  Harden :", sec.get("recommended_command"))
    ok = bool(result.get("ok")) if args.harden_secrets else (not st.get("missing_python") and not st.get("missing_system"))
    return 0 if ok else 2


if __name__ == "__main__":
    raise SystemExit(_cli())
