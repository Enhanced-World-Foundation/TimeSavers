#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Local secret storage for A-Tool profiles.

Goals:
- secrets never need to live in the public profile JSON;
- prefer OS-protected storage without adding a Python dependency;
- never invent/home-grow encryption;
- fall back to a private 0600 file when no OS vault is available.

Backends:
  Windows : DPAPI (CurrentUser) -> encrypted file in ~/agentsystem/secrets
  macOS   : Keychain via native Security.framework
  Linux   : Secret Service via secret-tool when available
  fallback: private-file (0600, separated from profiles; not encrypted at rest)

Set L4M_SECRET_BACKEND to one of: auto, dpapi, keychain, secret-service, private-file.
"""
from __future__ import annotations

import base64
import ctypes
import ctypes.wintypes as wt
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
import contextlib
import threading
import time
from typing import Any, Dict

HOME = os.path.expanduser(os.environ.get("ENGINE_HOME", "~/agentsystem"))
ROOT = os.path.join(HOME, "secrets")
SERVICE = "l4m-atool"
SAVED_SECRET = "__L4M_SAVED_SECRET__"

_SECRET_EXACT = {
    "password", "passwd", "pass", "api_key", "apikey", "token", "secret",
    "authorization", "webhook", "access_token", "refresh_token", "client_secret",
}
_SECRET_PARTS = ("password", "api_key", "apikey", "secret", "authorization", "webhook", "access_token", "refresh_token", "client_secret")


def is_secret_key(key: Any) -> bool:
    lk = str(key or "").strip().lower()
    return lk in _SECRET_EXACT or any(part in lk for part in _SECRET_PARTS)


def _private(path: str, is_dir: bool = False) -> str:
    try:
        if os.name == "posix":
            os.chmod(path, 0o700 if is_dir else 0o600)
    except Exception:
        pass
    return path


def _ensure_root() -> None:
    os.makedirs(ROOT, exist_ok=True)
    _private(ROOT, True)


def _safe_id(profile: str) -> str:
    return hashlib.sha256(str(profile).encode("utf-8", "surrogatepass")).hexdigest()

_LOCAL_LOCKS={}
_LOCAL_LOCKS_GUARD=threading.Lock()
_LOCK_DEPTH=threading.local()

def _local_profile_lock(profile):
    key=_safe_id(profile)
    with _LOCAL_LOCKS_GUARD:
        lock=_LOCAL_LOCKS.get(key)
        if lock is None:
            lock=threading.RLock(); _LOCAL_LOCKS[key]=lock
    return key,lock

@contextlib.contextmanager
def profile_lock(profile: str, timeout_s: float=8.0, stale_s: float=120.0):
    key,local=_local_profile_lock(profile)
    with local:
        depths=getattr(_LOCK_DEPTH,"depths",None)
        if depths is None: depths={}; _LOCK_DEPTH.depths=depths
        if depths.get(key,0):
            depths[key]+=1
            try: yield
            finally: depths[key]-=1
            return
        _ensure_root(); lr=os.path.join(ROOT,".locks"); os.makedirs(lr,exist_ok=True); _private(lr,True); path=os.path.join(lr,key+".lock"); start=time.time()
        while True:
            try: os.mkdir(path); _private(path,True); break
            except FileExistsError:
                try:
                    if time.time()-os.path.getmtime(path)>stale_s: shutil.rmtree(path,ignore_errors=True); continue
                except Exception: pass
                if time.time()-start>=timeout_s: raise TimeoutError("profile secret transaction lock timeout")
                time.sleep(.05)
        depths[key]=1
        try: yield
        finally: depths.pop(key,None); shutil.rmtree(path,ignore_errors=True)

def _file_path(profile: str, suffix: str = ".json") -> str:
    _ensure_root()
    return os.path.join(ROOT, _safe_id(profile) + suffix)


def _atomic_bytes(path: str, data: bytes) -> None:
    os.makedirs(os.path.dirname(path), exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix=".secret-", dir=os.path.dirname(path))
    try:
        with os.fdopen(fd, "wb") as fh:
            fh.write(data)
            fh.flush()
            try:
                os.fsync(fh.fileno())
            except Exception:
                pass
        _private(tmp)
        os.replace(tmp, path)
        _private(path)
    finally:
        try:
            if os.path.exists(tmp):
                os.remove(tmp)
        except Exception:
            pass


def _json_bytes(data: Dict[str, Any]) -> bytes:
    return json.dumps(data or {}, ensure_ascii=False, separators=(",", ":")).encode("utf-8")


def _parse_json(raw: bytes | str | None) -> Dict[str, Any]:
    if not raw:
        return {}
    try:
        if isinstance(raw, bytes):
            raw = raw.decode("utf-8")
        obj = json.loads(raw)
        return obj if isinstance(obj, dict) else {}
    except Exception:
        return {}


# ---------- tree helpers -------------------------------------------------
def redact_for_profile(value: Any, key: str = "") -> Any:
    """Replace secret values with a stable sentinel while preserving profile shape."""
    if is_secret_key(key):
        return SAVED_SECRET if value not in (None, "", False, []) else ""
    if isinstance(value, dict):
        return {k: redact_for_profile(v, k) for k, v in value.items()}
    if isinstance(value, list):
        return [redact_for_profile(v, key) for v in value]
    return value


def extract_secret_tree(value: Any, key: str = "") -> Any:
    """Return a shape-matching tree containing only secret material."""
    if is_secret_key(key):
        return value if value not in (None, "", False, [], SAVED_SECRET) else None
    if isinstance(value, dict):
        out = {}
        for k, v in value.items():
            sv = extract_secret_tree(v, k)
            if sv not in (None, {}, []):
                out[k] = sv
        return out
    if isinstance(value, list):
        arr = [extract_secret_tree(v, key) for v in value]
        return arr if any(x not in (None, {}, []) for x in arr) else []
    return None


def hydrate_profile(public: Any, secrets: Any, key: str = "") -> Any:
    """Replace secret sentinels with server-side secret material."""
    if is_secret_key(key):
        if public == SAVED_SECRET:
            return secrets if secrets not in (None, {}, []) else ""
        return public
    if isinstance(public, dict):
        sdict = secrets if isinstance(secrets, dict) else {}
        return {k: hydrate_profile(v, sdict.get(k), k) for k, v in public.items()}
    if isinstance(public, list):
        slist = secrets if isinstance(secrets, list) else []
        return [hydrate_profile(v, slist[i] if i < len(slist) else None, key) for i, v in enumerate(public)]
    return public


def contains_plain_secret(value: Any, key: str = "") -> bool:
    if is_secret_key(key):
        return value not in (None, "", False, [], SAVED_SECRET)
    if isinstance(value, dict):
        return any(contains_plain_secret(v, k) for k, v in value.items())
    if isinstance(value, list):
        return any(contains_plain_secret(v, key) for v in value)
    return False


# ---------- backend selection -------------------------------------------
def _configured_backend() -> str:
    forced = str(os.environ.get("L4M_SECRET_BACKEND", "auto") or "auto").strip().lower()
    aliases = {"file": "private-file", "secretservice": "secret-service", "secret_service": "secret-service"}
    forced = aliases.get(forced, forced)
    if forced != "auto":
        return forced
    if sys.platform.startswith("win"):
        return "dpapi"
    if sys.platform == "darwin":
        return "keychain"
    if sys.platform.startswith("linux") and shutil.which("secret-tool"):
        return "secret-service"
    return "private-file"


def backend_name() -> str:
    return _configured_backend()


def _private_fallback_count() -> int:
    try:
        _ensure_root(); return sum(1 for fn in os.listdir(ROOT) if fn.endswith(".json") and len(fn)>=64)
    except Exception: return 0

def backend_status() -> Dict[str, Any]:
    configured=backend_name(); fallback_count=_private_fallback_count(); secure=configured in ("dpapi","keychain","secret-service")
    actual="private-file" if configured=="private-file" else ("mixed" if fallback_count else configured)
    return {"backend":configured,"configured_backend":configured,"actual_backend":actual,
            "encrypted_at_rest":bool(secure and fallback_count==0),"os_protected":bool(secure and fallback_count==0),
            "fallback":bool(configured=="private-file" or fallback_count),"fallback_profiles":int(fallback_count),
            "warning":(f"{fallback_count} secret profile(s) use the private 0600 fallback" if fallback_count else "")}


# ---------- Windows DPAPI -----------------------------------------------
class _DATA_BLOB(ctypes.Structure):
    _fields_ = [("cbData", wt.DWORD), ("pbData", ctypes.POINTER(ctypes.c_byte))]


def _blob(data: bytes):
    buf = ctypes.create_string_buffer(data)
    return _DATA_BLOB(len(data), ctypes.cast(buf, ctypes.POINTER(ctypes.c_byte))), buf


def _dpapi_protect(data: bytes) -> bytes:
    blob_in, keep = _blob(data)
    blob_out = _DATA_BLOB()
    crypt32 = ctypes.windll.crypt32
    kernel32 = ctypes.windll.kernel32
    CRYPTPROTECT_UI_FORBIDDEN = 0x1
    if not crypt32.CryptProtectData(ctypes.byref(blob_in), SERVICE, None, None, None,
                                    CRYPTPROTECT_UI_FORBIDDEN, ctypes.byref(blob_out)):
        raise ctypes.WinError()
    try:
        return ctypes.string_at(blob_out.pbData, blob_out.cbData)
    finally:
        kernel32.LocalFree(blob_out.pbData)


def _dpapi_unprotect(data: bytes) -> bytes:
    blob_in, keep = _blob(data)
    blob_out = _DATA_BLOB()
    crypt32 = ctypes.windll.crypt32
    kernel32 = ctypes.windll.kernel32
    CRYPTPROTECT_UI_FORBIDDEN = 0x1
    if not crypt32.CryptUnprotectData(ctypes.byref(blob_in), None, None, None, None,
                                      CRYPTPROTECT_UI_FORBIDDEN, ctypes.byref(blob_out)):
        raise ctypes.WinError()
    try:
        return ctypes.string_at(blob_out.pbData, blob_out.cbData)
    finally:
        kernel32.LocalFree(blob_out.pbData)


# ---------- backend operations -----------------------------------------
def _private_get(profile: str) -> Dict[str, Any]:
    p = _file_path(profile, ".json")
    try:
        _private(p)
        return _parse_json(open(p, "rb").read())
    except FileNotFoundError:
        return {}
    except Exception:
        return {}


def _private_set(profile: str, data: Dict[str, Any]) -> bool:
    _atomic_bytes(_file_path(profile, ".json"), _json_bytes(data))
    return True


def _private_delete(profile: str) -> None:
    try:
        os.remove(_file_path(profile, ".json"))
    except FileNotFoundError:
        pass


def _dpapi_get(profile: str) -> Dict[str, Any]:
    p = _file_path(profile, ".dpapi")
    try:
        enc = open(p, "rb").read()
    except FileNotFoundError:
        return {}
    return _parse_json(_dpapi_unprotect(enc))


def _dpapi_set(profile: str, data: Dict[str, Any]) -> bool:
    _atomic_bytes(_file_path(profile, ".dpapi"), _dpapi_protect(_json_bytes(data)))
    return True


def _dpapi_delete(profile: str) -> None:
    try:
        os.remove(_file_path(profile, ".dpapi"))
    except FileNotFoundError:
        pass


def _mac_security_frameworks():
    sec = ctypes.cdll.LoadLibrary("/System/Library/Frameworks/Security.framework/Security")
    cf = ctypes.cdll.LoadLibrary("/System/Library/Frameworks/CoreFoundation.framework/CoreFoundation")
    sec.SecKeychainAddGenericPassword.restype = ctypes.c_int32
    sec.SecKeychainFindGenericPassword.restype = ctypes.c_int32
    sec.SecKeychainItemFreeContent.restype = ctypes.c_int32
    sec.SecKeychainItemDelete.restype = ctypes.c_int32
    sec.SecKeychainItemModifyAttributesAndData.restype = ctypes.c_int32
    sec.SecKeychainItemModifyAttributesAndData.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_uint32, ctypes.c_void_p]
    cf.CFRelease.argtypes = [ctypes.c_void_p]
    return sec, cf

def _mac_find(profile: str, want_password=True):
    sec, cf = _mac_security_frameworks()
    service = SERVICE.encode("utf-8")
    account = str(profile).encode("utf-8")
    pw_len = ctypes.c_uint32(0)
    pw_ptr = ctypes.c_void_p()
    item = ctypes.c_void_p()
    status = sec.SecKeychainFindGenericPassword(
        None, len(service), ctypes.c_char_p(service), len(account), ctypes.c_char_p(account),
        ctypes.byref(pw_len) if want_password else None, ctypes.byref(pw_ptr) if want_password else None,
        ctypes.byref(item))
    return status, pw_len, pw_ptr, item, sec, cf

def _keychain_get(profile: str) -> Dict[str, Any]:
    status, pw_len, pw_ptr, item, sec, cf = _mac_find(profile, True)
    if status != 0:
        return {}
    try:
        raw = ctypes.string_at(pw_ptr, int(pw_len.value)) if pw_ptr else b""
        return _parse_json(raw)
    finally:
        try:
            if pw_ptr: sec.SecKeychainItemFreeContent(None, pw_ptr)
        except Exception: pass
        try:
            if item: cf.CFRelease(item)
        except Exception: pass

def _keychain_delete(profile: str) -> None:
    try:
        status, _n, _p, item, sec, cf = _mac_find(profile, False)
        if status == 0 and item:
            try: sec.SecKeychainItemDelete(item)
            finally: cf.CFRelease(item)
    except Exception:
        pass

def _keychain_set(profile: str, data: Dict[str, Any]) -> bool:
    raw=_json_bytes(data); buf=ctypes.create_string_buffer(raw); status,_n,_p,item,sec,cf=_mac_find(profile,False)
    if status==0 and item:
        try: return sec.SecKeychainItemModifyAttributesAndData(item,None,len(raw),ctypes.cast(buf,ctypes.c_void_p))==0
        finally:
            try: cf.CFRelease(item)
            except Exception: pass
    sec,_cf=_mac_security_frameworks(); service=SERVICE.encode("utf-8"); account=str(profile).encode("utf-8")
    return sec.SecKeychainAddGenericPassword(None,len(service),ctypes.c_char_p(service),len(account),ctypes.c_char_p(account),len(raw),ctypes.cast(buf,ctypes.c_void_p),None)==0


def _secret_service_get(profile: str) -> Dict[str, Any]:
    r = subprocess.run(["secret-tool", "lookup", "service", SERVICE, "profile", profile],
                       text=True, capture_output=True, timeout=5)
    return _parse_json(r.stdout) if r.returncode == 0 else {}


def _secret_service_set(profile: str, data: Dict[str, Any]) -> bool:
    r = subprocess.run(["secret-tool", "store", "--label", f"A-Tool secrets: {profile}",
                        "service", SERVICE, "profile", profile], input=_json_bytes(data).decode("utf-8"),
                       text=True, capture_output=True, timeout=8)
    return r.returncode == 0


def _secret_service_delete(profile: str) -> None:
    subprocess.run(["secret-tool", "clear", "service", SERVICE, "profile", profile],
                   stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=5)


def get(profile: str) -> Dict[str, Any]:
    b = backend_name()
    try:
        if b == "dpapi":
            data = _dpapi_get(profile)
            return data or _private_get(profile)
        if b == "keychain":
            data = _keychain_get(profile)
            return data or _private_get(profile)
        if b == "secret-service":
            data = _secret_service_get(profile)
            return data or _private_get(profile)
    except Exception:
        # A previous write may have used the private fallback when the OS vault was
        # unavailable/locked. Read that fallback before reporting an empty secret set.
        return _private_get(profile)
    return _private_get(profile)


def set(profile: str, data: Dict[str, Any]) -> bool:
    data = data if isinstance(data, dict) else {}
    b = backend_name()
    try:
        if b == "dpapi":
            ok = _dpapi_set(profile, data)
            if ok: _private_delete(profile)
            return ok
        if b == "keychain":
            ok = _keychain_set(profile, data)
            if ok: _private_delete(profile)
            return ok
        if b == "secret-service":
            if _secret_service_set(profile,data): _private_delete(profile); return True
            forced=str(os.environ.get("L4M_SECRET_BACKEND","auto") or "auto").strip().lower()
            if forced not in ("","auto"): return False
            return _private_set(profile,data)
    except Exception:
        forced=str(os.environ.get("L4M_SECRET_BACKEND","auto") or "auto").strip().lower()
        if forced not in ("","auto","private-file","file"): return False
    return _private_set(profile,data)

def promote_private_fallback(profile: str) -> bool:
    """Move an existing 0600 fallback into the OS vault when it becomes available."""
    if backend_name() == "private-file":
        return False
    data = _private_get(profile)
    if not data:
        return False
    return bool(set(profile, data))


def delete(profile: str) -> None:
    b = backend_name()
    try:
        if b == "dpapi": _dpapi_delete(profile)
        elif b == "keychain": _keychain_delete(profile)
        elif b == "secret-service": _secret_service_delete(profile)
    except Exception:
        pass
    # Also remove a previous fallback copy after backend changes.
    _private_delete(profile)
    try:
        os.remove(_file_path(profile, ".dpapi"))
    except Exception:
        pass


def rename(old: str, new: str) -> bool:
    data = get(old)
    if data:
        if not set(new, data):
            return False
    delete(old)
    return True

def load_profile_file(path: str) -> Dict[str, Any]:
    """Load a profile for backend execution and hydrate saved secret sentinels.

    Legacy plaintext profiles remain usable; panel.py migrates them to the vault on
    normal startup/save. This helper never writes or prompts.
    """
    try:
        raw = json.load(open(path, encoding="utf-8"))
    except Exception:
        return {}
    if not isinstance(raw, dict):
        return {}
    if contains_plain_secret(raw):
        return raw
    name = str(raw.get("name") or os.path.basename(path).rsplit(".", 1)[0])
    return hydrate_profile(raw, get(name))
