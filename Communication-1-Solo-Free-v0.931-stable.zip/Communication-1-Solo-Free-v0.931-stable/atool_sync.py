import os
import threading
import json
import time
import datetime
import random
import stat
import shutil
import contextlib
from pathlib import Path


def _log(msg):
    """Cichy log do ~/agentsystem/logs/atools.log. Bez zaleznosci od engine."""
    try:
        home = os.path.expanduser(os.environ.get("ENGINE_HOME", "~/agentsystem"))
        d = os.path.join(home, "logs"); os.makedirs(d, exist_ok=True)
        try:
            if os.name == "posix": os.chmod(d, 0o700)
        except Exception: pass
        lp = os.path.join(d, "atools.log")
        with open(lp, "a", encoding="utf-8") as f:
            f.write("atool_sync: " + str(msg) + "\n")
        try:
            if os.name == "posix": os.chmod(lp, 0o600)
        except Exception: pass
    except Exception:
        pass

@contextlib.contextmanager
def _cross_process_lock(path, timeout_s=8.0, stale_s=60.0):
    """Small dependency-free interprocess mutex based on atomic mkdir.

    Used only around short read-modify-write operations. A stale lock left by a
    killed process is recovered after stale_s; normal code never waits forever.
    """
    start = time.time()
    os.makedirs(os.path.dirname(path), exist_ok=True)
    while True:
        try:
            os.mkdir(path)
            try:
                if os.name == "posix": os.chmod(path, 0o700)
            except Exception: pass
            try:
                with open(os.path.join(path, "owner.json"), "w", encoding="utf-8") as f:
                    json.dump({"pid": os.getpid(), "at": time.time()}, f)
            except Exception: pass
            break
        except FileExistsError:
            try:
                owner={}
                try: owner=json.load(open(os.path.join(path,"owner.json"),encoding="utf-8")) or {}
                except Exception: pass
                pid=owner.get("pid")
                live=False
                try:
                    if pid:
                        os.kill(int(pid),0); live=True
                except Exception: live=False
                # A short write lock owned by a live process is never stolen.
                # Age only recovers a corrupt legacy lock without a usable PID.
                if (pid and not live) or (not pid and time.time() - os.path.getmtime(path) > stale_s):
                    shutil.rmtree(path, ignore_errors=True)
                    continue
            except Exception:
                pass
            if time.time() - start >= timeout_s:
                raise TimeoutError("ecosystem lock timeout")
            time.sleep(0.05)
    try:
        yield
    finally:
        shutil.rmtree(path, ignore_errors=True)


def _ecosystem_lock_path():
    return os.path.join(eco_dir(), ".ecosystem-write.lock")


def _wake_update_lock_path():
    home = os.path.expanduser(os.environ.get("ENGINE_HOME", "~/agentsystem"))
    return os.path.join(home, "system", "wake", ".update.lock")


def _register_in_ecosystem_unlocked():
    """Wykonywane na starcie każdego A-Toola. Samorejestracja w centralnym ecosystem.json oraz zrzut launchera poziom wyżej."""
    HERE = os.path.dirname(os.path.abspath(__file__))
    PARENT_DIR = os.path.dirname(HERE) # Katalog matka ("Time Savers Ecosystem")
    atool_path = os.path.join(HERE, "atool.json")
    
    # Wspolne pliki ekosystemu: TO SAMO zrodlo co publish_schedule i /api/schedule_status.
    # eco_dir() sam wybiera nadrzedny .eco_data, a gdy read-only -> ~/agentsystem/.eco_data.
    # Recznie liczona sciezka rozjezdzala sie z odczytem przy fallbacku (pusty scheduler w UI).
    system_dir = eco_dir()
    os.makedirs(system_dir, exist_ok=True)
    eco_path = os.path.join(system_dir, "ecosystem.json")
    
    if not os.path.exists(atool_path):
        return # Brak atool.json - ignoruj
        
    with open(atool_path, "r", encoding="utf-8") as f:
        my_data = json.load(f)
        
    # Tworzymy eko, jeśli to pierwszy uruchomiony w historii A-Tool
    if os.path.exists(eco_path):
        with open(eco_path, "r", encoding="utf-8") as f:
            try:
                eco = json.load(f)
            except:
                eco = {"atools": []}
    else:
        eco = {"orchestrator": my_data.get("id"), "atools": []}
        
    # Aktualizuj wpis
    atools = eco.get("atools", [])
    my_id = my_data.get("id")
    
    # Aktualizuj rekord BEZ gubienia stanu wspólnego. Poprzednia implementacja
    # usuwała rekord i kasowała trust/schedule_live przy każdym starcie.
    previous = next((dict(a) for a in atools if a.get("id") == my_id), {})
    if previous:
        allowed, reason = _source_authorized_for_existing_record(HERE, previous)
        if not allowed:
            print(f"[Ecosystem] REFUSED '{my_id}': {reason}; "
                  f"registered path={previous.get('install_path') or previous.get('path')}, candidate={HERE}")
            return False
    atools = [a for a in atools if a.get("id") != my_id]
    updated = dict(previous)
    updated.update({
        "id": my_id,
        "name": my_data.get("name"),
        "number": my_data.get("number"),
        "version": my_data.get("version"),
        "path": os.path.basename(HERE),
        "install_path": os.path.realpath(HERE),
        "port": my_data.get("port"),
        "main": my_data.get("main", "panel.py"),
        "ui": my_data.get("ui", {}) if isinstance(my_data.get("ui"), dict) else {},
        "capabilities": my_data.get("capabilities", []),
        "shared_resources": my_data.get("shared_resources", {}),
        "schedule_profile": my_data.get("schedule_profile", {}),
        "ecosystem": my_data.get("ecosystem", {}),
        "last_seen": datetime.datetime.now().isoformat()
    })
    # Trust is not self-asserted. The first local/orchestrator A-Tool bootstraps
    # the ecosystem as the root tool; every later previously-unknown A-Tool starts
    # pending until the user (or future verified publisher signature) accepts it.
    if not eco.get("orchestrator") and not previous and not atools:
        eco["orchestrator"] = my_id
    if "trust" not in updated:
        updated["trust"] = "accepted" if eco.get("orchestrator") == my_id else "pending"
    try:
        _wp = os.path.join(HERE, "wake.py")
        if os.path.isfile(_wp):
            updated["wake_candidate"] = {
                "release": _source_int_constant(_wp, "WAKE_RELEASE", 0),
                "schema": _source_int_constant(_wp, "WAKE_SCHEMA", 1),
                "sha256": _sha256_file(_wp),
            }
    except Exception:
        pass
    atools.append(updated)
    
    eco["atools"] = atools
    
    tmp = _private_tmp(eco_path)
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(eco, f, indent=2, ensure_ascii=False)
    try:
        if os.name == "posix": os.chmod(tmp, 0o600)
    except Exception: pass
    os.replace(tmp, eco_path)
        
    print(f"[Ecosystem] Registered '{my_id}' in {eco_path}")
    
    # --- Tworzenie launcherów / plików plug 'n' play ---
    return True


def _eco_paths():
    """Zwraca (HERE, PARENT_DIR, eco_path) — wspolne dla rejestracji i publikacji harmonogramu.
    KRYTYCZNE: eco_path pochodzi z eco_dir() — TEGO SAMEGO zrodla, ktore czyta panel
    (/api/schedule_status) i boot. Wczesniej liczylismy sciezke recznie jako
    PARENT/.eco_data, co przy fallbacku do ~/agentsystem/.eco_data rozjezdzalo sie
    z odczytem: rejestracja pisala do jednego pliku, UI czytalo z drugiego -> pusty
    scheduler mimo dzialajacego wzbudzacza."""
    HERE = os.path.dirname(os.path.abspath(__file__))
    PARENT_DIR = os.path.dirname(HERE)
    eco_path = os.path.join(eco_dir(), "ecosystem.json")
    return HERE, PARENT_DIR, eco_path


def _publish_schedule_unlocked(runs=None, ai_mode=None, active_from=None, active_until=None, extra=None):
    """A-Tool PUBLIKUJE swoj realny harmonogram do wspolnego ecosystem.json.
    Dzieki temu zewnetrzny wzbudzacz (wake.py na crontab) wie KOGO i KIEDY odpalic,
    nawet gdy panel jest zamkniety.

      runs         : lista godzin "HH:MM" kiedy A-Tool ma sie odpalic (z jego schedulera)
      ai_mode      : tryb AI ("off"/"fast"/"balanced"/"deep") — wzbudzacz moze go respektowac
      active_from  : "YYYY-MM-DD" od kiedy harmonogram aktywny (None = od zawsze)
      active_until : "YYYY-MM-DD" do kiedy (None = bez konca) — daty aktywnosci niezaleznie co to za tool
      extra        : dict z dodatkowymi polami (np. every_hours, timezone)

    Zapisuje profilowy kontrakt do schedules_live[profile]. Dla zgodnosci wstecznej
    schedule_live pozostaje lustrzanym wpisem ostatnio opublikowanego profilu.
    NIE nadpisuje calego ecosystem.json.
    """
    HERE, PARENT_DIR, eco_path = _eco_paths()
    atool_path = os.path.join(HERE, "atool.json")
    if not os.path.exists(atool_path):
        return False
    try:
        with open(atool_path, "r", encoding="utf-8") as f:
            my_id = json.load(f).get("id")
    except Exception:
        return False
    if not my_id:
        return False

    # wczytaj istniejacy eco (albo pusty)
    eco = {"atools": []}
    if os.path.exists(eco_path):
        try:
            with open(eco_path, "r", encoding="utf-8") as f:
                eco = json.load(f)
        except Exception:
            eco = {"atools": []}
    previous = next((a for a in eco.get("atools", [])
                     if isinstance(a, dict) and a.get("id") == my_id), {})
    if previous:
        allowed, reason = _source_authorized_for_existing_record(HERE, previous)
        if not allowed:
            print(f"[Ecosystem] SCHEDULE REFUSED '{my_id}': {reason}")
            return False

    sched_live = {
        "runs": list(runs or []),
        "ai_mode": ai_mode,
        "active_from": active_from,
        "active_until": active_until,
        "folder": os.path.basename(HERE),      # human/back-compat label
        "install_path": os.path.realpath(HERE), # canonical local path; Wake pins it in launch contract
        "main": None,                           # uzupelnione nizej z atool.json
        "main_sha256": None,                    # hash pliku main — wake porownuje przed startem
        "published": datetime.datetime.now().isoformat(),
    }
    if isinstance(extra, dict):
        sched_live.update(extra)
    _extra = extra or {}
    profile_key = str(_extra.get("entry_id") or _extra.get("preset_id") or _extra.get("profile_id") or _extra.get("agent") or "__default__").strip() or "__default__"
    # profile_id remains the compatibility key used by older Wake builds; entry_id
    # is the neutral name used by generic A-Tools, presets and native tasks.
    sched_live["profile_id"] = profile_key
    sched_live.setdefault("entry_id", profile_key)
    sched_live.setdefault("entry_kind", str(_extra.get("entry_kind") or ("profile" if _extra.get("agent") else "task")))
    sched_live.setdefault("display_name", str(_extra.get("display_name") or _extra.get("agent") or profile_key))
    # dolacz main z atool.json (co uruchomic) + policz jego hash
    try:
        with open(atool_path, "r", encoding="utf-8") as f:
            sched_live["main"] = json.load(f).get("main", "panel.py")
    except Exception:
        sched_live["main"] = "panel.py"
    try:
        import hashlib
        _mp = os.path.join(HERE, sched_live["main"])
        with open(_mp, "rb") as _f:
            sched_live["main_sha256"] = hashlib.sha256(_f.read()).hexdigest()
    except Exception:
        sched_live["main_sha256"] = None       # brak hasha = wake potraktuje jako niezweryfikowany

    # Preferred execution contract: headless work is independent from panel.py.
    # The browser panel remains an optional UI only.
    try:
        # A generic A-Tool/preset may publish its own launch contract.  Keep it
        # verbatim.  Communication's wake_runner is only the compatibility/default
        # when no explicit contract was supplied.
        _runner = os.path.join(HERE, "wake_runner.py")
        _agent = str(sched_live.get("agent") or "").strip()
        if not isinstance(sched_live.get("launch"), dict) and os.path.isfile(_runner) and _agent:
            import hashlib
            with open(_runner, "rb") as _rf:
                _runner_sha = hashlib.sha256(_rf.read()).hexdigest()
            sched_live["launch"] = {
                "type": "python", "entry": "wake_runner.py",
                "args": ["--agent", _agent], "sha256": _runner_sha,
                "self_published": True,
            }
    except Exception:
        pass

    # Multiple profiles of one Template A-Tool must never overwrite each other.
    found = False
    for a in eco.get("atools", []):
        if a.get("id") == my_id:
            mp = a.get("schedules_live") if isinstance(a.get("schedules_live"), dict) else {}
            if not mp and isinstance(a.get("schedule_live"), dict) and a.get("schedule_live"):
                old = dict(a.get("schedule_live")); old_key = str(old.get("profile_id") or old.get("agent") or "__default__")
                mp[old_key] = old
            mp[profile_key] = sched_live
            a["schedules_live"] = mp
            a["schedule_live"] = sched_live  # legacy mirror only
            found = True
            break
    if not found:
        eco.setdefault("atools", []).append({"id": my_id, "schedules_live": {profile_key: sched_live}, "schedule_live": sched_live})

    os.makedirs(os.path.dirname(eco_path), exist_ok=True)
    tmp = _private_tmp(eco_path)
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(eco, f, indent=2)
    try:
        if os.name == "posix": os.chmod(tmp, 0o600)
    except Exception: pass
    os.replace(tmp, eco_path)   # atomowy zapis — nie zostawia polowicznego pliku
    return True

def publish_schedule(runs=None, ai_mode=None, active_from=None, active_until=None, extra=None):
    with _cross_process_lock(_ecosystem_lock_path()):
        return _publish_schedule_unlocked(runs, ai_mode, active_from, active_until, extra)


def publish_wake_entry(entry_id, *, runs=None, launch=None, display_name=None, entry_kind="task",
                       active_from=None, active_until=None, network_required=False,
                       retry_when_online=False, when_online=False, collision_keys=None,
                       ui_after_run="inherit", notify_after_run="inherit", metadata=None):
    """Publish a neutral Wake entry for any A-Tool, preset or native task.

    Wake does not need to know the product domain.  The entry owns its launch
    contract and optional metadata; Wake owns timing, safe process execution,
    retry/collision policy and UI-after-run behaviour.
    """
    entry_id = str(entry_id or "").strip()
    if not entry_id:
        raise ValueError("entry_id is required")
    extra = dict(metadata or {})
    extra.update({
        "entry_id": entry_id,
        "profile_id": entry_id,
        "entry_kind": str(entry_kind or "task"),
        "display_name": str(display_name or entry_id),
        "network_required": bool(network_required),
        "retry_when_online": bool(retry_when_online),
        "when_online": bool(when_online),
        "ui_after_run": str(ui_after_run or "inherit"),
        "notify_after_run": str(notify_after_run or "inherit"),
    })
    if launch is not None:
        if not isinstance(launch, dict):
            raise ValueError("launch must be a dict")
        _launch = dict(launch)
        _launch.setdefault("self_published", True)
        # Convenience for normal source development: a local simple entry gets
        # its pin automatically.  Builder/release signing remains a separate layer.
        if not _launch.get("sha256") and _launch.get("entry"):
            try:
                _lp = os.path.join(os.path.dirname(os.path.abspath(__file__)), str(_launch.get("entry")))
                if os.path.isfile(_lp):
                    _launch["sha256"] = _sha256_file(_lp)
            except Exception:
                pass
        extra["launch"] = _launch
    if collision_keys is not None:
        extra["collision_keys"] = list(collision_keys) if not isinstance(collision_keys, str) else [collision_keys]
    return publish_schedule(runs=runs or [], active_from=active_from, active_until=active_until, extra=extra)


def unpublish_schedule(profile_id):
    """Remove one profile schedule without touching sibling profiles/tool trust."""
    HERE, _PARENT, eco_path = _eco_paths(); profile_id = str(profile_id or "").strip()
    if not profile_id or not os.path.exists(eco_path): return False
    try:
        with open(os.path.join(HERE,"atool.json"),encoding="utf-8") as f: my_id=json.load(f).get("id")
    except Exception: return False
    with _cross_process_lock(_ecosystem_lock_path()):
        try:
            with open(eco_path,encoding="utf-8") as f: eco=json.load(f)
        except Exception: return False
        for a in eco.get("atools",[]):
            if a.get("id") != my_id: continue
            mp=a.get("schedules_live") if isinstance(a.get("schedules_live"),dict) else {}
            if profile_id not in mp: return False
            mp.pop(profile_id,None); a["schedules_live"]=mp
            a["schedule_live"] = (next(reversed(mp.values())) if mp else {})
            tmp = _private_tmp(eco_path)
            with open(tmp,"w",encoding="utf-8") as f: json.dump(eco,f,indent=2,ensure_ascii=False)
            os.replace(tmp,eco_path); return True
    return False


    
def register_in_ecosystem():
    with _cross_process_lock(_ecosystem_lock_path()):
        return _register_in_ecosystem_unlocked()


# ── ODCZYT EKOSYSTEMU (dodane: communicator widzi rodzenstwo) ────────────────
# register_in_ecosystem() tylko PISZE. Ta funkcja CZYTA — panel jej uzywa, zeby
# pokazac inne A-Tools wrzucone do katalogu nadrzednego. Bezpieczna gdy pliku
# brak (a-tool uruchomiony standalone, poza ekosystemem) -> zwraca pusto.


# ============================================================================
#  ensure_ready() — BOOTSTRAP PIERWSZEGO RUNU (najkrotsza wersja)
# ============================================================================
#  Problem: pierwszy A-Tool musi zalozyc wymagane katalogi/pliki, a katalog
#  nadrzedny moze byc NIEZAPISYWALNY (Program Files, nosnik read-only, brak
#  uprawnien). Wtedy rejestracja cicho padala i nie bylo ani ecosystem.json,
#  ani launchera — "blokada".
#
#  Rozwiazanie: probuj nadrzedny, a gdy nie da sie pisac — FALLBACK do
#  ~/agentsystem/.eco_data. A-Tool zawsze wystartuje. Zwraca status, zeby
#  panel mogl pokazac, gdzie realnie wyladowalo.
# ============================================================================

def _writable(d):
    """Czy da sie realnie pisac w tym katalogu (test zapisem, nie uprawnieniami)."""
    t = None
    try:
        os.makedirs(d, exist_ok=True)
        # A fixed .wtest races when panel/Wake/tool children start together: one
        # process removes another's probe, which made that process falsely choose
        # ~/agentsystem/.eco_data while its sibling chose ~/agentsystem. The two
        # processes then owned different ecosystem.json/run.lock files.
        t = os.path.join(d, f".wtest-{os.getpid()}-{threading.get_ident():x}-{random.randint(0,0xffffff):06x}")
        with open(t, "x") as f:
            f.write("x")
        os.remove(t)
        return True
    except Exception:
        return False
    finally:
        try:
            if t and os.path.exists(t): os.remove(t)
        except Exception: pass


def eco_dir():
    """Gdzie trzymamy wspolne pliki ekosystemu (ecosystem.json).
    ZASADA: RAZEM z reszta danych A-Toola (profiles/, data/, logs/), czyli w
    ENGINE_HOME (~/agentsystem). Wczesniej szlo do parent/.eco_data, co ODDZIELALO
    ecosystem.json od reszty i rozjezdzalo sie z tym, co user faktycznie ma
    ('ecosystem.json jest w agentsystem'). Najpierw szukamy ISTNIEJACEGO pliku,
    zeby nie zgubic rejestracji; gdy nigdzie go nie ma — zakladamy w ENGINE_HOME."""
    home = os.path.expanduser(os.environ.get("ENGINE_HOME", "~/agentsystem"))
    HERE = os.path.dirname(os.path.abspath(__file__))
    parent = os.path.dirname(HERE)
    candidates = [
        home,                                   # ~/agentsystem — razem z profiles/data/logs (PREFEROWANE)
        os.path.join(home, ".eco_data"),        # ~/agentsystem/.eco_data
        os.path.join(parent, ".eco_data"),      # stary domyslny (parent instalki) — back-compat
    ]
    for c in candidates:
        if os.path.exists(os.path.join(c, "ecosystem.json")):
            return c
    if _writable(home):
        os.makedirs(home, exist_ok=True)
        return home
    fb = os.path.join(home, ".eco_data")
    os.makedirs(fb, exist_ok=True)
    return fb


SYSTEM_WAKE_FILES = ("wake.py", "wake_ui.py", "wake_job_wrapper.py", "system_setup.py", "secret_store.py",
                     "hq.py", "events.py", "wake_i18n.py", "release_signing.py")


def _central_verifier(root, fallback_dir):
    """Load the signature verifier from the CENTRAL Wake, never from the candidate.

    Importing `release_signing` normally resolves to the candidate's own copy —
    a hostile package then ships a verifier that returns ok=True. The active
    central version is the only acceptable source; `fallback_dir` is used only
    when no central Wake exists yet (first install).
    """
    import importlib.util
    # Order matters. The copy pinned beside the trust store is the anchor: it is
    # written once when trust is established and is not swapped by any later
    # package, so it is preferred over the active version directory.
    paths = [os.path.join(root, "release_signing.py")]
    try:
        act = json.load(open(os.path.join(root, "active.json"), encoding="utf-8")) or {}
        vd = str(act.get("version_dir") or "").replace("/", os.sep)
        if vd:
            paths.append(os.path.join(root, vd, "release_signing.py"))
    except Exception:
        pass
    # The candidate's own verifier is acceptable ONLY on a true first install —
    # when no trust store exists either. Otherwise a hostile package could delete
    # active.json and have its own "ok=True" verifier loaded.
    if not os.path.isfile(os.path.join(root, "publisher_keys.json")):
        paths.append(os.path.join(fallback_dir, "release_signing.py"))
    for p in paths:
        if not os.path.isfile(p):
            continue
        try:
            spec = importlib.util.spec_from_file_location(
                f"_l4m_rsig_{abs(hash(p)) & 0xffffff:x}", p)
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            return mod, p
        except Exception:
            continue
    return None, ""


def _source_authorized_for_existing_record(here, previous):
    """May this directory rebind an already registered A-Tool identity?

    There is no switchable developer mode.  An unsigned workspace stays freely
    editable while the central installation has no publisher key.  Once a
    Builder product establishes publisher trust, only a package verified by
    that key may take over the stable tool id.
    """
    here=os.path.realpath(str(here))
    previous=previous if isinstance(previous,dict) else {}
    old=str(previous.get("install_path") or "").strip()
    if old:
        try:
            if os.path.realpath(os.path.expanduser(old))==here:
                return True,"same install path"
        except Exception: pass
    home=os.path.realpath(os.path.expanduser(os.environ.get("ENGINE_HOME","~/agentsystem")))
    root=os.path.join(home,"system","wake")
    verifier,_path=_central_verifier(root,here)
    keys={}
    if verifier is not None:
        try: keys=verifier.load_trusted_keys()
        except Exception: keys={}
    if not keys:
        return True,"editable source workspace"
    try:
        verifier_is_central=bool(_path and os.path.commonpath([os.path.realpath(root),os.path.realpath(_path)])==os.path.realpath(root))
    except Exception: verifier_is_central=False
    if verifier is not None and verifier_is_central:
        try:
            signed=verifier.verify_release(here,keys=keys,strict="code")
            if signed.get("ok"):
                return True,"verified publisher package"
        except Exception: pass
    return False,"signed AgentSystem refuses an unsigned or foreign copy with the same A-Tool id"


def _private_tmp(path):
    """Writer-private temp path.

    ecosystem.json / active.json are written by every A-Tool and by Wake. With a
    shared "<file>.tmp" two writers destroy each other's temp file: one replace()
    succeeds, the other raises ENOENT and its write is silently lost.
    """
    return f"{path}.{os.getpid()}.{threading.get_ident():x}.{random.randint(0, 0xffffff):06x}.tmp"


def _sha256_file(path):
    import hashlib
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _source_int_constant(path, name, default=0):
    try:
        import re
        txt = open(path, encoding="utf-8").read(8192)
        m = re.search(rf"^\s*{re.escape(name)}\s*=\s*(\d+)\s*$", txt, re.M)
        return int(m.group(1)) if m else default
    except Exception:
        return default


def _ensure_system_wake_unlocked():
    """Promote this folder's Wake into the existing AgentSystem.

    Raw source is editable and may refresh the central Wake without a mode flag.
    A Builder product establishes publisher trust and thereafter only verified
    signed products may update it.  No installer and no developer bypass exist.
    """
    here = os.path.dirname(os.path.abspath(__file__))
    home = os.path.expanduser(os.environ.get("ENGINE_HOME", "~/agentsystem"))
    root = os.path.join(home, "system", "wake")
    versions = os.path.join(root, "versions")
    staging = os.path.join(root, "staging")
    os.makedirs(versions, exist_ok=True); os.makedirs(staging, exist_ok=True)
    source_wake = os.path.join(here, "wake.py")
    source_boot = os.path.join(here, "my_wake.py")
    if not os.path.isfile(source_wake) or not os.path.isfile(source_boot):
        return {"ok": False, "error": "Wake candidate/bootstrap missing"}

    signature = {"ok": False, "signed": False, "key_id": "", "reason": "verifier unavailable"}
    pinned_keys = {}
    trust_state = "unavailable"
    _rsig, _rsig_path = _central_verifier(root, here)
    if _rsig is not None:
        try:
            pinned_keys = _rsig.load_trusted_keys()
            if pinned_keys:
                signature = _rsig.verify_release(here, keys=pinned_keys, strict="code")
                trust_state = "present"
            else:
                embedded = _rsig.load_publisher_keys(os.path.join(here, "publisher_keys.json"))
                if embedded:
                    first_check = _rsig.verify_release(here, keys=embedded, strict="code")
                    if first_check.get("ok"):
                        trust_state = _rsig.bootstrap_trust(os.path.join(here, "publisher_keys.json"))
                        pinned_keys = _rsig.load_trusted_keys()
                        signature = _rsig.verify_release(here, keys=pinned_keys, strict="code")
                    else:
                        signature = first_check
                else:
                    trust_state = "empty"
        except Exception as _sigex:
            signature = {"ok": False, "signed": False, "key_id": "",
                         "reason": f"verifier error: {_sigex}"}
    is_built_product = any(os.path.isfile(os.path.join(here, name))
                           for name in ("build_identity.json", "manifest.json", "release.sig"))
    editable_source = not pinned_keys and not is_built_product
    authorized = bool(signature.get("ok") or editable_source)
    if not authorized:
        why = ("publisher verification failed: " + str(signature.get("reason") or "unsigned")
               if is_built_product or pinned_keys else "unsigned package is not an editable source tree")
        return {"ok": False, "promoted": False, "staged": False, "error": why,
                "signed": False, "trust_store": trust_state, "verifier": _rsig_path}

    # The bootstrap is data-free and always copied only from an authorized
    # source/signed package.  There is no flag that can make an unauthorized
    # candidate replace it.
    central_boot = os.path.join(root, "my_wake.py")
    src_br = _source_int_constant(source_boot, "BOOTSTRAP_RELEASE", 1)
    dst_br = _source_int_constant(central_boot, "BOOTSTRAP_RELEASE", 0) if os.path.exists(central_boot) else 0
    if not os.path.exists(central_boot) or src_br >= dst_br:
        tmp = _private_tmp(central_boot)
        shutil.copy2(source_boot, tmp)
        try:
            if os.name == "posix": os.chmod(tmp, 0o700)
        except Exception: pass
        os.replace(tmp, central_boot)

    release = _source_int_constant(source_wake, "WAKE_RELEASE", 0)
    schema = _source_int_constant(source_wake, "WAKE_SCHEMA", 1)
    wake_sha = _sha256_file(source_wake)
    candidates = [fn for fn in SYSTEM_WAKE_FILES if os.path.isfile(os.path.join(here, fn))]
    if "wake.py" not in candidates or "wake_ui.py" not in candidates or "system_setup.py" not in candidates:
        return {"ok": False, "error": "incomplete Wake candidate"}
    files = {fn: _sha256_file(os.path.join(here, fn)) for fn in candidates}
    import hashlib
    bundle_raw = json.dumps(files, sort_keys=True, separators=(",", ":")).encode("utf-8")
    bundle_sha = hashlib.sha256(bundle_raw).hexdigest()
    version_name = f"r{release}-{bundle_sha[:12]}"
    final_dir = os.path.join(versions, version_name)

    active_path = os.path.join(root, "active.json")
    active = {}
    try:
        if os.path.exists(active_path): active = json.load(open(active_path, encoding="utf-8")) or {}
    except Exception: active = {}
    try: active_release = int(active.get("wake_release", -1))
    except Exception: active_release = -1
    _active_dir = os.path.join(root, str(active.get("version_dir") or "").replace("/", os.sep)) if active else ""
    _active_broken = bool(active) and bool(_active_dir) and not os.path.isdir(_active_dir)

    # Decide before staging. Signed products need a monotonically higher release;
    # editable source may refresh the same release while code is being changed.
    if active and not _active_broken:
        active_bundle = str(active.get("wake_bundle_sha256") or active.get("wake_sha256") or "")
        if release < active_release:
            return {"ok": True, "active": active, "candidate": version_name,
                    "promoted": False, "staged": False, "reason": "older Wake preserved",
                    "signed": bool(signature.get("ok")),
                    "publisher_key_id": signature.get("key_id") or "",
                    "signature_state": signature.get("reason") or "",
                    "trust_store": trust_state, "verifier": _rsig_path}
        if release == active_release and active_bundle != bundle_sha and not editable_source:
            return {"ok": True, "active": active, "candidate": version_name,
                    "promoted": False, "staged": False, "conflict": True,
                    "warning": "signed Wake changed without a WAKE_RELEASE increase"}

    if not os.path.isdir(final_dir):
        stage = os.path.join(staging, version_name + f"-{os.getpid()}")
        if os.path.exists(stage): shutil.rmtree(stage, ignore_errors=True)
        os.makedirs(stage, exist_ok=True)
        try:
            for fn in candidates:
                src = os.path.join(here, fn); dst = os.path.join(stage, fn)
                shutil.copy2(src, dst)
                try:
                    if os.name == "posix": os.chmod(dst, 0o700 if fn.endswith(".py") else 0o600)
                except Exception: pass
            with open(os.path.join(stage, "manifest.json"), "w", encoding="utf-8") as f:
                json.dump({"wake_release": release, "wake_schema": schema, "files": files}, f, indent=2)
            os.replace(stage, final_dir)
        except Exception:
            shutil.rmtree(stage, ignore_errors=True); raise
    else:
        for fn, expected in files.items():
            fp = os.path.join(final_dir, fn)
            if not os.path.isfile(fp) or _sha256_file(fp) != expected:
                return {"ok": False, "error": f"central Wake bundle is incomplete: {fn}"}

    active_rel = os.path.join("versions", version_name).replace("\\", "/")
    should_promote = (not active) or _active_broken
    reason = ("first install" if not active
              else "active version directory missing — reinstalling" if _active_broken
              else "already active/newer preserved")
    if should_promote:
        reason = "authorized first install/repair"
    elif release > active_release:
        should_promote = True
        reason = "higher verified Wake release" if signature.get("ok") else "updated editable source Wake"
    elif release == active_release:
        active_bundle = str(active.get("wake_bundle_sha256") or active.get("wake_sha256") or "")
        should_promote = bool(editable_source and active_bundle != bundle_sha)
        reason = "refreshed editable source Wake" if should_promote else "same Wake bundle"

    if should_promote:
        active = {"wake_release": release, "wake_schema": schema,
                  "wake_sha256": wake_sha, "wake_bundle_sha256": bundle_sha,
                  "version_dir": active_rel, "files": files,
                  "signed": bool(signature.get("ok")),
                  "publisher_key_id": signature.get("key_id") or "",
                  "signature_state": signature.get("reason") or "",
                  "activated_at": datetime.datetime.now().isoformat(timespec="seconds")}
        tmp = _private_tmp(active_path)
        with open(tmp, "w", encoding="utf-8") as f: json.dump(active, f, indent=2)
        try:
            if os.name == "posix": os.chmod(tmp, 0o600)
        except Exception: pass
        os.replace(tmp, active_path)
    return {"ok": True, "active": active, "candidate": version_name,
            "promoted": should_promote, "reason": reason,
            "signed": bool(signature.get("ok")),
            "publisher_key_id": signature.get("key_id") or "",
            "signature_state": signature.get("reason") or "",
            "trust_store": trust_state,
            "editable_source": bool(editable_source),
            "verifier": _rsig_path}

def ensure_system_wake():
    # Prevent two newly copied A-Tools from racing active.json promotion.
    os.makedirs(os.path.dirname(_wake_update_lock_path()), exist_ok=True)
    with _cross_process_lock(_wake_update_lock_path(), timeout_s=12.0, stale_s=120.0):
        return _ensure_system_wake_unlocked()


def ensure_ready():
    """PIERWSZY RUN: zaloz wszystko, czego brakuje. Idempotentne — kolejne runy
    nic nie psuja. Nigdy nie rzuca wyjatkiem; zwraca raport co powstalo."""
    HERE = os.path.dirname(os.path.abspath(__file__))
    PARENT = os.path.dirname(HERE)
    made, notes = [], []

    d = eco_dir()
    if not d.startswith(PARENT):
        notes.append("parent folder not writable -> using fallback in home")

    # katalogi wspolne
    for sub in ("", "cache", "logs"):
        p = os.path.join(d, sub) if sub else d
        if not os.path.isdir(p):
            try:
                os.makedirs(p, exist_ok=True); made.append(os.path.relpath(p, d) or ".eco_data")
            except Exception as ex:
                notes.append(f"cannot create {p}: {ex}")

    # ecosystem.json — pusty szkielet, gdy to pierwszy A-Tool w historii
    eco = os.path.join(d, "ecosystem.json")
    if not os.path.exists(eco):
        try:
            with open(eco, "w", encoding="utf-8") as f:
                json.dump({"orchestrator": None, "atools": []}, f, indent=2)
            made.append("ecosystem.json")
        except Exception as ex:
            notes.append(f"cannot create ecosystem.json: {ex}")

    # katalogi wlasne A-Toola (gdyby engine jeszcze nie zdazyl)
    home = os.path.expanduser(os.environ.get("ENGINE_HOME", "~/agentsystem"))
    for sub in ("profiles", "data", "logs"):
        p = os.path.join(home, sub)
        if not os.path.isdir(p):
            try:
                os.makedirs(p, exist_ok=True); made.append(f"~/agentsystem/{sub}")
                try:
                    if os.name == "posix": os.chmod(p, 0o700)
                except Exception: pass
            except Exception as ex:
                notes.append(f"cannot create {p}: {ex}")

    try:
        wr = ensure_system_wake()
        if wr.get("promoted"): made.append("~/agentsystem/system/wake")
        if wr.get("warning"): notes.append(wr.get("warning"))
        if not wr.get("ok"): notes.append("system Wake: " + str(wr.get("error") or "failed"))
    except Exception as ex:
        notes.append(f"system Wake init failed: {ex}")

    return {"eco_dir": d, "created": made, "notes": notes}


# ============================================================================
#  SLOT URUCHOMIENIA — atomowy, osobny dla każdego A-Toola
# ============================================================================
#  Kazdy proces probuje O_EXCL. Wake interpretuje odmowe jako retryable exit 3,
#  a panel moze przekazac intencje do kolejki Wake. Nikt nie nadpisuje locka
#  dzialajacego procesu i nikt nie oznacza kolidujacego runu jako wykonanego.

ECO_SLOT_STALE_S = 3600
ECO_SLOT_RECLAIM_GRACE_S = 5


def _slot_file(tool_id):
    import hashlib
    token=hashlib.sha256(str(tool_id or "this").encode("utf-8","ignore")).hexdigest()[:24]
    return os.path.join(eco_dir(), "run_locks", token + ".lock")


def _slot_pid_alive(pid):
    try:
        pid=int(pid)
        if pid<=0: return False
        if os.name=="nt":
            import subprocess
            out=subprocess.run(["tasklist","/FI",f"PID eq {pid}"],capture_output=True,text=True,timeout=3,check=False).stdout or ""
            return str(pid) in out
        os.kill(pid,0); return True
    except Exception:
        return False


def claim_eco_slot(tool_id, source="user"):
    """Atomically claim this A-Tool's slot.

    Independent A-Tools can run in parallel. Presets of the same A-Tool remain
    serialized because they normally share its profiles, caches and databases.
    Wake adds any future cross-tool collision keys in its own durable queue.
    """
    p=_slot_file(tool_id); os.makedirs(os.path.dirname(p),exist_ok=True)
    for _attempt in range(2):
        payload={"tool":str(tool_id),"source":str(source),"pid":os.getpid(),
                 "since":datetime.datetime.now().isoformat(timespec="seconds")}
        try:
            fd=os.open(p,os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o600)
            with os.fdopen(fd,"w",encoding="utf-8") as f: json.dump(payload,f)
            return True
        except FileExistsError:
            cur={}
            try: cur=json.load(open(p,encoding="utf-8")) or {}
            except Exception: pass
            try: age=time.time()-os.path.getmtime(p)
            except Exception: age=0
            owner_pid=cur.get("pid")
            # O_EXCL makes creation atomic, but the owner JSON is written just
            # after creation. During that tiny window another process may see an
            # empty/partial file. Never reclaim a brand-new lock, regardless of
            # what PID parsing/liveness says at that instant.
            if age < ECO_SLOT_RECLAIM_GRACE_S:
                return False
            # A valid live owner never becomes "stale" merely because a real
            # run lasts longer than one hour. Age is only a recovery rule for a
            # corrupt legacy lock that contains no usable PID.
            reclaim = ((bool(owner_pid) and not _slot_pid_alive(owner_pid)) or
                       (not owner_pid and age>ECO_SLOT_STALE_S))
            if reclaim:
                try: os.remove(p); continue
                except Exception: return False
            return False
        except Exception:
            # Failing closed avoids two mail/AI runs corrupting shared state.
            return False
    return False


def release_eco_slot(tool_id):
    """Zwolnij slot. Bezpieczne wielokrotnie i gdy locka juz nie ma."""
    p = _slot_file(tool_id)
    try:
        if os.path.exists(p):
            who = None; owner_pid = None
            try:
                rec=json.load(open(p, encoding="utf-8")) or {}
                who=rec.get("tool"); owner_pid=rec.get("pid")
            except Exception:
                pass
            if who in (None, tool_id) and owner_pid in (None,os.getpid()):
                os.remove(p)
    except Exception:
        pass


def eco_slot_status(tool_id=None):
    """Kto trzyma slot danego A-Toola (lub pierwszy aktywny slot)."""
    try:
        if tool_id is not None:
            paths=[_slot_file(tool_id)]
        else:
            root=os.path.join(eco_dir(),"run_locks")
            paths=[os.path.join(root,n) for n in os.listdir(root)] if os.path.isdir(root) else []
        for p in paths:
            if os.path.isfile(p):
                return json.load(open(p, encoding="utf-8"))
    except Exception:
        pass
    return None






# ============================================================================
#  POPUP A-TOOLS -> WAKE
# ============================================================================
#  Kazdy A-Tool publikuje do ecosystem.json WLASNY modul popupa, wersje, date
#  publikacji, polityke czasu i next_run_at. Wake tylko waliduje i wykonuje
#  najnowszy opublikowany popup A-Toola. 1-Clicki moga miec niezalezny lokalny
#  scheduler popupa i nie musza rejestrowac sie tutaj.

def _declare_popup_unlocked(version, popup_module=None):
    """Publish this A-Tool's own popup policy to Wake.

    A-Tools use the shared Wake service only as the clock/executor.  Timing remains
    product-owned: every local l4m_popup.py may define its own INITIAL_DELAY_S,
    MIN_DELAY_S, MAX_DELAY_S and DEFAULT_VISIBLE_S.  Re-registering the same popup
    never resets its next deadline; changing the popup file/version starts the new
    policy with that product's initial delay.

    1-Click programs do not need this registry at all: they may keep using
    l4m_popup.maybe_show() and their own local popup state.
    """
    HERE = os.path.dirname(os.path.abspath(__file__))
    try:
        my_id = (json.load(open(os.path.join(HERE, "atool.json"), encoding="utf-8")) or {}).get("id")
    except Exception:
        return False
    if not my_id:
        return False

    popup_path = os.path.join(HERE, "l4m_popup.py")
    try:
        import hashlib
        sha = hashlib.sha256(open(popup_path, "rb").read()).hexdigest() if os.path.exists(popup_path) else None
    except Exception:
        sha = None
    try:
        published_ts = float(os.path.getmtime(popup_path))
        published = datetime.datetime.fromtimestamp(published_ts).isoformat(timespec="seconds")
    except Exception:
        published_ts = time.time()
        published = datetime.datetime.fromtimestamp(published_ts).isoformat(timespec="seconds")

    def _const(name, fallback):
        try:
            return int(getattr(popup_module, name, fallback)) if popup_module is not None else int(fallback)
        except Exception:
            return int(fallback)

    policy = {
        "initial_delay_s": max(0, _const("INITIAL_DELAY_S", 6 * 60)),
        "min_delay_s": max(60, _const("MIN_DELAY_S", 4 * 60 * 60)),
        "max_delay_s": max(60, _const("MAX_DELAY_S", 5 * 24 * 60 * 60)),
        "visible_s": max(1, _const("DEFAULT_VISIBLE_S", 25)),
    }
    if policy["max_delay_s"] < policy["min_delay_s"]:
        policy["min_delay_s"], policy["max_delay_s"] = policy["max_delay_s"], policy["min_delay_s"]

    p = os.path.join(eco_dir(), "ecosystem.json")
    try:
        eco = json.load(open(p, encoding="utf-8")) if os.path.exists(p) else {}
    except Exception:
        eco = {}
    previous = next((a for a in eco.get("atools", [])
                     if isinstance(a, dict) and a.get("id") == my_id), {})
    if previous:
        allowed, reason = _source_authorized_for_existing_record(HERE, previous)
        if not allowed:
            print(f"[Ecosystem] POPUP REFUSED '{my_id}': {reason}")
            return False
    old = next((x for x in eco.get("popups", [])
                if isinstance(x, dict) and x.get("tool") == my_id), {})
    same_release = bool(old and old.get("sha256") == sha and int(old.get("version", 0) or 0) == int(version))
    if same_release:
        # A restart/copy must not make unchanged popup content look newly published.
        published_ts = float(old.get("published_ts") or published_ts)
        published = str(old.get("published") or datetime.datetime.fromtimestamp(published_ts).isoformat(timespec="seconds"))
    now = time.time()
    next_run = old.get("next_run_at") if same_release else (now + policy["initial_delay_s"])
    last_shown = old.get("last_shown") if same_release else None
    shown_count = int(old.get("shown_count", 0) or 0) if same_release else 0
    # Registration never displays the popup.  If the exact same release carries a
    # deadline that expired while Wake was broken/offline, normal A-Tool startup
    # must not cause an immediate surprise popup.  Refresh only that stale clock
    # using the publisher's normal post-display random window.  A new release still
    # receives its explicit first-run delay (normally ~6 minutes).
    if same_release:
        try:
            if next_run is None or float(next_run) <= now:
                next_run = now + random.randint(policy["min_delay_s"], policy["max_delay_s"])
        except Exception:
            next_run = now + random.randint(policy["min_delay_s"], policy["max_delay_s"])

    popups = [x for x in eco.get("popups", []) if isinstance(x, dict) and x.get("tool") != my_id]
    popups.append({
        "tool": my_id,
        "scope": "atool",
        "version": int(version),
        "folder": os.path.basename(HERE),
        "module": "l4m_popup.py",
        "sha256": sha,
        # File mtime is stable across ordinary starts; unlike "now" it does not make
        # a restarted old A-Tool look newer than an actually newer publication.
        "published": published,
        "published_ts": published_ts,
        "registered": datetime.datetime.now().isoformat(timespec="seconds"),
        "policy": policy,
        "next_run_at": next_run,
        "last_shown": last_shown,
        "shown_count": shown_count,
    })
    eco["popups"] = popups
    try:
        os.makedirs(os.path.dirname(p), exist_ok=True)
        tmp = _private_tmp(p)
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(eco, f, indent=2, ensure_ascii=False)
        os.replace(tmp, p)
        return True
    except Exception:
        return False


def declare_popup(version, popup_module=None):
    with _cross_process_lock(_ecosystem_lock_path()):
        return _declare_popup_unlocked(version, popup_module)


def maybe_show_popup(popup_module, lang=None):
    """Publish this A-Tool's popup release to the one shared Wake manager.

    Registration NEVER displays or reschedules a popup.  That separation is
    deliberate: starting/restarting an A-Tool cannot create an immediate popup or
    compete with the persistent Wake process.  Wake alone selects the newest
    valid release and owns its deadline.
    """
    ver = getattr(popup_module, "POPUP_VERSION", 1)
    try:
        return bool(declare_popup(ver, popup_module=popup_module))
    except Exception:
        return False



if __name__ == "__main__":
    register_in_ecosystem()
