// file-version: 0.931 | engine: 0.931 | updated: 2026-09-20
// English copy stays inline as the fail-safe base; non-English UI comes from transl packs.
const $=s=>document.querySelector(s);
// The server fingerprints the actual UI files and appends ?v=<build> to this script.
// Keep that token so boot() can detect a mixed/stale browser asset immediately.
window.L4M_UI_ASSET_TOKEN=(function(){try{return new URL(document.currentScript&&document.currentScript.src||location.href).searchParams.get('v')||'';}catch(_){return '';}})();
// api(): przed bylo golym fetch().then() — gdy serwer padal (zamkniety terminal,
// komputer usnal), kazde wywolanie rzucalo niezlapany "Failed to fetch" prosto do
// konsoli. poll() odpytuje co 1.2s bez limitu, wiec to zalewalo konsole tysiacami
// bledow. Teraz api() oznacza blad polaczenia jednym flagowanym polem zamiast
// rzucac — poll() moze go rozpoznac i PRZESTAC probowac zamiast dobijac sie w kolko.
let _offlineBannerShown=false;
function _showOfflineBanner(){
  if(_offlineBannerShown) return;
  _offlineBannerShown=true;
  const bar=document.getElementById('errbar');
  if(bar){
    bar.style.display='block';
    bar.style.background='#fef3c7';
    bar.style.color='#92400e';
    bar.style.borderLeft='4px solid #d97706';
    bar.textContent=ui('panel_stopped','⚠ Panel stopped — run: python3 panel.py   (buttons will work again after reconnect)');
  }
  setTimeout(()=>{ _offlineBannerShown=false; }, 10000);
}
function _hideOfflineBanner(){
  if(!_offlineBannerShown) return;
  const bar=document.getElementById('errbar');
  if(bar){
    bar.style.display='none';
    _offlineBannerShown=false;
  }
}
async function api(u,o){
  try{
    const opts=Object.assign({},o||{});
    opts.headers=Object.assign({},(o&&o.headers)||{}, {'X-L4M-Request':'1'});
    const r=await fetch(u,opts);
    const j=await r.json();
    _hideOfflineBanner();
    return j;
  }catch(e){
    _showOfflineBanner();
    return {_offline:true, _error:String(e && e.message || e)};
  }
}
// GLOBALNA esc — bez niej loadTagRules/showCalendar/mailAction rzucaly ReferenceError
// ── DIAGNOSTYKA: bez tego JEDEN blad JS zabija wszystkie przyciski po nim,
// a user widzi tylko "nic sie nie dzieje". Teraz zobaczy CO sie zepsulo.
window.__jsErrors = [];
window.addEventListener('error', function(e){
  window.__jsErrors.push({msg:e.message, line:e.lineno, col:e.colno});
  // Bledy "X is not a function" z inline onclick sa obslugiwane przez delegacje
  // klikniec (na dole skryptu) — nie strasz usera errbarem, bo przycisk ZADZIALA.
  if(/is not a function/.test(e.message||'')) return;
  const bar=document.getElementById('errbar');
  if(bar){
    bar.style.display='block';
    bar.textContent=ui('javascript_error','⚠ JavaScript error: {message} (line {line}) — some buttons may not work. Open 🛠 Dev Tools → Full log, or press F12 → Console.',
      {message:e.message,line:e.lineno});
  }
});
window.addEventListener('unhandledrejection', function(e){
  window.__jsErrors.push({msg:String(e.reason)});
  const bar=document.getElementById('errbar');
  if(bar){
    bar.style.display='block';
    bar.textContent=ui('request_failed','⚠ A request failed: {reason}',{reason:String(e.reason).slice(0,120)});
  }
});
const esc=s=>String(s==null?'':s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;');
const escAttr=esc;
const SAVED_SECRET='__L4M_SAVED_SECRET__';
const SAVED_SECRET_MASK='••••••••';
const _pendingMailboxSecrets={};
function _mailboxSecretKey(host,user){return String(host||'').trim().toLowerCase()+'|'+String(user||'').trim().toLowerCase();}
function secretEditVal(v){ return v===SAVED_SECRET?'':(v||''); }
function secretInputValue(id,original){ const el=$(id); const v=(el&&el.value)||''; return (!v && original===SAVED_SECRET)?SAVED_SECRET:v; }
function toggleSecret(id,btn){const el=$(id);if(!el)return;const show=el.type==='password';el.type=show?'text':'password';if(btn){btn.textContent=show?'🙈':'👁';btn.setAttribute('aria-label',show?ui('hide_secret','Hide secret'):ui('show_secret','Show secret'));}}
function secretInputHtml(id,value,placeholder){return `<div style="display:flex;gap:6px;align-items:center"><input type="password" autocomplete="new-password" spellcheck="false" id="${escAttr(id)}" value="${escAttr(value||'')}" placeholder="${escAttr(placeholder||'')}" style="flex:1"><button type="button" class="btn ghost" style="padding:6px 9px;min-width:38px" onclick="toggleSecret('${escAttr(id)}',this)" aria-label="${escAttr(ui('show_secret','Show secret'))}">👁</button></div>`;}
function secretField(id,label,val,hint){const saved=val===SAVED_SECRET;const h=[hint,saved?ui('secret_saved_hint','A secret is saved locally. Leave blank to keep it; type a new value to replace it.'):'' ].filter(Boolean).join(' ');return `<label>${label}</label>${h?`<div class="hint">${h}</div>`:''}${secretInputHtml(id,secretEditVal(val),saved?ui('secret_saved_placeholder','saved — leave blank to keep'):'')}`;}
async function refreshSecretStoreInfo(){
  const el=document.getElementById('secretstoreinfo'); if(!el)return;
  try{
    const s=await api('/api/security_status');
    const names={dpapi:'Windows DPAPI',keychain:'macOS Keychain','secret-service':'Linux Secret Service','private-file':ui('private_file_store','private file permissions (0600)')};
    const label=names[s.backend]||String(s.backend||'unknown');
    const protectedAtRest=!!s.encrypted_at_rest;
    let h='<b>🔐 '+ui('secret_storage','Secret storage')+':</b> '+esc(label)+' — '+(protectedAtRest?ui('encrypted_at_rest','OS-protected / encrypted at rest'):ui('not_encrypted_at_rest','protected by local file permissions, not encrypted at rest'));
    if(s.fallback&&s.harden_available){
      h+=' <button type="button" class="btn ghost" style="padding:3px 8px;font-size:11px;margin-left:6px" onclick="hardenSecretStore()">'+ui('harden_secret_storage','Harden secret storage')+'</button>';
      h+='<div class="hint">'+ui('harden_secret_storage_hint','Linux can move saved credentials to Secret Service/keyring. This is optional and only requests administrator permission when you click the button.')+'</div>';
    }
    el.innerHTML=h;
  }catch(e){ el.textContent=ui('secret_storage_status_unavailable','Secret storage status unavailable.'); }
}
async function hardenSecretStore(){
  if(!confirm(ui('harden_secret_confirm','Install the Linux Secret Service helper and move saved credentials into the OS keyring? Administrator authentication may be requested once.')))return;
  const r=await api('/api/secrets_harden',{method:'POST',headers:{'Content-Type':'application/json'},body:'{}'});
  if(r&&r.ok){flash(ui('secret_storage_hardened','Secret storage hardened.'));}
  else alert(ui('secret_storage_harden_failed','Could not harden secret storage: {error}',{error:(r&&((r.result&&r.result.error)||r.error))||ui('unknown','unknown')}));
  refreshSecretStoreInfo();
}
function safeExternalUrl(v){ try{ const u=new URL(String(v||''), location.href); return (u.protocol==='http:'||u.protocol==='https:')?u.href:''; }catch(_){ return ''; } }
// English is always present in this file. Translation packs only override known keys.
window.UITEXT={};
window.UILANGS=['en'];
window.LANG_META={en:{name:'English',native:'English'}};
function ui(key, fallback, values){
  let value=window.UITEXT[key] || fallback || key;
  Object.entries(values||{}).forEach(([name,replacement])=>{
    value=value.split('{'+name+'}').join(String(replacement==null?'':replacement));
  });
  return value;
}
function languageName(code){
  const meta=(window.LANG_META||{})[code]||{};
  return meta.native||meta.name||String(code||'').toUpperCase();
}
function languageOptions(current, includeOther){
  let codes=(window.UILANGS||['en']).slice();
  ['en','pl','de','es'].forEach(c=>{if(!codes.includes(c))codes.push(c);});
  const custom=!!(current&&!codes.includes(current));
  if(custom&&!includeOther)codes.push(current);
  let out=codes.map(c=>`<option value="${esc(c)}" ${current===c?'selected':''}>${esc(languageName(c))}</option>`).join('');
  if(includeOther)out+=`<option value="other" ${custom?'selected':''}>${esc(ui('other_language','Other…'))}</option>`;
  return out;
}
function toolLanguageState(agent,outputs){
  agent=agent||{};
  outputs=outputs||{};
  const globalLang=((window._globalSettings||{}).lang||'en').toLowerCase();
  const reportLang=String(agent.report_lang||outputs.report_lang||'').toLowerCase();
  const explicit=Object.prototype.hasOwnProperty.call(agent,'language_override');
  const override=explicit?agent.language_override===true:!!(reportLang&&reportLang!=='en'&&reportLang!==globalLang);
  return {override:override,lang:(override&&reportLang)?reportLang:globalLang,inherited:!override};
}
function generatedLanguageState(outputs){
  outputs=outputs||{};
  let mode=String(outputs.generated_language_mode||'').toLowerCase();
  if(!['source','panel','tool','fixed'].includes(mode)){
    mode=((window._globalSettings||{}).lang_mode==='force')?'tool':'source';
  }
  return {mode:mode,lang:String(outputs.generated_language||((window._globalSettings||{}).lang||'en')).toLowerCase()};
}
function priorityModelState(outputs){
  outputs=outputs||{};
  const m=String(outputs.priority_model||'').toLowerCase();
  if(['script','classic_ai','model4'].includes(m))return m;
  return outputs.ai_extract?'model4':(outputs.ai_priority?'classic_ai':'script');
}
function toggleGeneratedLanguage(){
  const s=document.getElementById('o-genlang-mode'), w=document.getElementById('o-genlang-wrap');
  if(w)w.style.display=(s&&s.value==='fixed')?'block':'none';
}
function onPriorityModelChange(){
  const s=document.getElementById('o-pmodel'), h=document.getElementById('o-pmodel-hint');
  if(!s||!h)return;
  const copy={
    script:ui('priority_model_script_hint','Deterministic script only. AI may still summarize, but it cannot change P.'),
    classic_ai:ui('classic_ai_hint','Classic keeps the deterministic script as the base. AI may correct within P2–P5, but cannot create P1/P1! unless the deterministic evidence gate already confirmed a direct event. Configured Rules remain authoritative.'),
    model4:ui('model4_hint','AI extracts structured facts; deterministic Model 4 rules calculate P. If facts are unusable or no M4 rule matches, Classic P stays final.')};
  h.textContent=copy[s.value]||'';
}
function applyUiText(){
  document.documentElement.lang=(window._globalSettings&&window._globalSettings.lang)||'en';
  document.querySelectorAll('[data-i18n]').forEach(el=>{
    const key=el.dataset.i18n, value=ui(key, el.dataset.i18nFallback||el.textContent);
    if(!el.dataset.i18nFallback) el.dataset.i18nFallback=el.textContent;
    el.textContent=value;
  });
  document.querySelectorAll('[data-i18n-title]').forEach(el=>{
    const key=el.dataset.i18nTitle;
    if(!el.dataset.i18nTitleFallback) el.dataset.i18nTitleFallback=el.title||'';
    el.title=ui(key,el.dataset.i18nTitleFallback);
  });
  document.querySelectorAll('[data-i18n-placeholder]').forEach(el=>{
    const key=el.dataset.i18nPlaceholder;
    if(!el.dataset.i18nPlaceholderFallback) el.dataset.i18nPlaceholderFallback=el.placeholder||'';
    el.placeholder=ui(key,el.dataset.i18nPlaceholderFallback);
  });
}
async function loadUiText(){
  const lang=(window._globalSettings&&window._globalSettings.lang)||'en';
  try{ const r=await api('/api/ui-text?lang='+encodeURIComponent(lang)); window.UITEXT=r.text||{};window.UILANGS=r.languages||['en'];window.LANG_META=r.language_meta||window.LANG_META; }
  catch(e){ window.UITEXT={}; }
  applyUiText();
}
// ====== LINK PLACEHOLDERS — edit these 4 URLs ======
const LINKS={website:"https://locally4me.org", buy:"https://ko-fi.com/4community/shop",
  ecs:"https://enhanced.world/ecs/", kofi:"https://ko-fi.com/4community",
  support:"https://ko-fi.com/4community", patreon:"https://ko-fi.com/4community"};
function applyLinks(){ const m={lnk1:LINKS.website,lnk2:LINKS.buy,lnk3:LINKS.support,lnk4:LINKS.patreon};
  for(const k in m){ const el=$('#'+k); if(el) el.href=m[k]; } }

// JEDEN blok "o mnie" dla obu wejsc. Wczesniej modal i zakladka mialy DWIE
// rozne wersje tego samego tekstu (modal krotsza, bez akapitu o kolejnych a-toolach)
// — user widzial inna tresc zaleznie od tego, skad wszedl.
function aboutBlurbHTML(){
  return `
      <p style="color:var(--txt);font-size:13px;line-height:1.65;margin:8px 0">
        ${ui('about_p1','I\'m Karol — a solo-founder. I build tools I want to use myself and refine them for other people. I am a self-taught developer creating resilience and ethics initiatives and software for mutual benefit.<br><br>These are <b>Automated / Agentic Tools</b>: small, local-first tools that do one job well and respect your privacy. No cloud lock-in, no data harvesting, no subscription traps. Your passwords stay on your machine; with AI off, nothing leaves it at all.')}</p>
      <p style="color:var(--txt);font-size:13px;line-height:1.65;margin:8px 0">
        ${ui('about_p2','This one reads your inboxes and tells you what actually needs you today. More are coming: a grant watcher, a lead finder and a regulatory monitor — all sharing the same engine, all yours to run.')}</p>
      <p style="color:var(--dim);font-size:12.5px;line-height:1.6;margin:8px 0">
        ${ui('about_p3','<b>Why support it:</b> I build this alone, in the hours left after a warehouse job. Every purchase, review or share buys time to build the next tool instead of moving boxes. If it saves you an hour a week, it has already paid for itself — and you are funding software that works for you, not for an advertiser.')}</p>
      <p style="color:var(--dim);font-size:12px;margin:8px 0 0">Locally4Me Group OÜ · Enhanced.World Foundation</p>`;
}

// JEDEN blok linkow dla obu wejsc (zakladka About w agencie ORAZ modal z gornego
// paska). Wczesniej modal mial wlasna kopie z href="#" i nazwami-placeholderami
// ("Patreon", "Community & help"), wiec z gory widziales STARE linki, a z agenta nowe.
function linksBlockHTML(){
  return `
      <div class="row" style="grid-template-columns:1fr 1fr;gap:8px;margin-top:6px">
        <a class="btn ghost" href="${LINKS.website}" target="_blank">${ui('link_website','🌐 Website')}</a>
        <a class="btn ghost" href="${LINKS.buy}" target="_blank">${ui('link_buy','🛒 Buy / Gumroad')}</a>
        <a class="btn ghost" href="${LINKS.ecs}" target="_blank">${ui('link_crowd_dev','💬 Crowd-Dev Open-Source Invitation')}</a>
        <a class="btn ghost" href="${LINKS.kofi}" target="_blank">${ui('link_supporters','❤️ Ko-fi supporters get upgraded software')}</a>
      </div>`;
}
let cur=null, offline=false, extract=[], pollTimer=null, _llmMode='api';

function askResetSeen(){
  confirmDanger({
    title: ui('reset_seen_title','Forget which mails were already reported?'),
    body: ui('reset_seen_body','The next Run will treat every mail in your inbox as new.'),
    warn: ui('reset_seen_warn','Useful for testing. On a real inbox you will get one big report of everything.'),
    okLabel: ui('reset_seen_ok','Forget and start fresh'),
    onOk: resetSeen,
  });
}
function askResetTags(){
  confirmDanger({
    title: ui('reset_tags_title','Reset tag rules to factory?'),
    body: ui('reset_tags_body','Every rule you wrote or fixed with ✎ will be replaced by the defaults.'),
    warn: ui('reset_tags_warn','A backup is saved first — you can restore it from 🛠 Dev Tools → Backups.'),
    okLabel: ui('reset_to_factory','Reset to factory'),
    onOk: resetTags,
  });
}
function askResetRules(){
  confirmDanger({
    title: ui('reset_classification_title','Reset classification rules?'),
    body: ui('reset_classification_body','Your custom urgent words, never-urgent senders and AI limits go back to defaults.'),
    okLabel: ui('reset_them','Reset them'),
    onOk: resetRules,
  });
}
async function boot(){
  try{ window._globalSettings = await api('/api/settings') || {}; }catch(e){ window._globalSettings={}; }
  await loadUiText();
  document.body.classList.toggle('compact', !!(window._globalSettings||{}).compact);
  const r=await api('/api/presets'); const ps=r.presets||r;
  window.APP_VERSION = r.version || 'Unknown';   // wersja do zgloszen w About
  window._devMode = !!r.dev;
  window.UI_BUILD = r.ui_build || '';
  if(window.L4M_UI_ASSET_TOKEN && window.UI_BUILD && window.L4M_UI_ASSET_TOKEN!==window.UI_BUILD){
    const bar=document.getElementById('errbar');
    if(bar){bar.style.display='block';bar.textContent='⚠ UI build mismatch: browser '+window.L4M_UI_ASSET_TOKEN+' / server '+window.UI_BUILD+'. Restart panel.py and hard reload once.';}
    throw new Error('UI build mismatch: browser '+window.L4M_UI_ASSET_TOKEN+' / server '+window.UI_BUILD);
  }
  // Everyday mode stays clean. --d/--dev reveals developer/diagnostic controls
  // that exist in this source. Builder still physically strips unavailable features
  // from customer editions, so a launch flag cannot restore removed code.
  if(!window._devMode){
    document.querySelectorAll('.dev-matrix-only').forEach(el=>{ el.style.display='none'; });
  }
  $('#ver').textContent=ui('version_label','version {version}',{version:r.version||'?'});
  if($('#ver') && r.ui_build) $('#ver').title='UI build '+r.ui_build+(r.ui_lines?(' · '+r.ui_lines+' lines'):'');
  applyLinks();   // linki w gornym pasku (lnk1..lnk4) — wczesniej wypelniane
                  // dopiero przy renderze agenta, wiec na starcie wisialy na href="#" 
  $('#presets').innerHTML=Object.entries(ps).map(([k,v])=>
    `<div class="item" onclick="loadPreset('${k}')"><div>${k}</div><div class="k">${v.kind}</div></div>`).join('');
  await refreshAgents();
  try{
    if(new URLSearchParams(location.search).get('wake')==='1') setTimeout(showSystemPanel,80);
  }catch(e){}
}
async function refreshAgents(){
  const a=await api('/api/agents');
  if(!Array.isArray(a)) return;
  const box=$('#agents');
  box.innerHTML=a.length?a.map((x,i)=>
    `<div class="item ${cur&&cur.name===x.name?'sel':''}">
      <div class="ag-open" data-i="${i}" style="cursor:pointer;flex:1">
        <div><span class="dot" style="background:${x.running?'var(--acc2)':'var(--line)'}"></span>${esc(x.name)}</div>
        <div class="k">${esc(x.kind||'')} ${x.running?`<span class=r>${ui('running','● running')}</span>`:''}</div></div>
      <button class="btn ghost ag-del" data-i="${i}" title="${esc(ui('delete_agent','Delete agent'))}" style="padding:2px 7px;font-size:13px">🗑</button></div>`).join('')
    :`<div class="tag">${ui('no_agents','none yet — pick a template')}</div>`;
  // Nazwy przekazujemy przez dataset, NIE wstrzykujemy do onclick — nazwa z & albo
  // apostrofem rozbijala atrybut HTML i ladowala uciety profil (utrata ustawien).
  box.querySelectorAll('.ag-open').forEach(function(el){
    el.addEventListener('click', function(){ loadAgent(a[+el.dataset.i].name); });
  });
  box.querySelectorAll('.ag-del').forEach(function(el){
    el.addEventListener('click', function(ev){ ev.stopPropagation(); delAgent(a[+el.dataset.i].name); });
  });
}
async function delAgent(n){
  if(!confirm(ui('delete_agent_confirm','Delete agent "{name}"? This removes its profile. Reports/history stay on disk.',{name:n}))) return;
  try{ await api('/api/delete',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name:n})});
    if(cur&&cur.name===n) cur=null;
    refreshAgents(); if(!cur){$('#tab-agent').innerHTML=`<div class="tag">${ui('agent_deleted','Agent deleted. Pick a template or another agent.')}</div>`;}
  }catch(e){ alert(ui('delete_failed','Delete failed')); }
}
async function loadPreset(k){ cur=await api('/api/preset?name='+encodeURIComponent(k)); cur.name=''; render(); }
async function loadAgent(n){ cur=await api('/api/profile?name='+encodeURIComponent(n)); cur._hadData=(((cur.sources||{}).inbox)||[]).length+(((cur.sources||{}).feeds)||[]).length>0; render(); refreshAgents();
  // Po wejsciu w agenta: jesli jest ZAPISANY wynik ostatniego runu (tez z tla/o czasie),
  // pokaz go od razu — maile gotowe do interakcji (draft, pokaz maila), nie pusty ekran.
  // Swiezy run wywolany recznie i tak nadpisze to czystym wynikiem.
  try{
    const hr=await api('/api/has_report?name='+encodeURIComponent(n));
    if(hr && hr.has && cur && cur.name===n){
      window._lastRunWhen = hr.when||0;
      showResult(n);
    }
  }catch(e){}
}

function field(id,label,val,hint,ta){
  return `<label>${label}</label>${hint?`<div class="hint">${hint}</div>`:''}`+
    (ta?`<textarea id="${escAttr(id)}">${esc(val||'')}</textarea>`:`<input id="${escAttr(id)}" value="${escAttr(val||'')}">`);
}

function _rssList(v){
  if(Array.isArray(v)) return v.map(x=>String(x||'').trim()).filter(Boolean);
  return String(v||'').split(/[;,]/).map(x=>x.trim()).filter(Boolean);
}
function normalizeRssDraft(raw){
  if(typeof raw==='string'){
    const parts=raw.split('|').map(x=>x.trim());
    raw={url:parts[0]||'',priority:+parts[1]||3,times:_rssList(parts[2]),name:parts[3]||'',category:parts[4]||'auto',max_items:parseInt(parts[5]||'')||'',enabled:!/^(off|false|0|no)$/i.test(parts[6]||'on'),tags:_rssList(parts[7]),include:_rssList(parts[8]),exclude:_rssList(parts[9])};
  }
  raw=raw||{};
  return {
    url:String(raw.url||'').trim(),
    name:String(raw.name||raw.label||'').trim(),
    category:String(raw.category||'auto').trim()||'auto',
    priority:Math.min(5,Math.max(1,parseInt(raw.priority||3)||3)),
    max_items:(raw.max_items==null?'':raw.max_items),
    times:Array.isArray(raw.times||raw.schedule)?(raw.times||raw.schedule).join(', '):String(raw.times||raw.schedule||''),
    enabled:raw.enabled!==false,
    tags:_rssList(raw.tags).join('; '),
    include:_rssList(raw.include||raw.include_keywords).join('; '),
    exclude:_rssList(raw.exclude||raw.exclude_keywords).join('; ')
  };
}
function rssFeedCardHtml(raw){
  const f=normalizeRssDraft(raw);
  return `<div class="rss-feed-card" data-rss-card style="border:1px solid var(--line);border-radius:10px;padding:12px;margin:10px 0;background:var(--card,#fff)">
    <div style="display:flex;gap:8px;align-items:center;margin-bottom:10px">
      <strong style="flex:1">${esc(f.name||ui('rss_feed','RSS / Atom feed'))}</strong>
      <label class="chk ${f.enabled?'on':''}" onclick="this.classList.toggle('on')" data-rss-enabled style="margin:0"><span></span> ${ui('enabled','Enabled')}</label>
      <button type="button" class="btn ghost" style="padding:5px 9px" onclick="removeRssFeedCard(this)">${ui('remove','Remove')}</button>
    </div>
    <label>${ui('rss_feed_url','Feed URL')}</label>
    <input data-rss-key="url" value="${escAttr(f.url)}" placeholder="https://example.org/feed.xml">
    <div class="row" style="grid-template-columns:1fr 1fr;margin-top:8px">
      <div><label>${ui('rss_display_name','Display name')}</label><input data-rss-key="name" value="${escAttr(f.name)}" placeholder="${escAttr(ui('rss_display_name_placeholder','e.g. Project news'))}"></div>
      <div><label>${ui('rss_category','Category')}</label><input data-rss-key="category" value="${escAttr(f.category)}" placeholder="auto"></div>
    </div>
    <div class="row" style="grid-template-columns:1fr 1fr 1fr;margin-top:8px">
      <div><label>${ui('rss_source_priority','Source priority')}</label><select data-rss-key="priority">${[1,2,3,4,5].map(n=>`<option value="${n}" ${f.priority===n?'selected':''}>${n}</option>`).join('')}</select></div>
      <div><label>${ui('rss_max_items','Max items / run')}</label><input data-rss-key="max_items" type="number" min="1" value="${escAttr(f.max_items)}" placeholder="20"></div>
      <div><label>${ui('rss_own_schedule','Own schedule')}</label><input data-rss-key="times" value="${escAttr(f.times)}" placeholder="06:00, 12:00"></div>
    </div>
    <div class="hint">${ui('rss_schedule_hint','Leave Own schedule blank to inherit the Communication schedule. Source priority only controls processing order; it does not force final message P1–P5.')}</div>
    <div class="row" style="grid-template-columns:1fr 1fr;margin-top:8px">
      <div><label>${ui('rss_fixed_tags','Fixed tags')}</label><input data-rss-key="tags" value="${escAttr(f.tags)}" placeholder="news; project"></div>
      <div><label>${ui('rss_include_phrases','Include phrases')}</label><input data-rss-key="include" value="${escAttr(f.include)}" placeholder="release; security"></div>
    </div>
    <label style="margin-top:8px">${ui('rss_exclude_phrases','Exclude phrases')}</label>
    <input data-rss-key="exclude" value="${escAttr(f.exclude)}" placeholder="sports; promo">
    <div style="display:flex;gap:8px;align-items:center;margin-top:10px">
      <button type="button" class="btn ghost" style="padding:6px 11px" onclick="testRssFeed(this)">${ui('rss_test_feed','Check feed')}</button>
      <span class="hint" data-rss-test-status></span>
    </div>
  </div>`;
}
function rssFeedsEditor(feeds){
  const arr=(feeds||[]).length?(feeds||[]):[];
  return `<label>${ui('rss_feeds','RSS / Atom feeds')}</label>
    <div class="hint">${ui('rss_editor_hint','Add each feed as a separate card. Only the Feed URL is required. Existing legacy pipe-delimited feed settings are read automatically and converted when you save.')}</div>
    <div id="rss-feed-list">${arr.map(rssFeedCardHtml).join('')}</div>
    <button type="button" class="btn ghost" style="margin-top:6px" onclick="addRssFeedCard()">➕ ${ui('rss_add_feed','Add feed')}</button>`;
}
function addRssFeedCard(){
  const list=document.getElementById('rss-feed-list'); if(!list)return;
  list.insertAdjacentHTML('beforeend',rssFeedCardHtml({}));
  const cards=list.querySelectorAll('[data-rss-card]');
  const last=cards[cards.length-1]; if(last){const inp=last.querySelector('[data-rss-key="url"]'); if(inp)inp.focus();}
}
function removeRssFeedCard(btn){
  const card=btn&&btn.closest('[data-rss-card]'); if(card)card.remove();
}
function rssCardToConfig(card){
  const get=k=>{const el=card.querySelector(`[data-rss-key="${k}"]`);return el?String(el.value||'').trim():'';};
  const url=get('url'); if(!url)return null;
  const f={url:url,priority:Math.min(5,Math.max(1,parseInt(get('priority')||'3')||3)),enabled:!!(card.querySelector('[data-rss-enabled]')&&card.querySelector('[data-rss-enabled]').classList.contains('on'))};
  const name=get('name'), category=get('category'), maxItems=parseInt(get('max_items')||'',10), times=_rssList(get('times')), tags=_rssList(get('tags')), inc=_rssList(get('include')), exc=_rssList(get('exclude'));
  if(name)f.name=name; if(category)f.category=category; else f.category='auto'; if(maxItems>0)f.max_items=maxItems;
  if(times.length)f.times=times; if(tags.length)f.tags=tags; if(inc.length)f.include=inc; if(exc.length)f.exclude=exc;
  return f;
}
function collectRssFeeds(){
  return Array.from(document.querySelectorAll('#rss-feed-list [data-rss-card]')).map(rssCardToConfig).filter(Boolean);
}
async function testRssFeed(btn){
  const card=btn&&btn.closest('[data-rss-card]'), out=card&&card.querySelector('[data-rss-test-status]');
  if(!card||!out)return;
  const feed=rssCardToConfig(card);
  if(!feed||!feed.url){out.textContent=ui('rss_url_required','Enter the Feed URL first.');return;}
  out.textContent=ui('rss_testing','Checking feed…');
  const r=await api('/api/test_feed',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({feed:feed})});
  if(r&&r.ok){
    const titles=(r.samples||[]).map(x=>x.title).filter(Boolean).slice(0,3);
    out.textContent='✓ '+ui('rss_test_ok','Feed works: {count} sample item(s).',{count:r.count||0})+(titles.length?' — '+titles.join(' · '):'');
  }else{
    out.textContent='⚠ '+ui('rss_test_failed','Could not read this feed: {error}',{error:(r&&r.error)||ui('unknown','unknown')});
  }
}
function render(){
  if(!cur){ // brak wczytanego agenta -> nie czytaj cur.kind (TypeError), pokaz pusto
    var e=$('#empty'), ed=$('#editor');
    if(e) e.style.display='block';
    if(ed) ed.style.display='none';
    return;
  }
  $('#empty').style.display='none'; $('#editor').style.display='block';
  // Jesli jakis run trwa (np. wrociles do panelu po przelaczeniu), wznow podglad
  // logu na zywo zamiast pokazywac pusto. Log biezacego runu nie zniknie.
  if(window._runningAgent && !pollTimer){
    pollTimer=setInterval(()=>poll(window._runningAgent),1200); poll(window._runningAgent);
  }
  $('#f-name').value=cur.name||''; $('#f-kind').value=cur.kind;
  const a=cur.agent||{}, s=cur.sources||{}, sc=cur.schedule||{}, o=cur.outputs||{}, llm=cur.llm||{};
  // AGENT
  let ag=field('a-goal',ui('agent_goal','What should this a-tool do?'),a.goal,ui('agent_goal_hint','One sentence describing the job. It steers the whole report and the AI. Example: "Watch my 3 inboxes and tell me what actually needs action today." Write it plainly, as if explaining to a colleague.'),true);
  // AUTO-CONFIG: wklej opis o sobie → propozycja ustawień (skrypt lub AI) → przegląd → zatwierdź
  ag+=`<div style="margin-top:8px"><span class="hint" style="cursor:pointer;color:var(--acc)" onclick="var e=document.getElementById('autocfg');e.style.display=e.style.display==='none'?'block':'none'">${ui('auto_configure','✨ Auto-configure — build my profile ▾')}</span>
    <div id="autocfg" style="display:none;margin-top:6px;padding:12px;border:1px solid var(--line);border-radius:8px">
      <div class="hint">${ui('auto_configure_intro','Give the tool anything about you — text, your website, a CV or project file. It builds a profile so the AI knows what matters to you. Nothing is saved until you click Apply; your current settings are backed up first.')}</div>

      <label style="margin-top:10px">${ui('about_you_text','1. About you (text)')}</label>
      <textarea id="ac-text" rows="3" placeholder="${esc(ui('about_you_placeholder','e.g. I run a small company in Leipzig. I care about client emails, invoices, grant deadlines and my ELSA exoskeleton study. I never read newsletters.'))}"></textarea>

      <label style="margin-top:10px">${ui('profile_links','2. Links (one per line — your own website, blog, "about" page)')}</label>
      <textarea id="ac-links" rows="2" placeholder="https://locally4me.org&#10;https://your-site.com/about"></textarea>
      <div class="hint" style="margin-top:4px">${ui('profile_links_hint','Works with plain web pages (your site, a blog, an "about" page). <b>Won\'t work:</b> LinkedIn, Facebook, X and other login-only or app-style pages — they hide their text from any tool. PDFs and Word/ODT files cannot be read from a link either — for those, open the file, copy the text, and paste it in box 3.')}</div>

      <label style="margin-top:10px">${ui('profile_files','3. Files — upload or paste')}</label>
      <div style="margin:4px 0"><button class="btn ghost" style="padding:5px 12px;font-size:13px" onclick="acPickFiles()">${ui('upload_profile_files','📎 Upload files (PDF, Word, ODT, TXT)')}</button>
        <span class="hint" id="ac-filelist" style="margin-left:8px"></span></div>
      <textarea id="ac-files" rows="3" placeholder="${esc(ui('profile_files_placeholder','…or paste text here — CV, project description, list of your projects…'))}"></textarea>
      <div class="hint" style="margin-top:4px">${ui('profile_upload_hint','Uploads are read on your own machine and used only to build this profile. PDF/Word/ODT need their reader library — if one is missing, the tool tells you exactly what to <code>pip install</code>. Plain text always works.')}</div>
      <div class="hint" style="margin-top:4px">${ui('profile_paste_hint','This is the most reliable source — it reads exactly what you paste. Open a PDF/Word/ODT, select all, and paste it here.')}</div>

      <label class="chk" id="ac-ai" onclick="this.classList.toggle('on')" style="margin-top:10px"><span></span> ${ui('profile_use_ai','Use AI (needs a key in Keys — gives a much better profile)')}</label>
      <div class="hint">${ui('profile_modes_hint','Both modes read the same sources: text you type, files you upload, and normal web pages. <b>Simple rules</b> (no AI) pick out keywords fast and offline. <b>AI</b> reads everything in full and writes a richer profile. Either way, you see what it read and can edit every field before applying it.')}</div>
      <button class="btn" style="margin-top:10px" onclick="acPropose()">${ui('build_my_profile','Build my profile')}</button>
      <div id="ac-out" style="margin-top:10px"></div>
    </div></div>`;
  if(cur.kind==='reporter'){
    ag+=`<div style="margin-top:8px"><span class="hint" style="cursor:pointer;color:var(--acc)" onclick="var e=document.getElementById('adv-agent');e.style.display=e.style.display==='none'?'block':'none'">${ui('advanced_priority_tagging','⚙ Advanced (priority, tagging) ▾')}</span>
      <div id="adv-agent" style="display:none;margin-top:6px">
      <label>${ui('agent_priority','Agent priority (1–5, default 3)')}</label>
      <select id="a-priority">${[1,2,3,4,5].map(n=>`<option value="${n}" ${(cur.priority||3)==n?'selected':''}>${n}${n==1?ui('most_important',' — most important'):n==5?ui('least_important',' — least important'):''}</option>`).join('')}</select>
      <div class="hint">${ui('agent_priority_hint','When you run several tools/agents and free-API limits or overlapping schedules force a choice, the higher-priority agent goes first. One agent? Leave it at 3.')}</div>
      <label class="chk ${cur.hide_prio_arrows?'on':''}" id="a-hidearrows" onclick="this.classList.toggle('on')" style="margin-top:10px"><span></span> ${ui('hide_priority_arrows','Hide the ▲▼ priority arrows in reports')}</label>
      <div class="hint">${ui('priority_arrows_hint','The report shows small ▲▼ controls when you hover over a mail priority. One click makes that sender always rank higher or lower. Turn this on to hide the controls completely.')}</div>
      <hr style="border-color:var(--line);margin:10px 0">
      <label>${ui('custom_tag_rules','Your custom tag rules')}</label>
      <div class="hint">${ui('custom_tag_rules_hint','Only the rules <b>you</b> added with the ✎ button in reports. The built-in factory rules are listed separately below and always apply — Reset brings them back if you clear everything.')}</div>
      <div id="tagrules" style="margin:6px 0;font-size:12px;color:var(--dim)">${ui('loading_plain','loading…')}</div>
      <button class="btn ghost" style="padding:4px 10px;font-size:12px" onclick="loadTagRules()">${ui('show_current_rules','🔄 Show current rules')}</button>
      <button class="btn ghost" style="padding:4px 10px;font-size:12px" onclick="resetTags()">${ui('reset_tag_rules','🗑 Reset tag rules to default')}</button>
      </div></div>`;
    ag+=`<div class="hint" style="margin-top:14px;color:var(--dim);font-weight:600;border-top:1px solid var(--line);padding-top:10px">⚙ ${ui('report_settings','Report settings')}</div>`;
    ag+=field('a-character',ui('report_tone','Report tone — how it should write'),a.character||'',ui('report_tone_hint','Sets the voice of every summary. Example: "calm, no scare tactics; serious matters framed as things to handle, not alarms." Empty = calm default. Match it to your audience — a lawyer wants sober, a founder wants punchy.'),true);
    ag+=field('a-focus',ui('focus_label','What matters most — focus'),a.focus||'',ui('focus_hint','<b>What to do:</b> in plain words, describe what matters most to you.<span class="ex-lab">Examples:</span><span class="ex">clients, invoices, the tax office and anything with a deadline\nmy university, grant bodies, and real people writing to me personally\nmy landlord, the bank, and my daughter’s school</span><b>What happens:</b> this is context for AI priority/summary decisions when AI is enabled. In Script-only mode use the explicit watchlist or Rules for deterministic priority. <b>Leave it empty</b> and the tool uses its normal defaults.'),false);
    ag+=field('a-exclude',ui('exclusions_label','Exclusions — dropped before the AI (comma-separated)'),a.exclude||'',ui('exclusions_hint','<b>What to do:</b> list words separated by commas. If a word shows up in the sender or the subject, that mail is dropped from the report.<span class="ex-lab">Example — type it just like this:</span><span class="ex">newsletter, facebook, noreply, promotions, groupon</span><b>What happens:</b> the mail stays in your inbox untouched — it only vanishes from the report, and the report still tells you how many were dropped. <b>Watch out:</b> short words match a lot — “pay” would also drop “PayPal receipt”.'),false);
    if(window._devMode){
      ag+=field('a-tagging',ui('tagging_scheme','Legacy tagging scheme (inactive)'),a.tagging||'',ui('tagging_scheme_hint','Legacy profile field retained for compatibility. The current engine does not read it; canonical priorities remain P1–P5. It is shown only in --d so old profile data is not silently lost.'),false);
    }
    ag+=`<label class="chk ${a.conclusion!==false?'on':''}" id="a-concl" onclick="this.classList.toggle('on')"><span></span> ${ui('add_conclusion','add a one-line conclusion at the end')}</label>
      <div class="hint">${ui('add_conclusion_hint','Adds a "Start with: X" line pointing at the single most urgent item, so you know where to begin. Best left ON — it turns a list into a decision.')}</div>`;
    const _langState=toolLanguageState(a,o),_knownLangs=(window.UILANGS||[]).concat(['en','pl','de','es']);
    const _langIsCustom=!_knownLangs.includes(_langState.lang);
    ag+=`<label class="chk ${_langState.override?'on':''}" id="a-lang-override" onclick="this.classList.toggle('on');toggleToolLanguageOverride()"><span></span> ${ui('language_override','Override language for this A-Tool')}</label>
      <div id="a-lang-wrap" style="display:${_langState.override?'block':'none'};margin-top:6px">
      <label>${ui('report_language','Report language')}</label>
      <select id="a-lang" onchange="var c=document.getElementById('a-lang-custom');if(c)c.style.display=this.value==='other'?'inline-block':'none';">
        ${languageOptions(_langState.lang,true)}
      </select>
      <input type="text" id="a-lang-custom" placeholder="${esc(ui('language_code_placeholder','e.g. fr, it, pt'))}" maxlength="12" style="display:${_langIsCustom?'inline-block':'none'};width:100px;margin-left:8px" value="${_langIsCustom?esc(_langState.lang):''}"></div>
      <div id="a-lang-inherited" class="hint" style="display:${_langState.override?'none':'block'}">${ui('language_inherited','Inherited: {language}').replace('{language}',esc(languageName(_langState.lang)))}</div>
      <div class="hint">${ui('report_language_hint','Controls the report shell/text for this A-Tool. AI summary/draft language is selected separately in Outputs. It does not change the panel language.')} <b>${ui('language_change_apply_hint','After changing this, press Save then Run — the current report does not re-translate on its own.')}</b></div>`;
    ag+=field('a-watch',ui('watchlist_label','Explicit watchlist / never-miss terms (optional)'),a.watchlist||'',ui('watchlist_hint','<b>What to do:</b> list words or phrases separated by commas or lines. Lines beginning with <code>#</code>/<code>//</code> and parenthesized template placeholders are ignored.<span class="ex-lab">Example:</span><span class="ex">bailiff, tax office, final notice, Locally4Me</span><b>What happens:</b> the deterministic script applies the watchlist priority configured in Rules, so this works with AI off too. Promo protection is controlled separately by the Rules setting “Explicit watchlist may protect a matching ad”.'),false);
  }
  if(cur&&cur.kind==='collector'){
    extract=[...(a.extract||['email'])];
    ag+=`<label>${ui('what_to_extract','What to extract from hits')}</label><div id="extract">`+
      ['email','linkedin','github','lab'].map(x=>`<span class="chk ${extract.includes(x)?'on':''}" onclick="tglEx('${x}')">${x}</span>`).join('')+`</div>`;
    const d=a.draft||{};
    ag+=`<div class="row"><div>${field('d-project',ui('draft_project','Project for the draft'),d.project)}</div>
      <div>${field('d-lang',ui('language','Language'),d.language||'English')}</div></div>`;
    ag+=`<label class="chk ${d.auto?'on':''}" id="dauto" onclick="this.classList.toggle('on')"><span></span> ${ui('generate_drafts','generate drafts automatically')}</label>`;
  }
  $('#tab-agent').innerHTML=ag;
  // KLUCZE (sekrety i polaczenia w jednym miejscu)
  let keys=`<div class="hint">${ui('keys_intro','Paste your AI key and mailbox passwords here. Click Save after any change. Saved secrets are hidden from the browser/API and kept in the local protected secret store.')}</div><div id="secretstoreinfo" class="hint" style="margin-top:7px;padding:7px 9px;border:1px solid var(--line);border-radius:8px">${ui('checking_secret_storage','Checking secret storage…')}</div>`;
  const llmMode=((llm.mode||'').toLowerCase()==='local' || (llm.provider||'').toLowerCase()==='ollama') ? 'local' : 'api';
  _llmMode=llmMode;
  keys+=`<label>${ui('brain_ai_model','Brain / AI model')}</label>
    <div class="hint">${ui('llm_mode_hint','Choose which engine should run now: cloud API or local model on this computer.')}</div>
    <div class="llm-mode">
      <button type="button" id="llm-mode-api" class="btn ghost llm-mode-btn ${llmMode==='api'?'on':''}" onclick="setLlmMode('api')">${ui('api_mode','☁ API')}</button>
      <button type="button" id="llm-mode-local" class="btn ghost llm-mode-btn ${llmMode==='local'?'on':''}" onclick="setLlmMode('local')">${ui('local_mode','🖥 Local')}</button>
    </div>
    <div id="llm-mode-note" class="hint"></div>
    <div class="llm-box">
    <label>${ui('llm_quick_label','Quick pick (fills the fields below)')}</label>
    <select id="l-preset" onchange="pickModel(this.value)">
      <option value="">— ${ui('llm_quick_choose','choose a provider')} —</option>
      <option value="groq">${ui('provider_groq_free','Groq (free tier) — gpt-oss-20b')}</option>
      <option value="groq120">${ui('provider_groq_quality','Groq — gpt-oss-120b (higher quality)')}</option>
      <option value="openrouter">${ui('provider_openrouter','OpenRouter (has free models)')}</option>
      <option value="xai">xAI / Grok</option>
      <option value="together">Together AI</option>
      <option value="deepinfra">DeepInfra (Qwen, Llama)</option>
      <option value="ollama">${ui('provider_ollama','Local Ollama (free, unlimited, slow)')}</option>
      <option value="anthropic">${ui('provider_anthropic','Anthropic (Claude — paid)')}</option>
    </select>
    <div class="hint">${ui('llm_hint','Pick a provider to auto-fill provider/base_url/model. For Local Ollama no API key is needed. If you already ran 1-click, use the local auto-fill button below.')}</div>
    <div class="row" style="margin-top:8px"><div id="l-prov-wrap">${field('l-prov',ui('provider','provider'),llm.provider||'grok')}</div><div id="l-model-wrap">${field('l-model',ui('model_label','model'),llm.model||'openai/gpt-oss-20b')}</div></div>
    <div class="row"><div id="l-url-wrap">${field('l-url',ui('base_url_label','base_url'),llm.base_url||'https://api.groq.com/openai/v1')}</div><div id="l-key-wrap">${secretField('l-key',ui('api_key_label','api_key'),llm.api_key,'')}</div></div>
    <div id="llm-local-actions" class="row" style="grid-template-columns:1fr 1fr;gap:8px;margin-top:8px">
      <button class="btn ghost" onclick="applyLocalOllama()">📥 ${ui('llm_local_apply','Use local Ollama from runtime.json / installed models')}</button>
      <button class="btn ghost" onclick="detectLocalOllama()">🔎 ${ui('llm_local_detect','Detect local Ollama setup')}</button>
    </div>
    <div id="localollama" class="hint" style="margin-top:8px"></div>
    <button class="btn ghost" style="margin-top:10px;padding:7px 14px" onclick="testLLM()">${ui('test_ai','🔌 Test AI (check the key)')}</button>
    <div id="llmtest" class="hint" style="margin-top:8px"></div>
    </div>`;
  // SOURCES (co przeszukac/czytac — bez sekretow)
  let so='';
  if(cur&&cur.kind==='collector'){
    keys+=`<hr style="border-color:var(--line);margin:16px 0">
      <label>${ui('search_engine','Search engine')}</label><div class="hint">${ui('search_engine_hint','grok = built-in web search (uses the key above; leave the field below empty). Or tavily/serper with your own key.')}</div>
      <div class="row"><div>${field('s-prov',ui('provider','provider'),s.provider||'grok')}</div><div>${secretField('s-key',ui('search_api_key','api_key (tavily/serper only)'),s.api_key,'')}</div></div>`;
    so=`${field('s-q',ui('query_templates','Query templates (1 per line, {region} as placeholder)'),(s.query_templates||[]).join('\n'),'',true)}
      ${field('s-reg',ui('regions','Regions (comma-separated)'),(s.regions||[]).join(', '))}
      <label class="chk ${(s.auto_expand||{}).on?'on':''}" id="sexp" onclick="this.classList.toggle('on')"><span></span> ${ui('add_queries_ai','each run, add new queries via the AI')}</label>`;
  } else {
    keys+=`<hr style="border-color:var(--line);margin:16px 0">
      <label>${ui('imap_mailboxes','IMAP mailboxes')}</label>
      <div class="hint">${ui('imap_mailboxes_hint','Pick your provider (the host fills in automatically), enter the login and password, then click Add. Gmail needs a 16-character APP PASSWORD (Google Account → Security → App passwords; requires 2-step verification). Zoho\'s free plan has NO IMAP.')}</div>
      <div class="row" style="grid-template-columns:1fr 1fr">
        <select id="mb-prov" onchange="mbHost()">
          <option value="imap.gmail.com">Gmail</option>
          <option value="poczta.o2.pl">o2.pl</option>
          <option value="mail.privateemail.com">Namecheap Private Email</option>
          <option value="imap.zoho.eu">${ui('zoho_paid_only','Zoho (paid only)')}</option>
          <option value="127.0.0.1">${ui('proton_via_bridge','Proton (via Bridge)')}</option>
          <option value="custom">${ui('other_type_host','other (type host)')}</option>
        </select>
        <input id="mb-host" value="imap.gmail.com" placeholder="host">
      </div>
      <div class="row" style="grid-template-columns:1fr 1fr;margin-top:8px">
        <input id="mb-user" placeholder="${esc(ui('login_placeholder','login (e.g. you@gmail.com)'))}">
        ${secretInputHtml('mb-pass','',ui('app_password','app password'))}
      </div>
      <button class="btn ghost" style="margin-top:8px;padding:7px 14px" onclick="mbAdd()" id="mb-addbtn">${ui('add_mailbox','➕ Add mailbox')}</button>
      <span id="mb-status" style="margin-left:10px;font-size:13px"></span>
      <div class="hint" style="margin-top:10px">${ui('mailboxes_format_hint','<b>Your mailboxes</b> — one per line, four parts separated by <b>|</b> (the pipe character):')}
        <span class="ex">server | login | password | priority</span>
        <span class="ex-lab">${ui('mailbox_examples','Real examples — copy the line that matches your provider:')}</span>
        <span class="ex">imap.gmail.com | you@gmail.com | abcd efgh ijkl mnop | 3
imap.o2.pl | yourlogin | your-password | 3
mail.privateemail.com | you@yourdomain.com | mailbox-password | 1
outlook.office365.com | you@outlook.com | your-password | 4</span>
        ${ui('mailbox_priority_hint','<b>Priority</b> is 1–5 and only decides which mailbox gets read first when the AI budget runs out: <b>1 = read this one first</b>, 3 = normal (leave it at 3 if unsure), 5 = least important.')}
      </div>
      <div class="note-warn">${ui('mailbox_password_warning','<b>Gmail needs an App Password, not your normal one.</b> Google → Manage your Account → Security → 2-Step Verification must be ON → App passwords → create one → you get 16 letters like <b>abcd efgh ijkl mnop</b>. Paste that. Your everyday Google password will always fail here.<br><b>o2.pl:</b> log in <b>without</b> @o2.pl. <b>privateemail:</b> use the mailbox password, not your Namecheap account password.')}</div>
      ${field('s-inbox','',(s.inbox||[]).map(b=>[b.imap,b.user,b.pass===SAVED_SECRET?SAVED_SECRET_MASK:b.pass,b.priority||3].join('|')).join('\n'),'',true)}
      <div class="hint">${ui('mailbox_queue_hint','Priority queues this mailbox\'s mail ahead of lower-priority boxes when AI time or free-API limits force a choice. Company inbox = 1, newsletters = 5.')}</div>`;
    so=`${rssFeedsEditor(s.feeds||[])}
      <div class="hint" style="margin-top:10px">${ui('multi_rss_hint','Each feed may use its own schedule, source priority, display name, category, item limit, fixed tags and include/exclude filters. Manual Run reads every enabled feed. Scheduled Wake reads only sources due for that slot. RSS items use the same rules, Tag Decision Graph, optional AI and report path as mail.')}</div>`;
  }
  $('#tab-keys').innerHTML=keys;
  refreshSecretStoreInfo();
  $('#tab-sources').innerHTML=so;
  setLlmMode(llmMode,{silent:true});
  // SCHEDULE
  $('#tab-schedule').innerHTML=
    `<div class="hint">${ui('schedule_intro','These options are independent — tick any combination. Manual (no ticks) = runs only when you click Run.')}</div>
    <label class="chk ${sc.run_on_start?'on':''}" id="sc-onstart" onclick="this.classList.toggle('on')"><span></span> ${ui('run_on_panel_start','Run once when the panel starts')}</label>
    <label class="chk ${sc.scheduled?'on':''}" id="sc-sched" onclick="this.classList.toggle('on')"><span></span> ${ui('run_at_set_times','Run automatically at set times (wakeup / scheduled)')}</label>
    <label class="chk ${sc.catchup!==false?'on':''}" id="sc-catch" onclick="this.classList.toggle('on')"><span></span> ${ui('schedule_catchup','Catch-up: if a scheduled slot was missed (panel was off), run it on next start')}</label>
    <div class="hint" style="margin:7px 0;padding:7px;background:#f8fafc;border-radius:7px">${ui('wake_background_hint','<b>Background is managed by Wake and is always on while Wake is running.</b> Use Advanced → Wake / Scheduler / Popup to enable or disable <i>Start with system</i>; closing Chrome does not stop Wake.')}</div>
    <div class="row" style="margin-top:12px"><div>${field('sc-n',ui('times_per_day','Times per day'),sc.times_per_day||2)}</div>
      <div>${field('sc-max',ui('max_mails_per_mailbox','Max mails read per mailbox'),sc.max_per_run||20)}</div></div>
      <div class="hint">${ui('max_mails_hint','How many of the newest mails to fetch from each mailbox. This is not the same as how many get an AI summary — that limit is in Outputs.')}</div>
    ${field('sc-win',ui('time_windows','Time windows (comma-separated, HH:MM)'),(sc.windows||['08:00','18:00']).join(', '))}
    <div class="hint">${ui('time_windows_hint','Every day at these times. Two is usually right — morning and evening.')}</div>

    <label style="margin-top:12px">${ui('one_off_run','One-off run (optional)')}</label>
    <div class="row" style="grid-template-columns:1fr 1fr">
      <div><input id="sc-date" type="date" value="${esc(sc.once_date||'')}"></div>
      <div><input id="sc-time" type="time" value="${esc(sc.once_time||'')}"></div>
    </div>
    <div class="hint">${ui('one_off_run_hint','Run once at a specific date and time — e.g. the morning a deadline lands. Leave empty for none.')}</div>
    <div class="hint">${ui('schedule_catchup_hint','Scheduled + catch-up work together: it fires at your times AND makes up a slot missed while the panel was closed. Free Wake/notify modules power this — no cron needed.')}</div>
    <hr style="border-color:var(--line);margin:14px 0">
    <label>${ui('calendar_reminders','📅 Calendar & reminders')}</label>
    <div class="hint">${ui('calendar_reminders_hint','Deadlines found in your mail land here automatically. You will get a desktop reminder the day before. You can also add reminders from any email (the 🔔 button in the report).')}</div>
    <button class="btn ghost" style="margin-top:8px" onclick="showCalendar()">${ui('open_calendar','📅 Open calendar')}</button>`;
  // OUTPUTS
  let ou='';
  if(cur&&cur.kind==='collector'){
    ou=field('o-table',ui('table_name','Table name'),o.table||'contacts',ui('table_saved_hint','Saved to data/<table>.csv and drafts/.'));
  }else{
    const ch=(o.report_channel||{type:'stdout'});
    const _p2Explicit=!!o.always_summary_user_set;
    const _p2Summary=_p2Explicit ? !!o.always_summary : (((o.ai_level||'fast')==='deep') || !!o.always_summary);
    window._p2SummaryTouched=_p2Explicit;
    ou=sect(ui('sec_core','① What this run actually does'),
        ui('sec_core_h','The five settings that decide speed, cost and how much the AI is allowed to change. Everything below is fine at its default.'),`
      <label>${ui('ai_summaries','AI summaries')}</label>
      <select id="o-ailevel" onchange="onAiLevelChange()">
        <option value="off" ${(o.ai_level||'fast')==='off'?'selected':''}>${ui('ai_level_off','OFF — no AI, script only (instant, free, no key)')}</option>
        <option value="fast" ${(o.ai_level||'fast')==='fast'?'selected':''}>${ui('ai_level_fast','ON, free tier (Groq) — one batch/min, small pauses')}</option>
        <option value="deep" ${(o.ai_level||'fast')==='deep'?'selected':''}>${ui('ai_level_deep','ON, paid or local (Ollama) — no pauses, no limits')}</option>
      </select>
      <div class="hint">${ui('ai_levels_hint','OFF = tags & priorities only, no AI text. Free tier = Groq\'s 8000 tokens/minute (works, occasional pause). Paid/local = faster, unlimited.')}</div>
      ${(()=>{const pm=priorityModelState(o);return `<label style="margin-top:12px">${ui('priority_model','Priority model')}</label>
      <select id="o-pmodel" onchange="onPriorityModelChange()">
        <option value="script" ${pm==='script'?'selected':''}>${ui('priority_model_script','0 — Script only (deterministic)')}</option>
        <option value="classic_ai" ${pm==='classic_ai'?'selected':''}>${ui('classic_ai_correction','Classic + AI correction — script decides first, AI may correct')}</option>
        <option value="model4" ${pm==='model4'?'selected':''}>${ui('model4_label','Model 4 — AI extracts facts, deterministic M4 rules calculate P')}</option>
      </select>
      <div class="hint" id="o-pmodel-hint"></div>`})()}
      <label style="margin-top:12px">${ui('ai_scope','How many messages the AI priority/tag review reads')}</label>
      <select id="o-aiscope">
        <option value="smart" ${(o.ai_scope||'smart')!=='all'?'selected':''}>${ui('ai_scope_smart','Only where the script is unsure (recommended — fast, free-tier friendly)')}</option>
        <option value="all" ${(o.ai_scope||'smart')==='all'?'selected':''}>${ui('ai_scope_all','Every new message (most thorough — slow and token-hungry on a free key)')}</option>
      </select>
      <div class="hint">${ui('ai_scope_hint','Applies to Classic+AI and Model 4 priority review and to AI tag correction. Messages the AI did not read are shown as script results, never as AI-confirmed.')}</div>
      <label class="chk ${_p2Summary?'on':''}" id="o-always" onclick="window._p2SummaryTouched=true;this.classList.toggle('on')" style="margin-top:12px"><span></span> ${ui('auto_summary_p2','Auto-summary also for P2 (P1/P1! always get one)')}</label>
      <div class="hint">${ui('auto_summary_p2_hint','P1 and P1! always get an auto-summary. Tick this to add P2 as well. Every summary is collapsible.')}</div>
      <label style="margin-top:12px">${ui('which_mails_read','Run scope — which messages should this run inspect?')}</label>
      <select id="o-scanmode">
        <option value="unread"${(o.scan_mode||'unread')==='unread'?' selected':''}>${ui('scan_unread','Unread messages from the look-back window (default)')}</option>
        <option value="since"${o.scan_mode==='since'?' selected':''}>${ui('scan_last_days','All messages from the last N days (read + unread)')}</option>
        <option value="all"${o.scan_mode==='all'?' selected':''}>${ui('scan_whole_mailbox','Whole mailbox (still protected by the hard safety cap)')}</option>
      </select>
      <div class="hint">${ui('scan_scope_hint','This controls which IMAP messages are eligible for this run. It does not reset the “already reported” memory — use Reset memory for that.')}</div>`,true)
    + sect(ui('sec_sum','② Summaries'),
        ui('sec_sum_h','Who gets a summary, how long it is, and in what language. Only a handful of messages are ever summarized.'),`
      <label>${ui('which_mails_summarized','Which mails get summarized')}</label>
      <select id="o-selmode">
        <option value="script" ${(o.ai_select_mode||'script')==='script'?'selected':''}>${ui('summary_select_script','Important ones (script picks — fast, predictable)')}</option>
        <option value="ai" ${(o.ai_select_mode||'script')==='ai'?'selected':''}>${ui('summary_select_ai','AI picks (reads the list first, chooses what is worth it — costs a little more)')}</option>
      </select>
      <div class="hint">${ui('summary_selection_hint','Either way, only a handful get summarized — not your whole inbox. AI-pick mode only chooses which messages to read; tags are changed only when the separate “Allow AI to correct/add tags” switch is ON.')}</div>
      <label style="margin-top:12px">${ui('summary_length','Summary length')}</label>
      <select id="o-depth">
        <option value="auto" ${(o.summary_depth||'auto')==='auto'?'selected':''}>${ui('summary_length_auto','Auto — 1 line for simple, up to 4 for complex')}</option>
        <option value="short" ${(o.summary_depth||'auto')==='short'?'selected':''}>${ui('summary_length_short','Short — always 1 line')}</option>
        <option value="detailed" ${(o.summary_depth||'auto')==='detailed'?'selected':''}>${ui('summary_length_detailed','Detailed — fuller, longer for long mails')}</option>
      </select>
      <div class="hint">${ui('summary_length_hint','This is the automatic summary in the report. The 📄 button on a row always produces a separate, fuller one on request.')}</div>
      ${(()=>{const gl=generatedLanguageState(o);return `<label style="margin-top:12px">${ui('generated_ai_language','AI summary & draft language')}</label>
      <select id="o-genlang-mode" onchange="toggleGeneratedLanguage()">
        <option value="source" ${gl.mode==='source'?'selected':''}>${ui('generated_lang_source','Same as each message (default)')}</option>
        <option value="panel" ${gl.mode==='panel'?'selected':''}>${ui('generated_lang_panel','Same as panel language')}</option>
        <option value="tool" ${gl.mode==='tool'?'selected':''}>${ui('generated_lang_tool','Same as this A-Tool report language')}</option>
        <option value="fixed" ${gl.mode==='fixed'?'selected':''}>${ui('generated_lang_fixed','Always use a selected language')}</option>
      </select>
      <div id="o-genlang-wrap" style="display:${gl.mode==='fixed'?'block':'none'};margin-top:6px">
        <select id="o-genlang" onchange="var c=document.getElementById('o-genlang-custom');if(c)c.style.display=this.value==='other'?'inline-block':'none';">${languageOptions(gl.lang,true)}</select>
        <input type="text" id="o-genlang-custom" placeholder="${esc(ui('language_code_placeholder','e.g. fr, it, pt'))}" maxlength="12" style="display:${!((window.UILANGS||[]).concat(['en','pl','de','es']).includes(gl.lang))?'inline-block':'none'};width:100px;margin-left:8px" value="${!((window.UILANGS||[]).concat(['en','pl','de','es']).includes(gl.lang))?esc(gl.lang):''}">
      </div>
      <div class="hint">${ui('generated_ai_language_hint','Applies to automatic summaries, 📄 on-demand summaries, automatic drafts and ✍ drafts. It does not change the original email or the panel UI.')}</div>`})()}`)
    + sect(ui('sec_tags','③ Tags and your rules'),
        ui('sec_tags_h','Your own rules always win. These switches only decide how much the AI may propose.'),`
      <label class="chk ${o.ai_tag_correction===true?'on':''}" id="o-aitags" onclick="this.classList.toggle('on')"><span></span> ${ui('ai_may_correct_tags','Allow AI / Model 4 facts to review, correct or add tags independently of summaries')}</label>
      <div class="hint">${ui('ai_may_correct_tags_hint','Independent from the priority model. OFF = tags stay deterministic even in Classic+AI or Model 4; AI can still affect P according to the selected priority model. Explicit user-rule tags remain authoritative.')}</div>
      <label class="chk ${o.ai_dissent_note===false?'':'on'}" id="o-aidis" onclick="this.classList.toggle('on')" style="margin-top:12px"><span></span> ${ui('show_ai_disagreement','Tell me when AI disagrees with my rule')}</label>
      <div class="hint">${ui('ai_disagreement_hint','Your own rules always win — the AI cannot override an importance ceiling you set with the ✎ button. With this on, the report adds a one-line note (<i>"AI would rate this P1 — your rule keeps it lower"</i>) so you know the AI saw it differently. Nothing changes; it is only a signal. Turn it off if you find it noisy.')}</div>
      <div class="bar" style="margin-top:10px"><button class="btn ghost" onclick="showRules()">${ui('rules_button','⚖ Rules')}</button><button class="btn ghost" onclick="showTagEditor('tags')">${ui('tags_rules_button','🏷 Tags & tag rules')}</button><button class="btn ghost" onclick="showClassificationSettings()">${ui('engine_behaviour_button','⚙ Engine behaviour')}</button></div>`)
    + sect(ui('sec_mailboxes','④ Mailboxes, folders and limits'),
        ui('sec_mailboxes_h','How much mail is pulled in and how much of it may reach the AI in one run.'),`
      <label class="chk ${o.scan_spam?'on':''}" id="o-spam" onclick="this.classList.toggle('on')"><span></span> ${ui('scan_spam','+ Spam / Junk folder')}</label>
      <label class="chk ${o.scan_promo?'on':''}" id="o-promo" onclick="this.classList.toggle('on')" style="margin-top:6px"><span></span> ${ui('scan_promotions','+ Promotions / Newsletters folder')}</label>
      <div class="hint">${ui('folders_scan_hint','Default really is INBOX only. Spam/Junk and Promotions/Newsletters are scanned only when selected. Social controls report visibility, not whether the mail is deleted or changed.')}</div>
      <label class="chk ${o.tight_scan?'on':''}" id="o-tight" onclick="this.classList.toggle('on')" style="margin-top:12px"><span></span> ${ui('tight_scan','Tight scan — last 3 days, max 150 mails per mailbox')}</label>
      <div class="hint">${ui('tight_scan_hint','For a mailbox you keep on top of day to day. Overrides the window below with a hard <b>3 days / 150 mails</b>. Leave it off for the normal <b>7 days / 1500 mails</b>.')}</div>
      ${field('o-scandays',ui('days_back','Look-back window (days)'),o.scan_days||7)}
      <div class="hint">${ui('unread_only_hint','<b>Unread</b> checks only messages still marked unread inside this many days. If you read mail on your phone first, choose <b>All messages from the last N days</b>. Tight scan overrides this with 3 days / 150 messages. The normal hard cap is about 8 months / 1500 messages per mailbox.')}</div>
      <label class="chk ${o.background?'on':''}" id="o-bg" onclick="this.classList.toggle('on');document.getElementById('o-maxwrap').style.display=this.classList.contains('on')?'block':'none'" style="margin-top:12px"><span></span> ${ui('summarize_more_than_12','Summarize more than 12 mails per run (for heavy inboxes / paid API)')}</label>
      <div id="o-maxwrap" class="hint" style="display:${o.background?'block':'none'}">
        ${ui('max_summaries','Max summaries per run')}: <input id="o-maxsumm" style="width:80px;display:inline-block" value="${o.max_summaries||999}">
        <br>${ui('max_summaries_hint','By default only the 12 most important get an AI summary each run, so you are never flooded and free limits are not hit. Turn this on if you have a paid key or a local model and want more.')}
      </div>
      <div class="hint" style="margin-top:6px">${ui('run_background_hint','A run keeps going in the background if you switch tabs; a new run will not start until it finishes.')}</div>`)
    + sect(ui('sec_output','⑤ Where the report goes'),
        ui('sec_output_h','Delivery, what stays visible in it, and what may touch your mailbox or calendar.'),`
      <label>${ui('report_channel','Report channel')}</label><select id="o-ch">
      ${['stdout','whatsapp','discord','telegram'].map(t=>`<option value="${t}" ${ch.type===t?'selected':''}>${t}</option>`).join('')}</select>
      <div class="hint" id="chhint"></div><div id="chf"></div>
      <label class="chk ${o.show_social===true?'on':''}" id="o-social" onclick="this.classList.toggle('on')" style="margin-top:12px"><span></span> ${ui('show_social','show social media notifications in report (otherwise hidden)')}</label>
      <label class="chk ${o.mark_read?'on':''}" id="o-mark" onclick="this.classList.toggle('on')" style="margin-top:6px"><span></span> ${ui('mark_read_after_report','mark emails as read after the report')}</label>
      <label class="chk ${o.auto_calendar?'on':''}" id="o-autocal" onclick="this.classList.toggle('on')" style="margin-top:6px"><span></span> ${ui('auto_add_deadlines','Auto-add deadlines from urgent mail (P1 / P1!) to the calendar')}</label>
      <div class="hint">${ui('auto_add_deadlines_hint','Off by default — you stay in control: add anything you want with the 🔔 button in the report. Tick this and deadlines from genuinely urgent mail (bailiff, unpaid invoice) land in the calendar by themselves.')}</div>`)
  }
  $('#tab-outputs').innerHTML=ou;
  if(cur.kind==='reporter'){ $('#o-ch').onchange=chFields; chFields(); onPriorityModelChange(); toggleGeneratedLanguage(); }
  $('#tab-about').innerHTML=`
    <div class="card" style="text-align:center;margin-bottom:16px">
      <!-- LOGO: wrzuc logo.png obok panel.py — pokaze sie automatycznie.
           Jesli pliku nie ma, zostaje kolorowy kafelek 4Me (onerror). -->
      <img src="/logo.png" alt="" style="height:72px;margin:0 auto 10px;display:block"
        onerror="this.style.display='none';document.getElementById('logo-slot').style.display='flex'">
      <div id="logo-slot" style="width:72px;height:72px;margin:0 auto 10px;border-radius:16px;
        background:linear-gradient(135deg,var(--acc),var(--acc2));display:none;align-items:center;
        justify-content:center;color:#fff;font-weight:800;font-size:26px">4Me</div>
      <div style="font-size:18px;font-weight:700">Locally4Me Inbox Reporter</div>
      <div style="color:var(--dim);font-size:13px;margin-top:2px">${ui('tagline','Your inbox, summarized. Calmly. Locally.')}</div>
    </div>

    <div class="card" style="margin-bottom:16px">
      <label>${ui('who_is_behind','Who is behind this')}</label>
${aboutBlurbHTML()}
    </div>

    <div class="card" style="margin-bottom:16px">
      <label>${ui('links','Links')}</label>
${linksBlockHTML()}
    </div>

    <hr style="border:0;border-top:1px solid var(--line);margin:22px 0">

    <div class="card">
      <label style="font-size:14px">${ui('feedback_newsletter','Feedback & Newsletter')}</label>
      <p style="color:var(--dim);font-size:13px;margin:6px 0 12px">
        ${ui('feedback_intro','Report a bug, request a feature, get help, or sign up for release news — it all reaches me directly.')}</p>
      <button class="btn" onclick="showAbout()">${ui('open_contact_form','✉ Open the contact form')}</button>
    </div>`;
  applyLinks();
  showTab('agent');
  applyHints();     // pokaz hinty ponownie po przerysowaniu pol
}

// JEDEN SZABLON FORMULARZA KONTAKTOWEGO dla obu wejsc: zakladki About w agencie
// ORAZ modalu z gornego paska. Wczesniej byly dwie osobne kopie, ktore sie
// rozjechaly (rozne kategorie, jedna miala pusty <option value="??">).
function contactFormHTML(opt){
  const withButtons = !(opt && opt.buttons === false);
  const bar = withButtons ? `
      <div class="bar">
        <button class="btn" onclick="sendFeedback()">${ui('send','Send')}</button>
        <span id="feedbackStatus" style="font-weight:600;font-size:13px"></span>
      </div>` : '';
  return `
      <label style="font-size:14px">${ui('feedback_newsletter','Feedback & Newsletter')}</label>
      <p style="color:var(--dim);font-size:13px;margin:6px 0 4px">
        ${ui('feedback_form_intro','Help improve A-Tools, or stay informed about future releases. Everything here goes straight to me.')}</p>
      <p style="color:var(--dim);font-size:12px;margin:0 0 14px">
        ${ui('feedback_form_detail','Bugs and requests become a thread in the community help board, so you can follow what happens to yours and see the fix list for the next release. Add your licence code if you have one — supporters get answered first.')}</p>
      <p style="color:var(--dim);font-size:11px;margin:0 0 10px">
        ${ui('feedback_privacy_note','🔒 This form sends your message to the developer via a secure Google service. Only the fields you fill in are transmitted — no telemetry, no tracking, no automatic data collection. Your email is used solely to respond to your request.')}</p>

      <label>${ui('category','Category')}</label>
      <select id="fb_type">
        <option value="BUG">${ui('feedback_bug','🐞 Bug report')}</option>
        <option value="FEATURE">${ui('feedback_feature','💡 Feature demand / custom request')}</option>
        <option value="SUPPORT">${ui('feedback_support','🆘 Questions and help')}</option>
        <option value="COMMUNITY">${ui('feedback_community','👥 Community support request — post it for others to answer')}</option>
        <option value="REVIEW">${ui('feedback_review','⭐ Review program / opinions')}</option>
        <option value="NEWSLETTER">${ui('feedback_contact','📬 Contact / newsletters')}</option>
      </select>

      <label style="margin-top:12px">${ui('email','Email')}</label>
      <input id="fb_email" type="email" placeholder="your@email.com">

      <!-- HONEYPOT: pulapka na boty. Czlowiek tego nie widzi i nie wypelni
           (poza ekranem, wylaczone z kolejnosci Tab, bez autouzupelniania).
           Bot wypelnia wszystko, co znajdzie w formularzu — i tym sie zdradza. -->
      <div style="position:absolute;left:-9999px;top:-9999px;height:0;overflow:hidden" aria-hidden="true">
        <label for="fb_website">${ui('website_plain','Website')}</label>
        <input id="fb_website" name="website" type="text" tabindex="-1" autocomplete="off">
      </div>

      <label style="margin-top:12px">${ui('licence_code','Licence / supporter code (optional)')}</label>
      <input id="fb_licence" placeholder="${esc(ui('licence_placeholder','If you bought or support the project — paste it here'))}">
      <div class="hint">${ui('licence_hint','Supporters get answered first. Leave empty if you are on the free edition.')}</div>

      <label style="margin-top:12px">${ui('subject','Subject')}</label>
      <input id="fb_subject" placeholder="${esc(ui('short_title','Short title'))}">

      <label style="margin-top:12px">${ui('description','Description')}</label>
      <textarea id="fb_description" rows="6" placeholder="${esc(ui('description_placeholder','Describe your issue, suggestion or request. For a bug: what did you do, what happened, what did you expect?'))}"></textarea>

      <label style="margin-top:14px">${ui('newsletters','Newsletters')}</label>
      <label class="chk" id="c-newsATools" onclick="this.classList.toggle('on')"><span></span> A-Tools</label>
      <label class="chk" id="c-news1Click" onclick="this.classList.toggle('on')"><span></span> 1-Click Apps</label>

      <label style="margin-top:14px">${ui('interested_in','Interested in — freebies, news & releases')}</label>
      <label class="chk" id="c-ecs" onclick="this.classList.toggle('on')"><span></span> ECS</label>
      <label class="chk" id="c-ecb" onclick="this.classList.toggle('on')"><span></span> ECB</label>
      <label class="chk" id="c-lete" onclick="this.classList.toggle('on')"><span></span> LETE</label>
      <label class="chk" id="c-l4m" onclick="this.classList.toggle('on')"><span></span> L4M+</label>
      <label class="chk" id="c-f4m" onclick="this.classList.toggle('on')"><span></span> Food4Me</label>
      <label class="chk" id="c-ew" onclick="this.classList.toggle('on')"><span></span> Enhanced.World</label>
${bar}`;
}

// GOOGLE SHEETS — zapis zgloszen (bug / feature / review / newsletter)
const GOOGLE_SCRIPT_URL =
  "https://script.google.com/macros/s/AKfycbx4dbnmKY6mnOUjS6SqP20dZJFGRlNtXs6PFbVc9aHfXFxInI9IHRyLXyLOpeEjX3u2/exec";

const _tick=id=>{ const el=$('#c-'+id); return !!(el && el.classList.contains('on')); };

async function sendFeedback(){
  const st=$('#feedbackStatus');
  const email=($('#fb_email')||{}).value||'';
  const type=($('#fb_type')||{}).value||'BUG';
  const desc=($('#fb_description')||{}).value||'';
  // ANTYSPAM 1: odstep miedzy zgloszeniami. Blokuje dwuklik i najprostsze skrypty.
  // W pamieci (nie localStorage — ten nie dziala w artefaktach).
  const now=Date.now(), gap=60000;
  if(window._fbLastSent && now-window._fbLastSent < gap){
    const left=Math.ceil((gap-(now-window._fbLastSent))/1000);
    st.innerHTML='<span style="color:var(--red)">'+ui('feedback_wait','Please wait {seconds}s before sending again.',{seconds:left})+'</span>';
    return;
  }
  // walidacja: newsletter potrzebuje tylko maila, reszta takze opisu
  if(!email){ st.innerHTML='<span style="color:var(--red)">'+ui('enter_email','Enter your email.')+'</span>'; return; }
  if(!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email.trim())){
    st.innerHTML='<span style="color:var(--red)">'+ui('invalid_email','That email does not look right.')+'</span>'; return; }
  if(type!=='NEWSLETTER' && !desc.trim()){
    st.innerHTML='<span style="color:var(--red)">'+ui('add_description','Add a description.')+'</span>'; return; }
  // ANTYSPAM 2: boty wysylaja "a" albo "test". Czlowiek napisze wiecej.
  if(type!=='NEWSLETTER' && desc.trim().length<15){
    st.innerHTML='<span style="color:var(--red)">'+ui('description_too_short','Please describe it in a bit more detail (15+ characters).')+'</span>';
    return; }
  if(desc.length>20000){
    st.innerHTML='<span style="color:var(--red)">'+ui('description_too_long','That is too long — please shorten it.')+'</span>'; return; }

  const data={
    type:type, app:"A-Tools", source:"Desktop",
    version:(window.APP_VERSION||'Unknown'),
    email:email,
    subject:($('#fb_subject')||{}).value||'',
    licence:($('#fb_licence')||{}).value||'',
    description:desc,
    newsATools:_tick('newsATools'), news1Click:_tick('news1Click'),
    ecs:_tick('ecs'), ecb:_tick('ecb'), lete:_tick('lete'),
    l4m:_tick('l4m'), f4m:_tick('f4m'), ew:_tick('ew'),
    os:navigator.platform||'Unknown',
    // honeypot: MUSI byc puste. Niepuste = bot (serwer odlozy do SPAM).
    website:($('#fb_website')||{}).value||''
  };
  st.innerHTML=ui('sending','Sending…');
  try{
    // Apps Script nie zwraca naglowkow CORS dla localhost. text/plain = brak preflightu.
    const r=await fetch(GOOGLE_SCRIPT_URL,{method:"POST",
      headers:{"Content-Type":"text/plain;charset=utf-8"},
      body:JSON.stringify(data)});
    // Traktujemy jako blad TYLKO gdy serwer wyraznie odpowie success:false.
    // Wczesniej kazda odpowiedz bez pola "success" (albo nieparsowalna) dawala
    // falszywe "Could not save", mimo ze wpis ladowal w arkuszu.
    let ok=true, id='';
    try{
      const j=await r.json();
      if(j && j.success===false) ok=false;
      id=(j&&j.id)||'';
    }catch(e){ /* opaque / nie-JSON = przyjmij ze poszlo */ }
    st.innerHTML = ok
      ? '<span style="color:var(--green)">'+ui('thank_you_request','✅ Thank you!{request}',{request:id?' '+ui('request_id','Request ID: {id}',{id:esc(id)}):''})+'</span>'
      : '<span style="color:var(--red)">'+ui('could_not_save_retry','❌ Could not save — try again in a moment.')+'</span>';
    if(ok){ window._fbLastSent=Date.now(); }   // start cooldownu dopiero po UDANYM wyslaniu
    if(ok && type!=='NEWSLETTER'){ $('#fb_description').value=''; $('#fb_subject').value=''; }
  }catch(err){
    st.innerHTML='<span style="color:var(--red)">'+ui('connection_error','❌ Connection error — check your internet.')+'</span>';
  }
}

function tglEx(x){ extract=extract.includes(x)?extract.filter(y=>y!==x):[...extract,x];
  document.querySelectorAll('#extract .chk').forEach(c=>c.classList.toggle('on',extract.includes(c.textContent))); }
function mbHost(){ const v=$('#mb-prov').value; if(v!=='custom')$('#mb-host').value=v; else $('#mb-host').value=''; }
async function mbAdd(){
  const h=$('#mb-host').value.trim(), u=$('#mb-user').value.trim(), p=$('#mb-pass').value.trim();
  if(!h||!u||!p){alert(ui('enter_mailbox_credentials','Enter host, login and password'));return;}
  const btn=$('#mb-addbtn'), st=$('#mb-status');
  if(btn) btn.disabled=true;
  if(st){st.textContent=ui('testing_connection','Testing connection…');st.style.color='var(--dim)';}
  try{
    const r=await api('/api/test_imap',{method:'POST',headers:{'Content-Type':'application/json'},
      body:JSON.stringify({imap:h,user:u,pass:p})});
    if(r&&r._offline){
      if(st){st.innerHTML=ui('mailbox_added_offline','⚠ Panel offline — added without testing');st.style.color='var(--warn,orange)';}
    }else if(r&&r.ok){
      if(st){st.innerHTML=ui('mailbox_connected','✓ Connected — mailbox added');st.style.color='var(--green,#22c55e)';}
    }else{
      const msg=r&&r.error?r.error:ui('unknown_error','Unknown error');
      const hint=r&&r.hint?' ➤ '+r.hint:'';
      if(st){st.innerHTML='✗ '+esc(msg)+hint;st.style.color='var(--red,#ef4444)';}
      if(btn) btn.disabled=false;
      return;
    }
  }catch(e){
    if(st){st.innerHTML=ui('mailbox_test_failed_added','⚠ Could not test — added anyway');st.style.color='var(--warn,orange)';}
  }
  _pendingMailboxSecrets[_mailboxSecretKey(h,u)]=p;
  const ta=$('#s-inbox'); ta.value=(ta.value?ta.value.trim()+'\n':'')+`${h}|${u}|${SAVED_SECRET_MASK}`;
  $('#mb-user').value=''; $('#mb-pass').value='';
  if(btn) btn.disabled=false;
}
function showInstr(){
  const g=gather();
  const txt=ui('quick_start_guide',`GUIDE — inbox reporter "{name}" (Locally4Me Agents)
=================================================================
WHAT IT DOES: reads your mailbox and, once or twice a day, gives you ONE short,
calm report (what matters, what to skip). Runs entirely on your own computer.

1) REQUIREMENTS: Python 3 (python.org). Optional: a free Groq AI key
   (console.groq.com -> API Keys) for nicer AI summaries. Works without it too.
2) RUN: in the folder with the files, type in a terminal:  python3 panel.py
   Your browser opens at:  http://localhost:8800
3) SET UP (Keys tab):
   - paste your Groq key (gsk_...), optional
   - add a mailbox: pick the provider, enter login and APP PASSWORD.
     GMAIL NOTE: not your normal password — a 16-character App Password
     (Google Account -> Security -> App passwords; needs 2-step verification).
4) CUSTOMIZE (Agent tab): character, what to focus on, exclusions, watchlist.
5) Click Save, then Run. Your report appears below.

SECURITY: your passwords stay on your computer. Never send them to anyone and
never show them on a recording — use "demo mode" for that.`,{name:g.name||ui('unnamed','(name)')});
  $('#logp').style.display='block'; $('#log').textContent=txt;
  $('#logclose').style.display='inline-block';
  $('#logp').scrollIntoView({behavior:'smooth'});
}
function closeLog(){ $('#logp').style.display='none'; $('#logclose').style.display='none'; }
function chFields(){
  const t=$('#o-ch').value, hints={stdout:ui('channel_stdout_hint','log only (test)'),
    whatsapp:ui('channel_whatsapp_hint','CallMeBot: message "I allow callmebot to send me messages" to +34 644 51 95 23 → you get an apikey'),
    discord:ui('channel_discord_hint','Discord: channel settings → Integrations → Webhooks → copy URL'),
    telegram:ui('channel_telegram_hint','@BotFather /newbot → token; chat_id from api.telegram.org/bot<TOKEN>/getUpdates')};
  $('#chhint').textContent=hints[t]||'';
  const f={whatsapp:['phone','apikey'],discord:['webhook'],telegram:['token','chat_id']}[t]||[];
  const ch=(cur.outputs||{}).report_channel||{};
  $('#chf').innerHTML=f.map(k=>{const sec=/^(apikey|token|webhook)$/i.test(k), saved=sec&&ch[k]===SAVED_SECRET; return sec?`<div style="margin-top:8px">${secretInputHtml('o-'+k,saved?'':(ch[k]||''),saved?ui('secret_saved_placeholder','saved — leave blank to keep'):k)}</div>`:`<input id="o-${escAttr(k)}" placeholder="${escAttr(k)}" value="${escAttr(ch[k]||'')}" style="margin-top:8px">`;}).join('');
}
function showTab(t){
  document.querySelectorAll('.tabs button').forEach(b=>b.classList.toggle('on',b.dataset.tab===t));
  // WSZYSTKIE zakladki — 'about' bylo POMINIETE, dlatego About &amp; Help byl pusty
  ['agent','keys','sources','schedule','outputs','about'].forEach(x=>{
    const el=document.getElementById('tab-'+x);
    if(el) el.hidden=(x!==t);      // brak elementu nie moze wywalic calego skryptu
  });
  applyHints();                    // hinty musza sie pojawic takze po zmianie zakladki
}
document.querySelectorAll('.tabs button').forEach(b=>b.onclick=()=>showTab(b.dataset.tab));
function toggleOff(){ offline=!offline; $('#offdot').textContent=offline?'●':'○'; $('#offchk').classList.toggle('on',offline); }

let _acSug=null;
let _acUploads=[];   // [{name, b64}] — wgrane pliki do zbudowania profilu
function acPickFiles(){
  const inp=document.createElement('input');
  inp.type='file'; inp.multiple=true;
  inp.accept='.pdf,.doc,.docx,.odt,.rtf,.txt,.md,.csv';
  inp.onchange=function(){
    const fs=Array.from(inp.files||[]); if(!fs.length) return;
    let pending=fs.length;
    fs.forEach(f=>{
      const rd=new FileReader();
      rd.onload=function(){
        const b64=String(rd.result||'').split(',')[1]||'';
        _acUploads.push({name:f.name, b64:b64});
        if(--pending===0) acRenderFiles();
      };
      rd.onerror=function(){ if(--pending===0) acRenderFiles(); };
      rd.readAsDataURL(f);
    });
  };
  inp.click();
}
function acRenderFiles(){
  const el=$('#ac-filelist'); if(!el) return;
  el.innerHTML=_acUploads.length
    ? _acUploads.map((u,i)=>`${esc(u.name)} <span style="cursor:pointer;color:var(--red)" onclick="acDropFile(${i})">✕</span>`).join(' &nbsp; ')
    : '';
}
function acDropFile(i){ _acUploads.splice(i,1); acRenderFiles(); }
async function acPropose(){
  const txt=($('#ac-text')||{}).value||'';
  const links=($('#ac-links')||{}).value||'';
  const files=($('#ac-files')||{}).value||'';
  if(!txt.trim() && !links.trim() && !files.trim() && !_acUploads.length){
    alert(ui('profile_source_required','Give it something — text, a link, an uploaded file, or pasted file text.'));return;}
  const useAi=$('#ac-ai')&&$('#ac-ai').classList.contains('on');
  if(useAi && !cur.name){alert(ui('save_agent_before_ai','Save the agent first (it needs a name), then use AI mode'));return;}
  const out=$('#ac-out'); out.innerHTML='<span class="hint">'+ui('building_profile','⏳ building your profile…')+'</span>';
  try{
    const r=await api('/api/autoconfig',{method:'POST',headers:{'Content-Type':'application/json'},
      body:JSON.stringify({text:txt,links:links,files:files,uploads:_acUploads,ai:useAi,name:cur.name||''})});
    _acSug=r.suggestion||{};
    const srcs=(_acSug._sources||[]);
    const srcHTML = srcs.length
      ? `<div class="hint" style="margin-top:8px;padding:8px;border:1px solid var(--line);border-radius:6px"><b>${ui('what_it_read','What it actually read:')}</b><br>`+
         srcs.map(s=>{const ok=/chars(?: read)?$/.test(s);
           return `<span style="color:${ok?'var(--acc)':'var(--dim)'}">${ok?'✓':'—'} ${esc(s)}</span>`;}).join('<br>')+
         `</div>`
      : `<div class="hint" style="margin-top:8px;color:var(--dim)">${ui('built_from_typed_text','Built from the text you typed (no links or files read).')}</div>`;
    out.innerHTML=`<div class="hint" style="color:var(--acc)">${ui('profile_suggestion_ready','Here is what it worked out — edit anything, then Apply:')}</div>`+
      srcHTML+
      ['focus','watchlist','exclude','character'].map(k=>
        `<label style="margin-top:6px">${k}</label><input id="ac-${k}" value="${esc(_acSug[k]||'')}">`).join('')+
      `<div class="hint" style="margin-top:8px">${ui('profile_plain_text_hint','The profile is a plain text file the AI reads before every report. You can see and edit it at any time — nothing is hidden.')}</div>
       <button class="btn" style="margin-top:10px" onclick="acApply()">${ui('apply_profile','✓ Apply (backup saved first)')}</button>
       <div class="hint" id="ac-status" style="margin-top:6px"></div>`;
  }catch(e){ out.innerHTML='<span class="hint" style="color:var(--red)">'+ui('failed_with_error','Failed: {error}',{error:esc(String(e))})+'</span>'; }
}
async function acApply(){
  if(!cur.name){alert(ui('save_agent_first','Save the agent first (needs a name)'));return;}
  const sug={}; ['focus','watchlist','exclude','character'].forEach(k=>sug[k]=($('#ac-'+k)||{}).value||'');
  const st=$('#ac-status'); if(st) st.textContent=ui('applying','⏳ applying…');
  try{
    const r=await api('/api/autoapply',{method:'POST',headers:{'Content-Type':'application/json'},
      body:JSON.stringify({name:cur.name,suggestion:sug})});
    if(r.ok){ if(st) st.innerHTML=ui('profile_applied','✓ Applied ({fields}). Backup saved. Reloading…',{fields:(r.applied||[]).join(', ')});
      setTimeout(async()=>{cur=await api('/api/profile?name='+encodeURIComponent(cur.name));render();},900); }
    else if(st) st.textContent=ui('could_not_apply','Could not apply — save the agent first.');
  }catch(e){ if(st) st.textContent=ui('apply_failed','Apply failed.'); }
}
function pickModel(v){
  const M={
    groq:      {prov:'grok',   url:'https://api.groq.com/openai/v1', model:'openai/gpt-oss-20b'},
    groq120:   {prov:'grok',   url:'https://api.groq.com/openai/v1', model:'openai/gpt-oss-120b'},
    openrouter:{prov:'grok',   url:'https://openrouter.ai/api/v1',   model:'meta-llama/llama-3.1-8b-instruct:free'},
    xai:       {prov:'grok',   url:'https://api.x.ai/v1',            model:'grok-2-latest'},
    together:  {prov:'grok',   url:'https://api.together.xyz/v1',    model:'meta-llama/Llama-3.3-70B-Instruct-Turbo'},
    deepinfra: {prov:'grok',   url:'https://api.deepinfra.com/v1/openai', model:'Qwen/Qwen2.5-72B-Instruct'},
    ollama:    {prov:'ollama', url:'',                               model:'llama3.2:3b'},
    anthropic: {prov:'grok',   url:'https://api.anthropic.com/v1',   model:'claude-haiku-4-5'},
  };
  const m=M[v]; if(!m) return;
  if($('#l-prov')) $('#l-prov').value=m.prov;
  if($('#l-url'))  $('#l-url').value=m.url;
  if($('#l-model'))$('#l-model').value=m.model;
  if(v==='ollama'){
    setLlmMode('local',{silent:true});
    applyLocalOllama();
  }else{
    setLlmMode('api',{silent:true});
  }
}
function onAiLevelChange(){
  const level=(document.getElementById('o-ailevel')||{}).value||'fast';
  const p2=document.getElementById('o-always');
  if(level==='deep' && p2 && !window._p2SummaryTouched) p2.classList.add('on');
}

function setLlmMode(mode,opt){
  const o=opt||{};
  _llmMode=(mode==='local')?'local':'api';
  const isLocal=_llmMode==='local';
  const bApi=$('#llm-mode-api'), bLocal=$('#llm-mode-local');
  if(bApi) bApi.classList.toggle('on',!isLocal);
  if(bLocal) bLocal.classList.toggle('on',isLocal);
  const note=$('#llm-mode-note');
  if(note){
    note.textContent=isLocal
      ? ui('llm_mode_local_note','Local mode: runs on your machine, no API key required.')
      : ui('llm_mode_api_note','API mode: uses a cloud provider endpoint and your API key.');
  }
  const localActions=$('#llm-local-actions');
  if(localActions) localActions.style.display=isLocal?'grid':'none';
  const localInfo=$('#localollama');
  if(localInfo && !isLocal) localInfo.textContent='';
  const keyWrap=$('#l-key-wrap');
  if(keyWrap) keyWrap.style.display=isLocal?'none':'block';
  const urlWrap=$('#l-url-wrap');
  if(urlWrap) urlWrap.style.display=isLocal?'none':'block';
  if(isLocal){
    // NIE KASUJEMY KLUCZA API. Zapamietujemy go i przywracamy przy powrocie na API —
    // wczesniej przelaczenie na Local czyscilo pole klucza i po powrocie trzeba bylo
    // wklejac go od nowa. Pamietamy tez provider/url API, zeby wrocic do dokladnie
    // tego samego ustawienia, a nie domyslnego groq.
    const k=($('#l-key')||{}).value||'';
    if(k) window._savedApiKey=k;
    if(($('#l-prov')||{}).value && $('#l-prov').value!=='ollama') window._savedApiProv=$('#l-prov').value;
    if(($('#l-url')||{}).value)  window._savedApiUrl=$('#l-url').value;
    if(($('#l-model')||{}).value && $('#l-prov').value!=='ollama') window._savedApiModel=$('#l-model').value;
    if($('#l-prov')) $('#l-prov').value='ollama';
    if($('#l-url'))  $('#l-url').value='';
    // pole klucza tylko UKRYTE (keyWrap wyzej), wartosci NIE zerujemy
    if(!o.silent) detectLocalOllama();
  }else{
    // POWROT NA API: przywroc zapamietany klucz i ustawienia, jesli pola sa puste/lokalne
    if(window._savedApiKey && $('#l-key') && !($('#l-key').value||'').trim()){
      $('#l-key').value=window._savedApiKey;
    }
    if($('#l-prov') && $('#l-prov').value==='ollama'){
      if(window._savedApiProv){ $('#l-prov').value=window._savedApiProv; }
      if(window._savedApiUrl && $('#l-url')){ $('#l-url').value=window._savedApiUrl; }
      if(window._savedApiModel && $('#l-model')){ $('#l-model').value=window._savedApiModel; }
      else if(!o.keepProvider && !window._savedApiProv){ pickModel('groq'); }
    }
  }
}
async function detectLocalOllama(){
  const el=$('#localollama');
  if(el){ el.textContent=ui('checking_ollama','Checking local Ollama…'); el.style.color='var(--dim)'; }
  try{
    const r=await api('/api/local_ollama');
    const list=(r.installed_models||[]).slice(0,8).join(', ')||'-';
    const rt=r.runtime_found?('runtime: '+(r.runtime_path||'')):(ui('llm_local_none','No local Ollama config found yet.'));
    if(el){ el.innerHTML=`${esc(rt)}<br>${ui('installed','installed')}: ${esc(list)}<br>${ui('suggested','suggested')}: ${esc(r.suggested_model||'')}`; el.style.color='var(--dim)'; }
  }catch(e){ if(el){ el.textContent=ui('local_detection_failed','Local detection failed.'); el.style.color='var(--red)'; } }
}
async function applyLocalOllama(){
  setLlmMode('local',{silent:true,keepProvider:true});
  const el=$('#localollama');
  if(el){ el.textContent=ui('applying_ollama','Applying local Ollama…'); el.style.color='var(--dim)'; }
  try{
    const r=await api('/api/local_ollama');
    if($('#l-prov')) $('#l-prov').value='ollama';
    if($('#l-url'))  $('#l-url').value='';
    // klucz API NIE jest kasowany — setLlmMode('local') zapamietal go i przywroci
    // przy powrocie na API. Pole i tak jest ukryte w trybie local.
    if($('#l-model'))$('#l-model').value=r.suggested_model||'llama3.2:3b';
    if($('#o-ailevel')) $('#o-ailevel').value='deep';
    if(el){
      const rt=r.runtime_found?('runtime: '+(r.runtime_path||'')):(ui('llm_local_none','No local Ollama config found yet.'));
      el.innerHTML=`✓ ${ui('llm_local_ok','Local Ollama applied. Save the agent, then click Run.')}<br>${esc(rt)}`;
      el.style.color='var(--acc)';
    }
  }catch(e){ if(el){ el.textContent=ui('local_apply_failed','Local apply failed.'); el.style.color='var(--red)'; } }
}
async function testLLM(){
  const mode=_llmMode==='local'?'local':'api';
  const llm={
    mode:mode,
    provider:mode==='local'?'ollama':(($('#l-prov')||{}).value||'grok'),
    model:($('#l-model')||{}).value||'',
    base_url:mode==='local'?'':((($('#l-url')||{}).value)||''),
    api_key:secretInputValue('#l-key',((cur&&cur.llm)||{}).api_key)
  };
  const el=$('#llmtest'); el.textContent=ui('checking','Checking…'); el.style.color='var(--dim)';
  const r=await api('/api/testllm',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({llm,name:(cur&&cur.name)||''})});
  const d=r.debug||{};
  const dbg=`url=${d.base_url} · model=${d.model} · key=${d.key_present?'set':'NONE'}`;
  if(r.ok){ el.innerHTML=ui('key_works','✓ Key works.')+' '+dbg; el.style.color='var(--acc)'; }
  else { el.innerHTML=ui('not_working','✗ Not working: {result}',{result:r.result})+'<br>'+dbg+(r.hint?'<br>➤ '+r.hint:''); el.style.color='var(--red)'; }
}
function toggleToolLanguageOverride(){
  const on=!!($('#a-lang-override')&&$('#a-lang-override').classList.contains('on'));
  const wrap=$('#a-lang-wrap'), inherited=$('#a-lang-inherited');
  if(wrap)wrap.style.display=on?'block':'none';
  if(inherited)inherited.style.display=on?'none':'block';
}
function gather(){
  const mode=_llmMode==='local'?'local':'api';
  const _fn=$('#f-name'); const g={name:_fn?_fn.value.trim():(cur&&cur.name)||'',kind:(cur&&cur.kind)||'reporter',preset:(cur&&cur.preset)||'',
    priority:+($('#a-priority')||{}).value||3,
    hide_prio_arrows:$('#a-hidearrows')?$('#a-hidearrows').classList.contains('on'):false,
    agent:{goal:($('#a-goal')||{}).value||''},
    llm:{
      mode:mode,
      provider:mode==='local'?'ollama':(($('#l-prov')||{}).value||'grok'),
      model:($('#l-model')||{}).value||'',
      base_url:mode==='local'?'':(($('#l-url')||{}).value||''),
      api_key:secretInputValue('#l-key',((cur&&cur.llm)||{}).api_key)
    },
    schedule:{times_per_day:+($('#sc-n')||{}).value||2,max_per_run:+($('#sc-max')||{}).value||20,
      windows:(($('#sc-win')||{}).value||'').split(',').map(s=>s.trim()).filter(Boolean),
      once_date:($('#sc-date')||{}).value||'',
      once_time:($('#sc-time')||{}).value||'',
      run_on_start:$('#sc-onstart')?$('#sc-onstart').classList.contains('on'):false,
      scheduled:$('#sc-sched')?$('#sc-sched').classList.contains('on'):false,
      catchup:$('#sc-catch')?$('#sc-catch').classList.contains('on'):true,
      background:true},
    sources:{}, outputs:{}};
  if(cur&&cur.kind==='collector'){
    g.agent.extract=extract;
    g.agent.draft={project:($('#d-project')||{}).value||'',language:($('#d-lang')||{}).value||'',
      auto:$('#dauto')?$('#dauto').classList.contains('on'):false,send:false};
    g.sources={provider:($('#s-prov')||{}).value||'',api_key:secretInputValue('#s-key',((cur&&cur.sources)||{}).api_key),
      query_templates:(($('#s-q')||{}).value||'').split('\n').map(s=>s.trim()).filter(Boolean),
      regions:(($('#s-reg')||{}).value||'').split(',').map(s=>s.trim()).filter(Boolean),
      auto_expand:{on:$('#sexp')?$('#sexp').classList.contains('on'):false,add:6}};
    g.outputs={table:($('#o-table')||{}).value||'contacts'};
  }else{
    g.agent.character=($('#a-character')||{}).value||'';
    g.agent.focus=($('#a-focus')||{}).value||'';
    g.agent.exclude=($('#a-exclude')||{}).value||'';
    g.agent.tagging=$('#a-tagging')?($('#a-tagging').value||''):(g.agent.tagging||'');
    g.agent.conclusion=$('#a-concl')?$('#a-concl').classList.contains('on'):true;
    const _langOverride=!!($('#a-lang-override')&&$('#a-lang-override').classList.contains('on'));
    g.agent.language_override=_langOverride;
    if(_langOverride){
      var _langSel=($('#a-lang')||{}).value||'en';
      g.agent.report_lang=_langSel==='other'?(($('#a-lang-custom')||{}).value||'en').trim().toLowerCase():_langSel;
    }
    g.agent.watchlist=($('#a-watch')||{}).value||'';
    g.sources={inbox:(($('#s-inbox')||{}).value||'').split('\n').map(l=>l.trim()).filter(Boolean).map(l=>{
        let[imap,user,pass,priority]=l.split('|');const raw=(pass||'').trim();pass=raw===SAVED_SECRET_MASK?(_pendingMailboxSecrets[_mailboxSecretKey(imap,user)]||SAVED_SECRET):raw;return{imap,user,pass,priority:+priority||3};}),
      feeds:collectRssFeeds()};
    const t=($('#o-ch')||{}).value||'none', ch={type:t};
    ({whatsapp:['phone','apikey'],discord:['webhook'],telegram:['token','chat_id']}[t]||[])
      .forEach(k=>{const original=(((cur&&cur.outputs)||{}).report_channel||{})[k]; ch[k]=/^(apikey|token|webhook)$/i.test(k)?secretInputValue('#o-'+k,original):(($('#o-'+k)||{}).value||'');});
    const ail=$('#o-ailevel'); const ailv=ail?ail.value:'fast';
    g.outputs={report_channel:ch, mark_read:$('#o-mark')?$('#o-mark').classList.contains('on'):false, only_new:true,
      ai_level:ailv, ai_off:ailv==='off', free_tier:ailv==='fast'||ailv==='balanced',
      draft_replies:ailv==='deep',
      ai_select_mode:($('#o-selmode')||{}).value||'script',
      priority_model:($('#o-pmodel')||{}).value||'script',
      ai_priority:(($('#o-pmodel')||{}).value||'script')==='classic_ai',
      ai_extract:(($('#o-pmodel')||{}).value||'script')==='model4',
      ai_tag_correction:$('#o-aitags')?$('#o-aitags').classList.contains('on'):false,
      ai_scope:($('#o-aiscope')||{}).value||'smart',
      generated_language_mode:($('#o-genlang-mode')||{}).value||'source',
      generated_language:(function(){var s=($('#o-genlang')||{}).value||((window._globalSettings||{}).lang||'en');return s==='other'?((($('#o-genlang-custom')||{}).value||'en').trim().toLowerCase()):s;})(),
      ai_dissent_note:$('#o-aidis')?$('#o-aidis').classList.contains('on'):true,
      scan_mode:($('#o-scanmode')||{}).value||'unread',
      scan_days:parseInt(($('#o-scandays')||{}).value||'7')||7,
      tight_scan:$('#o-tight')?$('#o-tight').classList.contains('on'):false,
      summary_depth:($('#o-depth')||{}).value||'auto',
      always_summary:$('#o-always')?$('#o-always').classList.contains('on'):false,
      always_summary_user_set:!!window._p2SummaryTouched,
      background:$('#o-bg')?$('#o-bg').classList.contains('on'):false,
      max_summaries:(function(){var v=parseInt(($('#o-maxsumm')||{}).value,10); return (v&&v>0)?v:999;})(),
      scan_spam:$('#o-spam')?$('#o-spam').classList.contains('on'):false,
      auto_calendar:$('#o-autocal')?$('#o-autocal').classList.contains('on'):false,
      scan_promo:$('#o-promo')?$('#o-promo').classList.contains('on'):false,
      show_social:$('#o-social')?$('#o-social').classList.contains('on'):false};
  }
  return g;
}
function exportConfig(){
  window.open('/api/exportconfig','_blank');
  flash(ui('config_exported','Safe config exported — passwords and API keys stay on this computer.'));
}
function exportReport(){
  const name=(cur&&cur.name)||'';
  if(!name){ flash(ui('select_agent_first','Select an A-Tool first.')); return; }
  window.open('/api/export?name='+encodeURIComponent(name),'_blank','noopener');
}
function importConfig(){
  var inp=document.createElement('input');
  inp.type='file'; inp.accept='.json';
  inp.onchange=function(){
    var f=inp.files&&inp.files[0]; if(!f) return;
    var rd=new FileReader();
    rd.onload=async function(){
      var data;
      try{ data=JSON.parse(rd.result); }catch(e){ alert(ui('invalid_config_file','Not a valid config file')); return; }
      if(!confirm(ui('restore_config_confirm','Restore configuration from this file? Your current profiles will be backed up first.'))) return;
      var r=await api('/api/importconfig',{method:'POST',headers:{'Content-Type':'application/json'},
        body:JSON.stringify({data:data})});
      if(r&&r.ok){ alert(ui('config_restored','Restored {profiles} agent(s) and {files} file(s). Reloading.',{profiles:r.profiles,files:r.files})); location.reload(); }
      else alert(ui('import_failed','Import failed: {error}',{error:(r&&r.error)||ui('unknown','unknown')}));
    };
    rd.readAsText(f);
  };
  inp.click();
}
async function save(){
  const g=gather(); if(!g.name){alert(ui('enter_name','Enter a name'));return;}
  const oldName=(cur&&cur.name)?cur.name:'';
  let existingNameForSave=oldName;
  // ZMIANA NAZWY: jesli agent byl juz zapisany pod inna nazwa, PRZENIES plik
  // (rename) zamiast tworzyc drugi. Bez tego edycja nazwy zostawiala sierotę,
  // a nastepny Save/czyszczenie nadpisywalo pierwotny agent pustka.
  if(oldName && oldName!==g.name){
    const rr=await api('/api/rename',{method:'POST',headers:{'Content-Type':'application/json'},
      body:JSON.stringify({old:oldName,new:g.name})});
    if(rr&&rr.ok===false&&rr.error){ alert(ui('rename_failed','Rename: {error}',{error:rr.error})); return; }
    existingNameForSave=g.name; // po rename edytujemy juz profil pod nowa nazwa
  }
  // OSTRZEZENIE: nie nadpisuj skonfigurowanego agenta pustymi ustawieniami przez pomylke
  const boxes=(((g.sources||{}).inbox)||[]).length + (((g.sources||{}).feeds)||[]).length;
  if(oldName===g.name && boxes===0 && cur && cur._hadData){
    if(!confirm(ui('save_without_sources_confirm','This will save {name} with NO mailboxes/feeds — its previous settings will be overwritten. Continue?',{name:g.name}))) return;
  }
  g._existing_name=existingNameForSave;
  g._allow_overwrite=!!existingNameForSave && existingNameForSave===g.name;
  const sv=await api('/api/save',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(g)});
  if(sv && sv.ok===false){ alert(sv.error||ui('could_not_save','Could not save')); return; }
  Object.keys(_pendingMailboxSecrets).forEach(k=>delete _pendingMailboxSecrets[k]);
  cur=await api('/api/profile?name='+encodeURIComponent(g.name));
  cur._hadData = boxes>0;
  await refreshAgents();
  flash(ui('saved_name','Saved: {name}',{name:g.name}));
}
function _settingsValue(v){
  if(v===null||v===undefined) return '—';
  if(typeof v==='boolean') return v?'ON':'OFF';
  if(Array.isArray(v)) return v.length?v.map(x=>typeof x==='object'?JSON.stringify(x):String(x)).join(', '):'—';
  if(typeof v==='object') return JSON.stringify(v);
  return String(v);
}
function _settingsFlatten(obj,prefix,lines,depth){
  depth=depth||0;
  const pad='  '.repeat(depth+1);
  if(!obj||typeof obj!=='object'||Array.isArray(obj)){
    lines.push(`${pad}${prefix||'value'}: ${_settingsValue(obj)}`); return;
  }
  Object.keys(obj).forEach(k=>{
    const v=obj[k], label=String(k).replace(/_/g,' ');
    if(v&&typeof v==='object'&&!Array.isArray(v)&&depth<3){
      lines.push(`${pad}${label}:`);
      _settingsFlatten(v,'',lines,depth+1);
    }else{
      lines.push(`${pad}${label}: ${_settingsValue(v)}`);
    }
  });
}
function formatSettingsSnapshot(r,full){
  r=r||{}; const out=[];
  const title=(t)=>{ if(out.length) out.push(''); out.push(`── ${t} ──`); };
  const line=(label,value)=>out.push(`  ${label.padEnd(18,' ')} ${_settingsValue(value)}`);
  if(!full){
    out.push(`${ui('settings_current_title','CURRENT SETTINGS')}${r.agent?' — '+r.agent:''}`);
    const imp=r.important||{};
    title(ui('settings_run_behaviour','RUN BEHAVIOUR'));
    line(ui('settings_priority_model','Priority model:'),imp.priority_model);
    line(ui('settings_ai_level','AI level:'),imp.ai_level);
    line(ui('settings_ai_edits_tags','AI edits tags:'),imp.ai_can_edit_tags);
    if(imp.summary) line(ui('settings_summary','Summary:'),`selection=${_settingsValue(imp.summary.selection)} · length=${_settingsValue(imp.summary.length)} · P2=${_settingsValue(imp.summary.p2)}`);
    if(imp.language) line(ui('settings_language','Language:'),Object.entries(imp.language).map(([k,v])=>`${k}=${_settingsValue(v)}`).join(' · '));
    if(imp.scan) line(ui('settings_scan','Scan:'),`mode=${_settingsValue(imp.scan.mode)} · days=${_settingsValue(imp.scan.days)} · tight=${_settingsValue(imp.scan.tight)} · spam=${_settingsValue(imp.scan.spam)} · promotions=${_settingsValue(imp.scan.promotions)}`);
    line(ui('settings_auto_calendar','Auto calendar:'),imp.auto_calendar);
    if(imp.schedule) line(ui('settings_schedule_short','Schedule:'),`enabled=${_settingsValue(imp.schedule.scheduled)} · on-start=${_settingsValue(imp.schedule.run_on_start)} · times=${_settingsValue(imp.schedule.windows)}`);
    title(ui('settings_agent','AGENT')); _settingsFlatten((r.all_ui_settings||{}).agent||{},'',out,0);
    title(ui('settings_sources','SOURCES')); _settingsFlatten((r.all_ui_settings||{}).sources||{},'',out,0);
    title(ui('settings_schedule','SCHEDULE')); _settingsFlatten((r.all_ui_settings||{}).schedule||{},'',out,0);
    title(ui('settings_ai_output','AI & OUTPUT')); _settingsFlatten((r.all_ui_settings||{}).outputs||{},'',out,0);
    title(ui('settings_provider','PROVIDER')); _settingsFlatten((r.all_ui_settings||{}).llm||{},'',out,0);
    title(ui('settings_rules','RULES')); _settingsFlatten(r.rules||{},'',out,0);
    title(ui('settings_last_run','LAST RUN')); _settingsFlatten(r.last_run||{},'',out,0);
    if(r.developer_hint){ out.push('',r.developer_hint); }
    return out.join('\n').replace(/\n{3,}/g,'\n\n').trim();
  }
  out.push(ui('settings_full_debug_title','FULL DEBUG SETTINGS SNAPSHOT'));
  const order=[
    [ui('settings_resolved_profile','RESOLVED PROFILE'),'resolved_profile'], [ui('settings_effective_language','EFFECTIVE LANGUAGE'),'effective_language_policy'],
    [ui('settings_wake','WAKE'),'wake_runtime'], [ui('settings_dependencies','DEPENDENCIES'),'dependencies'], [ui('settings_published_schedule','PUBLISHED SCHEDULE'),'published_schedule'],
    [ui('settings_classification_rules','CLASSIFICATION RULES'),'effective_classification_rules'], [ui('settings_tag_rules','TAG RULES'),'effective_tag_rules'],
    [ui('settings_sources_paths','SOURCES / PATHS'),'sources'], [ui('settings_raw_files','RAW FILES'),'raw']
  ];
  const used=new Set();
  order.forEach(([label,key])=>{ if(r[key]!==undefined){ used.add(key); title(label); _settingsFlatten(r[key],'',out,0); } });
  Object.keys(r).filter(k=>!used.has(k)).forEach(k=>{ title(k.replace(/_/g,' ').toUpperCase()); _settingsFlatten(r[k],'',out,0); });
  return out.join('\n').replace(/\n{3,}/g,'\n\n').trim();
}

async function revealSetup(){
  const name=(cur&&cur.name)||((($('#f-name')||{}).value)||'').trim();
  $('#logp').style.display='block'; $('#log').textContent=window._devMode?ui('loading_settings_snapshot','Loading full settings snapshot…'):ui('loading_current_settings','Loading current settings…');
  try{
    const r=await api('/api/settings_snapshot?name='+encodeURIComponent(name)+(window._devMode?'&detail=full':''));
    if(r&&r._offline){ $('#log').textContent=ui('panel_offline','Panel offline.'); return; }
    // Server returns the raw persisted documents + resolved profile + exact source paths.
    // No duplicate defaults live in this UI, so this view cannot drift from the engine files.
    $('#log').textContent=formatSettingsSnapshot(r,!!window._devMode);
  }catch(e){ $('#log').textContent=ui('settings_snapshot_failed','Could not load settings snapshot: {error}',{error:e}); }
  $('#logclose').style.display='inline-block'; $('#logp').scrollIntoView({behavior:'smooth'});
}
async function resetSeen(){
  const g=gather(); if(!g.name){alert(ui('enter_agent_name','Enter the agent name'));return;}
  let r=null; try{ r=await api('/api/resetseen',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name:g.name})}); }catch(e){}
  if(!r||!r.ok){ flash(ui('memory_clear_failed','Could not clear the memory: {error}',{error:(r&&r.msg)||'server refused'})); return; }
  flash(ui('memory_cleared_n','Memory cleared ({count} message ids). Unread mail still on the server will be reported again.',{count:(r.cleared||0)}));
}
async function showSeenMemory(){
  const _fn=$('#f-name');
  const _name=(_fn?_fn.value.trim():null)||(cur&&cur.name)||'';
  const box=document.getElementById('seenmem');
  if(!_name){ if(box) box.innerHTML='<span class="hint">'+ui('pick_agent','Pick an A-Tool.')+'</span>'; return; }
  try{
    const r=await api('/api/seen_status?name='+encodeURIComponent(_name));
    if(box) box.innerHTML=`<div class="hint" style="font-size:11px">${ui('seen_memory_status','Remembered as already reported: <b>{count}</b> messages.<br>File: <code>{path}</code> {state}',{count:esc(String(r.count??'?')),path:esc(r.path||'?'),state:r.exists?'✓':ui('file_not_created','✗ (not created yet)')})}</div>`;
  }catch(e){ if(box) box.innerHTML='<span class="hint">'+ui('could_not_read','Could not read.')+'</span>'; }
}
async function run(){
  const g=gather(); if(!g.name){alert(ui('enter_name_save_first','Enter a name and save first'));return;}
  // BUG (naprawiony): Run wysylal zapis BEZ pol _existing_name/_allow_overwrite.
  // Serwerowa blokada anty-duplikat odrzucala go po cichu ({ok:false}), a Run
  // szedl dalej na STARYM profilu z dysku. Efekt: swiezo wklejony klucz API
  // nigdy sie nie zapisywal, wiec 📄 streszczenie i ✍ draft zwracaly
  // "(no AI key - open the Keys tab...)". Teraz Run uzywa tego samego kontraktu
  // zapisu co przycisk Save i ZATRZYMUJE sie, gdy zapis nie przeszedl.
  g._existing_name = (cur && cur.name) ? cur.name : '';
  g._allow_overwrite = !!g._existing_name && g._existing_name === g.name;
  const sv=await api('/api/save',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(g)});
  if(sv && sv.ok===false){ alert((sv.error||ui('could_not_save','Could not save'))+'\n\n'+ui('run_stopped_unsaved','Run stopped — your settings were NOT saved.')); return; }
  cur=g;
  const rr=await api('/api/run',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name:g.name,offline})});
  if(rr && rr.ok===false){ alert(rr.msg||ui('could_not_start','Could not start')); return; }
  window._runningAgent=g.name;           // kto REALNIE biegnie — przetrwa przelaczenie zakladki
  $('#logp').style.display='block'; $('#resp').style.display='none';
  $('#log').textContent=ui('working_processing','⏳ Working — processing…');
  $('#logclose').style.display='none';
  if(pollTimer)clearInterval(pollTimer);
  pollTimer=setInterval(()=>poll(window._runningAgent),1200); poll(window._runningAgent);
}

// ── Wskaznik postepu runu (bez pokazywania tresci raportu) ──────────────────
// _runPct: probuje wyliczyc % z markerow logu typu 'batch 2/3'. Gdy brak -> null.
// Skanuje TYLKO linie z 'batch' albo 'mail', wiec nigdy nie zlapie tresci maila.
function _runPct(log){
  if(!log) return null;
  var best=null, lines=String(log).split(/\r?\n/);
  for(var i=0;i<lines.length;i++){
    var ln=lines[i].toLowerCase();
    if(ln.indexOf('batch')<0 && ln.indexOf('mail')<0 && ln.indexOf('/')<0) continue;
    var m=lines[i].match(/(\d+)\s*\/\s*(\d+)/);
    if(m){ var a=+m[1], b=+m[2]; if(b>0){ var p=Math.round(100*a/b); if(p>=0&&p<=100) best=p; } }
  }
  return best;
}
var _dotN=0;
function _dots(){ _dotN=(_dotN+1)%4; return '.'.repeat(_dotN); }

let _pollFailStreak=0;
const POLL_MAX_FAILS=5;   // ~6s bledow (5 x 1.2s) i przestajemy dobijac sie w kolko

async function poll(name){
  if(!name) return;
  const r=await api('/api/log?name='+encodeURIComponent(name));
  if(r && r._offline){
    _pollFailStreak++;
    if(_pollFailStreak>=POLL_MAX_FAILS){
      clearInterval(pollTimer);
      window._runningAgent=null;
      $('#logp').style.display='block'; $('#logclose').style.display='block';
      $('#log').textContent=ui('lost_panel_connection','⚠ Lost connection to the panel (server not responding).\nThe run may have finished or the panel process stopped. Refresh the page to check.');
      refreshAgents();
    }
    return;   // nie przetwarzaj polowicznej/pustej odpowiedzi jako prawdziwy stan
  }
  _pollFailStreak=0;
  // Pokazuj log biezacego runu ZAWSZE gdy agent biegnie — nawet jesli w zakladce
  // jest teraz inny agent. Wczesniej log znikal po przelaczeniu, bo warunek
  // patrzyl na aktualna zakladke, nie na to, co faktycznie sie wykonuje.
  if(r.running){
    // WAZNE: tail_log() zwraca ogon logu agenta, w ktorym siedzi PELNY raport
    // z poprzedniego runu (engine wpisuje 'RAPORT [stdout]' do logu). Gdybysmy
    // pokazali r.log surowo, user w trakcie nowego runu widzialby STARY raport.
    // Dlatego: chowamy stary wynik i pokazujemy czysty wskaznik Working/%.
    $('#resp').style.display='none';
    $('#logp').style.display='block';
    $('#logclose').style.display='none';
    var pct=_runPct(r.log);
    $('#log').textContent = (pct!=null)
        ? ui('working_percent','⏳ Working — {percent}%',{percent:pct})
        : (ui('working_processing','⏳ Working — processing…')+_dots());
  }
  refreshAgents();
  if(!r.running){
    clearInterval(pollTimer);
    window._runningAgent=null;
    if(cur && cur.name===name) showResult(name);   // wynik tylko gdy patrzysz na tego agenta
  }
}
// ── GROZNE AKCJE — jeden mechanizm dla wszystkich ──────────────────────────
// Zamiast confirm() (ktory ludzie klikaja odruchowo), przycisk zmienia sie w
// "Click again to confirm" i wraca po 4s. Dziala dla KAZDEJ akcji — nowe
// niebezpieczne przyciski dostaja to za darmo: onclick="danger(this,'opis',fn)"
const _armed=new WeakMap();
function danger(btn, what, fn){
  if(_armed.get(btn)){
    clearTimeout(_armed.get(btn));
    _armed.delete(btn);
    btn.textContent=btn.dataset.orig||btn.textContent;
    btn.style.background=''; btn.style.color='';
    fn();
    return;
  }
  btn.dataset.orig=btn.dataset.orig||btn.textContent;
  btn.textContent=ui('click_again_confirm','⚠ Click again to confirm');
  btn.style.background='var(--red)'; btn.style.color='#fff';
  const t=setTimeout(()=>{
    _armed.delete(btn);
    btn.textContent=btn.dataset.orig;
    btn.style.background=''; btn.style.color='';
  }, 4000);
  _armed.set(btn, t);
}
// ── POTWIERDZENIE GROZNYCH AKCJI — jeden szablon dla wszystkich a-tooli ─────
// Uzycie:  confirmDanger({title, body, okLabel, onOk})
// Kazda groźna akcja (restore, clear, reset, delete) uzywa TEGO SAMEGO okna.
// Nowy a-tool dostaje to za darmo — nie pisze wlasnego confirm().
function confirmDanger(opt){
  const {title, body, okLabel, onOk, warn} = opt||{};
  const prev = $('#modal').style.display==='block' ? $('#modalbody').innerHTML : null;
  const html = `
    <div style="max-width:520px">
      <div style="font-weight:700;font-size:16px;color:var(--red);margin-bottom:8px">
        ⚠ ${esc(title||ui('are_you_sure','Are you sure?'))}</div>
      <div style="font-size:13px;line-height:1.6;color:var(--txt)">${body||''}</div>
      ${warn?`<div style="margin-top:10px;padding:9px 11px;background:#fef2f2;border-left:3px solid var(--red);
        border-radius:0 6px 6px 0;font-size:12.5px;color:var(--txt)">${warn}</div>`:''}
      <div class="bar" style="margin-top:16px">
        <button class="btn" style="background:var(--red);border-color:var(--red)"
          onclick="_dangerOk()">${esc(okLabel||ui('yes_do_it','Yes, do it'))}</button>
        <button class="btn ghost" onclick="_dangerCancel()">${ui('cancel','Cancel')}</button>
      </div>
    </div>`;
  window.__dangerPrev = prev;
  window.__dangerFn = onOk;
  openModal(html);
}
function _dangerOk(){
  const fn = window.__dangerFn;
  window.__dangerFn = null;
  if(window.__dangerPrev){ openModal(window.__dangerPrev); window.__dangerPrev=null; }
  else closeModal();
  if(typeof fn === 'function') fn();
}
function _dangerCancel(){
  window.__dangerFn = null;
  if(window.__dangerPrev){ openModal(window.__dangerPrev); window.__dangerPrev=null; }
  else closeModal();
}
// --- STOS NAWIGACJI MODALI --------------------------------------------------
// Kazdy panel rejestruje sie przez enterPanel(nazwa_funkcji). Back (goBack)
// wraca do TEGO panelu, z ktorego naprawde przyszlismy — niezaleznie od tego,
// czy Dev Tools bylo otwarte w innym oknie / z paska u gory / bezposrednio.
window._navStack = window._navStack || [];
function enterPanel(fnName){
  // Jesli wchodzimy do panelu, z ktorego wlasnie wrocilismy (goBack), nie dubluj.
  if(window._navReturning){ window._navReturning=false; window._navCur=fnName; return; }
  if(window._navCur && window._navCur!==fnName) window._navStack.push(window._navCur);
  window._navCur=fnName;
}
function goBack(){
  var prev=window._navStack.pop();
  if(prev && window[prev]){ window._navReturning=true; window[prev](); }
  else closeModal();
}

// JEDEN przycisk powrotu, z etykieta zalezna od tego SKAD przyszedles.
// Wczesniej panele mialy na sztywno "← Back to Dev Tools" PLUS osobny Cancel/Close
// — wiec z gornego paska pojawialy sie dwa guziki, a jeden z nich klamal.
const _PANEL_LABEL_KEYS={showAdmin:['dev_tools_plain','Dev Tools'],showOpps:['platforms','platforms'],showSettings:['settings','Settings'],
  showBackups:['backups','Backups'],showRules:['rules','Rules'],showCalendar:['calendar','Calendar'],
  showAbout:['contact_plain','Contact'],showDocs:['docs_plain','Docs'],showUsage:['ai_cost','AI cost'],
  showTagEditor:['tag_rules','Tag rules'],editContext:['profile_plain','profile']};
function backBtn(){
  var prev=window._navStack.length ? window._navStack[window._navStack.length-1] : null;
  // BRAK HISTORII (panel otwarty wprost z gornego paska) -> NIC nie zwracamy.
  // Modal ma juz stale "✕ close" w rogu, wiec dolny "Close" byl czystym dubletem.
  if(!prev) return '';
  var spec=_PANEL_LABEL_KEYS[prev], name=spec?ui(spec[0],spec[1]):'';
  return '<button class="btn ghost" onclick="goBack()">'+ui('back_to','← Back{destination}',{destination:name?' '+ui('to_destination','to {name}',{name:esc(name)}):''})+'</button>';
}
// Podpina onclick w DOWOLNYM kontenerze. Wydzielone z openModal, bo tresc
// wstawiana PO otwarciu modala (np. multirun do #benchout) nigdy nie dostawala
// eventow — przyciski byly widoczne, ale martwe ("jest tekst, nie da sie kliknac").
function wireClicks(root){
  if(!root) return;
  root.querySelectorAll('[onclick]').forEach(function(el){
    if(el._wiredClick) return;
    var code=el.getAttribute('onclick');
    if(!code) return;
    el._wiredClick=true;
    el.removeAttribute('onclick');            // usun natywny, zeby nie dublowac
    el.addEventListener('click', function(ev){
      setTimeout(function(){
        try{ (new Function(code)).call(el); }
        catch(e){
          // CSP blokuje eval w niektorych przegladarkach — awaryjnie obsluz
          // najczestsze wzorce bez eval, zeby UI nie byl martwy.
          try{
            var m=code.match(/^\s*(\w+)\s*\(\s*\)\s*;?\s*$/);
            if(m && typeof window[m[1]]==='function'){ window[m[1]](); return; }
            if(/classList\.toggle\('on'\)/.test(code)){ el.classList.toggle('on'); return; }
            var q=code.match(/^\s*(\w+)\s*\(\s*'([^']*)'\s*\)\s*;?\s*$/);
            if(q && typeof window[q[1]]==='function'){ window[q[1]](q[2]); return; }
          }catch(e2){}
          console.error('onclick:', code, e);
        }
      }, 0);
    });
  });
}

function openModal(html){
  var mb=$('#modalbody');
  mb.innerHTML=html;
  $('#modal').style.display='block';
  document.body.style.overflow='hidden';
  wireClicks(mb);
  // DEV-ONLY (matrix, demo mode, where-to-apply): ukryj przy KAZDYM renderze
  // modala, nie tylko przy starcie — inaczej wracaly po otwarciu Dev Tools.
  if(!window._devMode){
    mb.querySelectorAll('.dev-matrix-only').forEach(el=>{ el.style.display='none'; });
  }
  // Niezalezna od atrybutu onclick, wiec dziala nawet gdy Chrome go pomija.
  var known={'dt-profile':'editContext','st-profile':'editContext'};
  Object.keys(known).forEach(function(id){
    var bt=document.getElementById(id);
    if(bt && !bt._wired){
      bt._wired=true;
      bt.addEventListener('click', function(){
        setTimeout(function(){ if(window[known[id]]) window[known[id]](); }, 0);
      });
    }
  });
}
function closeModal(){
  $('#modal').style.display='none';
  document.body.style.overflow='';
  window._navStack=[]; window._navCur=null; window._navReturning=false;
}

// ── Podglad ekosystemu: kto jeszcze siedzi w katalogu nadrzednym ────────────

async function showAdmin(){
  enterPanel('showAdmin');
  // DEV TOOLS — dziala dla WSZYSTKICH a-tooli; wybierasz, ktory testujesz
  openModal('<div style="font-weight:700;color:var(--acc);font-size:16px">'+ui('dev_tools_plain','🛠 Dev Tools')+'</div><div class="hint">'+ui('loading_plain','loading…')+'</div>');
  let agents=[]; try{ agents=await api('/api/agents'); }catch(e){}
  if(!Array.isArray(agents)) agents=[];   // serwer down -> api() zwraca {_offline:true}, nie tablice
  const sel = window._devAgent || (cur&&cur.name) || (agents[0]&&agents[0].name) || '';
  window._devAgent = sel;

  let h='<div style="font-weight:700;color:var(--acc);font-size:16px;margin-bottom:8px">'+ui('dev_tools_plain','🛠 Dev Tools')+'</div>';

  h+=`<div style="padding:8px 10px;background:#f8fafc;border-radius:8px;margin-bottom:12px">
    <label style="margin:0">${ui('which_atool_testing','Which A-Tool are you testing?')}</label>
    <select id="dev-agent" onchange="window._devAgent=this.value;showAdmin()" style="margin-top:4px">
      ${agents.map(a=>`<option value="${esc(a.name)}" ${a.name===sel?'selected':''}>${esc(a.name)} (${esc(a.kind)})</option>`).join('')||'<option>'+ui('no_atools_yet','no A-Tools yet')+'</option>'}
    </select>
    <div class="hint" style="margin-top:4px">${ui('testing_atool_hint','Everything below runs against this one. Switch it to test another.')}</div>
  </div>`;

  h+=`<div style="font-weight:600;margin:12px 0 6px">${ui('test_it','Test it')}</div>
    <div class="hint">${ui('test_it_hint_clear','Read-only checks for the selected A-Tool: profile/source loading, AI connectivity, last report/body cache, rules, calendars, backups, dependencies, docs and user profile. These tests do not change schedules, autostart or configuration.')}</div>
    <button class="btn ghost" style="padding:5px 11px;font-size:12px" onclick="runFullCheck()">${ui('test_all_features','🧪 Test all features')}</button>
    <button class="btn ghost dev-matrix-only" style="padding:5px 11px;font-size:12px" onclick="compareAgents()">${ui('multi_run_matrix','⚖ Multi-run matrix')}</button>
    <button class="btn ghost" style="padding:5px 11px;font-size:12px" onclick="showRawLog()">${ui('full_log','📜 Full log')}</button>
    <div id="benchout" style="margin-top:8px"></div>

    <div style="font-weight:600;margin:16px 0 6px">${ui('notification_tests','Notification tests')}</div>
    <div class="hint">${ui('notification_tests_hint','These send a test only. They do not enable autostart or change your schedule.')}</div>
    <button class="btn ghost" style="padding:5px 11px;font-size:12px" onclick="testNotify('desktop')">${ui('desktop_popup','🔔 Desktop popup')}</button>
    <button class="btn ghost" style="padding:5px 11px;font-size:12px" onclick="testNotify('channel')">${ui('messenger_channel','💬 Messenger channel')}</button>
    <div class="hint" id="ntstat" style="margin-top:6px"></div>

    <div style="font-weight:600;margin:16px 0 6px">${ui('wake_schedule_management','Wake & schedule management')}</div>
    <div class="hint">${ui('wake_schedule_management_hint','These controls can change background behaviour. Open the Wake manager to edit Wake/popup settings, inspect both calendars and jump to each local A-Tool schedule.')}</div>
    <button class="btn ghost" style="padding:5px 11px;font-size:12px" title="${esc(ui('system_panel_hint','Wake settings, schedules, popup, calendars and dependencies'))}" onclick="showSystemPanel()">${ui('wake_scheduler_popup','🖥 Wake / Scheduler / Popup')}</button>
    <div class="dev-matrix-only">
    <div style="font-weight:600;margin:16px 0 6px">${ui('demo_mode','Demo mode')}</div>
    <div class="hint">${ui('demo_mode_hint','Fake mail (fictional bailiff, bank and tax office — none of it real) for recording a video. Demo never touches your calendar and never notifies.')}</div>
    <label class="chk ${offline?'on':''}" id="offchk" onclick="toggleOff();showAdmin()" style="margin-top:6px"><span id="offdot">${offline?'●':'○'}</span> ${ui('demo_mode_state','demo mode {state}',{state:offline?ui('demo_on','— ON (report is fake!)'):ui('demo_off','— off')})}</label>
    </div>

    <div style="font-weight:600;margin:16px 0 6px">${ui('settings_data','Settings & data')}</div>
    <button class="btn ghost" style="padding:5px 11px;font-size:12px" onclick="showSettings()">${ui('global_settings_button','⚙ Global settings (UI + all A-Tools)')}</button>
    <button class="btn ghost" style="padding:5px 11px;font-size:12px" id="dt-profile">${ui('my_profile','👤 My profile')}</button>
    <button class="btn ghost" style="padding:5px 11px;font-size:12px" onclick="showTagEditor('tags')">${ui('tags_rules_button','🏷 Tags & tag rules')}</button>
    <button class="btn ghost" style="padding:5px 11px;font-size:12px" onclick="showRules()">${ui('rules_button','⚖ Rules')}</button>
    <button class="btn ghost" style="padding:5px 11px;font-size:12px" onclick="showBackups()">${ui('backups_button','↩ Backups')}</button>
    <button class="btn" style="padding:5px 11px;font-size:12px" onclick="exportConfig()">${ui('export_all_config','💾 Export ALL config')}</button>
    <button class="btn ghost" style="padding:5px 11px;font-size:12px" onclick="importConfig()">${ui('import_config','📥 Import config')}</button>
    <button class="btn ghost" style="padding:5px 11px;font-size:12px" title="${esc(ui('export_main_calendar_hint','Export user deadlines and notes to .ics; technical Wake schedules are exported separately'))}" onclick="exportCal(&quot;main&quot;)">${ui('export_main_calendar','📅 Export main calendar')}</button>
    <button class="btn ghost" style="padding:5px 11px;font-size:12px" title="${esc(ui('show_seen_memory_hint','Show how many messages are remembered as already reported'))}" onclick="showSeenMemory()">${ui('show_seen_memory','👁 Show seen-memory')}</button>
    <button class="btn ghost" style="padding:5px 11px;font-size:12px" title="${esc(ui('reset_seen_title_hint','Forget which messages were already reported — the next run will show them again'))}" onclick="askResetSeen()">${ui('reset_already_reported','🧠 Reset “already reported”')}</button>
    <div id="seenmem" style="margin-top:8px"></div>
    <div class="hint" style="margin-top:6px">${ui('export_config_warning','💾 Safe Export saves agents, mailbox/account settings, tags, rules and your profile, but <b>does not export passwords or API keys</b>. On a new computer, enter secrets again. Import keeps existing local secrets when possible.')}</div>
    <button class="btn ghost" style="padding:5px 11px;font-size:12px" onclick="showUsage()">${ui('ai_cost_button','📊 AI cost')}</button>
    <button class="btn ghost" style="padding:5px 11px;font-size:12px" onclick="showDocs()">${ui('docs','📖 Docs')}</button>
    <button class="btn ghost dev-matrix-only" style="padding:5px 11px;font-size:12px" onclick="showOpps()">${ui('where_apply','🎯 Where to apply')}</button>
    <div class="bar"><button class="btn ghost" onclick="closeModal()">${ui('close','✕ Close')}</button></div>`;
  openModal(h);
}

async function compareAgents(){
  // MACIERZ WIELU RUNOW: TEN SAM a-tool, rozne KOMBINACJE ustawien, obok siebie.
  // CEL: ocenic, ktora konfiguracja daje najlepszy wynik dla deva
  // (czytelnosc / accuracy / efektywnosc) — nie samo wykrywanie rozjazdow.
  const el=$('#benchout'); if(!el) return;
  const nm=window._devAgent||(cur&&cur.name)||'';
  if(!nm){ el.innerHTML='<span class="hint">'+ui('pick_agent','Pick an A-Tool.')+'</span>'; return; }
  let M={combos:[]};
  try{ M=await api('/api/modes'); }catch(e){}

  let h=`<div style="font-weight:600;margin-bottom:4px">${ui('multi_run_for','⚖ Multi-run — {name}',{name:esc(nm)})}</div>
    <div class="hint">${ui('multi_run_intro','Runs the same A-Tool several times with different settings and lays the results side by side, so you can judge which configuration reads best, is most accurate and most efficient.')}</div>
    <div style="margin-top:10px;font-weight:600;font-size:13px">${ui('which_engine','Which engine')}</div>
    <label class="chk on" id="me-matrix" onclick="pickMrEngine('matrix')"><span></span> ${ui('matrix_engine','Matrix (combinations × 4 sample mails)')}</label>
    <div class="hint" style="margin:2px 0 6px 4px">${ui('matrix_engine_hint','Newer. Whole combinations as rows, four sample mails as columns, repeats marked “=”, delta vs base and agent-to-agent tests.')}</div>
    <label class="chk" id="me-classic" onclick="pickMrEngine('classic')"><span></span> ${ui('classic_engine','Classic (modes + flags)')}</label>
    <div class="hint" style="margin:2px 0 8px 4px">${ui('classic_engine_hint','The original. Pick modes and extra flags applied to every mode; shows totals and where priorities changed.')}</div>

    <div id="mr-matrix-opts">
    <div style="margin-top:6px;font-weight:600;font-size:13px">${ui('which_combinations','Which combinations to run')}</div>
    <div class="hint" style="margin-bottom:4px">${ui('which_combinations_hint','Tick whole combinations. Each is one run with a fixed set of switches.')}</div>`;
  for(const c of (M.combos||[])){
    const on = (c.key||'').indexOf('invoke')<0 ? 'on' : '';
    h+=`<label class="chk ${on}" id="mc-${esc(c.key)}" onclick="this.classList.toggle('on')"><span></span> ${esc(c.name)}${c.invoke?' <span class="hint">(agent→agent)</span>':''}</label>
        <div class="hint" style="margin:2px 0 8px 4px">${esc(c.desc)}</div>`;
  }
  h+=`</div>

    <div id="mr-classic-opts" style="display:none">
    <div style="margin-top:6px;font-weight:600;font-size:13px">${ui('which_modes','Which modes to run')}</div>`;
  for(const m of (M.modes||[])){
    const on = (m.key==='script'||m.key==='ai_fast') ? 'on' : '';
    h+=`<label class="chk ${on}" id="mr-${esc(m.key)}" onclick="this.classList.toggle('on')"><span></span> ${esc(m.label)}</label>
        <div class="hint" style="margin:2px 0 8px 4px">${esc(m.note)}</div>`;
  }
  h+=`<div style="margin-top:8px;font-weight:600;font-size:13px">${ui('extra_switches','Extra switches (applied to every mode)')}</div>`;
  for(const f of (M.flags||[])){
    h+=`<label class="chk" id="mf-${esc(f.key)}" onclick="this.classList.toggle('on')"><span></span> ${esc(f.label)}</label> `;
  }
  h+=`</div>

    <div style="margin-top:10px">
      <label class="chk${(window._globalSettings&&window._globalSettings.mr_no_memory===false)?'':' on'}" id="mc-nomem" onclick="this.classList.toggle('on')"><span></span> ${ui('block_memory','🔒 Block run memory (debug on the same mails)')}</label>
      <div class="hint">${ui('block_memory_h','Keep this on for debugging. Every run sees the same mails; real memory is restored afterwards and nothing is marked read.')}</div>
    </div>
    <div class="bar">
      <button class="btn" onclick="runMatrix()">▶ ${ui('run','Run')}</button>
      <button class="btn ghost" onclick="saveMrSettings()">${ui('save_these_settings','💾 Save these settings')}</button>
      ${backBtn()}
      <span class="hint" id="mcstat"></span>
    </div>
    <div id="mcout" style="margin-top:10px"></div>`;
  el.innerHTML=h;
  wireClicks(el);          // bez tego checkboxy sa martwe (wstawione po otwarciu modala)
  // przywroc zapisany wybor silnika (domyslnie matrix)
  pickMrEngine((window._globalSettings&&window._globalSettings.mr_engine)||'matrix');
}

async function saveMrSettings(){
  // ZAPIS ustawien multirunu — wczesniej "Block run memory" wracalo do ON
  // przy kazdym otwarciu i nie bylo jak tego zmienic na stale.
  const st=$('#mcstat');
  try{
    const s=window._globalSettings||{};
    s.mr_engine = window._mrEngine||'matrix';
    s.mr_no_memory = !!($('#mc-nomem') && $('#mc-nomem').classList.contains('on'));
    await api('/api/settings',{method:'POST',headers:{'Content-Type':'application/json'},
      body:JSON.stringify(s)});
    window._globalSettings=s;
  if(st) st.innerHTML='<span style="color:var(--green)">'+ui('saved_next_open','saved — this is how it will open next time')+'</span>';
  }catch(e){ if(st) st.innerHTML='<span style="color:var(--red)">'+ui('could_not_save','Could not save.')+'</span>'; }
}

function pickMrEngine(which){
  window._mrEngine=which;
  const mx=document.getElementById('me-matrix'), cl=document.getElementById('me-classic');
  const mo=document.getElementById('mr-matrix-opts'), co=document.getElementById('mr-classic-opts');
  if(mx) mx.classList.toggle('on', which==='matrix');
  if(cl) cl.classList.toggle('on', which==='classic');
  if(mo) mo.style.display = which==='matrix' ? 'block' : 'none';
  if(co) co.style.display = which==='classic' ? 'block' : 'none';
}

async function runMatrix(){
  const nm=window._devAgent||(cur&&cur.name)||'';
  const st=$('#mcstat'), out=$('#mcout');
  const which=window._mrEngine||'matrix';
  let M={combos:[],modes:[],flags:[]};
  try{ M=await api('/api/modes'); }catch(e){}

  let payload={name:nm, engine:which}, count=0, aiCount=0;
  if(which==='classic'){
    const modes=(M.modes||[]).map(m=>m.key).filter(k=>{
      const e=document.getElementById('mr-'+k); return e && e.classList.contains('on'); });
    const flags=(M.flags||[]).map(f=>f.key).filter(k=>{
      const e=document.getElementById('mf-'+k); return e && e.classList.contains('on'); });
    if(modes.length<1){ if(st) st.textContent=ui('pick_one_mode','Pick at least one mode.'); return; }
    payload.modes=modes; payload.flags=flags;
    count=modes.length; aiCount=modes.filter(k=>k!=='script').length;
  }else{
    const combos=(M.combos||[]).map(c=>c.key).filter(k=>{
      const e=document.getElementById('mc-'+k); return e && e.classList.contains('on'); });
    if(combos.length<1){ if(st) st.textContent=ui('pick_one_combination','Pick at least one combination.'); return; }
    payload.combos=combos;
    count=combos.length; aiCount=combos.filter(k=>k.indexOf('script')<0).length;
  }
  payload.no_memory = $('#mc-nomem') && $('#mc-nomem').classList.contains('on');

  const wait=aiCount>1?(aiCount-1)*65:0;
  if(st) st.innerHTML = wait
    ? ui('multi_run_wait','⏳ running {count} run(s) — about {minutes} min. <span class="hint">It pauses between AI runs because the free tier resets its limit each minute.</span>',{count,minutes:Math.round(wait/60)+1})
    : ui('multi_run_running','⏳ running {count} run(s)…',{count});
  if(out) out.innerHTML='';
  try{
    const r=await api('/api/multirun',{method:'POST',headers:{'Content-Type':'application/json'},
      body:JSON.stringify(payload)});
    if(!r.ok){ if(st) st.innerHTML='<span style="color:var(--red)">'+ui('failed_with_error','Failed: {error}',{error:esc(r.error||'')})+'</span>'; return; }
    if(st) st.innerHTML='<span style="color:var(--green)">'+ui('done','done')+'</span>';
    if(r.engine==='classic') renderMatrixClassic(r, out);
    else renderMatrix(r, out);
  }catch(e){ if(st) st.innerHTML='<span style="color:var(--red)">'+ui('failed_with_error','Failed: {error}',{error:esc(String(e))})+'</span>'; }
}

function renderMatrixClassic(r, out){
  // STARY render: podsumowanie trybow + gdzie priorytety sie rozjechaly.
  const modes=r.modes||{}, keys=Object.keys(modes);
  if(!keys.length){ out.innerHTML='<span class="hint">'+ui('nothing_came_back','Nothing came back.')+'</span>'; return; }
  let h='<div style="font-weight:600;margin:12px 0 6px">'+ui('mode_results','What each mode produced')+'</div>';
  h+='<div style="overflow-x:auto"><table style="width:100%;font-size:12px;border-collapse:collapse">';
  h+='<tr><th style="text-align:left;padding:4px;border-bottom:1px solid var(--line)"></th>'+
     keys.map(k=>`<th style="text-align:left;padding:4px;border-bottom:1px solid var(--line)">${esc(modes[k].label||k)}</th>`).join('')+'</tr>';
  const rows=[
    [ui('mails_seen','mails seen'),        k=>modes[k].mails],
    [ui('flagged_important','flagged important'), k=>modes[k].important],
    [ui('ai_summaries','AI summaries'),      k=>modes[k].summaries],
    [ui('tokens_used','tokens used'),       k=>modes[k].tokens],
    [ui('time_taken','time taken'),        k=>modes[k].elapsed+'s'],
    [ui('error','error'),             k=>modes[k].error||'—'],
  ];
  for(const [label,fn] of rows){
    const vals=keys.map(k=>{ try{ return String(fn(k)); }catch(e){ return '?'; } });
    const differ=new Set(vals).size>1;
    h+=`<tr><td style="padding:3px 4px;color:var(--dim);white-space:nowrap">${esc(label)}</td>`+
       vals.map(v=>`<td style="padding:3px 4px;${differ?'background:#fffbeb':''}">${esc(v)}</td>`).join('')+'</tr>';
  }
  h+='</table></div>';
  const changed=(r.diff&&r.diff.priority_changed)||[];
  h+=`<div style="font-weight:600;margin:16px 0 6px">${ui('mode_disagreements','Where the modes disagree ({count})',{count:changed.length})}</div>`;
  if(!changed.length){
    h+='<div class="hint" style="padding:10px;background:#f0fdf4;border-radius:8px">'+ui('modes_agree','Every mode ranked every mail the same. The script alone is doing the work; AI is only rewriting summaries.')+'</div>';
  }else{
    h+='<div class="hint">'+ui('modes_disagree_hint','These are the mails where enabling AI changed the outcome. Review them to judge whether the change was correct.')+'</div>';
    h+='<table style="width:100%;font-size:12px;margin-top:6px">';
    for(const c of changed){
      h+=`<tr><td style="padding:5px;border-bottom:1px solid var(--line)"><b>${esc(c.from)}</b> — ${esc(c.title)}<div style="margin-top:3px">`;
      for(const k of keys){
        const p=(c.priorities||{})[k]; if(!p) continue;
        h+=`<span style="display:inline-block;margin-right:10px"><span class="hint">${esc(modes[k].label||k)}:</span> <b>${esc(p)}</b></span>`;
      }
      h+='</div>';
      const sums=c.summaries||{};
      if([...new Set(Object.values(sums))].length>1){
        h+='<div style="margin-top:4px;font-size:11px">';
        for(const k of keys){ if(!sums[k]) continue;
          h+=`<div style="margin-top:2px"><span class="hint">${esc(modes[k].label||k)}:</span> ${esc(sums[k])}</div>`; }
        h+='</div>';
      }
      h+='</td></tr>';
    }
    h+='</table>';
  }
  out.innerHTML=h;
}

function renderMatrix(r, out){
  const rows=(r.matrix&&r.matrix.rows)||[], sample=r.sample||[];
  if(!rows.length){ out.innerHTML='<span class="hint">'+ui('nothing_came_back','Nothing came back.')+'</span>'; return; }
  const cols=sample.filter(s=>!s.missing);
  const SLOT={p1:ui('slot_p1','P1! type'),p2:ui('slot_p2','P2 type'),bulk:ui('slot_bulk','bulk / promo'),neutral:ui('slot_neutral','neutral')};

  // NAGLOWEK: 4 wybrane maile jako kolumny + info o brakujacych typach (regula domknieta)
  let h='<div style="font-weight:600;margin:12px 0 6px">'+ui('matrix_title','The matrix — rows are combinations, columns are the four sample mails')+'</div>';
  const missing=sample.filter(s=>s.missing);
  if(missing.length){
    h+='<div class="hint" style="padding:8px;background:#fff7ed;border-radius:8px;margin-bottom:8px">';
    h+=ui('matrix_missing_slots','Some slots had no matching mail, so they are intentionally empty:')+'<br>';
    for(const m of missing) h+=`• <b>${esc(SLOT[m.slot]||m.slot)}</b>: ${esc(m.reason||ui('not_found','not found'))}<br>`;
    h+='</div>';
  }
  if(!cols.length){ out.innerHTML=h+'<div class="hint">'+ui('no_sample_mails','No usable sample mails.')+'</div>'; return; }

  h+='<div style="overflow-x:auto"><table style="width:100%;font-size:12px;border-collapse:collapse">';
  h+='<tr><th style="text-align:left;padding:5px;border-bottom:1px solid var(--line);min-width:150px">'+ui('combination','combination')+'</th>';
  for(const c of cols){
    h+=`<th style="text-align:left;padding:5px;border-bottom:1px solid var(--line);min-width:150px;vertical-align:top">
      <span class="hint">${esc(SLOT[c.slot]||c.slot)}</span><br><b>${esc(c.title||c.from||c.mid)}</b>
      <div class="hint">${esc(c.from||'')}</div></th>`;
  }
  h+='</tr>';

  window._matrixRunRows=rows;
  for(let rowIndex=0; rowIndex<rows.length; rowIndex++){
    const row=rows[rowIndex];
    h+=`<tr><td style="padding:5px;border-bottom:1px solid var(--line);vertical-align:top">
      <b>${esc(row.name)}</b>${row.invoke?' <span class="hint">(agent→agent)</span>':''}
      <div class="hint" style="margin-top:2px">${esc(row.desc||'')}</div>
      <div style="margin-top:4px">
        <button class="btn ghost" style="padding:2px 7px;font-size:10px" onclick="openMatrixRunLog(${rowIndex},'plain')">📜 Log</button>
        <button class="btn ghost" style="padding:2px 7px;font-size:10px" onclick="openMatrixRunLog(${rowIndex},'debug')">🔬 Debug</button>
      </div>`;
    // Δ vs base — glebokosc / penetracja folderow (nie na poziomie agregatu-werdyktu)
    if(!row.is_base){
      const dr=row.d_reach, df=row.d_folders;
      if(dr||df){
        h+=`<div class="hint" style="margin-top:3px">${ui('delta_vs_base','Δ vs base')}: `
          +`${df>0?'+':''}${df} ${ui('folders','folders')}, ${dr>0?'+':''}${dr} ${ui('messages_reached','messages reached')}</div>`;
      }
    } else {
      h+=`<div class="hint" style="margin-top:3px">${ui('base','base')}: ${row.folders} ${ui('folders','folders')}, ${row.reach} ${ui('messages_short','msgs')}</div>`;
    }
    if(row.error) h+=`<div class="hint" style="color:var(--red);margin-top:3px">${esc(row.error)}</div>`;
    h+='</td>';
    for(const c of cols){
      const cell=(row.cells||{})[c.mid];
      if(!cell || !cell.present){
        h+='<td style="padding:5px;border-bottom:1px solid var(--line);color:var(--dim)">—</td>';
        continue;
      }
      // ABSOLUTNIE identyczna jak w poprzednim runie -> tylko znacznik "="
      if(cell.same_as_prev){
        h+='<td style="padding:5px;border-bottom:1px solid var(--line);text-align:center;color:var(--dim)" title="'+esc(ui('identical_run_above','identical to the run above'))+'">=</td>';
        continue;
      }
      const hl = cell.flag ? 'background:#fffbeb;' : '';
      h+=`<td style="padding:5px;border-bottom:1px solid var(--line);vertical-align:top;${hl}">
        <div><b>${esc(cell.priority)}</b> ${(cell.tags||[]).map(t=>`<span class="hint">#${esc(t)}</span>`).join(' ')}</div>
        <div style="margin-top:2px">${esc(cell.title||'')}</div>
        <div class="hint" style="margin-top:2px">${esc(cell.summary||'')}</div></td>`;
    }
    h+='</tr>';
  }
  h+='</table></div>';

  // Podswietlone maile = tam siedza bugi. To glowny wynik, ale bez werdyktu-agregatu.
  const fl=(r.matrix&&r.matrix.flagged_mids)||[];
  if(fl.length){
    h+=`<div class="hint" style="margin-top:8px;padding:8px;background:#fffbeb;border-radius:8px">`
      +ui('highlighted_cells','Highlighted cells mean the same mail received a different tag or priority across runs. Review them for accuracy.')+'</div>';
  }

  // KOSZT — osobno, na dole, drobnym drukiem. Metryka poboczna.
  h+='<div style="margin-top:10px;font-size:11px;color:var(--dim)">'+ui('cost_side_metric','Cost (side metric)')+': ';
  h+=rows.map(row=>`${esc(row.name.split(' · ')[0])} — ${row.tokens} tok, ${row.elapsed}s`).join(' · ');
  h+='</div>';

  out.innerHTML=h;
}

function openMatrixRunLog(index,which){
  const rows=window._matrixRunRows||[], row=rows[index]||{};
  const txt=which==='debug'?(row.debug_log||'(no debug trace captured)'):(row.plain_log||'(no run log captured)');
  const w=window.open('',`multirun-${index}-${which}`,'width=900,height=650,resizable=yes,scrollbars=yes');
  if(!w){ alert(ui('popup_blocked','The browser blocked the log window. Allow pop-ups for localhost and click again.')); return; }
  w.document.title=`${row.name||'Multi-run'} — ${which==='debug'?'Debug':'Log'}`;
  w.document.body.style.margin='0';
  w.document.body.style.background='#0f172a';
  w.document.body.style.color=which==='debug'?'#a5f3fc':'#e2e8f0';
  const pre=w.document.createElement('pre');
  pre.style.cssText='white-space:pre-wrap;word-break:break-word;margin:0;padding:16px;font:12px/1.45 ui-monospace,SFMono-Regular,Menlo,Consolas,monospace';
  pre.textContent=txt;
  w.document.body.replaceChildren(pre);
  try{ w.focus(); }catch(e){}
}

function toggleNoiseCat(el,cat){
  if(el) el.classList.toggle('on');
  const root=document.getElementById('rl-noise-chips');
  const hidden=document.getElementById('rl-noise-cats');
  if(root&&hidden){hidden.value=Array.from(root.querySelectorAll('[data-noise-cat].on')).map(x=>x.dataset.noiseCat).join(', ');}
}
function showRules(){ return showTagEditor('all'); }
async function showClassificationSettings(){
  enterPanel('showClassificationSettings');
  const [r,tagR]=await Promise.all([
    api('/api/rules'),
    api('/api/tags?name='+encodeURIComponent((cur&&cur.name)||''))
  ]);
  if(r&&r._offline){ openModal('<div class="hint">'+ui('panel_not_responding','⚠ Panel not responding — run <code>python3 panel.py</code>')+'</div><div class="bar">'+backBtn()+'</div>'); return; }
  const R=(r&&r.rules)||{};
  const allP=['P1!','P1','P2','P3','P4','P5'];
  const psel=(id,val,allowOff)=>`<select id="${id}">${allowOff?'<option value=""'+(!val?' selected':'')+'>'+ui('off_no_limit','off / no limit')+'</option>':''}`+
    allP.map(p=>`<option value="${p}" ${val===p?'selected':''}>${p}</option>`).join('')+'</select>';
  const boolRow=(key,label,note)=>`<label class="chk ${R[key]?'on':''}" id="rl-${key}" onclick="this.classList.toggle('on')" style="margin-top:8px"><span></span> ${esc(label)}</label><div class="hint" style="margin:2px 0 0 4px">${note}</div>`;
  let h=`<div style="font-weight:700;color:var(--acc);font-size:16px;margin-bottom:4px">⚖ ${ui('classification_engine_settings','Classification engine settings')}</div>
    <div class="hint">${ui('classification_engine_settings_intro','These are global engine-behaviour settings, not message rules. They control safety rails such as watchlist priority, noise ceilings and how far AI correction may move a priority. Exact/custom message rules are edited separately under Rules.')}</div>`;

  h+=`<div style="font-weight:600;margin:14px 0 4px">${ui('watchlist_context_section','Explicit watchlist & automatic context')}</div>
    <label>${ui('explicit_watchlist_priority','Explicit watchlist priority')}</label>${psel('rl-watch-pri',R.watchlist_priority||'P1',false)}
    <div class="hint">${ui('explicit_watchlist_priority_hint','Default P1. This is deliberate user intent, so a watchlist hit may be P1!, P1, P2… exactly as you choose.')}</div>`;
  h+=boolRow('watchlist_protect_ads',ui('watchlist_protect_ads','Explicit watchlist may protect a matching ad from automatic hiding'),ui('watchlist_protect_ads_hint','This affects only the explicit watchlist — USER_CONTEXT relevance is still the softer path.'));
  h+=`<div class="row" style="margin-top:8px"><div><label>${ui('context_boost','USER_CONTEXT relevance boost (levels)')}</label>
      <input id="rl-ctx-boost" type="number" min="0" max="2" value="${esc(String(R.context_priority_boost??1))}"></div>
      <div><label>${ui('context_max_priority','USER_CONTEXT maximum priority')}</label>${psel('rl-ctx-max',R.context_max_priority||'P2',false)}</div></div>
    <div class="hint">${ui('context_boost_hint','Automatic project/context relevance can improve the Classic result, but is not the explicit watchlist. The engine clamps the boost to 0–2 levels.')}</div>`;

  h+='<div style="font-weight:600;margin:14px 0 4px">'+ui('noise_ads_safety','Noise / ads safety')+'</div>';
  h+=boolRow('ads_never_critical',ui('ads_never_critical','Ads & marketing can never become a verified critical threat'),ui('ads_never_critical_hint','Keeps marketing wording from masquerading as court/debt/security evidence.'));
  h+=boolRow('ads_light_off',ui('disable_ad_downranking','Disable automatic ad down-ranking'),ui('disable_ad_downranking_hint','Use this only if you prefer to control promotional mail entirely with your own message rules.'));
  h+=boolRow('ai_can_raise_ads',ui('ai_raise_ads','Allow Classic AI-correction to raise an ad'),ui('ai_raise_ads_hint','When enabled, the configured noise ceiling still applies unless there is explicit user intent.'));
  const _noiseKnown=['ads','marketing','social','news','system'];
  const _noiseSelected=new Set(R.noise_categories||[]);
  h+=`<label style="margin-top:8px">${ui('noise_ceiling','Noise importance ceiling')}</label>${psel('rl-noise-cap',R.noise_max_priority||'P3',true)}
      <label style="margin-top:8px">${ui('noise_categories','Categories treated as noise')}</label>
      <input type="hidden" id="rl-noise-cats" value="${esc((R.noise_categories||[]).join(', '))}">
      <div id="rl-noise-chips" style="display:flex;gap:6px;flex-wrap:wrap;margin-top:5px">${_noiseKnown.map(c=>`<span class="chk ${_noiseSelected.has(c)?'on':''}" data-noise-cat="${c}" onclick="toggleNoiseCat(this,'${c}')"><span></span>${c}</span>`).join('')}</div>
      <div class="hint">${ui('noise_categories_hint','Click the categories that should be treated as noise. The ceiling limits how important those categories may become; disabling the ceiling removes that global cap.')}</div>`;

  h+=`<details style="margin-top:14px"><summary style="cursor:pointer;font-weight:600;color:var(--acc)">${ui('advanced_rule_settings','⚙ Advanced engine rule settings')}</summary><div style="padding:4px 2px 0">`;
  h+='<div style="font-weight:600;margin:12px 0 4px">'+ui('classic_ai_safety','Classic + AI correction safety rails')+'</div>';
  h+=boolRow('ai_can_assign_p1bang',ui('ai_assign_p1bang','Allow Classic AI-correction to assign P1!'),ui('ai_assign_p1bang_hint','Default OFF. P1! is normally reserved for deterministic critical evidence.'));
  h+=`<label>${ui('max_ai_correction','Maximum upward AI correction (priority levels)')}</label>
      <input id="rl-jump" type="number" min="0" max="5" value="${esc(String(R.ai_max_priority_jump??2))}">
      <div class="hint">${ui('max_ai_correction_hint','The engine separately limits downward correction; explicit message-rule floors and ceilings always remain authoritative.')}</div>
      <div style="font-weight:600;margin:14px 0 4px">${ui('high_priority_validation','Deterministic high-priority validation')}</div>
      <label style="margin-top:8px">${ui('verified_action_priority','Confirmed direct/actionable event priority')}</label>${psel('rl-verified-action-pri',R.verified_action_priority||'P1',false)}
      <label style="margin-top:8px">${ui('verified_severe_priority','Confirmed severe/immediate event priority')}</label>${psel('rl-verified-severe-pri',R.verified_severe_priority||'P1!',false)}
      <div class="hint">${ui('verified_priority_hint','Defaults: P1 and P1!. These levels are used only after the deterministic evidence gate confirms that the event concerns the reader; a keyword alone never reaches them.')}</div>
      <label style="margin-top:8px">${ui('security_alert_priority','Non-critical security alert priority')}</label>${psel('rl-sec',R.security_alert_priority||'P2',false)}
      <label style="margin-top:8px">${ui('content_reference_priority','Non-direct risk-topic mention priority')}</label>${psel('rl-content-pri',R.content_reference_priority||'P3',false)}
      <label style="margin-top:8px">${ui('newsletter_priority','Explicit newsletter priority')}</label>${psel('rl-newsletter-pri',R.newsletter_priority||'P3',false)}
      <div class="hint">${ui('content_priority_hint','These two levels apply only when alarming wording describes a topic or somebody else’s event. A direct event concerning you still requires independent evidence for P1/P1!.')}</div>`;

  h+='<div style="font-weight:600;margin:14px 0 4px">'+ui('classification_tags','Classification & tags')+'</div>';
  h+=boolRow('project_tags_from_body',ui('project_tags_body','Detect project tags in the body too'),ui('project_tags_body_hint','OFF keeps project tags limited to sender/subject; ON also searches body text.'));
  h+=boolRow('educational_never_critical',ui('educational_never_critical','Educational/newsletter content is never critical without an addressed threat'),ui('educational_never_critical_hint','Prevents a training article about lawsuits or debt from becoming an alarm just because it contains legal keywords.'));
  h+=`<label>${ui('critical_keywords','Extra deterministic critical keywords')}</label>
      <input id="rl-kw" value="${esc((R.critical_keywords||[]).join(', '))}" placeholder="visa, landlord, final notice">
      <label style="margin-top:8px">${ui('never_critical_senders','Senders never treated as critical')}</label>
      <input id="rl-never" value="${esc((R.never_critical_senders||[]).join(', '))}" placeholder="newsletter@, noreply@">
      <label style="margin-top:8px">${ui('max_tags_message','Maximum tags kept per message')}</label>
      <input id="rl-tag-limit" type="number" min="1" max="30" value="${esc(String(R.tag_limit??6))}">`;
  h+='</div></details>';

  h+=`<div class="bar" style="margin-top:12px"><button class="btn ghost" onclick="showRules()">${ui('open_rules','⚖ Open Rules')}</button></div>`;

  h+=`<div class="bar"><button class="btn" onclick="saveRules()">${ui('save_rules','Save rules')}</button>
      <button class="btn ghost" onclick="askResetRules()">↺ ${ui('reset_factory','Reset to factory defaults')}</button>${backBtn()}<span class="hint" id="rlstat"></span></div>`;
  openModal(h);
}
async function saveRules(){
  const st=$('#rlstat'); if(st) st.textContent=ui('saving','saving…');
  const list=v=>(v||'').split(',').map(x=>x.trim()).filter(Boolean);
  const on=id=>{const e=$('#'+id);return !!(e&&e.classList.contains('on'));};
  const rules={
    ads_never_critical:on('rl-ads_never_critical'),
    noise_max_priority:($('#rl-noise-cap')||{}).value||'',
    noise_categories:list(($('#rl-noise-cats')||{}).value),
    ai_max_priority_jump:parseInt(($('#rl-jump')||{}).value||'2',10),
    ai_can_assign_p1bang:on('rl-ai_can_assign_p1bang'),
    ai_can_raise_ads:on('rl-ai_can_raise_ads'),
    verified_action_priority:($('#rl-verified-action-pri')||{}).value||'P1',
    verified_severe_priority:($('#rl-verified-severe-pri')||{}).value||'P1!',
    security_alert_priority:($('#rl-sec')||{}).value||'P2',
    content_reference_priority:($('#rl-content-pri')||{}).value||'P3',
    newsletter_priority:($('#rl-newsletter-pri')||{}).value||'P3',
    project_tags_from_body:on('rl-project_tags_from_body'),
    critical_keywords:list(($('#rl-kw')||{}).value),
    never_critical_senders:list(($('#rl-never')||{}).value),
    educational_never_critical:on('rl-educational_never_critical'),
    ads_light_off:on('rl-ads_light_off'),
    watchlist_priority:($('#rl-watch-pri')||{}).value||'P1',
    watchlist_protect_ads:on('rl-watchlist_protect_ads'),
    context_priority_boost:parseInt(($('#rl-ctx-boost')||{}).value||'1',10),
    context_max_priority:($('#rl-ctx-max')||{}).value||'P2',
    tag_limit:parseInt(($('#rl-tag-limit')||{}).value||'6',10),
  };
  try{
    const rr=await api('/api/rules_save',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({rules})});
    if(rr&&rr.ok===false){if(st)st.textContent=ui('save_failed_error','save failed: {error}',{error:rr.error||''});return;}
    if(st) st.innerHTML='<span style="color:var(--green)">'+ui('saved_next_run','✓ saved — applies on the next Run')+'</span>';
  }catch(e){if(st)st.textContent=ui('save_failed','save failed');}
}
async function resetRules(){
  const r=await api('/api/rules');
  await api('/api/rules_save',{method:'POST',headers:{'Content-Type':'application/json'},
    body:JSON.stringify({rules:r.defaults||{}})});
  showClassificationSettings();
}
async function showOpps(cat){
  enterPanel('showOpps');
  openModal('<div class="hint">'+ui('loading','⏳ loading…')+'</div>');
  const [r, FP] = await Promise.all([
    api('/api/opps'+(cat?('?cat='+encodeURIComponent(cat)):'')),
    api('/api/finder_presets').catch(()=>({presets:[]}))
  ]);
  const cats=r.categories||{}, notes=r.notes||{}, items=r.items||[];
  const presets=FP.presets||[];

  let h=`<div style="font-weight:700;color:var(--acc);font-size:16px;margin-bottom:4px">${ui('finder_title','🎯 Finder — where to apply')}</div>
    <div class="hint">${ui('finder_intro','Platforms that pay, communities that bring users, grants and places to sell. Sorted by benefit versus entry barrier. Applications are written from your profile, so you do not repeat the same information.')}</div>`;

  // SIGNUP KIT — polautomatyczne zakladanie kont
  h+=`<div style="margin-top:10px;padding:10px 12px;background:#f0f9ff;border-radius:8px">
    <div style="font-weight:600;font-size:13px">${ui('semi_automatic_signup','⚡ Semi-automatic signup')}</div>
    <div class="hint" style="margin-top:2px">${ui('semi_automatic_signup_hint','Bots are blocked by captchas and identity checks, but a password manager can fill repeated data. You solve the captcha and confirm registration.')}</div>
    <button class="btn ghost" style="padding:4px 11px;font-size:12px;margin-top:6px" onclick="showSignupKit()">
      ${ui('generate_signup_kit','📋 Generate my signup kit')}</button>
  </div>`;

  // PRESETY TEMATYCZNE — kazdy z wlasnymi polami (jak zakladki w Reporterze)
  if(presets.length){
    h+=`<div style="font-weight:600;margin:14px 0 4px">${ui('finder_topics','Topics — each needs different facts about you')}</div>
      <div class="hint">${ui('finder_topics_hint','Pick a topic, see what that kind of platform asks for, and fill it in once.')}</div>
      <div style="margin-top:6px">`;
    for(const p of presets){
      h+=`<button class="btn ghost" style="padding:4px 10px;font-size:12px;margin:0 4px 4px 0"
        onclick='showFinderTopic(${JSON.stringify(p)})'>${esc(p.label)}</button>`;
    }
    h+='</div>';
  }

  h+='<div style="margin:14px 0 6px;font-weight:600">'+ui('all_platforms','All platforms')+'</div>';
  h+=`<button class="btn ghost" style="padding:4px 10px;font-size:12px;${!cat?'background:#eff4ff':''}" onclick="showOpps()">${ui('all','All')}</button> `;
  for(const k in cats){
    h+=`<button class="btn ghost" style="padding:4px 10px;font-size:12px;${cat===k?'background:#eff4ff':''}" onclick="showOpps('${esc(k)}')">${esc(cats[k].split('(')[0])}</button> `;
  }
  if(cat && notes[cat]) h+=`<div class="hint" style="margin-top:8px">${esc(notes[cat])}</div>`;

  const badge={not_started:['⬜','var(--dim)',ui('not_started','not started')],
               applied:['📨','var(--amber)',ui('applied','applied')],
               accepted:['✅','var(--green)',ui('accepted','accepted')],
               rejected:['❌','var(--red)',ui('rejected','rejected')],
               skipped:['⏭','var(--dim)',ui('skipped','skipped')]};
  h+='<table style="width:100%;font-size:13px;margin-top:8px">';
  for(const it of items){
    const b=badge[it.status]||badge.not_started;
    h+=`<tr><td style="padding:8px 4px;border-bottom:1px solid var(--line)">
      <div style="display:flex;justify-content:space-between;align-items:baseline;gap:8px;flex-wrap:wrap">
        <div><b>${esc(it.name)}</b>
          <span class="hint" style="margin-left:6px">${esc(it.pay||'')}</span>
          <span style="color:${b[1]};font-size:11px;margin-left:6px">${b[0]} ${esc(b[2])}</span></div>
        <div>
          <a class="btn ghost" style="padding:3px 9px;font-size:11px" href="${esc(safeExternalUrl(it.url))}" target="_blank" rel="noopener noreferrer">${ui('open_external','open ↗')}</a>
          <button class="btn ghost" style="padding:3px 9px;font-size:11px"
            onclick='oppDraft(${JSON.stringify(it)})'>${ui('write_application','✍ write my application')}</button>
        </div>
      </div>
      <div class="hint" style="margin-top:2px">${esc(it.notes||'')}</div>
      <div id="opp-${esc((it.name||'').replace(/[^a-zA-Z0-9]/g,''))}" style="margin-top:4px"></div>
    </td></tr>`;
  }
  h+='</table>';
  h+='<div class="bar"><button class="btn ghost" onclick="closeModal()">'+ui('close','Close')+'</button></div>';
  openModal(h);
}

function showFinderTopic(p){
  // Preset tematyczny — wlasne pola edycji, jak zakladka w Reporterze
  const saved=JSON.parse(localStorage_get('finder_'+p.key)||'{}');
  let h=`<div style="font-weight:700;color:var(--acc);font-size:16px;margin-bottom:4px">${esc(p.label)}</div>
    <div class="hint">${esc(p.note)}</div>
    <div class="hint" style="margin-top:6px">${ui('finder_fill_once','Fill these once. Every application for this kind of platform is written from them.')}</div>`;
  for(const f of (p.fields||[])){
    h+=`<label style="margin-top:12px">${esc(f.label)}</label>
      <input id="ft-${esc(f.key)}" value="${esc(saved[f.key]||'')}" placeholder="${esc(f.example)}">
      <div class="hint">${esc(f.hint)}</div>`;
  }
  h+=`<div class="bar">
      <button class="btn" onclick='saveFinderTopic(${JSON.stringify(p)})'>${ui('save','Save')}</button>
      <button class="btn ghost" onclick="showOpps()">${ui('back_to_platforms','← Back to platforms')}</button>
      <span class="hint" id="ftstat"></span>
    </div>`;
  openModal(h);
}
// prosty magazyn w pamieci (artefakty nie maja localStorage)
const _store={};
function localStorage_get(k){ return _store[k]||null; }
function localStorage_set(k,v){ _store[k]=v; }

function saveFinderTopic(p){
  const data={};
  for(const f of (p.fields||[])){
    const el=document.getElementById('ft-'+f.key);
    if(el) data[f.key]=el.value;
  }
  localStorage_set('finder_'+p.key, JSON.stringify(data));
  const st=$('#ftstat');
  if(st) st.innerHTML='<span style="color:var(--green)">'+ui('finder_saved','✓ saved — applications for these platforms now use it')+'</span>';
}

async function showSignupKit(){
  openModal('<div class="hint">'+ui('building_signup_kit','⏳ building your signup kit…')+'</div>');
  const r=await api('/api/signupkit');
  const h=`<div style="font-weight:700;color:var(--acc);font-size:16px;margin-bottom:4px">${ui('signup_kit','📋 Signup kit')}</div>
    <div class="hint">${ui('signup_kit_hint','Import the CSV into Bitwarden. Signup forms can then be filled with one click; you only solve the captcha and confirm registration.')}</div>
    <textarea id="kit" rows="20" style="font-family:ui-monospace,monospace;font-size:11px;margin-top:8px">${esc(r.text||'')}</textarea>
    <div class="bar">
      <button class="btn" onclick="navigator.clipboard.writeText(document.getElementById('kit').value);this.textContent=ui('copied','✓ copied')">${ui('copy_all','📋 Copy all')}</button>
      <button class="btn ghost" onclick="showOpps()">${ui('back','← Back')}</button>
    </div>`;
  openModal(h);
}
async function oppDraft(it){
  const slot='opp-'+(it.name||'').replace(/[^a-zA-Z0-9]/g,'');
  const el=document.getElementById(slot); if(!el) return;
  el.innerHTML='<span class="hint">'+ui('writing_from_profile','⏳ writing it from your profile…')+'</span>';
  try{
    const r=await api('/api/opp_draft',{method:'POST',headers:{'Content-Type':'application/json'},
      body:JSON.stringify({platform:it, name:(cur&&cur.name)||''})});
    if(!r.ok){ el.innerHTML='<span class="hint" style="color:var(--red)">'+esc(r.error||'failed')+'</span>'; return; }
    el.innerHTML=`
      <textarea id="txt-${slot}" rows="8" style="font-size:12px;margin-top:4px">${esc(r.text)}</textarea>
      <div style="margin-top:4px">
        <button class="btn ghost" style="padding:3px 9px;font-size:11px"
          onclick="navigator.clipboard.writeText(document.getElementById('txt-${slot}').value);this.textContent=ui('copied','✓ copied')">${ui('copy','📋 Copy')}</button>
        <button class="btn ghost" style="padding:3px 9px;font-size:11px"
          onclick="oppStatus(${JSON.stringify(it.name)},'applied')">${ui('mark_applied','📨 Mark as applied')}</button>
        <button class="btn ghost" style="padding:3px 9px;font-size:11px"
          onclick="oppStatus(${JSON.stringify(it.name)},'skipped')">${ui('skip_this','⏭ Skip this one')}</button>
      </div>
      <div class="hint" style="margin-top:3px">${ui('application_review_hint','Read it before sending. It is built from your profile; if something is missing, update the user profile and regenerate.')}</div>`;
  }catch(e){ el.innerHTML='<span class="hint" style="color:var(--red)">'+ui('failed_with_error','Failed: {error}',{error:esc(String(e))})+'</span>'; }
}
async function oppStatus(name, state){
  try{
    await api('/api/opp_status',{method:'POST',headers:{'Content-Type':'application/json'},
      body:JSON.stringify({platform:name, state:state})});
    showOpps();
  }catch(e){}
}
async function runFullCheck(){
  // Sprawdza kazda funkcje, ktorej dotknie kupujacy — dla WYBRANEGO a-toola
  const el=$('#benchout'); if(!el) return;
  const nm=window._devAgent||(cur&&cur.name)||'';
  if(!nm){ el.innerHTML='<span class="hint">'+ui('pick_agent','Pick an A-Tool.')+'</span>'; return; }
  let P=null; try{ P=await api('/api/profile?name='+encodeURIComponent(nm)); }catch(e){}
  if(!P){ el.innerHTML='<span class="hint">'+ui('could_not_load_atool','Could not load that A-Tool.')+'</span>'; return; }
  el.innerHTML=ui('testing_atool','⏳ testing {name}…',{name:esc(nm)});
  const res=[];
  const t=async(name,fn)=>{ try{ const r=await fn(); res.push([name,true,r||'ok']); }
                            catch(e){ res.push([name,false,String(e).replace('Error: ','').slice(0,90)]); } };

  await t(ui('check_agent_file','Agent file loads'), async()=>P.name+' ('+P.kind+')');
  await t(ui('check_mailboxes','Mailboxes configured'), async()=>{ const n=((P.sources||{}).inbox||[]).length;
    if(!n) throw new Error(ui('check_no_sources','none — the tool has nothing to read')); return n; });
  await t(ui('check_ai_key','AI key'), async()=>{ const L=P.llm||{};
    if(!(L.api_key||'').trim()){
      if(L.provider==='ollama') return ui('check_local_model','local model (no key needed)');
      throw new Error(ui('check_no_ai_key','no key — AI features will do nothing')); }
    const r=await api('/api/testllm',{method:'POST',headers:{'Content-Type':'application/json'},
      body:JSON.stringify({llm:L,name:nm})});
    if(!r.ok) throw new Error((r.code==='NO_KEY'?ui('check_key_not_readable','key not readable')+': ':'')+(r.result||ui('rejected','rejected')));
    return ui('works','works')+' · '+(L.model||''); });
  await t(ui('check_last_report','Last report readable'), async()=>{
    const r=await api('/api/reportjson?name='+encodeURIComponent(nm));
    const n=(r.mailboxes||[]).length;
    if(!n) throw new Error(ui('check_no_report','no report yet — click Run once'));
    return ui('mailboxes_count','{count} mailbox(es)',{count:n}); });
  await t(ui('check_body_cache','Body cache (needed for 📄 ✍ 📋)'), async()=>{
    const r=await api('/api/reportjson?name='+encodeURIComponent(nm));
    let withMid=0, total=0;
    for(const mb of (r.mailboxes||[])) for(const row of (mb.rows||[])){ total++; if(row.mid) withMid++; }
    if(!total) throw new Error(ui('no_rows_plain','no rows'));
    if(!withMid) throw new Error(ui('check_rows_no_id','rows have no message id — summary and draft buttons will fail'));
    return ui('rows_have_id','{withId}/{total} rows have an id',{withId:withMid,total}); });
  await t(ui('check_tag_rules','Tag rules'), async()=>{ const r=await api('/api/tags?name='+encodeURIComponent(nm));
    return ui('rules_count','{custom} yours + {factory} factory',{custom:(r.custom||[]).length,factory:(r.preset_rules||[]).length}); });
  await t(ui('calendar','Calendar'), async()=>{ const r=await api('/api/calendar'); return ui('entries_count','{count} entries',{count:(r.items||[]).length}); });
  await t(ui('backups_button','Backups'), async()=>{ const r=await api('/api/backups'); return (r.items||[]).length; });
  await t(ui('check_optional_deps','Optional dependencies (tray/popup/scheduler)'), async()=>{
    const r=await api('/api/deps_status');
    if(!r||!r.missing||!r.missing.length) return ui('all_present','all present');
    return ui('missing','MISSING')+': '+r.missing.join(', ')+'  →  '+r.pip_cmd;
  });
  await t(ui('check_docs','Documentation included'), async()=>{ const r=await api('/api/docs');
    if(!(r.files||[]).length) throw new Error(ui('check_no_docs','none — the user has nothing to read'));
    return (r.files||[]).join(', '); });
  await t(ui('check_profile','User profile filled in'), async()=>{
    const r=await api('/api/context'); const txt=(r.text||'');
    const blank=[];
    if(/\(your name, role/.test(txt)) blank.push(ui('who_i_am','Who I am'));
    if(/\(name them exactly|\(list your projects/.test(txt)) blank.push(ui('active_projects','Active projects'));
    if(/\(people, partners/.test(txt)) blank.push(ui('what_i_care_about','What I care about'));
    if(/\(one line per mailbox/.test(txt)) blank.push(ui('source_purpose','Purpose of each source'));
    if(blank.length) throw new Error(ui('blank_ai_guessing','blank: {fields} — AI is guessing',{fields:blank.join(', ')}));
    return ui('filled_in','filled in'); });

  const bad=res.filter(r=>!r[1]).length;
  let h=`<div style="font-weight:600;margin-bottom:6px">${bad
    ?`<span style="color:var(--red)">${ui('problems_count','{count} problem(s)',{count:bad})}</span>`
    :'<span style="color:var(--green)">'+ui('safe_to_ship','All good — safe to ship')+'</span>'}</div>`;
  h+='<table style="width:100%;font-size:12px">';
  for(const [n,ok,r] of res){
    h+=`<tr><td style="padding:3px 5px;white-space:nowrap;vertical-align:top">${ok
      ?'<span style="color:var(--green)">✓</span>'
      :'<span style="color:var(--red)">✗</span>'} ${esc(n)}</td>
      <td style="padding:3px 5px;color:var(--dim);word-break:break-word;max-width:350px">${esc(String(r))}</td></tr>`;
  }
  h+='</table>';
  el.innerHTML=h;
}

async function showUsage(){
  enterPanel('showUsage');
  const nm=window._devAgent||(cur&&cur.name)||'';
  const r=await api('/api/usage?name='+encodeURIComponent(nm));
  if(r&&r._offline){ openModal('<div class="hint">'+ui('panel_not_responding','⚠ Panel not responding — run <code>python3 panel.py</code>')+'</div><div class="bar">'+backBtn()+'</div>'); return; }
  let h='<div style="font-weight:700;color:var(--acc);font-size:16px;margin-bottom:10px">'+ui('ai_usage_cost','📊 AI usage & cost')+'</div>';
  h+='<table style="width:100%;font-size:13px">';
  const row=(k,v,hint)=>`<tr><td style="padding:5px 6px;color:var(--dim);white-space:nowrap;vertical-align:top">${esc(k)}</td>
    <td style="padding:5px 6px"><b>${esc(String(v))}</b>${hint?`<div class="hint">${hint}</div>`:''}</td></tr>`;
  h+=row(ui('tokens_all_time','Tokens, all time'), (r.total_tokens||0).toLocaleString(), ui('tokens_all_time_hint','Everything this installation ever sent to AI.'));
  h+=row(ui('last_run','Last run'), (r.last_tokens||0).toLocaleString()+' '+ui('tokens','tokens'), ui('last_run_cost_hint','What the most recent report used.'));
  h+=row(ui('summaries_last_run','Summaries last run'), r.last_summaries||0, ui('summaries_last_run_hint','How many messages received an AI summary.'));
  h+=row(ui('tokens_per_summary','Tokens per summary'), r.per_summary?Math.round(r.per_summary):'—',
         ui('tokens_per_summary_hint','Lower is better. Long messages cost more; exclusions reduce usage.'));
  h+=row(ui('queued_next_run','Queued for next run'), r.overflow||0, ui('queued_next_run_hint','Reached the cap and waiting for the next run.'));
  h+='</table>';
  h+=`<div class="hint" style="margin-top:12px;padding:10px;background:#fef2f2;border-radius:8px">
    ${ui('groq_limit_hint','<b>Groq free tier = 8000 tokens/minute.</b> Above that limit the provider returns HTTP 429 and the run finishes with script-only summaries.<br><br>To use less: add exclusions, narrow the watchlist and choose Short summaries.<br>To use more: use a paid key or a local Ollama model.')}</div>`;
    try{
    const s=await api('/api/stats')||{};
    const hrs=Math.floor((s.minutes_saved||0)/60), mins=(s.minutes_saved||0)%60;
    h+=`<div style="font-weight:600;margin:14px 0 6px">${ui('since_installed','Since you installed it')}</div>
      <table style="width:100%;font-size:13px;border-collapse:collapse">
      <tr><td>${ui('runs','Runs')}</td><td style="text-align:right"><b>${s.runs||0}</b></td></tr>
      <tr><td>${ui('mails_handled','Mails handled')}</td><td style="text-align:right"><b>${s.mails||0}</b></td></tr>
      <tr><td>${ui('needed_attention','Needed your attention')}</td><td style="text-align:right"><b>${s.important||0}</b></td></tr>
      <tr><td>${ui('ai_summaries_written','AI summaries written')}</td><td style="text-align:right"><b>${s.summaries||0}</b></td></tr>
      <tr><td>${ui('time_saved_estimate','Time saved (estimate)')}</td><td style="text-align:right"><b>${hrs}h ${mins}m</b></td></tr>
      </table>
      <div class="hint">${ui('time_saved_hint','Estimate: 20 seconds for each message you did not need to open and 45 seconds for each summary read instead of the full message.')}</div>`;
  }catch(e){}
  h+='<div class="bar">'+backBtn()+'</div>';
  openModal(h);
}



async function toggleAutostart(){
  const btns=document.querySelectorAll('[onclick*="toggleAutostart"]');
  btns.forEach(b=>{ b.disabled=true; b.textContent=ui('setting','⏳ setting…'); });
  try{
    const r=await api('/api/autostart',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({enable:!window._autostartOn})});
    if(r&&r._offline){ btns.forEach(b=>{ b.disabled=false; b.textContent=ui('start_with_system','⚡ Start with system'); }); flash(ui('panel_offline','Panel offline')); return; }
    if(r&&r.ok){
      window._autostartOn=r.enabled;
      const label=r.enabled?ui('autostart_on','✓ Autostart ON'):ui('start_with_system','⚡ Start with system');
      btns.forEach(b=>{ b.disabled=false; b.textContent=label; });
      flash(r.enabled?ui('autostart_enabled','⚡ Autostart ON — scheduler starts after login ({where})',{where:r.where||''}):ui('autostart_off','Autostart OFF'));
    } else {
      btns.forEach(b=>{ b.disabled=false; b.textContent=ui('start_with_system','⚡ Start with system'); });
      flash(ui('autostart_failed','Autostart failed: {error}',{error:(r&&r.error)||ui('unknown_error','unknown error')}));
    }
  }catch(e){ btns.forEach(b=>{ b.disabled=false; b.textContent=ui('start_with_system','⚡ Start with system'); }); flash(ui('autostart_error','Autostart error: {error}',{error:e})); }
}

async function exportCal(kind='main'){
  const label=kind==='wake'?ui('wake_schedule','⏰ Wake schedule'):ui('main_calendar','📅 Main calendar');
  try{
    const r=await api('/api/calendar_export',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({kind})});
    if(r&&r._offline){ flash(ui('panel_offline','Panel offline')); return; }
    if(r&&r.ok) flash(ui('calendar_exported','{label} saved: {path} — open or import it in your system calendar',{label:label,path:r.path||'calendar.ics'}));
    else flash(ui('calendar_export_failed','{label} export failed: {error}',{label:label,error:(r&&r.error)||''}));
  }catch(e){ flash(ui('calendar_export_error','{label} export error: {error}',{label:label,error:e})); }
}

async function wakeTest(action){
  const name=(window._devAgent||'');
  const r=await api('/api/wake_test',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:action||'wake',name})});
  if(r&&r._offline){ flash(ui('panel_offline','Panel offline')); return; }
  if(r&&r.ok){
    if(action==='wake') flash(ui('wake_checked','Wake checked due schedules{result}',{result:r.due_started?ui('task_started',' — task started'):ui('nothing_due',' — nothing due now')}));
    else if(action==='agent') flash(ui('atool_test_started','Selected A-Tool test started: {name}',{name:r.agent_started||name}));
    else flash(ui('wake_atool_test_started','Wake + selected A-Tool test started'));
    setTimeout(showSystemPanel,500);
  }else flash(ui('test_failed','Test failed: {error}',{error:(r&&r.error)||ui('unknown_error','unknown error')}));
}

async function installDeps(){
  const st=document.getElementById('dep-install-status');
  if(st) st.textContent=ui('installing','⏳ installing…');
  const r=await api('/api/deps_install',{method:'POST',headers:{'Content-Type':'application/json'},body:'{}'});
  if(r&&r._offline){ if(st) st.textContent=ui('panel_offline_warning','⚠ panel offline'); return; }
  if(r&&r.ok&&r.installing){
    if(st) st.textContent=ui('pip_background','⏳ pip running in background…');
    let checks=0;
    const poll=setInterval(async()=>{
      checks++;
      const s=await api('/api/deps_install_status');
      if(s&&s.done){ clearInterval(poll); if(st) st.innerHTML='<span style="color:var(--green)">'+ui('installed_refresh','✓ Installed! Refresh panel to activate.')+'</span>'; }
      else if((s&&s.error)||checks>30){ clearInterval(poll); if(st) st.innerHTML='<span style="color:var(--red)">'+ui('error_check_log','Error — check log')+'</span>'; }
    },4000);
  } else if(r&&r.msg){ if(st) st.textContent='✓ '+r.msg; }
  else { if(st) st.textContent=ui('failed','⚠ failed'); }
}

async function showDocs(){
  enterPanel('showDocs');
  const r=await api('/api/docs');
  if(r&&r._offline){ openModal('<div class="hint">'+ui('panel_not_responding','⚠ Panel not responding — run <code>python3 panel.py</code>')+'</div><div class="bar">'+backBtn()+'</div>'); return; }
  let h='<div style="font-weight:700;color:var(--acc);font-size:16px;margin-bottom:10px">'+ui('guide_docs','📖 Guide & docs')+'</div>';
  const files=(r&&r.files)||[];
  if(!files.length){
    h+='<div class="hint">'+ui('no_documentation','No documentation found next to panel.py.')+'</div>';
  }else{
    h+='<div class="hint">'+ui('docs_hint','Files shipped with the tool. Click one to read it here.')+'</div><div style="margin-top:8px">';
    h+=files.map(f=>`<button class="btn ghost" style="padding:5px 11px;font-size:12px;margin:0 4px 4px 0"
      onclick='readDoc(${JSON.stringify(f)})'>📄 ${esc(f)}</button>`).join('');
    h+='</div><div id="docbody" style="margin-top:12px"></div>';
  }
  h+='<div class="bar">'+backBtn()+'</div>';
  openModal(h);
}
async function readDoc(name){
  const el=$('#docbody'); if(el) el.innerHTML='<span class="hint">'+ui('loading','⏳ loading…')+'</span>';
  try{
    const r=await api('/api/docs?file='+encodeURIComponent(name));
    if(el) el.innerHTML=`<pre style="max-height:50vh;overflow:auto;background:#f8fafc;padding:12px;
      border-radius:8px;font-size:12px;white-space:pre-wrap">${esc(r.text||ui('empty','(empty)'))}</pre>`;
  }catch(e){ if(el) el.innerHTML='<span class="hint">'+ui('could_not_read_it','Could not read it.')+'</span>'; }
}

async function showSettings(){
  enterPanel('showSettings');
  // USTAWIENIA GLOBALNE — dotycza UI i WSZYSTKICH a-tooli, nie jednego.
  // Wczesniej nie bylo ich nigdzie: kazde ustawienie siedzialo w profilu agenta.
  const g = window._globalSettings || {};
  let h=`<div style="font-weight:700;color:var(--acc);font-size:16px;margin-bottom:4px">⚙ ${ui('global_settings','Global settings')}</div>
    <div class="hint">${ui('global_settings_hint','These affect the panel and every a-tool. Per-a-tool settings stay in that a-tool\'s tabs.')}</div>

    <div style="font-weight:600;margin:14px 0 6px">${ui('interface','Interface')}</div>
    <label class="chk ${g.expand_default?'on':''}" id="g-expand" onclick="this.classList.toggle('on')"><span></span> ${ui('expand_default','Open every section expanded by default')}</label>
    <div class="hint">${ui('expand_default_hint','Off = advanced sections start collapsed (less overwhelming). On = everything visible immediately.')}</div>

    <label class="chk ${g.hints_default?'on':''}" id="g-hints" onclick="this.classList.toggle('on')" style="margin-top:8px"><span></span> ${ui('show_hints_default','Show hints by default')}</label>
    <div class="hint">${ui('show_hints_default_hint','Starts the panel with 💡 Tips on, instead of off.')}</div>

    <label class="chk ${g.compact?'on':''}" id="g-compact" onclick="this.classList.toggle('on')" style="margin-top:8px"><span></span> ${ui('compact_report','Compact report (denser rows)')}</label>
    <div class="hint">${ui('compact_report_hint','Tighter line spacing in the report — fits more on screen.')}</div>

    <label style="margin-top:12px">${ui('panel_language','Panel language')}</label>
    <select id="g-lang">
      ${(window.UILANGS||['en']).map(l=>`<option value="${esc(l)}" ${(g.lang||'en')===l?'selected':''}>${esc(languageName(l))}</option>`).join('')}
    </select>
    <div class="hint">${ui('panel_language_hint','Interface, hints and help text. Changing it translates the panel after saving; it does not overwrite each A-Tool\'s report language.')}</div>

    <label class="chk ${(g.lang_mode==='force')?'on':''}" id="g-one-language" onclick="this.classList.toggle('on')" style="margin-top:12px"><span></span> ${ui('one_language_everywhere','One language everywhere')}</label>
    <div class="hint">${ui('one_language_hint','Default for A-Tools that do not override it: On = generated AI text uses the A-Tool/report language; Off = generated AI text follows each message. Each reporter can override this in Outputs.')}</div>

    <div style="font-weight:600;margin:16px 0 6px">${ui('shared_by_every_atool','Shared by every A-Tool')}</div>
    <div class="hint">${ui('shared_settings_hint','These live outside any single agent — all your tools read them.')}</div>
    <div style="margin-top:8px">
      <button class="btn ghost" style="padding:5px 11px;font-size:12px" id="st-profile">${ui('my_profile_who','👤 My profile (who you are)')}</button>
      <button class="btn ghost" style="padding:5px 11px;font-size:12px" onclick="showRules()">${ui('rules_button','⚖ Rules')}</button>
      <button class="btn ghost" style="padding:5px 11px;font-size:12px" onclick="showTagEditor('tags')">${ui('tags_rules_button','🏷 Tags & tag rules')}</button>
      <button class="btn ghost" style="padding:5px 11px;font-size:12px" onclick="showCalendar()">${ui('shared_calendar','📅 Shared calendar')}</button>
    </div>

    <div class="bar">
      <button class="btn" onclick="saveSettings()">${ui('save','Save')}</button>
      ${backBtn()}
      <span class="hint" id="gstat"></span>
      <button class="btn ghost" onclick="closeModal()">${ui('close','✕ Close')}</button>
    </div>`;
  openModal(h);
}
async function saveSettings(){
  const patch = {
    expand_default: $('#g-expand').classList.contains('on'),
    hints_default:  $('#g-hints').classList.contains('on'),
    compact:        $('#g-compact').classList.contains('on'),
    lang:           ($('#g-lang')||{}).value || 'en',
    lang_mode:      ($('#g-one-language')&&$('#g-one-language').classList.contains('on'))?'force':'adapt',
  };
  window._globalSettings = Object.assign({},window._globalSettings||{},patch);
  const st=$('#gstat');
  try{
    await api('/api/settings',{method:'POST',headers:{'Content-Type':'application/json'},
      body:JSON.stringify(patch)});
    if(st) st.innerHTML='<span style="color:var(--green)">'+ui('saved','✓ saved')+'</span>';
  }catch(e){ if(st) st.innerHTML='<span style="color:var(--red)">'+ui('save_failed','save failed')+'</span>'; }
  // zastosuj od razu
  document.body.classList.toggle('compact', !!window._globalSettings.compact);
  if(window._globalSettings.hints_default && hintMode===0) cycleHints();
  if(window._globalSettings.expand_default) toggleAllAdvanced();
  // przeladuj hinty w wybranym jezyku
  HINTS=null; if(hintMode) applyHints();
  await loadUiText();
  // Dynamic fields are generated by render(), therefore refresh the active
  // a-tool too.  This does not save or alter its configuration.
  if(cur) render();
}
async function showRawLog(){
  // DWA logi: zwykly (co sie stalo) i debug (PELNY slad — kazdy krok, kazdy blad).
  // Debug jest tym, czego brakowalo: bledy w tle ginely bezpowrotnie.
  const el=$('#benchout'); if(!el) return;
  const nm=window._devAgent||(cur&&cur.name)||'';
  if(!nm){ el.innerHTML='<span class="hint">'+ui('pick_agent','Pick an A-Tool.')+'</span>'; return; }
  el.innerHTML=ui('reading','⏳ reading…');
  try{
    const [r,d]=await Promise.all([
      api('/api/log?name='+encodeURIComponent(nm)),
      api('/api/debug?name='+encodeURIComponent(nm)).catch(()=>({text:'(no debug log)'}))
    ]);
    el.innerHTML=`
      <div class="bar" style="margin:0 0 6px">
        <button class="btn ghost" style="padding:3px 10px;font-size:11px" onclick="showLogTab('plain')">${ui('activity','📋 Activity')}</button>
        <button class="btn ghost" style="padding:3px 10px;font-size:11px" onclick="showLogTab('debug')">${ui('debug_trace','🔬 Debug trace')}</button>
        <span class="hint">${ui('debug_trace_hint','Debug shows every step of the last run — paste it to me when something breaks.')}</span>
      </div>
      <pre id="log-plain" style="max-height:40vh;overflow:auto;background:#0f172a;color:#e2e8f0;
        padding:10px;border-radius:8px;font-size:11px;white-space:pre-wrap">${esc(r.text||'(empty)')}</pre>
      <pre id="log-debug" hidden style="max-height:40vh;overflow:auto;background:#0f172a;color:#a5f3fc;
        padding:10px;border-radius:8px;font-size:11px;white-space:pre-wrap">${esc(d.text||'(no debug log yet — run once)')}</pre>
      <div class="bar">
        <button class="btn ghost" style="padding:3px 10px;font-size:11px"
          onclick="copyLog()">${ui('copy_visible_log','📋 Copy visible log')}</button>
      </div>`;
  }catch(e){ el.innerHTML='<span class="hint">'+ui('could_not_read_log','Could not read the log.')+'</span>'; }
}
function showLogTab(which){
  const p=document.getElementById('log-plain'), d=document.getElementById('log-debug');
  if(p) p.hidden = (which!=='plain');
  if(d) d.hidden = (which!=='debug');
}
function copyLog(){
  const p=document.getElementById('log-plain'), d=document.getElementById('log-debug');
  const vis = (p && !p.hidden) ? p : d;
  if(vis) navigator.clipboard.writeText(vis.textContent||'');
}

async function testNotify(kind){
  const st=$('#ntstat'); if(st) st.textContent=ui('sending','⏳ sending…');
  try{
    const r=await api('/api/testnotify',{method:'POST',headers:{'Content-Type':'application/json'},
      body:JSON.stringify({kind:kind, name:(cur&&cur.name)||''})});
    if(st) st.innerHTML = r.ok
      ? '<span style="color:var(--green)">✓ '+esc(r.msg||ui('sent','sent'))+'</span>'
      : '<div style="color:var(--red);white-space:pre-wrap;margin-top:4px;padding:8px;background:#fef2f2;border-radius:6px;font-size:12px">'+esc(r.msg||ui('failed_plain','failed'))+'</div>';
  }catch(e){ if(st) st.textContent=ui('failed_with_error','failed: {error}',{error:e}); }
}
async function showBackups(){
  enterPanel('showBackups');
  const r=await api('/api/backups');
  if(r&&r._offline){ openModal('<div class="hint">'+ui('panel_not_responding','⚠ Panel not responding — run <code>python3 panel.py</code>')+'</div><div class="bar">'+backBtn()+'</div>'); return; }
  const b=(r&&r.items)||[];
  const pol=(r&&r.policy)||{};
  let h='<div style="font-weight:700;color:var(--acc);font-size:16px;margin-bottom:10px">'+ui('backups_title','↩ Backups')+'</div>';
  h+='<div class="hint">'+ui('backups_intro','Every time AI changes your profile or you reset tags, the old version is saved here. Click Restore to go back.')+'</div>';
  // ZAJETOSC + REGULA — user musi widziec, ile to zajmuje i co sie dzieje ze starymi.
  h+=`<div class="hint" style="margin-top:8px;padding:8px;background:var(--bg2,#f8fafc);border-radius:8px">
    ${ui('backup_disk_status','<b>{count}</b> backup(s) · <b>{kb} KB</b> on disk',{count:r.total||0,kb:r.total_kb||0})}`
    +((r.total||0)>(r.shown||0)?` · ${ui('showing_newest','showing newest {count}',{count:r.shown})}`:'')
    +`<br>${ui('backup_policy','<b>Nothing is ever deleted automatically.</b> Backups only grow until you press <b>Clean up now</b> — and even then you first get a list of what would go, and can cancel. Suggested policy when you do run it: keep the newest <b>{plain}</b> uncompressed, gzip the older ones, drop anything past <b>{total}</b> files or <b>{days}</b> days. The newest backup is never deleted.',{plain:pol.keep_plain||10,total:pol.keep_total||60,days:pol.max_age_days||90})}</div>`;
  if(!b.length){ h+='<div class="hint" style="margin-top:10px">'+ui('no_backups','No backups yet.')+'</div>'; }
  else{
    h+='<table style="width:100%;font-size:13px;margin-top:10px">';
    for(const f of b){
      h+=`<tr><td style="padding:4px 6px">${esc(f.name)}${f.gz?' <span class="hint">(gz)</span>':''}</td>
        <td style="padding:4px 6px;color:var(--dim)">${esc(f.when)}</td>
        <td style="padding:4px 6px;color:var(--dim)">${f.kb||0} KB</td>
        <td style="padding:4px 6px"><button class="btn ghost" style="padding:2px 9px;font-size:12px"
          onclick='askRestore(${JSON.stringify(f.id||f.name)}, ${JSON.stringify(f.name)})'>${ui('restore','Restore')}</button></td></tr>`;
    }
    h+='</table>';
  }
  h+='<div class="bar"><button class="btn ghost" onclick="pruneBackups()">'+ui('clean_up_now','🧹 Clean up now')+'</button>'
    +backBtn()
    +'<span class="hint" id="bkstat"></span></div>';
  openModal(h);
}

async function pruneBackups(){
  // KROK 1: tylko PODGLAD. Nic nie jest kasowane, dopoki user nie potwierdzi.
  const st=$('#bkstat'); if(st) st.textContent=ui('checking','Checking…');
  let r;
  try{ r=await api('/api/backups_prune'); }
  catch(e){ if(st) st.innerHTML='<span style="color:var(--red)">'+ui('check_failed','Check failed.')+'</span>'; return; }
  const del=r.to_delete||[], comp=r.to_compress||[];
  if(st) st.textContent='';

  if(!del.length && !comp.length){
    if(st) st.innerHTML='<span style="color:var(--green)">'+ui('nothing_to_clean','Nothing to clean — backups are already tidy.')+'</span>';
    return;
  }

  // Jesli nie ma nic do skasowania, sama kompresja jest bezpieczna (dane zostaja).
  if(!del.length){
    if(st) st.textContent=ui('compressing','Compressing…');
    try{
      const d=await api('/api/backups_prune?compress_only=1',{method:'POST',headers:{'Content-Type':'application/json'},body:'{}'});
      if(st) st.innerHTML=`<span style="color:var(--green)">${ui('compressed_nothing_deleted','compressed {count}, freed ~{kb} KB — nothing deleted',{count:d.compressed||0,kb:d.freed_kb||0})}</span>`;
      setTimeout(showBackups, 900);
    }catch(e){ if(st) st.innerHTML='<span style="color:var(--red)">'+ui('compression_failed','Compression failed.')+'</span>'; }
    return;
  }

  // KROK 2: sa pliki DO SKASOWANIA — pokaz je i ostrzez przed zamknieciem okna.
  let list='<ul style="margin:8px 0 0 18px;padding:0;font-size:12.5px;max-height:180px;overflow:auto">';
  for(const f of del.slice(0,40)){
    list+=`<li>${esc(f.name)} <span style="color:var(--dim)">— ${f.kb||0} KB · ${esc(f.why||'')}</span></li>`;
  }
  if(del.length>40) list+=`<li style="color:var(--dim)">${ui('and_more','…and {count} more',{count:del.length-40})}</li>`;
  list+='</ul>';

  confirmDanger({
    title: ui('backups_delete_title','These backups will be permanently deleted'),
    body: ui('backups_delete_body','<b>{count} backup file(s)</b> will be <b>deleted for good</b>',{count:del.length})
      + (comp.length?ui('backups_compress_more',' and {count} more will be compressed (compression keeps the data).',{count:comp.length}):'.')
      + list,
    warn: ui('backups_delete_warn','If any of these could still be useful, copy them out FIRST — close this window, open your backups folder and save what you need. Once you press the button below they are gone. Your newest backup is never deleted.'),
    okLabel: ui('delete_and_clean','Delete {count} and clean up',{count:del.length}),
    onOk: async ()=>{
      try{
        const d=await api('/api/backups_prune',{method:'POST',headers:{'Content-Type':'application/json'},body:'{}'});
        showBackups();
        setTimeout(()=>{ const s2=$('#bkstat');
          if(s2) s2.innerHTML=`<span style="color:var(--green)">${ui('cleanup_result','compressed {compressed}, deleted {deleted}, freed ~{kb} KB',{compressed:d.compressed||0,deleted:d.deleted||0,kb:d.freed_kb||0})}</span>`;
        }, 300);
      }catch(e){ flash(ui('cleanup_failed','Cleanup failed.')); }
    }
  });
}
function askRestore(id, name){
  confirmDanger({
    title: ui('restore_backup_title','Restore this backup?'),
    body: ui('restore_backup_body','This replaces your current version with the one from <b>{name}</b>.',{name:esc(name||'')}),
    warn: ui('restore_backup_warn','Your current version is saved as a new backup first — so you can undo this.'),
    okLabel: ui('restore_it','Restore it'),
    onOk: ()=>restoreBackup(id),
  });
}
async function restoreBackup(id){
  // drugi klik juz byl (danger()) — twoja obecna wersja jest zapisywana przed nadpisaniem
  try{
    const r=await api('/api/restore',{method:'POST',headers:{'Content-Type':'application/json'},
      body:JSON.stringify({id:id})});
    alert(r.ok?ui('restored_reload','Restored. Reload the agent to see it.'):ui('restore_failed_error','Restore failed: {error}',{error:r.error||''}));
    if(r.ok && cur && cur.name){ cur=await api('/api/profile?name='+encodeURIComponent(cur.name)); render(); }
    closeModal();
  }catch(e){ alert(ui('restore_failed','Restore failed')); }
}
function calMonth(d){
  window._calOffset = (d===0) ? 0 : (window._calOffset||0)+d;
  showCalendar('grid');
}
async function addCalEvent(){
  const title=prompt(ui('event_title_prompt','Event title (what is it?)')); if(!title) return;
  const when=prompt(ui('event_date_prompt','Date — DD.MM.YYYY (e.g. 25.12.2026)')); if(!when) return;
  if(!/^\d{1,2}\.\d{1,2}\.\d{4}$/.test(when.trim())){ alert(ui('use_date_format','Use DD.MM.YYYY')); return; }
  try{
    const r=await api('/api/calendar_add',{method:'POST',headers:{'Content-Type':'application/json'},
      body:JSON.stringify({title:title.trim(),when:when.trim(),agent:'manual'})});
    if(r&&r.ok===false){ alert(ui('could_not_add','Could not add: {error}',{error:r.error||ui('unknown','unknown')})); return; }
    showCalendar(window._calView||'list');
  }catch(e){ alert(ui('could_not_add_event','Could not add the event')); }
}
async function showCalendar(view){
  enterPanel('showCalendar');
  window._calView = view || window._calView || 'list';
  openModal('<div class="hint">'+ui('loading_calendar','⏳ loading calendar…')+'</div>');
  try{
    const r=await api('/api/calendar');
    const items=(r.items||[]).slice();
    const today=new Date(); today.setHours(0,0,0,0);
    const parse=(w)=>{ const m=(w||'').match(/(\d{1,2})\.(\d{1,2})\.?(\d{4})?/); if(!m) return null;
      const yy=m[3]||today.getFullYear(); return new Date(yy, +m[2]-1, +m[1]); };
    items.forEach(c=>{ const d=parse(c.when);
      c._days = d? Math.round((d-today)/864e5) : null; c._d=d; });

    let h='<div style="font-weight:700;color:var(--acc);font-size:16px;margin-bottom:4px">'+ui('shared_calendar','📅 Shared calendar')+'</div>';
    h+='<div class="hint">'+ui('shared_calendar_hint','Deadlines from your mail land here. All A-Tools share this one calendar.')+'</div>';
    h+=`<div style="margin:10px 0;display:flex;gap:6px;align-items:center;flex-wrap:wrap">
      <button class="btn ghost" style="padding:4px 10px;font-size:12px;${window._calView==='list'?'background:#eff4ff':''}" onclick="showCalendar('list')">${ui('list_view','≣ List')}</button>
      <button class="btn ghost" style="padding:4px 10px;font-size:12px;${window._calView==='grid'?'background:#eff4ff':''}" onclick="showCalendar('grid')">${ui('month_view','▦ Month')}</button>
      <button class="btn ghost" style="padding:4px 10px;font-size:12px;${window._calView==='sched'?'background:#eff4ff':''}" onclick="showCalendar('sched')">${ui('wake_scheduler','⏰ Wake / Scheduler')}</button>
      <span style="flex:1"></span>
      <button class="btn" style="padding:4px 10px;font-size:12px" onclick="addCalEvent()">${ui('add_event','＋ Add event')}</button>
    </div>`;
    if(window._calView==='grid'){
      h+=`<div style="margin:6px 0;display:flex;gap:6px;align-items:center">
        <button class="btn ghost" style="padding:3px 9px;font-size:12px" onclick="calMonth(-1)">${ui('previous','‹ Prev')}</button>
        <button class="btn ghost" style="padding:3px 9px;font-size:12px" onclick="calMonth(0)">${ui('today','Today')}</button>
        <button class="btn ghost" style="padding:3px 9px;font-size:12px" onclick="calMonth(1)">${ui('next','Next ›')}</button>
      </div>`;
    }

    if(window._calView==='grid'){
      // MACIERZ: siatka miesiaca — jeden rzut oka na to, co nadchodzi
      const _off = window._calOffset || 0;
      const base=new Date(today.getFullYear(), today.getMonth()+_off, 1);
      const byDay={};
      items.forEach(c=>{ if(!c._d) return;
        const k=c._d.toISOString().slice(0,10); (byDay[k]=byDay[k]||[]).push(c); });
      for(let mo=0; mo<2; mo++){   // ten miesiac + nastepny
        const first=new Date(base.getFullYear(), base.getMonth()+mo, 1);
        const last=new Date(first.getFullYear(), first.getMonth()+1, 0).getDate();
        let lead=(first.getDay()+6)%7;   // pon=0
        h+=`<div style="font-weight:600;margin:14px 0 6px">${first.toLocaleString(document.documentElement.lang||'en',{month:'long',year:'numeric'})}</div>`;
        h+='<table style="width:100%;table-layout:fixed;border-collapse:collapse;font-size:11px">';
        h+='<tr>'+ui('weekdays_short','Mon,Tue,Wed,Thu,Fri,Sat,Sun').split(',').map(d=>
          `<th style="padding:3px;color:var(--dim);font-weight:600">${d}</th>`).join('')+'</tr><tr>';
        for(let i=0;i<lead;i++) h+='<td></td>';
        for(let day=1; day<=last; day++){
          if((lead+day-1)%7===0 && day>1) h+='</tr><tr>';
          const dt=new Date(first.getFullYear(), first.getMonth(), day);
          const key=dt.toISOString().slice(0,10);
          const evs=byDay[key]||[];
          const isToday=dt.getTime()===today.getTime();
          const past=dt<today;
          let bg='transparent', bd='1px solid var(--line)';
          if(evs.length){ bg = past?'#f1f5f9' : (dt-today<=864e5*2 ? '#fee2e2' : '#fef3c7'); }
          if(isToday){ bd='2px solid var(--acc)'; }
          h+=`<td style="border:${bd};background:${bg};height:52px;vertical-align:top;padding:3px;
              ${evs.length?'cursor:pointer':''}" ${evs.length?`title="${esc(evs.map(e=>e.title).join(' · '))}"`:''}>
              <div style="font-weight:${isToday?'700':'400'};color:${past?'var(--dim)':'var(--txt)'}">${day}</div>
              ${evs.slice(0,2).map(e=>`<div style="font-size:9px;line-height:1.25;overflow:hidden;
                 text-overflow:ellipsis;white-space:nowrap;color:var(--txt)">${esc((e.title||'').slice(0,18))}</div>`).join('')}
              ${evs.length>2?`<div style="font-size:9px;color:var(--dim)">+${evs.length-2}</div>`:''}
            </td>`;
        }
        h+='</tr></table>';
      }
      h+='<div class="hint" style="margin-top:8px">'+ui('calendar_legend','🔴 within 2 days · 🟡 upcoming · ⬜ past. Hover over a day to see what is on it.')+'</div>';
    } else if(window._calView==='sched'){
      // WIDOK SCHEDULERA: kiedy jaki a-tool sie odpali + status + debug log.
      h+='<div style="display:flex;align-items:center;gap:8px;margin-bottom:8px">'+
         '<span class="hint" style="margin:0">'+ui('schedule_view_hint','When each A-Tool will run. Data comes from ecosystem.json and the debug log.')+'</span>'+
         `<span class="hint" style="margin:0;color:var(--dim)">· ${ui('refreshed_time','refreshed {time}',{time:esc(new Date().toLocaleTimeString())})}</span>`+
         '<button class="btn ghost" style="padding:3px 10px;font-size:12px" onclick="showCalendar()">'+ui('refresh','🔄 Refresh')+'</button></div>';
      let ss={};
      try{ ss=await api('/api/schedule_status'); }catch(e){ ss={error:String(e)}; }
      const planned=ss.planned||[];
      if(ss.next_popup && ss.next_popup.at){
        h+=`<div style="background:#f5f3ff;border-left:3px solid #8b5cf6;padding:6px 10px;margin:4px 0;border-radius:6px;font-size:12px">
          ${ui('next_popup','🔔 Next popup (one for all A-Tools, newest wins):')} <b>${esc(ss.next_popup.at)}</b></div>`;
      }
      const _wkcal=((ss.wake||{}).calendar||{}), _wkcaln=_wkcal.next||null;
      if(_wkcaln){ h+=`<div style="background:#f8fafc;border-left:3px solid #64748b;padding:6px 10px;margin:4px 0;border-radius:6px;font-size:12px">${ui('wake_calendar_next','📅 Wake watches the main calendar too · next:')} <b>${esc(_wkcaln.at||'')}</b> — ${esc(_wkcaln.title||'')}</div>`; }
      h+='<div style="font-weight:600;margin:10px 0 4px">'+ui('scheduled_atools','🗓 Scheduled A-Tools')+'</div>';
      if(planned.length){
        h+='<table style="width:100%;border-collapse:collapse;font-size:12px">';
        h+='<tr style="text-align:left;color:var(--dim)"><th style="padding:4px">'+ui('tool','Tool')+'</th><th>'+ui('version','Version')+'</th><th>'+ui('wake_hours','Wake hours')+'</th><th>'+ui('mail_own_rss','Mail / own RSS')+'</th><th>'+ui('status','Status')+'</th></tr>';
        planned.forEach(p=>{ h+=`<tr style="border-top:1px solid var(--line)">
          <td style="padding:4px"><b>${esc(p.tool||'?')}</b></td>
          <td style="color:var(--dim)">${esc(p.version||'—')}</td>
          <td>${p.scheduled?esc(Array.isArray(p.runs)?p.runs.join(', '):String(p.runs||'-')):'<span style="color:var(--dim)">—</span>'}</td>
          <td><span class="hint">${ui('mail','mail')} ${esc(((p.mail_runs)||[]).join(', ')||'—')}<br>RSS ${esc(((p.feed_runs)||[]).join(', ')||'—')}</span></td>
          <td>${p.scheduled?('<span style="color:var(--acc)">'+ui('published','✓ published')+'</span>'+(p.once_date?('<br><span class="hint">'+ui('once','once')+' '+esc(p.once_date)+' '+esc(p.once_time||'08:00')+'</span>'):'')):'<span style="color:var(--dim)">'+ui('manual_only','manual only')+'</span>'}</td></tr>`; });
        h+='</table>';
      } else if(ss.seen_atools){
        h+=`<div class="hint">${ui('no_published_schedules','I can see {count} A-Tool(s) in the ecosystem, but none published a schedule. Enable “scheduled” in that A-Tool and run it once.',{count:ss.seen_atools})}</div>`;
      } else { h+='<div class="hint">'+ui('no_scheduled_atools','No A-Tools in ecosystem.json. Run an agent with “scheduled” enabled.')+'</div>'; }
      const jobs=ss.jobs||[];
      h+='<div style="font-weight:600;margin:14px 0 4px">'+ui('active_jobs','⚙ Active jobs (APScheduler)')+'</div>';
      if(jobs.length){ h+='<ul style="margin:0;padding-left:18px;font-size:12px">';
        jobs.forEach(j=>{ h+=`<li>${esc(j.id||'?')} — ${ui('next_job','next')}: ${esc(j.next||'?')}</li>`; }); h+='</ul>';
      } else { h+='<div class="hint">'+ui('no_apscheduler_jobs','No in-process APScheduler jobs. Wake can still execute published schedules independently.')+'</div>'; }
      const dbg=ss.debug||[];
      h+='<div style="font-weight:600;margin:14px 0 4px">'+ui('scheduler_debug_log','🐞 Scheduler debug log')+'</div>';
      if(dbg.length){ h+=`<pre style="background:#0f172a;color:#e2e8f0;padding:10px;border-radius:8px;font-size:11px;max-height:220px;overflow:auto;white-space:pre-wrap">${esc(dbg.join('\n'))}</pre>`;
      } else { h+='<div class="hint">'+ui('scheduler_log_empty','The log is empty — run an agent or enable scheduling, then refresh.')+'</div>'; }
      const pt=ss.paths||{};
      h+=`<details style="margin-top:10px"><summary style="cursor:pointer;font-size:11px;color:var(--dim)">${ui('diagnostic_sources','Where this data comes from (diagnostics)')}</summary>
        <div class="hint" style="font-size:11px;margin-top:4px">
          eco_dir: <code>${esc(pt.eco_dir||'?')}</code><br>
          ecosystem.json: <code>${esc(pt.ecosystem||'?')}</code> ${pt.eco_exists?ui('exists','✓ exists'):ui('does_not_exist','✗ (does not exist)')}<br>
          ${ui('atools_in_file','A-Tools in file')}: <b>${esc(String(ss.seen_atools??'?'))}</b><br>
          debug log: <code>${esc(pt.debug_log||'?')}</code><br>
          ${ss.jobs_error?('jobs_error: '+esc(ss.jobs_error)+'<br>'):''}
          ${ss.planned_error?('planned_error: '+esc(ss.planned_error)+'<br>'):''}
          <div style="margin-top:6px;color:var(--dim)">${ui('old_panel_warning','If the values above are empty or “?”, the panel is serving an old version — hard reload (Ctrl+Shift+R) or restart the panel.')}</div>
        </div></details>`;
      if(ss.error){ h+=`<div class="hint" style="color:var(--red)">${ui('error_with_value','Error: {error}',{error:esc(ss.error)})}</div>`; }
    } else {
      // LISTA: posortowana po pilnosci, z licznikiem dni
      items.sort((a,b)=>(a._days==null?9999:a._days)-(b._days==null?9999:b._days));
      if(!items.length){
        h+='<div class="hint" style="margin-top:14px;padding:14px;background:#f8fafc;border-radius:8px">'+ui('calendar_empty','Nothing yet. Deadlines appear after a Run when auto-add is enabled, or add them with the 🔔 button in a report.')+'</div>';
      }else{
        h+='<table style="width:100%;font-size:13px;margin-top:6px">';
        for(const c of items){
          const days=c._days;
          let badge='', col='var(--dim)';
          if(days!==null){
            if(days<0){ badge=ui('days_ago','{count}d ago',{count:-days}); }
            else if(days===0){ badge=ui('today_upper','TODAY'); col='var(--red)'; }
            else if(days===1){ badge=ui('tomorrow','tomorrow'); col='var(--red)'; }
            else if(days<=7){ badge=ui('in_days','in {count} days',{count:days}); col='var(--amber)'; }
            else { badge=ui('in_days','in {count} days',{count:days}); }
          }
          const ico={deadline:'⏰',note:'📝',event:'📅',task:'✅'}[c.kind]||'•';
          h+=`<tr>
            <td style="padding:6px;white-space:nowrap;border-bottom:1px solid var(--line)">
              ${ico} <b>${esc(c.when||'—')}</b>${c.time?' '+esc(c.time):''}
              ${badge?`<div style="font-size:11px;color:${col};font-weight:600">${esc(badge)}</div>`:''}</td>
            <td style="padding:6px;border-bottom:1px solid var(--line)">${esc(c.title||'')}
              <div class="hint">${esc(c.agent||'')}${c.note?' · '+esc(c.note):''}</div></td>
          </tr>`;
        }
        h+='</table>';
      }
    }
    h+='<div class="bar"><button class="btn ghost" onclick="closeModal()">'+ui('close','Close')+'</button>'+
       '<button class="btn ghost" onclick="askClearCalendar()">'+ui('clear_all','🗑 Clear all')+'</button></div>';
    openModal(h);
  }catch(e){ openModal('<div class="hint" style="color:var(--red)">'+ui('calendar_unavailable','Calendar unavailable: {error}',{error:esc(String(e))})+'</div>'); }
}
function askClearCalendar(){
  confirmDanger({
    title: ui('clear_calendar_title','Remove every calendar entry?'),
    body: ui('clear_calendar_body','All deadlines and reminders will be deleted.'),
    warn: ui('clear_calendar_warn','Real deadlines come back on the next Run. Reminders you added by hand (🔔) do NOT come back.'),
    okLabel: ui('delete_them_all','Delete them all'),
    onOk: clearCalendar,
  });
}
async function clearCalendar(){
  try{
    await api('/api/calendar_clear',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({})});
    showCalendar();
  }catch(e){ alert(ui('could_not_clear','Could not clear')); }
}
async function showResult(name){
  const r=await api('/api/result?name='+encodeURIComponent(name)); $('#resp').style.display='block';
  $('#logp').style.display='none';   // nie pokazuj raportu dwa razy (log juz go zawiera)
  if(r.type!=='report'){ return showCollectorResult(r); }
  window._rname=name; window._rtext=r.text||'(empty)';
  await showTable(name);
}
function pdot(p){const c={'P1!':'#dc2626',P1:'#ef4444',P2:'#d97706',P3:'#0891b2',P4:'var(--dim)',P5:'var(--dim)'}[p]||'var(--dim)';
  return `<span class="pval" data-p="${p}" style="color:${c};font-weight:700;cursor:pointer">${p}</span>`;}
// JEDNO menu akcji dla WSZYSTKICH maili (zwykle i ukryte) — jeden kod, dwa miejsca.
// Wczesniej ukryte mialy okrojone menu bez „fix tag"/„promo", wiec nie dalo sie
// poprawic zle sklasyfikowanego ukrytego maila. Teraz maja pelne menu.
function rowActionsHTML(r, slot, src, mlink){
  const mid=JSON.stringify(r.mid||''), s=JSON.stringify(src||''), sl='"'+slot+'"';
  const from=JSON.stringify(r.from||''), ruleFrom=JSON.stringify(r.addr||r.from||''), sum=JSON.stringify(r.summary||''), dl=JSON.stringify(r.deadline||'');
  return `<button class="btn ghost" style="padding:3px 8px;font-size:12px" title="${esc(ui('show_full_text','Show full text'))}" onclick='mailAction("full",${mid},${s},${sl})'>📋</button> `+
    `<button class="btn ghost" style="padding:3px 8px;font-size:12px" title="${esc(ui('summarize_on_demand','Summarize on demand'))}" onclick='mailAction("summary",${mid},${s},${sl})'>📄</button> `+
    `<button class="btn ghost" style="padding:3px 8px;font-size:12px" title="${esc(ui('draft_reply','Draft a reply'))}" onclick='mailAction("draft",${mid},${s},${sl})'>✍</button> `+
    `<button class="btn ghost" style="padding:3px 8px;font-size:12px" title="${esc(ui('add_to_calendar','Add to calendar'))}" onclick='addNote(${from},${sum},${dl})'>🔔</button> `+
    (mlink?`<a class="btn ghost" style="padding:3px 8px;font-size:12px" title="${esc(ui('open_webmail','Open in webmail'))}" href="${mlink}" target="_blank">🔗</a> `:'')+
    `<details style="display:inline-block;position:relative"><summary style="cursor:pointer;list-style:none;padding:3px 8px;font-size:12px;color:var(--dim);border:1px solid var(--line);border-radius:6px">⋯</summary>`+
    `<div style="position:absolute;right:0;z-index:5;background:var(--card,#fff);border:1px solid var(--line);border-radius:8px;padding:4px;white-space:nowrap;box-shadow:0 6px 18px #0002">`+
    (window._devMode?
      `<button class="btn ghost" style="padding:4px 10px;font-size:12px;display:block;width:100%;text-align:left" title="${esc(ui('why_priority','Why this priority & tags?'))}" onclick='mailAction("explain",${mid},${s},${sl})'>${ui('why_priority_button','🧠 Why priority & tags')}</button>`+
      `<button class="btn ghost" style="padding:4px 10px;font-size:12px;display:block;width:100%;text-align:left" title="${esc(ui('recheck_hint','Ask the AI about this one message: priority and tags. Nothing is changed automatically.'))}" onclick='mailAction("recheck",${mid},${s},${sl})'>${ui('recheck_button','🤖 Re-check with AI')}</button>`+
      `<div style="border-top:1px solid var(--line);margin:3px 0"></div>`
      :'')+
    `<button class="btn ghost" style="padding:4px 10px;font-size:12px;display:block;width:100%;text-align:left" title="${esc(ui('always_sum_hint','Always write a summary for this sender, whatever its priority'))}" onclick='summaryRule(${ruleFrom},true)'>${ui('always_sum','📄 Always summarize this sender')}</button>`+
    `<button class="btn ghost" style="padding:4px 10px;font-size:12px;display:block;width:100%;text-align:left" title="${esc(ui('never_sum_hint','Never spend a summary on this sender'))}" onclick='summaryRule(${ruleFrom},false)'>${ui('never_sum','🚫 Never summarize this sender')}</button>`+
    `<button class="btn ghost" style="padding:4px 10px;font-size:12px;display:block;width:100%;text-align:left" title="${esc(ui('hide_sender_hint','Hide this sender (P5 + promo)'))}" onclick='markHideAlways(${ruleFrom})'>${ui('hide_always','👁‍🗨 Hide always')}</button>`+
    `<button class="btn ghost" style="padding:4px 10px;font-size:12px;display:block;width:100%;text-align:left" title="${esc(ui('unhide_sender_hint','Remove hide/promo rules for this sender'))}" onclick='unhideSender(${ruleFrom})'>${ui('unhide','👁 Unhide')}</button>`+
    `</div></details>`;
}
function _tagDisplayRank(tag){
  const t=String(tag||'').toLowerCase();
  if(/^(‼|⚠|💸|🧾|✅|📊|📦|❓|⏰|📅|⚖|🚓|🏛)/.test(tag||'')) return 5;
  if((tag||'').startsWith('⭐')) return 10;
  if(t.includes('question')||t.includes('shipment')||t.includes('order')||t.includes('invoice')||t.includes('payment due')||t.includes('paid')) return 5;
  if(t.includes('promo')||t.includes('newsletter')||t.includes('social')||t.includes('notification')) return 35;
  if(t.includes('financial notice')||t.includes('bank')||t.includes('subscription')||t==='💳 payment') return 70;
  return 20;
}
function reportSemanticTags(r){
  let arr=(r.tags||[]).map(t=>String(t||'').trim()).filter(function(t){
    if(!t)return false;
    if(t.startsWith('💰'))return false;
    if(t.startsWith('⏰') && t!=='⏰ deadline')return false;
    // Deprecated generic tag from older reports/builds. Current engine emits
    // concrete states (paid/payment due/invoice/transaction/statement) instead.
    if(t==='💳 payment')return false;
    return true;
  });
  const seen=new Set();arr=arr.filter(t=>{const k=t.toLocaleLowerCase();if(seen.has(k))return false;seen.add(k);return true;});
  if(!r.tag_order_manual && !r.tag_order_resolved){arr=arr.map((t,i)=>({t,i,r:_tagDisplayRank(t)})).sort((a,b)=>a.r-b.r||a.i-b.i).map(x=>x.t);}
  return arr;
}
function _tagDataJSON(r){try{return esc(JSON.stringify(reportSemanticTags(r)));}catch(_){return '[]';}}
// ── WHO SET THE PRIORITY: one glyph per row, explained once above the report.
// The full sentence used to sit inside every row and pushed the subject out of
// view. The glyph carries the same tooltip; the legend above the frame names it.
const AI_BADGES = {
  m4_bad:    {icon:'⚠', bg:'#fff7ed', fg:'#9a3412'},
  scope:     {icon:'⚙', bg:'#f1f5f9', fg:'#475569'},
  m4_change: {icon:'🧩', bg:'#dcfce7', fg:'#166534'},
  m4_same:   {icon:'✓', bg:'#f0fdf4', fg:'#15803d'},
  ai_change: {icon:'🤖', bg:'#eef2ff', fg:'#4338ca'},
  ai_block:  {icon:'≠', bg:'#fef3c7', fg:'#92400e'},
};
function aiLegendText(key,r){
  r=r||{};
  switch(key){
    case 'm4_bad':    return ui('lg_m4_bad','no usable AI answer — script result stands');
    case 'scope':     return ui('lg_scope','not sent to AI — script was sure');
    case 'm4_change': return ui('lg_m4_change','Model 4 changed the priority');
    case 'm4_same':   return ui('lg_m4_same','Model 4 agreed with the script');
    case 'ai_change': return ui('lg_ai_change','AI changed the priority');
    case 'ai_block':  return ui('lg_ai_block','AI disagreed — your rule won');
  }
  return '';
}
function aiPriBadge(r){
  let key='', title='';
  if(r.m4_review){
    key='m4_bad';
    title=(r.m4_review==='M4_NO_FACTS'
      ? ui('m4_no_facts','The model did not return usable facts for this message, so the script result stands. Nothing is pending — this is the final priority.')
      : ui('m4_no_rule','Facts were extracted but no Model 4 rule covers them, so the script result stands. Nothing is pending — this is the final priority.'))
      + (r.m4_advisory?(' · '+ui('ai_advisory','AI would have said')+' '+r.m4_advisory):'');
  } else if(r._ai_scope_skipped){
    key='scope';
    title=ui('scope_skipped_title','The script was confident about this message, so no model call was spent on it. Switch the AI scope to \u201cEvery new message\u201d if you want the AI to read this one too.');
  } else if(r._m4 && r._script_pri){
    if(r._m4_changed){ key='m4_change';
      title=ui('model4_changed_title','Model 4: AI extracted facts and the script calculated priority. Classic gave {classic}; Model 4 gave {model4}.',{classic:r._script_pri,model4:r.priority}); }
    else { key='m4_same';
      title=ui('model4_same_title','Model 4 used: AI extracted facts and the script calculated the same priority as Classic ({priority}) — consistent.',{priority:r.priority}); }
  } else if(r._ai_pri && r._script_pri){
    key='ai_change';
    title=ui('ai_changed_priority_title','AI changed the priority. Script: {script}; AI: {ai}.',{script:r._script_pri,ai:r.priority});
  } else if(r._ai_dissent){
    key='ai_block';
    title=ui('ai_dissent_title','AI proposed {priority}; your rule kept the current priority.',{priority:r._ai_dissent});
  }
  if(!key) return {key:'',html:''};
  const b=AI_BADGES[key];
  return {key:key, html:` <span class="tag" data-ai="${key}" style="font-size:11px;padding:0 5px;background:${b.bg};color:${b.fg}" title="${esc(title+' — '+aiLegendText(key,r))}">${b.icon}</span>`};
}
function aiLegendHTML(j){
  const seen=[];
  for(const b of (j.mailboxes||[]))
    for(const r of (b.rows||[]).concat(b.hidden_rows||[])){
      const k=aiPriBadge(r).key;
      if(k && seen.indexOf(k)<0) seen.push(k);
    }
  if(!seen.length) return '';
  const items=seen.map(k=>`<span style="white-space:nowrap"><span class="tag" style="font-size:11px;padding:0 5px;background:${AI_BADGES[k].bg};color:${AI_BADGES[k].fg}">${AI_BADGES[k].icon}</span> ${esc(aiLegendText(k))}</span>`).join('<span style="opacity:.35">|</span>');
  return `<div style="display:flex;flex-wrap:wrap;gap:8px;align-items:center;margin:0 0 8px;padding:5px 10px;
    background:var(--card,#fff);border:1px solid var(--line);border-radius:8px;font-size:11.5px;color:var(--dim)">
    <b style="font-weight:600">${ui('who_set_priority','Priority set by')}:</b>${items}</div>`;
}

// ── SETTINGS SECTIONS ──────────────────────────────────────────────────────
// The Outputs tab used to be one flat wall: no grouping, no statement of what a
// group decides, and the settings that actually change cost and speed buried
// under "Advanced". One numbered card per decision area, each with a single line
// saying what it controls. Section 1 is open; the rest are collapsed.
function sect(title, subtitle, inner, open){
  return `<details ${open?'open':''} style="margin:0 0 10px;border:1px solid var(--line);border-radius:10px;background:var(--card,#fff);overflow:hidden">
    <summary style="cursor:pointer;padding:9px 12px;background:#f8fafc;font-weight:700;font-size:13.5px;
      display:flex;align-items:baseline;gap:8px;flex-wrap:wrap">
      <span>${title}</span>
      <span style="font-weight:400;font-size:13px;color:var(--dim)">${subtitle}</span>
    </summary>
    <div style="padding:10px 12px 12px">${inner}</div></details>`;
}

function tagBadgeHTML(tag,r,secondary){
  const cls=secondary?'tag tag-edit-secondary':'tag tag-edit';
  const st=secondary?'font-size:12px;opacity:.85;cursor:pointer':'font-weight:600;cursor:pointer';
  return `<span class="${cls}" style="${st}" title="${esc(ui('click_tag_to_fix','Click to edit tags or their rule'))}" `+
    `data-tag="${esc(tag||'')}" data-tags='${_tagDataJSON(r)}' data-from="${esc(r.from||'')}" data-addr="${esc(r.addr||r.from||'')}" `+
    `data-title="${esc((r.title||r.summary||'').slice(0,120))}" data-mid="${esc(r.mid||'')}" data-src="${esc(r.src||'')}" `+
    `onclick="openTagPop(event,this)">${esc(tag||'')}</span>`;
}
function tagAddButtonHTML(r){
  return `<button class="btn ghost tag-edit" style="padding:1px 6px;font-size:11px;margin-left:3px;vertical-align:middle" `+
    `title="${esc(ui('add_tag_rule_here','Add / edit tags for this message'))}" data-tag="" data-tags='${_tagDataJSON(r)}' data-from="${esc(r.from||'')}" `+
    `data-addr="${esc(r.addr||r.from||'')}" data-title="${esc((r.title||r.summary||'').slice(0,120))}" `+
    `data-mid="${esc(r.mid||'')}" data-src="${esc(r.src||'')}" onclick="openTagPop(event,this)">＋🏷</button>`;
}
function reportAmountFact(r){
  // Amounts are high-risk presentation facts. Do not show a raw number merely
  // because a regex/model found one. It needs a concrete financial state, or an
  // explicit verified flag from a future extractor. This hides legal-capital,
  // promo-price and other contextless amounts from the report UI.
  const tags=reportSemanticTags(r);
  const verified=!!(r.facts&&r.facts.amount_verified===true) || tags.some(t=>[
    '💸 payment due','✅ paid','🧾 invoice','💳 transaction','📊 statement'
  ].includes(String(t||'')));
  if(!verified)return '';
  if(r.facts&&r.facts.amount)return String(r.facts.amount).replace(/^\uFFFD+\s*/,'');
  const t=(r.tags||[]).find(x=>String(x||'').trim().startsWith('💰'));
  return t?String(t).trim().slice(1).trim().replace(/^\uFFFD+\s*/,''):'';
}
function prowbg(p,important){
  // Tlo wiersza wg pilnosci: P1!/P1 czerwonawe, P2 zolte, reszta jak dotad.
  if(p==='P1!'||p==='P1') return 'background:#fef2f2';
  if(p==='P2') return 'background:#fffbeb';
  return important?'background:#eff4ff':'';
}
async function showTable(name){
  let j; try{ j=await api('/api/reportjson?name='+encodeURIComponent(name));}catch(e){ j={mailboxes:[]}; }
  if(window._devMode) window._reportCopyRows={};
  let h=`<div class="bar" style="margin:0 0 10px"><button class="btn ghost" style="padding:6px 12px" onclick="toggleView()">${window._tv==='text'?ui('switch_table','▦ Switch to Table'):ui('switch_text','≣ Switch to Text')}</button>
    ${window._devMode?`<button class="btn ghost" style="padding:6px 12px" onclick="copySelectedRows(false)">${ui('copy_selected','📋 Copy selected')}</button><button class="btn ghost" style="padding:6px 12px" onclick="copySelectedRows(true)">${ui('copy_selected_why','🧠 Copy selected + Why')}</button>`:''}
    <span class="tag">${esc(j.note||'')}</span></div>`;
  // Gdy pokazujemy wynik ostatniego runu po WEJSCIU (nie swiezy), powiedz z kiedy jest,
  // zeby user wiedzial, ze to zaległy run — i mogl odswiezyc jednym kliknieciem.
  if(window._lastRunWhen){
    const mins=Math.round((Date.now()/1000 - window._lastRunWhen)/60);
    const ago = mins<1?ui('just_now','just now'):(mins<60?ui('minutes_ago','{count} min ago',{count:mins}):ui('hours_ago','{count} h ago',{count:Math.round(mins/60)}));
    h+=`<div style="background:#eff6ff;border-left:3px solid var(--acc);padding:7px 12px;margin-bottom:8px;border-radius:6px;font-size:13px;display:flex;align-items:center;gap:10px">
      <span>${ui('last_check_ready','📬 Last check result ({ago}) — ready to act on.',{ago:esc(ago)})}</span></div>`;
    window._lastRunWhen=0;
  }
  if(j.demo) h+=`<div style="background:#fffbeb;border-left:3px solid #d97706;padding:8px 12px;margin-bottom:8px;color:#b45309;font-weight:600;border-radius:6px">${ui('demo_data_banner','⚠ DEMO DATA — fake emails, not your real inbox. Turn off demo mode for real mail.')}</div>`;
  for(const f of (j.fails||[])) h+=`<div style="background:#fef2f2;border-left:3px solid #dc2626;padding:8px 12px;margin-bottom:6px;color:#b91c1c;border-radius:6px">${ui('could_not_read_mailbox','⚠ Could not read {mailbox}: {reason}',{mailbox:esc(f.mailbox),reason:esc(f.why)})}</div>`;
  if(window._tv==='text'){ h+='<div style="font-family:ui-monospace,Menlo,Consolas,monospace;font-size:14px;line-height:1.5">'+fmtReport(window._rtext)+'</div>'; $('#res').innerHTML=h; return; }
  if(!j.mailboxes||!j.mailboxes.length){ h+=`<pre>${ui('empty','(empty)')}</pre>`; $('#res').innerHTML=h; return; }
  h+=aiLegendHTML(j);
  for(const b of j.mailboxes){
    const hid=(b.hidden_rows||[]);
    h+=`<div style="margin:14px 0 4px;font-weight:700;color:var(--acc2);border-bottom:1px solid var(--line);padding-bottom:3px">
      📬 ${esc(b.mailbox)} <span class="tag">${ui('mailbox_counts','· {new_count} new · {hidden_count} hidden',{new_count:b.total,hidden_count:b.hidden})}</span>
      ${b.hidden?`<button class="btn ghost" style="padding:2px 8px;font-size:11px;margin-left:6px;font-weight:400"
        onclick="toggleHidden('${esc(b.mailbox.replace(/[^a-zA-Z0-9]/g,''))}')">${ui('show_hidden','👁 show hidden')}</button>`:''}
    </div>
    <div id="hid-${esc(b.mailbox.replace(/[^a-zA-Z0-9]/g,''))}" style="display:none;margin:4px 0 8px;
      padding:8px 10px;background:#f8fafc;border-radius:8px;font-size:12px">
      <div class="hint" style="margin-bottom:6px">${ui('hidden_subject_only','These rows are hidden by your visibility policy. The run already analyzed the content it fetched; click 📋 to inspect the full source message.')}</div>
      ${hid.length?hid.map((r,hi)=>{
        const hslot='hb-'+esc(b.mailbox.replace(/[^a-zA-Z0-9]/g,''))+'-'+hi;
        return `<div style="padding:4px 0;border-bottom:1px solid var(--line)">
          <span class="prio-cell" data-from="${esc(r.from||'')}" data-addr="${esc(r.addr||'')}" data-tags='${esc(JSON.stringify(r.tags||[]))}' data-title="${esc((r.summary||'').slice(0,80))}" data-mid="${esc(r.mid||'')}" data-src="${esc(r.src||b.mailbox||'')}" style="position:relative;padding-right:2px">${pdot(r.priority)}</span>
          <span class="hint">${esc(r.date)}</span>
          <b>${esc(r.from)}</b>: ${esc(r.summary)}
          ${reportAmountFact(r)?` <span style="margin-left:4px;padding:1px 6px;border-radius:999px;background:#eef2ff;color:#4338ca;font-weight:600" title="${esc(ui('extracted_fact','Extracted fact'))}">💰 ${esc(reportAmountFact(r))}</span>`:''}
          ${reportSemanticTags(r).map(t=>tagBadgeHTML(t,r,true)).join(' ')}${tagAddButtonHTML(r)}
          ${r.mid?rowActionsHTML(r, hslot, r.src||b.mailbox, webmailLink(r.src||b.mailbox)):''}
          <div id="${hslot}"></div>
        </div>`;}).join(''):`<span class="hint">${ui('nothing_stored','Nothing stored — run again to capture them.')}</span>`}
    </div>`;
    if(!b.rows.length){ h+=`<div class="tag" style="padding:6px">${ui('nothing_needs_attention','nothing needs attention')}</div>`; continue; }
    h+='<div style="overflow-x:auto;margin:0 -2px"><table style="width:100%;border-collapse:collapse;font-size:13px;min-width:700px"><tr style="color:var(--dim)">'+
       '<th style="text-align:left;padding:5px 6px;border-bottom:1px solid var(--line)">!</th>'+
       `<th style="text-align:left;padding:5px 6px;border-bottom:1px solid var(--line)">${ui('date','Date')}</th>`+
       `<th style="text-align:left;padding:5px 6px;border-bottom:1px solid var(--line);max-width:200px">${ui('sender','From')}</th>`+
       `<th style="text-align:left;padding:5px 6px;border-bottom:1px solid var(--line)">${ui('what_is_it','What it is')}</th>`+
       `<th style="text-align:left;padding:5px 6px;border-bottom:1px solid var(--line)">${ui('tags_label','Tags')}</th>`+
       `<th style="text-align:left;padding:5px 6px;border-bottom:1px solid var(--line)">${ui('actions','Do')}</th></tr>`;
    for(const r of b.rows){
      const xn=r.count>1?` <span class="tag">(×${r.count})</span>`:'';
      // Tagi ZWIJANE domyslnie (<details>): przy 3-4 tagach na wiersz kolumna
      // TAG GLOWNY zawsze widoczny (pierwszy = najwazniejszy). Pozostale (jesli sa)
      // w rozwijanym <details>. Wczesniej WSZYSTKIE byly schowane — blad.
      const _tagList=reportSemanticTags(r);
      let tags='';
      if(_tagList.length){
        const _main=_tagList[0];
        const _secondary=_tagList[1]||'';
        const _rest=_tagList.slice(2);
        tags=tagBadgeHTML(_main,r,false);
        if(_secondary) tags+=' '+tagBadgeHTML(_secondary,r,true);
        if(_rest.length){
          tags+=` <details style="display:inline-block"><summary style="cursor:pointer;color:var(--dim);font-size:12px">+${_rest.length}</summary>`
            +`<div style="margin-top:3px;white-space:normal">`+_rest.map(t=>tagBadgeHTML(t,r,true)).join(' ')+`</div></details>`;
        }
      }
      tags+=tagAddButtonHTML(r);
      const bg=prowbg(r.priority,r.important);
      const rid='m'+Math.random().toString(36).slice(2,8);
      if(window._devMode) window._reportCopyRows[rid]={row:r,src:(r.src||b.mailbox||''),slot:rid};
      // PODGLAD SKRYPT vs AI: gdy AI zmienilo priorytet, pokaz maly znacznik
      // (ukryty w tekscie, widoczny na hover) — user wie, ze to nie skrypt.
      // Pokazuje KTORY silnik ustalil priorytet i jaka byla wersja skryptu:
      //  Model 4 (ekstraktor) -> zielony znacznik "M4: P3→P1"
      //  AI-sedzia            -> niebieski "AI: P3→P1"
      //  sam skrypt           -> brak znacznika (priorytet skryptu jest finalny)
      const _aiPri = aiPriBadge(r).html;
      const mlink=webmailLink(r.src||b.mailbox);
      // OSOBNY BLOK STRESZCZENIA dla P1/P1!/P2: pokazujemy tylko gdy AI dalo tresciwe
      // streszczenie (dluzsze niz tytul i nie bedace jego kopia). Wtedy linia "What it
      // is" = tytul, streszczenie w bloku identycznym z on-demand (summaryDetails).
      // P1/P1! zawsze. P2 tylko gdy tick "always_summary" w ustawieniach Outputs.
      const _aiS=(r.ai_summary||'').trim(), _ttl=(r.title||'').trim();
      // Engine owns automatic-summary selection. If ai_summary exists, render it
      // through the same colored/expandable Summary component as on-demand 📄.
      const _hasAiBlock = _aiS.length>0;
      const _whatItIs = (r.summary||_ttl||'');
      const _sumBlock = _hasAiBlock ? summaryDetails(_aiS) : '';
      const _dissentWhy = esc(r._ai_dissent_reason||'');
      const _dissentBlock = r._ai_dissent ? `<div style="margin-top:4px;font-size:11px;color:#92400e;background:#fef3c7;border-radius:5px;padding:3px 6px">${ui('ai_dissent_row','🤖 AI suggested {ai}; your rule kept {kept}. Nothing was changed.',{ai:esc(r._ai_dissent),kept:esc(r.priority)})}${_dissentWhy?` <span style="opacity:.85">— ${_dissentWhy}</span>`:''}</div>` : '';
      const _calBlock = r.calendar_auto ? `<span class="tag" style="font-size:10px;background:#ecfdf5;color:#047857" title="${esc(ui('calendar_auto_status','Automatic calendar: {status}',{status:r.calendar_auto}))}">📅 ${esc(r.calendar_auto)}</span>` : '';
      const _copySelect=window._devMode?`<input class="report-copy-select" type="checkbox" value="${rid}" title="${esc(ui('select_for_copy','Select this message for copying'))}" style="margin:0 5px 0 0;vertical-align:middle" onclick="event.stopPropagation()">`:'';
      h+=`<tr style="${bg}"${window._devMode?` data-copy-row="${rid}"`:''}><td class="prio-cell" data-from="${esc(r.from||'')}" data-addr="${esc(r.addr||'')}" data-tags='${esc(JSON.stringify(r.tags||[]))}' data-title="${esc((r.title||r.summary||'').slice(0,80))}" data-mid="${esc(r.mid||'')}" data-src="${esc(r.src||b.mailbox||'')}" style="padding:5px 6px;border-bottom:1px solid var(--line);white-space:nowrap">${_copySelect}${pdot(r.priority)}${_aiPri}</td>`+
         `<td style="padding:5px 6px;border-bottom:1px solid var(--line);white-space:nowrap;color:var(--dim);font-size:13px">${esc(r.date)}</td>`+
         `<td style="padding:5px 6px;border-bottom:1px solid var(--line);font-size:14px;font-weight:600;max-width:200px;overflow:hidden;text-overflow:ellipsis" title="${esc(r.addr||r.from||'')}">${esc(r.from)}${xn}</td>`+
         `<td style="padding:5px 6px;border-bottom:1px solid var(--line);font-size:14px;line-height:1.45">${esc(_whatItIs)}${r.deadline?` <b style="color:var(--acc2)">⏰${esc(r.deadline)}</b>`:''}${reportAmountFact(r)?` <span style="padding:1px 6px;border-radius:999px;background:#eef2ff;color:#4338ca;font-weight:600" title="${esc(ui('extracted_fact','Extracted fact'))}">💰 ${esc(reportAmountFact(r))}</span>`:''}`+
         _sumBlock+_dissentBlock+_calBlock+
         ((r.attach&&r.attach.length)?`<div class="hint" style="margin-top:2px">📎 ${r.attach.map(esc).join(' · ')}</div>`:'')+
         `<div id="${rid}" style="margin-top:4px"></div></td>`+
         `<td style="padding:5px 6px;border-bottom:1px solid var(--line)">${tags}</td>`+
         `<td style="padding:5px 6px;border-bottom:1px solid var(--line);white-space:nowrap">`+
           rowActionsHTML(r, rid, r.src||b.mailbox, mlink)+
         `</td></tr>`;
      if(r.draft) h+=`<tr style="${bg}"><td></td><td colspan="5" style="padding:2px 6px 8px;border-bottom:1px solid var(--line);color:var(--acc)">${ui('draft_label','✍ draft')}: ${esc(r.draft)}</td></tr>`;
    }
    h+='</table></div>';
  }
  // Pod tabela: przejscie do widoku tekstowego (pelen raport z ukrytymi, konkluzja, social)
  h+=`<div style="margin-top:14px;padding:10px 12px;background:#f8fafc;border-radius:8px;
      display:flex;gap:10px;align-items:center;flex-wrap:wrap">
      <span class="hint" style="margin:0">${ui('report_views_hint','<b>Table</b> is ordered by priority and has action buttons. <b>Text</b> is exactly what is sent to Discord or Telegram.')}</span>
      <button class="btn ghost" style="padding:5px 12px;font-size:12px" onclick="toggleView()">${window._tv==='text'?ui('switch_table','▦ Switch to Table'):ui('switch_text','≣ Switch to Text')}</button>
    </div>`;
  $('#res').innerHTML=h;
}
// POMOC — trzy tryby: off (czysto) / tips (rada: co wpisac) / tech (mechanika: co sie stanie)
let HINTS=null, hintMode=0;   // 0=off, 1=tips, 2=tech
const HINT_KEYS=['hints_off','hints_tips','hints_tech'];

async function cycleHints(){
  hintMode=(hintMode+1)%3;
  const btn=$('#hintbtn');
  if(btn) btn.textContent=ui('hints','💡 Hints')+': '+ui(HINT_KEYS[hintMode],['off','Tips','Technical'][hintMode]);
  if(hintMode && !HINTS){
    var L=(window._globalSettings&&window._globalSettings.lang)||'en';
    try{ HINTS=await api('/api/help?lang='+L); }catch(e){ HINTS={}; }
  }
  applyHints();
}
function applyHints(){
  // usun stare
  document.querySelectorAll('.helpbox').forEach(e=>e.remove());
  if(!hintMode || !HINTS) return;
  const level = hintMode===1 ? 'tip' : 'tech';
  const col   = hintMode===1 ? 'var(--acc2)' : 'var(--acc)';
  const ico   = hintMode===1 ? '💡' : '⚙';
  for(const key in HINTS){
    const txt=(HINTS[key]||{})[level];
    if(!txt) continue;
    const el=document.getElementById(key);
    if(!el) continue;
    const box=document.createElement('div');
    box.className='helpbox';
    box.style.cssText=`margin:4px 0 10px;padding:8px 10px;background:#f8fafc;
      border-left:2px solid ${col};border-radius:0 6px 6px 0;font-size:12px;
      line-height:1.6;color:var(--txt);white-space:pre-line`;
    box.textContent=`${ico} ${txt}`;
    // wstaw pod polem (albo pod jego wrapperem)
    const anchor = el.closest('div') && el.closest('div').parentElement===el.parentElement
      ? el : el;
    anchor.parentNode.insertBefore(box, anchor.nextSibling);
  }
}
function toggleHidden(id){
  const el=document.getElementById('hid-'+id);
  if(el) el.style.display = el.style.display==='none' ? 'block' : 'none';
}
function toggleAllAdvanced(){
  // GENERYCZNE: znajduje KAZDA zwijana sekcje na WIDOCZNEJ zakladce.
  // Nowa sekcja z klasą "foldable" albo id zaczynajacym sie od adv-/autocfg
  // dziala automatycznie — bez dopisywania jej tutaj.
  const visible = [...document.querySelectorAll('.tabc')].filter(t=>!t.hidden);
  const sections = [];
  for(const tab of visible){
    tab.querySelectorAll('[id^="adv-"], [id^="autocfg"], [id$="wrap"], .foldable')
       .forEach(e=>sections.push(e));
  }
  if(!sections.length) return;
  const anyHidden = sections.some(e=>e.style.display==='none' || getComputedStyle(e).display==='none');
  sections.forEach(e=>{ e.style.display = anyHidden ? 'block' : 'none'; });
  const btn=document.getElementById('expandall');
  if(btn){
    btn.textContent = anyHidden ? '⊖' : '⊕';
    btn.title = anyHidden ? ui('collapse_every_section','Collapse every section on this tab') : ui('expand_every_section','Expand every section on this tab');
  }
}
function toggleView(){ window._tv=window._tv==='text'?'table':'text'; showTable(window._rname); }
function _copyRowBaseText(r){
  r=r||{};
  const tags=reportSemanticTags(r);
  let lines=[`${r.priority||''} | ${r.date||''} | ${r.from||r.addr||''}`, String(r.title||r.summary||'').trim()];
  if(tags.length) lines.push('Tags: '+tags.join(', '));
  if(r.ai_summary) lines.push('Summary: '+String(r.ai_summary).trim());
  return lines.filter(Boolean).join('\n');
}
async function copySelectedRows(withWhy){
  if(!window._devMode){ flash(ui('dev_only','Available only in --d diagnostics mode.')); return; }
  const ids=[...document.querySelectorAll('.report-copy-select:checked')].map(x=>x.value);
  if(!ids.length){ flash(ui('select_messages_first','Select one or more messages first.')); return; }
  const chunks=[];
  for(const id of ids){
    const item=(window._reportCopyRows||{})[id]; if(!item) continue;
    let txt=_copyRowBaseText(item.row);
    if(withWhy){
      try{
        const rr=await api('/api/mailaction',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name:window._rname,mid:item.row.mid||'',src:item.src||'',kind:'explain',variant:0})});
        const why=String((rr&&rr.result)||'').trim();
        if(why) txt+='\n\nWhy priority & tags:\n'+why;
      }catch(e){ txt+='\n\nWhy priority & tags: [failed to load]'; }
    }
    chunks.push(txt);
  }
  const all=chunks.join('\n\n--------------------\n\n');
  try{ await navigator.clipboard.writeText(all); flash(ui('copied_selected','Copied {count} selected message(s).',{count:chunks.length})); }
  catch(e){ flash(ui('copy_failed','Copy failed.')); }
}

// Link do webmaila wg domeny skrzynki (klik 🔗 otwiera właściwy serwis)
function webmailLink(addr){
  const d=(addr||'').split('@')[1]||'';
  if(/gmail|googlemail/.test(d)) return 'https://mail.google.com/';
  if(/o2\.pl|poczta\.o2/.test(d)) return 'https://poczta.o2.pl/';
  if(/wp\.pl/.test(d)) return 'https://poczta.wp.pl/';
  if(/onet/.test(d)) return 'https://poczta.onet.pl/';
  if(/interia/.test(d)) return 'https://poczta.interia.pl/';
  if(/outlook|hotmail|live/.test(d)) return 'https://outlook.live.com/mail/';
  if(/proton/.test(d)) return 'https://mail.proton.me/';
  if(/yahoo/.test(d)) return 'https://mail.yahoo.com/';
  if(d) return 'https://'+d;   // fallback: domena
  return '';
}

// Akcja na żądanie: streść / draft dla JEDNEGO maila (nie czeka na cały run)
async function loadTagRules(){
  const el=$('#tagrules'); if(!el) return;
  el.innerHTML='<span class="hint">'+ui('loading_plain','loading…')+'</span>';
  try{
    const r=await api('/api/tags?name='+encodeURIComponent(cur&&cur.name||''));
    let h='';
    const tagRelated=x=>!!(x&&x.tag)||((x&&x.where)==='tag');
    const rulesHtml=(list)=>list.map(rule=>{
      const actions=[]; if(rule.tag)actions.push('tag='+rule.tag); if(rule.min_priority)actions.push('floor='+rule.min_priority); if(rule.max_priority)actions.push('ceiling='+rule.max_priority); if(rule.show)actions.push('show');
      return `<div>• ${esc((rule.match||[]).join(', '))} <span style="opacity:.6">(${esc(rule.where||'all')})</span>${actions.length?' → <b>'+esc(actions.join(' + '))+'</b>':''}</div>`;
    }).join('');
    const factory=(r.preset_rules||[]).filter(tagRelated), mine=(r.custom||[]).filter(tagRelated), built=r.builtin||[];
    h+='<div style="margin-top:4px"><b style="color:var(--acc2)">'+ui('factory_tag_catalog','Factory tag catalog')+'</b></div>';
    h+=built.length?'<div style="display:flex;gap:4px;flex-wrap:wrap;margin-top:4px">'+built.map(t=>'<span class="tag">'+esc(t)+'</span>').join('')+'</div>':'<div class="hint">'+ui('no_factory_tags','No factory tag catalog was returned.')+'</div>';
    h+='<div style="margin-top:8px"><b style="color:var(--acc2)">'+ui('factory_tag_rules','Factory rules that assign/use tags')+'</b></div>';
    h+=factory.length?rulesHtml(factory):'<div class="hint">'+ui('no_factory_rules_here','No factory tag rules.')+'</div>';
    h+='<div style="margin-top:8px"><b style="color:var(--acc)">'+ui('your_tag_rules','Your rules that assign/use tags')+'</b></div>';
    h+=mine.length?rulesHtml(mine):'<div style="opacity:.7">'+ui('no_tag_rules_yet','none — no user tag rules yet')+'</div>';
    if(r.used&&r.used.length)h+='<div style="margin-top:8px"><b>'+ui('seen_last_report','Seen in the last report')+'</b></div><div style="opacity:.8">'+r.used.map(esc).join(' · ')+'</div>';
    h+='<div class="bar" style="margin-top:8px"><button class="btn ghost" style="padding:4px 9px;font-size:11px" onclick="showTagEditor(\'tags\')">'+ui('tag_focused_view','🏷 Tag-focused view')+'</button><button class="btn ghost" style="padding:4px 9px;font-size:11px" onclick="showTagEditor(\'all\')">'+ui('open_all_rules','⚙ Exact/custom message rules')+'</button><button class="btn ghost" style="padding:4px 9px;font-size:11px" onclick="showClassificationSettings()">'+ui('engine_behaviour_button','⚙ Engine behaviour')+'</button></div>';
    el.innerHTML=h;
  }catch(e){ el.textContent=ui('could_not_load_rules','Could not load rules ({error})',{error:e}); }
}
async function resetTags(){
  // PODWÓJNE potwierdzenie — reset kasuje twoje reguły
  if(!confirm(ui('reset_custom_tags_confirm','Reset all custom tag rules to the defaults?\n\nThis removes rules you added with the ✎ button.'))) return;
  if(!confirm(ui('cannot_undo_confirm','Are you sure? This cannot be undone.\n\nClick OK to reset now.'))) return;
  try{
    await api('/api/tags_reset',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({})});
    alert(ui('tag_rules_reset','Tag rules reset to default. Takes effect on the next Run.'));
    loadTagRules();
  }catch(e){ alert(ui('reset_failed','Reset failed.')); }
}
// ── TAG POPOVER: immediate message-tag correction + separate future rule.
function _ensureTagPop(){
  if(document.getElementById('tag-pop'))return;
  const d=document.createElement('div');d.id='tag-pop';
  d.style.cssText='display:none;position:fixed;z-index:92;background:var(--card,#fff);border:1px solid var(--line);border-radius:10px;padding:9px 11px;box-shadow:0 6px 20px #0003;font-size:12px;max-width:min(560px,94vw)';
  document.body.appendChild(d);
  document.addEventListener('pointerdown',e=>{if(d.style.display!=='none'&&!d.contains(e.target)&&!e.target.closest('.tag-edit,.tag-edit-secondary'))closeTagPop();});
}
function closeTagPop(){
  const data=window._tagPopData,p=document.getElementById('tag-pop');if(p)p.style.display='none';window._tagPopData=null;
  if(data&&data.dirty&&window._rname)setTimeout(()=>showTable(window._rname),0);
}
function _tagPopSelected(){const d=window._tagPopData||{};return (d.tags||[])[d.selectedIndex]||'';}
function _tagPopRenderCurrent(){
  const d=window._tagPopData||{},box=document.getElementById('tp-tags');if(!box)return;
  if(!(d.tags||[]).length){box.innerHTML='<span class="hint">'+ui('no_tags_current_message','No tags on this message yet.')+'</span>';return;}
  box.innerHTML=d.tags.map((t,i)=>`<span class="tag" draggable="true" ondragstart="tagPopDragStart(event,${i})" ondragover="event.preventDefault()" ondrop="tagPopDrop(event,${i})" onclick="tagPopSelect(${i})" style="cursor:grab;${i===d.selectedIndex?'outline:2px solid var(--acc);outline-offset:1px;':''}" title="${esc(ui('drag_tag_hint','Drag to change display order; click to edit'))}">${esc(t)}</span>`).join(' ');
}
function tagPopSelect(i){const d=window._tagPopData||{};d.selectedIndex=i;const inp=document.getElementById('tp-new');if(inp)inp.value=(d.tags||[])[i]||'';_tagPopRenderCurrent();tagPopBindChanged();}
function tagPopDragStart(ev,i){const d=window._tagPopData||{};d.dragIndex=i;try{ev.dataTransfer.effectAllowed='move';ev.dataTransfer.setData('text/plain',String(i));}catch(_){}}
async function tagPopDrop(ev,i){ev.preventDefault();const d=window._tagPopData||{};let from=d.dragIndex;try{const x=parseInt(ev.dataTransfer.getData('text/plain'),10);if(Number.isFinite(x))from=x;}catch(_){}if(!Number.isFinite(from)||from<0||from===i)return;const a=d.tags||[];const [x]=a.splice(from,1);a.splice(i,0,x);d.selectedIndex=i;_tagPopRenderCurrent();await _persistCurrentTags();}
async function _persistCurrentTags(){
  const d=window._tagPopData||{};if(!d.mid)return false;
  try{const r=await api('/api/message_tags',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name:window._rname||((cur&&cur.name)||''),mid:d.mid,src:d.src||'',tags:d.tags||[]})});if(r&&r.ok){d.dirty=true;return true;}flash(ui('tag_update_failed','Could not update tags in the current report.'));return false;}catch(_){flash(ui('tag_update_failed','Could not update tags in the current report.'));return false;}
}
async function tagPopReplaceNow(){const d=window._tagPopData||{},v=((document.getElementById('tp-new')||{}).value||'').trim();if(!v){flash(ui('enter_tag','Enter a tag.'));return;}if(d.selectedIndex<0){d.tags.push(v);d.selectedIndex=d.tags.length-1;}else d.tags[d.selectedIndex]=v;d.tags=[...new Map(d.tags.map(x=>[String(x).toLocaleLowerCase(),x])).values()];d.selectedIndex=d.tags.findIndex(x=>String(x).toLocaleLowerCase()===v.toLocaleLowerCase());_tagPopRenderCurrent();tagPopBindChanged();await _persistCurrentTags();}
async function tagPopAddNow(){const d=window._tagPopData||{},v=((document.getElementById('tp-new')||{}).value||'').trim();if(!v){flash(ui('enter_tag','Enter a tag.'));return;}if(!d.tags.some(x=>String(x).toLocaleLowerCase()===v.toLocaleLowerCase()))d.tags.push(v);d.selectedIndex=d.tags.findIndex(x=>String(x).toLocaleLowerCase()===v.toLocaleLowerCase());_tagPopRenderCurrent();tagPopBindChanged();await _persistCurrentTags();}
async function tagPopRemoveNow(){const d=window._tagPopData||{};if(d.selectedIndex<0||d.selectedIndex>=d.tags.length)return;d.tags.splice(d.selectedIndex,1);d.selectedIndex=Math.min(d.selectedIndex,d.tags.length-1);const inp=document.getElementById('tp-new');if(inp)inp.value=_tagPopSelected();_tagPopRenderCurrent();tagPopBindChanged();await _persistCurrentTags();}
function openTagPop(ev,el){
  ev.stopPropagation();_ensureTagPop();let tags=[];try{tags=JSON.parse(el.dataset.tags||'[]')||[];}catch(_){}const clicked=el.dataset.tag||'';
  const d={tag:clicked,tags:Array.isArray(tags)?tags.slice():[],from:el.dataset.from||'',addr:el.dataset.addr||'',title:el.dataset.title||'',mid:el.dataset.mid||'',src:el.dataset.src||'',selectedIndex:-1,dragIndex:-1,dirty:false};
  d.selectedIndex=clicked?d.tags.findIndex(x=>x===clicked):-1;if(d.selectedIndex<0&&clicked){d.tags.push(clicked);d.selectedIndex=d.tags.length-1;}window._tagPopData=d;
  const p=document.getElementById('tag-pop');
  p.innerHTML='<div style="font-weight:700;margin-bottom:5px">'+ui('tags_for_message','🏷 Tags for this message')+'</div>'+ '<div id="tp-tags" style="display:flex;gap:5px;flex-wrap:wrap;align-items:center;margin:4px 0 7px"></div>'+ '<div class="hint" style="margin-bottom:5px">'+ui('tag_edit_hint','Click a tag to edit it. Drag tags to change which ones are shown first.')+'</div>'+ '<div style="display:flex;gap:4px;align-items:center;flex-wrap:wrap"><input id="tp-new" value="'+esc(_tagPopSelected())+'" placeholder="'+esc(ui('new_tag','new tag'))+'" style="padding:4px 6px;min-width:170px">'+ '<button class="btn" style="padding:4px 9px" onclick="tagPopReplaceNow()">'+ui('replace_tag','Replace')+'</button>'+ '<button class="btn ghost" style="padding:4px 9px" onclick="tagPopAddNow()">＋ '+ui('add_tag','Add')+'</button>'+ '<button class="btn ghost" style="padding:4px 9px;color:var(--red)" onclick="tagPopRemoveNow()">− '+ui('remove_tag_this_message','Remove here')+'</button></div>'+ '<div style="border-top:1px solid var(--line);margin:9px 0 7px;padding-top:7px"><b>'+ui('future_rule','Future similar messages')+'</b> <span class="hint">'+ui('future_rule_hint','Optional: save the selected/new tag as a reusable rule.')+'</span></div>'+ '<div style="display:flex;gap:4px;align-items:center;flex-wrap:wrap"><select id="tp-bind" onchange="tagPopBindChanged()" style="padding:3px 6px"><option value="from">'+ui('sender','sender')+'</option>'+((d.tags||[]).length?'<option value="tag">'+ui('tag','tag')+'</option>':'')+'<option value="keyword">'+ui('keyword','keyword')+'</option></select>'+ '<button class="btn" style="padding:3px 9px" onclick="tagPopSave()">💾 '+ui('save_future_rule','Save rule')+'</button>'+ '<button class="btn ghost" style="padding:3px 8px" onclick="tagPopAdvanced()" title="'+esc(ui('advanced_rule','Advanced rule'))+'">✎</button>'+ '<button class="btn ghost" style="padding:3px 8px" onclick="tagPopRemoveCustom()" title="'+esc(ui('remove_custom_tag_rule','Remove matching custom tag rule'))+'">🗑</button></div>'+ '<div id="tp-detail" class="hint" style="margin-top:5px"></div>';
  _tagPopRenderCurrent();tagPopBindChanged();
  const rect=el.getBoundingClientRect();p.style.display='block';let left=rect.right+4,top=rect.top-4;const pw=p.offsetWidth;if(left+pw>window.innerWidth-8)left=rect.left-pw-4;left=Math.max(8,Math.min(left,Math.max(8,window.innerWidth-pw-8)));if(top+p.offsetHeight>window.innerHeight-8)top=window.innerHeight-p.offsetHeight-8;if(top<4)top=4;p.style.left=left+'px';p.style.top=top+'px';
}
function tagPopBindChanged(){
  const d=window._tagPopData||{},b=(document.getElementById('tp-bind')||{}).value||'from',box=document.getElementById('tp-detail');if(!box)return;
  if(b==='from')box.innerHTML=esc(d.addr||d.from||'');
  else if(b==='tag')box.innerHTML='<span class="tag">'+esc(_tagPopSelected()||'')+'</span>';
  else box.innerHTML='<input id="tp-kw" style="padding:3px 6px;width:210px" placeholder="'+esc(ui('word_placeholder','word / phrase…'))+'">';
}
function _tagPopMatch(){const d=window._tagPopData||{},b=(document.getElementById('tp-bind')||{}).value||'from';if(b==='from')return {match:d.addr||d.from,where:'from'};if(b==='tag')return {match:_tagPopSelected(),where:'tag'};return {match:((document.getElementById('tp-kw')||{}).value||'').trim(),where:'subject'};}
async function tagPopSave(){
  const d=window._tagPopData||{},m=_tagPopMatch(),newtag=((document.getElementById('tp-new')||{}).value||'').trim();if(!m.match||!newtag){flash(ui('tag_rule_needs_match_and_tag','Choose what to match and enter a tag.'));return;}
  const payload={match:m.match,match_on:m.where,tag:newtag,scope:'tool:'+((cur&&cur.name)||''),name:(cur&&cur.name)||''};
  let r=await api('/api/tag_rule',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});if(r&&r.needs_confirmation){if(!confirm(_ruleRiskConfirmText(r.validation)))return;payload.confirm_risk=true;r=await api('/api/tag_rule',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});}
  if(r&&r.ok){if(d.selectedIndex>=0)d.tags[d.selectedIndex]=newtag;else{d.tags.push(newtag);d.selectedIndex=d.tags.length-1;}await _persistCurrentTags();flash(ui('tag_rule_saved','Tag rule saved.'));closeTagPop();}else flash(ui('quick_rule_failed','Rule not saved: {error}',{error:(r&&r.error)||''}));
}
function tagPopAdvanced(){const d=window._tagPopData||{},seed=_tagPopSelected()||((document.getElementById('tp-new')||{}).value||'').trim();closeTagPop();editTag(d.addr||d.from,d.title,d.mid,d.src,{tag:seed,current_tags:d.tags||[]});}
async function tagPopRemoveCustom(){const m=_tagPopMatch();if(!m.match)return;if(!confirm(ui('remove_matching_custom_tag_rule','Remove custom tag action matching "{match}"? Factory extraction is not deleted.',{match:m.match})))return;const r=await api('/api/tags_remove_for',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({match:m.match,where:m.where,mode:'tag',name:(cur&&cur.name)||''})});if(r&&r.ok){flash(ui('custom_tag_action_removed','Custom tag action removed.'));closeTagPop();}else flash(ui('failed_plain','Failed.'));}


// ── PRIO POPOVER: klik na badge P → kompaktowy horyzontalny popover ──
// ▲ ▼ │ [sender/tag/keyword ▼] [detail] [💾] [✎ guided/AI/advanced]
// Jeden globalny div, pozycjonowany fixed, zamyka sie klikiem poza / Escape.
function prioArrowsHTML(){ return ''; }
function _ensurePrioPop(){
  if(document.getElementById('prio-pop')) return;
  const d=document.createElement('div'); d.id='prio-pop';
  d.style.cssText='display:none;position:fixed;z-index:90;background:var(--card,#fff);'+
    'border:1px solid var(--line);border-radius:10px;padding:6px 10px;'+
    'box-shadow:0 6px 20px #0003;font-size:13px;max-width:min(420px,90vw);white-space:normal';
  document.body.appendChild(d);
  document.addEventListener('pointerdown',function(e){
    if(!d.contains(e.target)&&!e.target.classList.contains('pval')) closePrioPop();
  });
  document.addEventListener('keydown',function(e){ if(e.key==='Escape') closePrioPop(); });
}
function closePrioPop(){ const p=document.getElementById('prio-pop'); if(p) p.style.display='none'; window._ppData=null; }
function openPrioPop(ev, from, prio, tags, title, addr, mid, src){
  ev.stopPropagation();
  _ensurePrioPop();
  const pop=document.getElementById('prio-pop');
  const data={f:(from||'').trim(), a:(addr||'').trim(), p:prio||'P3', t:tags||[], s:(title||'').slice(0,80), mid:mid||'', src:src||''};
  window._ppData=data;
  const hasTags=data.t.length>0;
  let h='<div style="display:flex;align-items:center;gap:4px;flex-wrap:wrap">'+
    '<span class="pa-btn" style="cursor:pointer;padding:2px 6px;font-size:15px;user-select:none" onclick="ppBump(\'up\')">▲</span>'+
    '<span class="pa-btn" style="cursor:pointer;padding:2px 6px;font-size:15px;user-select:none" onclick="ppBump(\'down\')">▼</span>'+
    '<span style="color:var(--line);margin:0 2px">│</span>'+
    '<select id="pp-bind" style="padding:3px 6px;font-size:12px;border-radius:6px;border:1px solid var(--line)" onchange="ppBindChanged()">'+
      '<option value="from" selected>'+ui('sender','sender')+'</option>'+
      (hasTags?'<option value="tag">'+ui('tag','tag')+'</option>':'')+
      '<option value="keyword">'+ui('keyword','keyword')+'</option>'+
    '</select>'+
    '<button class="btn" style="padding:3px 10px;font-size:12px;flex-shrink:0" onclick="ppSave()" title="'+esc(ui('save_quick_rule','Save quick rule'))+'">💾</button>'+
    '<button class="btn ghost" style="padding:3px 8px;font-size:12px;flex-shrink:0" onclick="ppOpenBuilder()" title="'+esc(ui('open_safe_rule_builder','Guided / AI / advanced rule builder'))+'">✎</button>'+
    '</div>'+
    '<div id="pp-detail" style="margin-top:4px;word-break:break-all;font-size:12px"></div>';
  pop.innerHTML=h;
  ppBindChanged();
  const rect=ev.target.getBoundingClientRect();
  let left=rect.right+4, top=rect.top-4;
  pop.style.display='block';
  const pw=pop.offsetWidth;
  if(left+pw>window.innerWidth-8) left=rect.left-pw-4;
  left=Math.max(8,Math.min(left,Math.max(8,window.innerWidth-pw-8)));
  if(top+pop.offsetHeight>window.innerHeight-8) top=window.innerHeight-pop.offsetHeight-8;
  if(top<4) top=4;
  pop.style.left=left+'px'; pop.style.top=top+'px';
}
function ppBindChanged(){
  const sel=document.getElementById('pp-bind'); if(!sel) return;
  const box=document.getElementById('pp-detail'); if(!box) return;
  const d=window._ppData||{};
  if(sel.value==='from'){
    var label=d.a||d.f||'';
    box.innerHTML='<span class="hint" style="font-size:11px">'+esc(label)+'</span>';
  } else if(sel.value==='tag'){
    if(d.t.length===1){
      box.innerHTML='<span class="tag" style="font-size:11px">'+esc(d.t[0])+'</span>';
    } else {
      box.innerHTML='<select id="pp-tag" style="padding:3px 6px;font-size:12px;border-radius:6px;border:1px solid var(--line)">'+
        d.t.map(function(t){return '<option value="'+esc(t)+'">'+esc(t)+'</option>';}).join('')+'</select>';
    }
  } else {
    // A priority keyword must be chosen deliberately. Never seed it from the first
    // subject word ("Re:", "The", etc.), because that silently creates broad rules.
    box.innerHTML='<input id="pp-kw" style="padding:3px 6px;font-size:12px;width:150px;border-radius:6px;border:1px solid var(--line)" value="" placeholder="'+esc(ui('word_placeholder','word / phrase…'))+'">';
  }
}
function _ppReadPrio(){
  var d=window._ppData||{};
  var n=parseInt(String(d.p||'').replace(/[^0-9]/g,''),10);
  return (n>=1&&n<=5)?n:3;
}
async function ppBump(dir){
  var d=window._ppData||{}; if(!d.f) return;
  var n=_ppReadPrio();
  var target = dir==='up' ? Math.max(1, n-1) : Math.min(5, n+1);
  if(target===n){ flash(dir==='up'?ui('already_p1','Already P1.'):ui('already_p5','Already P5.')); return; }
  var cap='P'+target;
  // Do not silently learn a sender rule. Arrows only choose the desired priority;
  // Save then asks which evidence should carry that correction.
  d.p=cap;
  const box=document.getElementById('pp-detail');
  if(box) box.insertAdjacentHTML('beforeend','<div class="hint" style="margin-top:3px">'+ui('target_priority_selected','Target: {priority} — choose how to bind it, then Save.',{priority:cap})+'</div>');
}
function _ruleRiskConfirmText(vr){
  vr=vr||{};const st=vr.stats||{},lines=[];
  lines.push(ui('rule_risk_confirm','This rule may affect more messages than intended. Save it anyway?'));
  if(st.scanned!==undefined&&st.scanned>0)lines.push(ui('rule_impact_summary','Current preview: {matched}/{scanned} messages, {senders} sender(s).',{matched:st.matched||0,scanned:st.scanned||0,senders:st.senders||0}));
  for(const w of (vr.warnings||[]).slice(0,5))lines.push('• '+w);
  lines.push(ui('rule_can_refine','Cancel to refine the rule instead.'));
  return lines.join('\n');
}
async function ppSave(){
  var d=window._ppData||{};
  var bind=(document.getElementById('pp-bind')||{}).value||'from';
  var n=_ppReadPrio();
  var cap='P'+n;
  var matchVal='', matchOn='from';
  if(bind==='from'){
    if(!d.a){ flash(ui('sender_email_required','Cannot create a sender priority rule without the real sender email.')); return; }
    matchVal=d.a; matchOn='from';
  }
  else if(bind==='tag'){
    var tsel=document.getElementById('pp-tag');
    matchVal = tsel ? tsel.value : (d.t[0]||'');
    matchOn='tag';
  } else {
    matchVal=(document.getElementById('pp-kw')||{}).value.trim();
    matchOn='subject';
  }
  if(!matchVal){ flash(ui('nothing_to_pin','Nothing to pin.')); return; }
  var payload={match:matchVal, match_on:matchOn, tag:'',
               min_priority:cap, max_priority:cap,
               scope:'tool:'+((cur&&cur.name)||''), name:(cur&&cur.name)||''};
  try{
    var r=await api('/api/tag_rule',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});
    if(r&&r.needs_confirmation){
      if(!confirm(_ruleRiskConfirmText(r.validation))) return;
      payload.confirm_risk=true;
      r=await api('/api/tag_rule',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});
    }
    if(r&&r.ok){
      var label=bind==='from'?ui('sender','sender'):bind==='tag'?ui('tag','tag'):ui('keyword','keyword');
      flash(ui('rule_pinned','📌 {label} "{match}" → always {priority}',{label:label,match:matchVal.slice(0,25),priority:cap}));
      closePrioPop();
    } else {
      var verr=(r&&r.validation&&r.validation.errors)||[];
      var msg=verr.length?verr.join('; '):((r&&r.error)||ui('could_not_save_rule','Could not save rule.'));
      flash(ui('quick_rule_failed','Rule not saved: {error}',{error:msg}));
    }
  }catch(e){ flash(ui('could_not_save_rule','Could not save rule.')); }
}

function ppOpenBuilder(){
  var d=window._ppData||{};
  var n=_ppReadPrio(), cap='P'+n;
  closePrioPop();
  return editTag(d.a||d.f,d.s,d.mid,d.src,{min_priority:cap,max_priority:cap});
}
function _ppUpdateBadges(from, cap){
  try{
    document.querySelectorAll('.prio-cell').forEach(function(td){
      var row=td.closest('tr')||td.closest('div');
      if(row&&row.textContent&&row.textContent.indexOf(from.slice(0,20))>=0){
        var pv=td.querySelector('.pval');
        if(pv) pv.outerHTML=pdot(cap);
      }
    });
  }catch(_){}
}

// Wyciagnij UKRYTY mail wyzej: ustaw podloge P2 dla nadawcy. Od nastepnego runu
// scoring podnosi go i oznacza important=True -> nie wpada juz do 'hidden'.
async function promoteHidden(from){
  from=(from||'').trim();
  if(!from){ flash(ui('no_sender','No sender.')); return; }
  try{
    const r=await api('/api/tag_rule',{method:'POST',headers:{'Content-Type':'application/json'},
      body:JSON.stringify({match:from, match_on:'from', tag:'', min_priority:'P2', max_priority:'',
                           scope:'tool:'+((cur&&cur.name)||'')})});
    if(r&&r.ok) flash(ui('sender_promoted','"{sender}" will no longer be hidden — higher from next run (P2).',{sender:from.slice(0,30)}));
    else flash(ui('failed_optional_error','Failed{error}',{error:(r&&r.error)?': '+r.error:'.'}));
  }catch(e){ flash(ui('failed_plain','Failed.')); }
}

// Oznacz nadawcę jako promo/ad. Reguła OGÓLNA (match=nadawca), zero hardcode domen.
// NIE wymusza sztywno P5 — user wybiera poziom (bo bardzo oplacalna promocja moze
// byc warta P4/P3), a tag "🏷 promo" zostaje i wiaze sie z bazowym ukrywaniem promo.
// Domyslnie P5 (chowane), ale mozna podniesc — reguly usera i tak sa nadrzedne.
function markPromo(from){
  from=(from||'').trim();
  if(!from){ flash(ui('no_sender','No sender.')); return; }
  const html=`<div style="font-weight:700;color:var(--acc);margin-bottom:8px">${ui('mark_as_promo','🏷 Mark as promo/ad')}</div>
    <div class="hint" style="margin-bottom:10px"><b>${esc(from)}</b><br>${ui('promo_rule_hint','General rule for this sender — “promo” tag + chosen importance level.')}</div>
    <label>${ui('promo_importance','How important are its promos?')}</label>
    <select id="mp-cap">
      <option value="P5">${ui('promo_p5','P5 — never important, hidden with other promo (default)')}</option>
      <option value="P4">${ui('promo_p4','P4 — rarely important, but show under “Worth a look”')}</option>
      <option value="P3">${ui('promo_p3','P3 — sometimes valuable, show higher')}</option>
    </select>
    <div class="hint" style="margin-top:8px">${ui('promo_tag_stays','The “🏷 promo” tag remains regardless of the level — you can change it later in Rules.')}</div>
    <div style="display:flex;gap:8px;margin-top:12px">
      <button class="btn" style="flex:1" onclick="markPromoApply(${JSON.stringify(from)})">${ui('save_rule','✓ Save rule')}</button>
      <button class="btn ghost" onclick="closeModal()">${ui('cancel','Cancel')}</button>
    </div>`;
  openModal(html);
}
async function markPromoApply(from){
  const cap=(($('#mp-cap')||{}).value)||'P5';
  try{
    const r=await api('/api/tag_rule',{method:'POST',headers:{'Content-Type':'application/json'},
      body:JSON.stringify({match:from, match_on:'from', tag:'🏷 promo',
                           min_priority:cap, max_priority:cap, scope:'tool:'+((cur&&cur.name)||'')})});
    closeModal();
    if(r&&r.ok){
      try{
        document.querySelectorAll('.prio-cell').forEach(td=>{
          const row=td.closest('tr'); if(!row) return;
          if(row.textContent && row.textContent.indexOf(from.slice(0,20))>=0){
            const dot=td.querySelector('span'); if(dot){ dot.outerHTML=pdot(cap); }
          }
        });
      }catch(_){}
      flash(ui('marked_as_promo','Marked {sender} as promo ({priority}).',{sender:from.slice(0,30),priority:cap}));
    } else flash(ui('failed_optional_error','Failed{error}',{error:(r&&r.error)?': '+r.error:'.'}));
  }catch(e){ closeModal(); flash(ui('failed_plain','Failed.')); }
}
function _ruleActionsText(rule){
  const a=[];if(rule&&rule.tag)a.push('tag='+rule.tag);if(rule&&rule.min_priority)a.push('floor='+rule.min_priority);if(rule&&rule.max_priority)a.push('ceiling='+rule.max_priority);if(rule&&rule.show)a.push('show');if(rule&&rule.stop)a.push('stop');return a.join(' + ')||'—';
}
function _ruleLabel(rule,index){return '#'+(index+1)+' · '+(rule.where||'all')+' · '+((rule.match_mode||'any').toUpperCase())+' · '+((rule.match||[]).join(' + '))+' → '+_ruleActionsText(rule);}
function selectExistingRuleForEdit(value){
  const idx=parseInt(value,10),list=window._trAllCustomRules||[],banner=$('#tr-existing-detail');
  if(!Number.isFinite(idx)||idx<0||!list[idx]){
    window._trExistingIndex=-1;window._trExisting=null;window._trCondition=null;
    if(banner)banner.innerHTML=ui('new_rule_mode','New rule — nothing existing will be replaced.');
    const mode=$('#tr-builder-mode');if(mode)mode.value=window._trMid?'guided':'expert';
    ruleBuilderModeChanged();return;
  }
  const r=list[idx];window._trExistingIndex=idx;window._trExisting=r;
  const set=(id,v)=>{const e=$(id);if(e)e.value=v||'';};set('#tr-tag',r.tag||'');set('#tr-floor',r.min_priority||'');set('#tr-cap',r.max_priority||'');set('#tr-scope',r.scope||'all');set('#tr-on',r.where||'all');set('#tr-match-mode',r.match_mode||'any');set('#tr-word',(r.match||[]).join(', '));
  const sh=$('#tr-show');if(sh){if(r.show)sh.classList.add('on');else sh.classList.remove('on');}
  window._trCondition={match:(r.match||[]).slice(),where:r.where||'all',match_mode:r.match_mode||'any'};
  const mode=$('#tr-builder-mode');if(mode)mode.value='expert';ruleBuilderModeChanged();
  if(banner)banner.innerHTML='<b>'+ui('editing_existing_rule','Editing existing rule')+'</b><br><code>'+esc(_ruleLabel(r,idx))+'</code>';
  previewRule();
}
async function deleteExistingRule(){
  const idx=window._trExistingIndex;if(!Number.isFinite(idx)||idx<0)return;
  if(!confirm(ui('delete_this_rule_confirm','Delete this exact custom rule? Factory rules are not affected.')))return;
  const r=await api('/api/tags_remove_index',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({index:idx,name:(cur&&cur.name)||''})});
  if(r&&r.ok){flash(ui('rule_deleted','Rule deleted.'));closeModal();loadTagRules();}else flash(ui('failed_plain','Failed.'));
}
async function editTag(from, summary, mid, src, seedAction){
  const nm=(cur&&cur.name)||'';let _allTags=[],custom=[];
  try{
    const r=await api('/api/tags?name='+encodeURIComponent(nm));
    if(r&&!r._offline){custom=(r.custom||[]);const seen=new Set();for(const t of [].concat(r.used||[],r.builtin||[],r.ai||[],custom.map(c=>c.tag))){const v=(t||'').trim();if(v&&!seen.has(v.toLowerCase())){seen.add(v.toLowerCase());_allTags.push(v);}}}
  }catch(e){}
  seedAction=seedAction||{};const currentTags=Array.isArray(seedAction.current_tags)?seedAction.current_tags:[];
  const fromNorm=String(from||'').trim().toLowerCase(),srcNorm=String(src||'').trim().toLowerCase(),tagNorm=new Set(currentTags.map(x=>String(x||'').trim().toLowerCase()));
  const matches=[];custom.forEach((rule,index)=>{const where=String(rule.where||rule.match_on||'all').toLowerCase(),terms=(rule.match||[]).map(x=>String(x||'').trim().toLowerCase());let hit=false;if(where==='from')hit=terms.includes(fromNorm);else if(where==='source')hit=terms.includes(srcNorm);else if(where==='tag')hit=terms.some(x=>tagNorm.has(x));if(hit)matches.push({rule,index});});
  const first=matches.length?matches[0]:null,existing=first&&first.rule;
  const eTag=existing?(existing.tag||''):(seedAction.tag||'');const eCap=existing?(existing.max_priority||''):(seedAction.max_priority||'');const eFloor=existing?(existing.min_priority||''):(seedAction.min_priority||'');const eShow=existing?!!existing.show:!!seedAction.show;
  const eScope=existing?(existing.scope||('tool:'+nm)):('tool:'+nm),eWhere=existing?(existing.where||'from'):'subject',eMode=existing?(existing.match_mode||'any'):'any',eMatch=existing?((existing.match||[]).join(', ')):'';
  window._trFrom=from||'';window._trMid=mid||'';window._trSrc=src||'';window._trExisting=existing||null;window._trExistingIndex=first?first.index:-1;window._trAllCustomRules=custom;
  let existingBox='';
  if(matches.length){existingBox=`<div style="margin-bottom:9px;padding:8px;background:#f0fdf4;border:1px solid #bbf7d0;border-radius:7px"><b>${ui('existing_rules_affect_message','Existing custom rule(s) affecting this message')}</b><select id="tr-existing-select" onchange="selectExistingRuleForEdit(this.value)" style="display:block;width:100%;margin-top:5px;padding:5px">${matches.map(x=>`<option value="${x.index}" ${x.index===window._trExistingIndex?'selected':''}>${esc(_ruleLabel(x.rule,x.index))}</option>`).join('')}<option value="-1">＋ ${ui('create_new_rule','Create a new rule instead')}</option></select><div id="tr-existing-detail" class="hint" style="margin-top:5px"><b>${ui('editing_existing_rule','Editing existing rule')}</b><br><code>${esc(_ruleLabel(existing,first.index))}</code></div></div>`;}
  const html=`<div style="font-weight:700;color:var(--acc);font-size:16px;margin-bottom:4px">${ui('safe_rule_builder','✎ Safe rule builder')}</div><div class="hint" style="margin-bottom:10px"><b>${esc(from||'')}</b><br>${esc((summary||'').slice(0,120))}</div>${existingBox}
    <div style="font-weight:600;margin:8px 0 4px">1. ${ui('rule_action_step','What should change?')}</div><div class="row"><div><label>${ui('tag_optional','Tag (optional)')}</label><input id="tr-tag" list="tr-taglist" value="${esc(eTag)}" placeholder='${esc(ui('tag_picker_placeholder','pick or type — e.g. "🎓 study"'))}'><datalist id="tr-taglist">${_allTags.map(t=>`<option value="${esc(t)}">`).join('')}</datalist></div><div><label>${ui('always_show','Always show')}</label><label class="chk ${eShow?'on':''}" id="tr-show" onclick="this.classList.toggle('on')"><span></span> ${ui('never_hide','never hide')}</label></div></div>
    <div class="row"><div><label>${ui('priority_floor','Priority floor — never less important than')}</label><select id="tr-floor">${_prioOptions(eFloor)}</select></div><div><label>${ui('priority_ceiling','Priority ceiling — never more important than')}</label><select id="tr-cap">${_prioOptions(eCap)}</select></div></div><div class="hint">${ui('priority_bounds_hint','Exact lock: set both to the same P. One-sided bounds remain reviewable. P1/P1! and hide-style rules receive stricter validation.')}</div>
    <div style="font-weight:600;margin:14px 0 4px">2. ${ui('rule_condition_step','Which similar messages should this apply to?')}</div><div style="display:flex;gap:7px;align-items:center;flex-wrap:wrap"><select id="tr-builder-mode" onchange="ruleBuilderModeChanged()" style="min-width:190px"><option value="guided" ${(!existing&&mid)?'selected':''}>${ui('guided_no_ai','Guided — no AI')}</option><option value="ai">${ui('ai_assisted_rule','AI-assisted')}</option><option value="expert" ${(existing||!mid)?'selected':''}>${ui('manual_expert','Manual / expert')}</option></select><span class="hint">${ui('rule_builder_mode_hint','All modes use the same backend validator before saving.')}</span></div><div id="tr-builder-body" style="margin-top:8px"></div>
    <div id="tr-manual" style="margin-top:8px;display:none;padding:8px;border:1px solid var(--line);border-radius:8px"><div class="row"><div><label>${ui('match_in','Match in')}</label><select id="tr-on" onchange="ruleConditionChanged()">${_whereOptions(eWhere)}</select></div><div><label>${ui('match_logic','Match logic')}</label><select id="tr-match-mode" onchange="ruleConditionChanged()"><option value="any" ${eMode==='all'?'':'selected'}>ANY — ${ui('any_term','any term')}</option><option value="all" ${eMode==='all'?'selected':''}>ALL — ${ui('all_terms','all terms together')}</option></select></div></div><label>${ui('match','Match')}</label><input id="tr-word" value="${esc(eMatch)}" oninput="ruleConditionChanged()" placeholder="${esc(ui('match_phrase_hint','distinctive phrase; separate multiple cues with commas'))}"><div class="hint">${ui('match_logic_hint','ANY makes every term an independent trigger. ALL is safer when several cues must occur together.')}</div></div>
    <label style="margin-top:10px">${ui('scope','Scope')}</label><input id="tr-scope" list="tr-scopes" value="${esc(eScope)}"><datalist id="tr-scopes"><option value="tool:${esc(nm)}"><option value="kind:reporter"><option value="kind:collector"><option value="all"></datalist><label class="chk" id="tr-translate" onclick="this.classList.toggle('on')" style="margin-top:8px"><span></span> ${ui('translate_after_save','Generate equally-specific language variants with configured AI')}</label><div class="hint">${ui('translate_after_save_hint','Optional. Sender/source/tag identifiers are never translated. Text translations are kept per language instead of being mixed into one global keyword list.')}</div>
    <div style="font-weight:600;margin:14px 0 4px">3. ${ui('validate_save_step','Validate, preview, then save')}</div><div class="bar"><button class="btn ghost" onclick="previewRule()">${ui('validate_preview','🔍 Validate + preview')}</button><button class="btn" id="tr-save" onclick="saveTagRule()">${existing?ui('update_rule','Update this rule'):ui('save_rule_plain','Save rule')}</button>${existing?`<button class="btn ghost" style="color:var(--red)" onclick="deleteExistingRule()">${ui('delete_this_rule','Delete this rule')}</button>`:''}</div><label id="tr-expert-wrap" style="display:none;margin-top:6px"><input type="checkbox" id="tr-expert-override"> ${ui('expert_override','Expert override for breadth warnings/high-impact single-word rules')}</label><span class="hint" id="tr-stat" style="display:block;margin-top:6px"></span><div id="tr-prev" style="margin-top:8px"></div><div class="bar" style="margin-top:8px">${backBtn()}</div>`;
  openModal(html);window._trCondition=existing?{match:(existing.match||[]).slice(),where:eWhere,match_mode:eMode}:null;ruleBuilderModeChanged();if(existing)setTimeout(()=>selectExistingRuleForEdit(String(window._trExistingIndex)),0);
}

function _currentCorrection(){
  return {tag:(($('#tr-tag')||{}).value||'').trim(),min_priority:(($('#tr-floor')||{}).value||''),max_priority:(($('#tr-cap')||{}).value||''),show:!!($('#tr-show')&&$('#tr-show').classList.contains('on'))};
}
function _manualCondition(){
  const where=(($('#tr-on')||{}).value||'subject'),raw=(($('#tr-word')||{}).value||'').trim();
  let match=raw.split(',').map(x=>x.trim()).filter(Boolean);
  if(where==='from'&&!match.length&&window._trFrom)match=[window._trFrom];
  return {match,where,match_mode:(($('#tr-match-mode')||{}).value||'any')};
}
function _applyRuleCondition(rule,label){
  if(!rule)return;window._trCondition={match:(rule.match||[]).slice(),where:rule.where||'all',match_mode:rule.match_mode||'any'};
  const on=$('#tr-on'),word=$('#tr-word'),mode=$('#tr-match-mode');if(on)on.value=window._trCondition.where;if(word)word.value=(window._trCondition.match||[]).join(', ');if(mode)mode.value=window._trCondition.match_mode;
  const body=$('#tr-builder-body');if(body)body.innerHTML='<div style="padding:7px 9px;background:#eff4ff;border-radius:7px"><b>'+esc(label||ui('selected_condition','Selected condition'))+'</b><br><span class="hint">'+esc(window._trCondition.where)+' · '+esc(window._trCondition.match_mode.toUpperCase())+' · '+esc(window._trCondition.match.join(' + '))+'</span></div>';
  previewRule();
}
function useGuideCandidate(i){const c=(window._trGuideCandidates||[])[i];if(c)_applyRuleCondition(c.rule,c.kind+': '+c.label);}
async function loadGuidedRuleChoices(){
  const body=$('#tr-builder-body');if(!body)return;if(!window._trMid){body.innerHTML='<div class="hint">'+ui('guide_needs_message','Guided mode needs a message from the latest report. Use Manual here, or run the tool and open Fix tag from a message.')+'</div>';return;}
  body.innerHTML='<span class="hint">'+ui('analyzing_without_ai','Analyzing literal phrases locally…')+'</span>';
  try{const r=await api('/api/rule_guide',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name:(cur&&cur.name)||'',mid:window._trMid})});
    if(!r||!r.ok){body.innerHTML='<span style="color:var(--red)">'+esc((r&&r.error)||ui('failed_plain','Failed.'))+'</span>';return;}
    window._trGuideCandidates=r.candidates||[];
    let h='<div class="hint" style="margin-bottom:5px">'+ui('guided_choose_evidence','Choose the evidence that really defines similar messages. Nothing is saved yet.')+'</div>';
    (window._trGuideCandidates||[]).forEach((c,i)=>{const st=c.stats||{};const meta=st.scanned?` · ${st.matched||0}/${st.scanned}`:'';h+=`<button class="btn ghost" style="margin:2px 4px 2px 0;padding:4px 8px;font-size:11px" onclick="useGuideCandidate(${i})">${esc(c.kind)}: ${esc(c.label)}${esc(meta)}</button>`;});
    body.innerHTML=h||'<div class="hint">'+ui('no_safe_candidates','No safe literal candidate found; use AI-assisted or Manual.')+'</div>';
  }catch(e){body.innerHTML='<span style="color:var(--red)">'+ui('failed_plain','Failed.')+'</span>';}
}
async function requestAiRuleSuggestion(){
  const body=$('#tr-builder-body');if(!body)return;if(!window._trMid){body.innerHTML='<div class="hint">'+ui('ai_rule_needs_message','AI-assisted learning needs the clicked message in the latest cache.')+'</div>';return;}
  body.innerHTML='<span class="hint">'+ui('ai_finding_narrow_rule','AI is looking for the narrowest reusable literal condition…')+'</span>';
  try{const r=await api('/api/rule_suggest',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name:(cur&&cur.name)||'',mid:window._trMid,correction:_currentCorrection()})});
    if(!r||!r.ok){body.innerHTML='<span style="color:var(--red)">'+esc((r&&r.error)||ui('failed_plain','Failed.'))+'</span>';return;}
    if(r.no_rule){body.innerHTML='<div class="hint">'+ui('ai_no_safe_rule','AI did not find enough evidence for a reusable rule: ') + esc(r.reason||'')+'</div>';return;}
    window._trAiCandidate=r.rule;const vr=r.validation||{};body.innerHTML=`<div style="padding:8px;background:#f0fdf4;border-radius:8px"><b>${ui('ai_suggestion','AI suggestion')}</b><br>${esc((r.rule.match||[]).join(' + '))} <span class="tag">${esc((r.rule.match_mode||'any').toUpperCase())}</span> <span class="tag">${esc(r.rule.where||'all')}</span><br><span class="hint">${esc(r.reason||'')}${vr.risk?' · risk '+esc(vr.risk):''}</span><div style="margin-top:6px"><button class="btn" onclick="_applyRuleCondition(window._trAiCandidate,'AI suggestion')">${ui('use_suggestion','Use suggestion')}</button></div></div>`;
  }catch(e){body.innerHTML='<span style="color:var(--red)">'+ui('failed_plain','Failed.')+'</span>';}
}
function ruleBuilderModeChanged(){
  const mode=(($('#tr-builder-mode')||{}).value||'guided'),manual=$('#tr-manual'),expert=$('#tr-expert-wrap'),body=$('#tr-builder-body'),tr=$('#tr-translate');
  if(manual)manual.style.display=mode==='expert'?'block':'none';if(expert)expert.style.display=mode==='expert'?'block':'none';
  if(mode==='guided'){if(tr)tr.classList.remove('on');loadGuidedRuleChoices();}
  else if(mode==='ai'){if(tr)tr.classList.add('on');if(body)body.innerHTML='<button class="btn" onclick="requestAiRuleSuggestion()">'+ui('suggest_safe_condition','🤖 Suggest safe condition')+'</button><div class="hint" style="margin-top:4px">'+ui('ai_does_not_choose_action','AI chooses only the condition. Your tag/P/show action stays exactly as selected above.')+'</div>';}
  else {if(body)body.innerHTML='<div class="hint">'+ui('manual_rule_hint','Manual mode exposes the raw matcher. The same validator still runs before save.')+'</div>';ruleConditionChanged();}
}
function ruleConditionChanged(){if((($('#tr-builder-mode')||{}).value||'')==='expert')window._trCondition=_manualCondition();}
function _ruleDraft(){
  const cond=((($('#tr-builder-mode')||{}).value||'')==='expert')?_manualCondition():window._trCondition;if(!cond)return null;
  return Object.assign({},cond,_currentCorrection(),{scope:(($('#tr-scope')||{}).value||'all')});
}
function _renderRuleValidation(vr){
  const box=$('#tr-prev');if(!box)return;const st=(vr&&vr.stats)||{};
  const invalid=!(vr&&vr.ok),needs=!!(vr&&vr.requires_confirmation);
  const bg=invalid?'#fef2f2':(needs?'#fffbeb':'#f0fdf4');
  const head=invalid?ui('validation_blocked','⛔ Invalid rule'):(needs?ui('validation_review','⚠ Review before saving'):ui('validation_passed','✓ Validation passed'));
  let h=`<div style="padding:8px;border-radius:8px;background:${bg}"><b>${head}</b> <span class="tag">${esc((vr&&vr.risk)||'?')}</span>`;
  if(st.scanned!==undefined)h+=`<br><span class="hint">${ui('rule_matches_count','Matches <b>{matched}</b> of {scanned} messages in your last report.',{matched:st.matched||0,scanned:st.scanned||0})} ${st.senders?ui('across_senders','across {count} senders',{count:st.senders}):''}</span>`;
  for(const e of (vr&&vr.errors||[]))h+='<div style="color:var(--red);margin-top:4px">• '+esc(e)+'</div>';for(const w of (vr&&vr.warnings||[]))h+='<div style="color:#92400e;margin-top:4px">• '+esc(w)+'</div>';
  if(st.examples&&st.examples.length){h+='<div style="margin-top:5px;font-size:11px;max-height:120px;overflow:auto">';for(const e of st.examples)h+=`<div>${esc(e.priority||'')} · ${esc(e.from||'')} — ${esc(e.title||'')}</div>`;h+='</div>';}
  box.innerHTML=h+'</div>';
}

async function previewRule(){
  const st=$('#tr-stat'),rule=_ruleDraft();if(!rule||!(rule.match||[]).length){if(st)st.textContent=ui('choose_condition_first','Choose a condition first.');return null;}if(st)st.textContent=ui('checking','Checking…');
  try{const expert=!!($('#tr-expert-override')&&$('#tr-expert-override').checked);const r=await api('/api/rule_validate',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name:(cur&&cur.name)||'',rule,expert_override:expert})});if(st)st.textContent='';_renderRuleValidation(r);return r;}catch(e){if(st)st.textContent=ui('check_failed','Check failed.');return null;}
}
async function saveTagRule(){
  const st=$('#tr-stat'),rule=_ruleDraft();if(!rule||!(rule.match||[]).length){if(st)st.textContent=ui('choose_condition_first','Choose a condition first.');return;}
  if(!rule.tag&&!rule.min_priority&&!rule.max_priority&&!rule.show){if(st)st.textContent=ui('choose_rule_action','Choose at least one action: tag, floor, ceiling, or Always show.');return;}
  const expert=!!($('#tr-expert-override')&&$('#tr-expert-override').checked),vr=await previewRule();if(!vr||!vr.ok){if(st)st.textContent=ui('fix_invalid_before_save','Fix the invalid rule before saving.');return;}
  let confirmed=expert;
  if(vr.requires_confirmation&&!expert){if(!confirm(_ruleRiskConfirmText(vr)))return;confirmed=true;}
  const payload={match:rule.match,match_on:rule.where,match_mode:rule.match_mode,tag:rule.tag||'',min_priority:rule.min_priority||'',max_priority:rule.max_priority||'',show:!!rule.show,scope:rule.scope||'all',name:(cur&&cur.name)||'',expert_override:expert,confirm_risk:confirmed,translate:!!($('#tr-translate')&&$('#tr-translate').classList.contains('on'))};
  if(Number.isFinite(window._trExistingIndex)&&window._trExistingIndex>=0)payload.replace_index=window._trExistingIndex;
  try{let rr=await api('/api/tag_rule',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});
    if(rr&&rr.needs_confirmation){if(!confirm(_ruleRiskConfirmText(rr.validation)))return;payload.confirm_risk=true;rr=await api('/api/tag_rule',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});}
    if(rr&&rr.ok===false){if(st)st.innerHTML='<span style="color:var(--red)">'+esc((rr.validation&&rr.validation.errors||[]).join('; ')||rr.error||ui('could_not_save','Could not save.'))+'</span>';if(rr.validation)_renderRuleValidation(rr.validation);return;}
    if(rr&&Number.isFinite(rr.index))window._trExistingIndex=rr.index;
    if(st)st.innerHTML='<span style="color:var(--green)">'+ui('saved_applies_next_run','Saved — applies on the next Run.')+'</span>';if(rr&&rr.translated)toast(ui('rule_translated_languages','Rule saved with {count} language variant(s).',{count:rr.translated}));
  }catch(e){if(st)st.innerHTML='<span style="color:var(--red)">'+ui('could_not_save','Could not save.')+'</span>';}
}


async function removeTagsFor(from){
  if(!from) return;
  if(!confirm(ui('remove_tag_rules_confirm','Remove the custom tag action for "{sender}"?\nPriority/show actions on the same sender are preserved.',{sender:from}))) return;
  try{
    const r=await api('/api/tags_remove_for',{method:'POST',headers:{'Content-Type':'application/json'},
      body:JSON.stringify({match:from, where:'from', mode:'tag', name:(cur&&cur.name)||''})});
    if(r&&r.ok) flash(ui('tag_rules_removed','🗑 Tag action for "{sender}" removed — priority/show actions were preserved.',{sender:from}));
    else flash(ui('could_not_remove','Could not remove: {error}',{error:(r&&r.error)||ui('unknown','unknown')}));
  }catch(e){ flash(ui('failed_remove_tags','Failed to remove tags.')); }
}
// "Always / never summarize" is a rule action like any other, saved through the
// same endpoint and visible in the rules list — not a hidden per-sender setting.
async function summaryRule(from, always){
  if(!from) return;
  const q = always
    ? ui('always_sum_confirm','Always summarize messages from "{sender}", whatever priority they get?',{sender:from})
    : ui('never_sum_confirm','Never summarize messages from "{sender}"? An explicit "never" also overrides the P1/P2 rule.',{sender:from});
  if(!confirm(q)) return;
  const payload={match:from, match_on:'from', scope:'tool:'+((cur&&cur.name)||''), name:(cur&&cur.name)||''};
  payload[always?'always_summary':'never_summary']=true;
  payload[always?'never_summary':'always_summary']=false;
  let r=await api('/api/tag_rule',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});
  if(r&&r.needs_confirmation){ if(!confirm(_ruleRiskConfirmText(r.validation))) return;
    payload.confirm_risk=true;
    r=await api('/api/tag_rule',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)}); }
  if(r&&r.ok) flash(always?ui('always_sum_saved','📄 "{sender}" will always be summarized.',{sender:from})
                         :ui('never_sum_saved','🚫 "{sender}" will not be summarized.',{sender:from}));
  else flash(ui('quick_rule_failed','Rule not saved: {error}',{error:(r&&r.error)||''}));
}
async function markHideAlways(from){
  if(!from) return;
  if(!confirm(ui('hide_sender_confirm','Always hide messages from "{sender}"?\nThey will get P5 + promo tag and appear in the hidden section.',{sender:from}))) return;
  try{
    await api('/api/tag_rule',{method:'POST',headers:{'Content-Type':'application/json'},
      body:JSON.stringify({match:from, match_on:'from', tag:'🏷 promo', min_priority:'', max_priority:'P5',
                           scope:'all'})});
    flash(ui('sender_hidden','👁‍🗨 "{sender}" will be hidden from now on.',{sender:from}));
  }catch(e){ flash(ui('failed_plain','Failed.')); }
}
async function unhideSender(from){
  if(!from) return;
  if(!confirm(ui('unhide_sender_confirm','Remove hide/promo rules for "{sender}"?\nTheir messages will appear normally again.',{sender:from}))) return;
  try{
    await api('/api/tags_remove_for',{method:'POST',headers:{'Content-Type':'application/json'},
      body:JSON.stringify({match:from, where:'from', mode:'hide'})});
    flash(ui('sender_unhidden','👁 "{sender}" is no longer hidden. Re-run to see the change.',{sender:from}));
  }catch(e){ flash(ui('failed_plain','Failed.')); }
}
function addNote(from, summary, deadline){
  // PORZADNY FORMULARZ (nie prompt): data + godzina + notatka + kiedy przypomniec
  const d=deadline||'';
  const html=`<div style="font-weight:700;color:var(--acc);margin-bottom:10px">${ui('add_reminder','🔔 Add a reminder')}</div>
    <label>${ui('what_is_it','What is it?')}</label>
    <input id="rm-title" value="${esc((from?from+': ':'')+(summary||'').slice(0,70))}">
    <div class="row" style="margin-top:10px">
      <div><label>${ui('date','Date')}</label><input id="rm-date" type="date" value="${_toISO(d)}"></div>
      <div><label>${ui('time_optional','Time (optional)')}</label><input id="rm-time" type="time" value="09:00"></div>
    </div>
    <label style="margin-top:10px">${ui('note_optional','Note (optional)')}</label>
    <textarea id="rm-note" rows="2" placeholder="${esc(ui('reminder_note_placeholder','Anything you want to remember about this'))}">${esc(summary||'')}</textarea>
    <label style="margin-top:10px">${ui('remind_me','Remind me')}</label>
    <div>
      <label class="chk on" id="rm-p1" onclick="this.classList.toggle('on')"><span></span> ${ui('one_day_before','1 day before')}</label>
      <label class="chk on" id="rm-p2" onclick="this.classList.toggle('on')"><span></span> ${ui('two_hours_before','2 hours before')}</label>
      <label class="chk" id="rm-p3" onclick="this.classList.toggle('on')"><span></span> ${ui('thirty_days_before','30 days before')}</label>
      <label class="chk" id="rm-p4" onclick="this.classList.toggle('on')"><span></span> ${ui('on_the_day','on the day')}</label>
    </div>
    <div class="hint">${ui('reminder_defaults','Default: a day before and 2 hours before. Tick more if you want earlier warnings.')}</div>
    <div class="bar">
      <button class="btn" onclick="saveNote()">${ui('add_to_calendar','Add to calendar')}</button>
      <button class="btn ghost" onclick="showCalendar()">${ui('cancel','Cancel')}</button>
    </div>`;
  openModal(html);
}
function _toISO(d){
  // "15.07.2026" -> "2026-07-15" (dla <input type=date>)
  const m=(d||'').match(/(\d{1,2})\.(\d{1,2})\.?(\d{4})?/);
  if(!m) return '';
  const yy=m[3]||new Date().getFullYear();
  return `${yy}-${String(m[2]).padStart(2,'0')}-${String(m[1]).padStart(2,'0')}`;
}
async function saveNote(){
  const title=($('#rm-title')||{}).value||'';
  if(!title){alert(ui('reminder_name_required','What is it? Give it a name.'));return;}
  const iso=($('#rm-date')||{}).value||'';
  const time=($('#rm-time')||{}).value||'';
  // ISO -> DD.MM.YYYY (format ktory rozumie kalendarz)
  let when='';
  if(iso){ const [y,mo,dd]=iso.split('-'); when=`${dd}.${mo}.${y}`; }
  const lead=[];
  if($('#rm-p3')&&$('#rm-p3').classList.contains('on')) lead.push(30);
  if($('#rm-p1')&&$('#rm-p1').classList.contains('on')) lead.push(1);
  if($('#rm-p4')&&$('#rm-p4').classList.contains('on')) lead.push(0);
  const hours2=$('#rm-p2')&&$('#rm-p2').classList.contains('on');
  try{
    await api('/api/calendar_add',{method:'POST',headers:{'Content-Type':'application/json'},
      body:JSON.stringify({agent:window._rname||'me',kind:when?'deadline':'note',
        title:title, when:when, time:time,
        note:($('#rm-note')||{}).value||'',
        lead_days:lead, remind_2h:hours2})});
    closeModal();
  }catch(e){ alert(ui('could_not_add','Could not add: {error}',{error:e})); }
}
// JEDEN wyglad streszczenia dla auto (tabela) i on-demand (guzik 📄). Zwijany
// <details open>, ten sam kolor/border/tlo/overflow. Kopia, nie osobne wersje.
function summaryDetails(text, expanded){
  const col='var(--acc2)';
  // One renderer for BOTH automatic and on-demand summaries. Keeping the full
  // card (border/background/header) here prevents the auto-summary from looking
  // like plain text while the 📄 action uses a separate visual treatment.
  return `<details open class="mail-summary-box" style="margin-top:6px;border:1px solid var(--line);border-left:3px solid ${col};border-radius:7px;background:#f8fafc;overflow:hidden">`+
    `<summary style="cursor:pointer;font-size:12px;color:${col};font-weight:600;padding:5px 8px;background:#f1f5f9">`+
      `${expanded?ui('detailed_summary','📄 Detailed summary'):ui('summary','📄 Summary')}`+
      `<span style="font-weight:400;opacity:.7;margin-left:6px">${expanded?ui('summary_on_request','on request'):ui('summary_automatic','automatic')}</span>`+
    `</summary>`+
    `<div style="color:var(--txt);font-size:12px;padding:7px 9px;white-space:pre-wrap;word-break:break-word;max-height:300px;overflow:auto">${esc(text)}</div></details>`;
}
async function mailAction(kind, mid, src, slot, variant){
  const el=document.getElementById(slot);
  if(!mid){ if(el) el.innerHTML='<span class="hint">'+ui('no_message_id','No message id — click Run once, then the buttons work.')+'</span>'; return; }
  if(variant===undefined) variant=0;
  if(el) el.innerHTML='<span class="hint">'+ui('working_plain','⏳ working…')+'</span>';
  try{
    const r=await api('/api/mailaction',{method:'POST',headers:{'Content-Type':'application/json'},
      body:JSON.stringify({name:window._rname,mid:mid,src:src,kind:kind,variant:variant})});
    const txt=r.result||'(empty)';
    if(el){
      const ico={summary:'📄',draft:'✍',full:'📋',explain:'🧠'}[kind]||'•';
      const col={summary:'var(--acc2)',draft:'var(--acc)',full:'var(--txt)',explain:'var(--acc)'}[kind]||'var(--txt)';
      // przy draftcie: przycisk ↻ generuje KOLEJNY, inny wariant (rosnaca temperatura)
      let again='';
      if(kind==='draft'){
        const nv=variant+1;
        const args=JSON.stringify(mid)+','+JSON.stringify(src)+','+JSON.stringify(slot)+','+nv;
        again=`<button onclick='mailAction("draft",${args})' title="${esc(ui('different_draft','Generate a different draft'))}"
           style="position:sticky;float:right;top:0;margin-right:6px;background:#fff;border:1px solid var(--line);
           border-radius:4px;cursor:pointer;padding:1px 6px;font-size:11px;color:var(--acc)">↻ ${ui('another','another')}</button>`;
      }
      // Wynik (m.in. "why priority?") w <details open>: pojawia sie rozwiniety (jak dotad),
      // ale teraz user moze go ZWINAC klikiem na naglowek zamiast tylko usuwac przez ✕ —
      // zajmuje mniej miejsca bez utraty tresci.
      if(kind==='summary'){
        el.innerHTML=summaryDetails(txt,true);
      } else {
      el.innerHTML=`<details open style="margin-top:4px">`+
        `<summary style="cursor:pointer;font-size:12px;color:${col}">${ico} ${kind==='explain'?ui('why_priority','Why this priority & tags?'):ui('mail_action_'+kind,kind)}</summary>`+
        `<div style="color:${col};font-size:12px;margin-top:4px;padding:6px 8px;background:#f8fafc;border-left:2px solid ${col};border-radius:4px;white-space:pre-wrap;word-break:break-word;max-height:300px;overflow:auto;position:relative">`+
        `<button onclick="document.getElementById('${slot}').innerHTML=''" title="${esc(ui('close','Close'))}"
           style="position:sticky;float:right;top:0;background:#fff;border:1px solid var(--line);
           border-radius:4px;cursor:pointer;padding:1px 6px;font-size:11px;color:var(--dim)">✕</button>`+
        again+
        `${esc(txt)}</div></details>`;
      }
    }
  }catch(e){ if(el) el.innerHTML='<span class="hint" style="color:var(--red)">'+ui('failed_with_error','Failed: {error}',{error:esc(String(e))})+'</span>'; }
}
async function showCollectorResult(r){
  const rows=r.rows||[]; if(rows.length<2){ $('#res').innerHTML='<pre>'+ui('no_rows','(no rows — check the log / sources)')+'</pre>'; return; }
  const head=rows[0], body=rows.slice(1);
  $('#res').innerHTML='<table><tr>'+head.map(h=>`<th>${h}</th>`).join('')+'</tr>'+
    body.map(r=>'<tr>'+r.map(c=>`<td>${(c||'').replace(/</g,'&lt;').slice(0,80)}</td>`).join('')+'</tr>').join('')+'</table>';
}
function _mkAnchorId(mid){ return 'row-'+String(mid).replace(/[^a-zA-Z0-9]/g,'').slice(0,24); }
function fmtReport(t){
  // koloruje raport: naglowki skrzynek, priorytety, podsumowanie, sekcje 'also'/'hidden'
  return t.split('\n').map(line=>{
    // ── LINKI DO WIERSZA: ⟦anchor:MID⟧ w naglowku maila = cel skoku (id, niewidoczny);
    //    ⟦mid:MID⟧ w "Warto zobaczyc"/"TO DO" = klikalny link, ktory tam przewija.
    let anchorId='';
    line=line.replace(/⟦anchor:([^⟧]*)⟧/g,(_,mid)=>{ anchorId=_mkAnchorId(mid); return ''; });
    let clickMid='';
    line=line.replace(/⟦mid:([^⟧]*)⟧/g,(_,mid)=>{ clickMid=mid; return ''; });
    const e=esc(line);
    const idAttr=anchorId?` id="${anchorId}"`:'';
    const wrap=(html)=>{
      if(clickMid){
        const tgt=_mkAnchorId(clickMid);
        return `<div style="cursor:pointer" title="Jump to this mail below" onclick="(function(){var el=document.getElementById('${tgt}');if(el){el.scrollIntoView({behavior:'smooth',block:'center'});el.style.transition='background .2s';el.style.background='#fff3cd';setTimeout(function(){el.style.background='';},1400);}})()">${html} <span style="color:var(--acc);font-size:12px">↗</span></div>`;
      }
      return html;
    };
    if(/^═══.*SUMMARY|^═══.*PODSUMOWANIE|^═══.*RESUMEN/.test(line))
      return `<div${idAttr} style="margin-top:14px;padding:8px 12px;background:#eff4ff;border-left:3px solid var(--acc);font-weight:700;color:var(--acc);border-radius:6px">${e}</div>`;
    if(/^═══/.test(line))
      return `<div${idAttr} style="margin-top:12px;font-weight:700;color:var(--acc2);border-bottom:1px solid var(--line);padding-bottom:3px">${e}</div>`;
    if(/^🔴/.test(line)) return `<div${idAttr} style="color:#dc2626;font-weight:600;margin-top:6px">${e}</div>`;
    if(/^🟠/.test(line)) return `<div${idAttr} style="color:var(--acc2);font-weight:600;margin-top:6px">${e}</div>`;
    if(/^➤/.test(line)) return `<div${idAttr} style="margin-top:8px;color:var(--acc);font-weight:700">${e}</div>`;
    if(/^\s+\+|hidden:|ukryte:|ocultos:/.test(line)) return `<div${idAttr} style="color:var(--dim);font-size:13px">${e}</div>`;
    if(/^\s+·|Also worth|Warto rzucic|Vale la pena/.test(line)) return `<div${idAttr} style="color:var(--dim)">${e}</div>`;
    if(/^\*/.test(line)) return `<div${idAttr} style="font-weight:700;font-size:15px">${e}</div>`;
    // linie "Warto zobaczyc"/"TO DO" (• ...) z linkiem do wiersza
    if(clickMid) return wrap(`<div${idAttr}>${e||'&nbsp;'}</div>`);
    return `<div${idAttr}>${e||'&nbsp;'}</div>`;
  }).join('');
}
function flash(m){ $('#logp').style.display='block'; $('#log').textContent=m; }
function toast(m, ok){
  if(!document.getElementById('toast-css')){
    const s=document.createElement('style'); s.id='toast-css';
    s.textContent='.toast{position:fixed;left:50%;bottom:26px;transform:translate(-50%,20px);'+
      'z-index:300;padding:10px 18px;border-radius:10px;font-size:13px;font-weight:600;color:#fff;'+
      'box-shadow:0 8px 24px rgba(0,0,0,.18);opacity:0;pointer-events:none;transition:opacity .2s,transform .2s}'+
      '.toast.good{background:#16a34a}.toast.bad{background:#dc2626}'+
      '.toast.show{opacity:1;transform:translate(-50%,0)}';
    document.head.appendChild(s);
  }
  let t=document.getElementById('toast');
  if(!t){ t=document.createElement('div'); t.id='toast'; document.body.appendChild(t); }
  t.textContent=(ok===false?'⚠ ':'✓ ')+m;
  t.className='toast '+(ok===false?'bad':'good')+' show';
  clearTimeout(window._toastT);
  window._toastT=setTimeout(()=>{ t.className='toast '+(ok===false?'bad':'good'); }, 2600);
}
function showAbout(){
  enterPanel('showAbout');
  // About to JEDEN szablon dla WSZYSTKICH a-tooli — nie ma sensu trzymac go
  // w zakladkach agenta (nie dzialal bez wybranego agenta). Teraz: modal, zawsze dostepny.
  const h = `
    <div style="text-align:center;margin-bottom:16px">
      <div style="width:64px;height:64px;margin:0 auto 10px;border-radius:15px;
        background:linear-gradient(135deg,var(--acc),var(--acc2));display:flex;align-items:center;
        justify-content:center;color:#fff;font-weight:800;font-size:24px">L4</div>
      <div style="font-size:18px;font-weight:700">Locally4Me A-Tools</div>
      <div style="color:var(--dim);font-size:13px">${ui('tagline','Your inbox, summarized. Calmly. Locally.')}</div>
    </div>

    <div style="font-size:13px;line-height:1.65">${aboutBlurbHTML()}</div>

${linksBlockHTML()}

    <hr style="border:0;border-top:1px solid var(--line);margin:20px 0">

${contactFormHTML({buttons:false})}
    <div class="bar">
      <button class="btn" onclick="sendFeedback()">${ui('send','Send')}</button>
      ${backBtn()}
      <span id="feedbackStatus" style="font-weight:600;font-size:13px"></span>
    </div>`;
  openModal(h);
}

async function editContext(){
  enterPanel('editContext');
  let txt='';
  try{ const r=await api('/api/context'); txt=(r&&!r._offline)?r.text||'':''; }catch(e){ txt=''; }
  if(txt==='' && _offlineBannerShown){ openModal('<div class="hint">'+ui('panel_not_responding','⚠ Panel not responding — run <code>python3 panel.py</code>')+'</div><div class="bar">'+backBtn()+'</div>'); return; }
  const html=`<div style="font-weight:700;color:var(--acc);font-size:16px;margin-bottom:4px">${ui('global_user_profile','👤 Global user profile')}</div>
    <div class="hint">${ui('global_profile_intro','Shared by <b>ALL your A-Tools</b> — one source of truth about you. The AI has no memory of its own, so this is the only way it knows who you are, what your projects are called, and what matters. Fill it in and every tool gets smarter.')}</div>
    <div class="hint" style="margin-top:8px;padding:8px 10px;background:#f8fafc;border-left:2px solid var(--acc);border-radius:4px">
      ${ui('global_profile_parts','<b>Two parts, one file:</b><br>• <b>Above the AI line</b> — yours. The A-Tools read it but <b>never change it</b>.<br>• <b>Below "Learned by the A-Tools"</b> — what the tools work out over time. You can delete anything there; it rebuilds. It never overwrites your part.<br><b>Context budget:</b> on the free tier only a short version is sent (to save tokens); with a paid key or local model the whole file goes.')}</div>
    <textarea id="ctx" placeholder="${esc(ui('profile_edit_placeholder','✏️ Click here and type — this field is editable.'))}" style="min-height:340px;margin-top:10px;font-family:ui-monospace,monospace;font-size:12px"></textarea>
    <div class="bar">
      <button class="btn" onclick="saveContext()">${ui('save_profile','Save profile')}</button>
      ${backBtn()}
      <span class="hint" id="ctxstat"></span>
    </div>`;
  openModal(html);
  // WSTAW tekst przez .value, NIE do template literala — profil moze zawierac
  // backtick lub ${...}, ktore rozbijaja template literal i wywalaja cala funkcje
  // (to bylo powodem, dla ktorego 👤 My profile "nie dzialalo", a inne okna tak).
  var ta=document.getElementById('ctx'); if(ta) ta.value=txt;
}
async function saveContext(){
  const st=$('#ctxstat'); if(st) st.textContent=ui('saving','saving…');
  try{
    await api('/api/context',{method:'POST',headers:{'Content-Type':'application/json'},
      body:JSON.stringify({text:$('#ctx').value})});
    if(st) st.textContent=ui('profile_saved_all','✓ saved — all A-Tools will use it');
    setTimeout(closeModal, 900);
  }catch(e){ if(st) st.textContent=ui('save_failed','save failed'); }
}
async function saveWakeSettings(){
  const st=$('#wk-save-status'); if(st)st.textContent=ui('saving','saving…');
  const num=(id,def)=>{const e=$(id);const n=e?Number(e.value):def;return Number.isFinite(n)?n:def;};
  const body={check_interval_s:num('#wk-check',30),schedule_window_min:num('#wk-window',5),wake_browser:!!($('#wk-browser')&&$('#wk-browser').checked),retry_pending_when_online:!!($('#wk-retry')&&$('#wk-retry').checked),popup_enabled:!!($('#wk-pop-enabled')&&$('#wk-pop-enabled').checked)};
  try{const r=await api('/api/wake_settings',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});if(!r||r.ok===false)throw new Error((r&&r.error)||'failed');if(st)st.textContent=ui('saved','✓ saved');setTimeout(showSystemPanel,450);}catch(e){if(st)st.textContent=ui('save_failed','save failed')+': '+e;}
}
async function openLocalSchedule(name){closeModal();await loadAgent(name);showTab('schedule');}
function openToolPort(port){if(port)window.open('http://localhost:'+Number(port)+'/','_blank','noopener');}
async function openWakeNative(){try{const r=await api('/api/wake_ui',{method:'POST'});if(!r||r.ok===false)throw new Error((r&&r.error)||'failed');}catch(e){alert(ui('wake_ui_open_failed','Could not open system Wake UI')+': '+e);}}

async function showSystemPanel(){
  enterPanel('showSystemPanel');
  openModal('<div class="hint">'+ui('loading_system_status','⏳ loading system status…')+'</div>');
  let ss={}, dd={};
  try{ ss=await api('/api/schedule_status'); }catch(e){}
  try{ dd=await api('/api/deps_status'); }catch(e){}
  if(ss&&ss._offline){ openModal('<div class="hint">'+ui('panel_not_responding','⚠ Panel not responding — run <code>python3 panel.py</code>')+'</div><div class="bar">'+backBtn()+'</div>'); return; }
  ss=ss||{}; dd=dd||{};
  const wk=ss.wake||{}, wps=wk.popup||{}, wpp=wps.policy||{}, tools=wk.tools||[];
  let h='<div style="font-weight:700;color:var(--acc);font-size:16px;margin-bottom:8px">'+ui('wake_scheduler_popup','🖥 Wake / Scheduler / Popup')+'</div>';
  h+='<div class="hint">'+ui('wake_system_manager_note','Wake is one system-wide background manager. This A-Tool only shows its status here; schedules, both calendars, autostart and per-A-Tool settings are edited in the standalone Wake UI.')+'</div>';
  h+='<div style="font-weight:600;margin:12px 0 4px">'+ui('wake_background','⏰ Wake / background')+'</div>';
  h+=`<div>${ui('manager','Manager')}: <b>${wk.running?ui('running_upper','RUNNING'):ui('stopped_upper','STOPPED')}</b>${wk.pid?(' · PID '+esc(String(wk.pid))):''}${wk.mode?(' · '+ui('mode','mode')+'=<b>'+esc(String(wk.mode))+'</b>'):''}${wk.tray_backend?(' · '+ui('tray_backend','tray')+'=<b>'+esc(String(wk.tray_backend))+'</b>'):''}</div>`;
  const au=wk.autostart||{};
  h+=`<div>${ui('start_with_system_plain','Start with system')}: <b>${au.enabled?ui('on','ON'):ui('off','OFF')}</b> · ${ui('installed','installed')}: <b>${au.installed?ui('yes','YES'):ui('no','NO')}</b></div>`;
  h+=`<div>${ui('registered_atools','Registered A-Tools')}: <b>${esc(String(tools.length))}</b> · ${ui('pending_commands','pending commands')}: <b>${esc(String(wk.pending_commands||0))}</b></div>`;
  h+='<div class="bar" style="margin-top:9px"><button class="btn" onclick="openWakeNative()">'+ui('open_native_wake','🖥 Open system Wake UI')+'</button></div>';

  h+='<div style="font-weight:600;margin:12px 0 4px">'+ui('shared_desktop_popup','🪧 Shared desktop popup')+'</div>';
  if(wps.registered){
    h+=`<div>${ui('popup_winner','Winner')}: <b>${esc(wps.tool||'—')}</b> · v${esc(String(wps.version||'—'))} · ${ui('published','published')}: ${esc(wps.published||'—')}</div>`;
    h+=`<div>${ui('next_job','Next')}: <b>${esc(wps.next_at||'not scheduled')}</b> · ${ui('shown_count','shown')}: ${esc(String(wps.shown_count||0))}</div>`;
    h+=`<div class="hint">${ui('policy','Policy')}: first ${Math.round((wpp.initial_delay_s||0)/60)} min · next random ${Math.round((wpp.min_delay_s||0)/3600)}–${Math.round((wpp.max_delay_s||0)/3600)} h · ${esc(String(wpp.visible_s||'—'))} s. ${ui('popup_owner_hint','The newest valid popup release owns its own timing; starting this A-Tool does not show it immediately.')}</div>`;
  }else h+='<div class="hint">'+ui('no_popup_time','No popup time registered yet.')+'</div>';

  h+='<div style="font-weight:600;margin:12px 0 4px">'+ui('first_run_dependencies','📦 First-run dependencies')+'</div>';
  if(dd.missing&&dd.missing.length){
    h+='<div style="color:var(--red)">'+ui('missing','Missing')+': '+dd.missing.map(esc).join(', ')+'</div>';
    h+='<div class="hint">'+ui('dependencies_one_prompt_hint','Automatic admin setup is attempted only once per dependency-contract version. Use the button below only when you deliberately want to retry.')+'</div>';
    h+='<button class="btn" style="padding:5px 14px;font-size:12px;margin-top:4px" onclick="installDeps()">'+ui('install_verify_missing','📦 Install / verify missing')+'</button> <span id="dep-install-status"></span>';
  }else h+='<div style="color:var(--green)">'+ui('dependency_ok','Dependency preflight OK ✓')+'</div>';
  const P=ss.paths||{};
  h+='<details style="margin-top:10px"><summary style="cursor:pointer">'+ui('diagnostics_files','Diagnostics / files')+'</summary><div class="hint">ecosystem.json: '+esc(String(P.ecosystem||'?'))+' '+(P.eco_exists?'✓':'✗')+'<br>wake log: '+esc(String(wk.log||'?'))+'<br>eco_dir: '+esc(String(P.eco_dir||'?'))+'</div></details>';
  h+='<div class="bar" style="margin-top:12px"><button class="btn ghost" onclick="showSystemPanel()">'+ui('refresh','🔄 Refresh')+'</button>'+backBtn()+'</div>';
  openModal(h);
}

function matchCellHTML(rule,i){
  const langs=window._trLangs||['en','pl'];
  const ml=rule.match_lang&&typeof rule.match_lang==='object'?rule.match_lang:{};
  let s=`<div class="hint" style="font-size:10px">${ui('canonical_match','Canonical match (your exact source)')}</div>`+
        `<input id="tr-match-${i}" value="${esc((rule.match||[]).join(', '))}" style="padding:5px;min-width:240px">`+
        `<div class="hint" style="font-size:10px;margin-top:4px">${ui('translations','Translations')}</div><div class="rule-lang-inputs">`;
  langs.forEach(c=>{
    const words=(ml[c]||[]).join(', ');
    s+=`<div class="lang-match" data-lang="${esc(c)}" style="margin:2px 0">`+
       `<span class="rule-lang-label" style="font-size:10px;font-weight:700;text-transform:uppercase;color:var(--dim);margin-right:4px">${esc(c)}</span>`+
       `<input id="tr-match-${i}-${esc(c)}" value="${esc(words)}" style="padding:4px;min-width:210px;font-size:11px" placeholder="—"></div>`;
  });
  return s+'</div>';
}
function readMatchCell(i){
  const langs=window._trLangs||['en','pl'];
  const original=(window._trRules||[])[i]||{};
  const bylang=Object.assign({},original.match_lang&&typeof original.match_lang==='object'?original.match_lang:{});
  langs.forEach(c=>{
    const el=$('#tr-match-'+i+'-'+c);if(!el)return;
    const seen=new Set(),arr=[];
    el.value.split(',').map(x=>x.trim()).filter(Boolean).forEach(value=>{const key=value.toLocaleLowerCase();if(!seen.has(key)){seen.add(key);arr.push(value);}});
    if(arr.length)bylang[c]=arr;else delete bylang[c];
  });
  const el=$('#tr-match-'+i),seen=new Set(),flat=[];
  (el?el.value:'').split(',').map(x=>x.trim()).filter(Boolean).forEach(value=>{const key=value.toLocaleLowerCase();if(!seen.has(key)){seen.add(key);flat.push(value);}});
  return {flat,bylang:Object.keys(bylang).length?bylang:null};
}
function selectRuleLang(code){window._trActiveLang=code;applyRuleLangVisibility();}
function applyRuleLangVisibility(){
  const langs=window._trLangs||['en'];
  let active=window._trActiveLang||(window._devMode?'*':(langs[0]||'en'));
  if(active!=='*'&&!langs.includes(active))active=window._devMode?'*':(langs[0]||'en');
  window._trActiveLang=active;
  document.querySelectorAll('.lang-card').forEach(el=>{
    const on=el.dataset.lang===active;
    el.style.borderColor=on?'var(--acc)':'var(--line)';el.style.background=on?'#eff4ff':'#f8fafc';
  });
  const showAll=active==='*';
  document.querySelectorAll('.lang-match').forEach(el=>{el.style.display=(showAll||el.dataset.lang===active)?'block':'none';});
  document.querySelectorAll('.rule-lang-label').forEach(el=>{el.style.display=showAll?'inline':'none';});
}
function langCardsHTML(){
  const langs=window._trLangs||['en','pl'];
  if(window._devMode){if(window._trActiveLang!=='*'&&!langs.includes(window._trActiveLang))window._trActiveLang='*';}
  else if(!langs.includes(window._trActiveLang))window._trActiveLang=langs[0]||'en';
  let cards=window._devMode?`<span class="lang-card" data-lang="*" onclick="selectRuleLang('*')" title="${esc(ui('all_languages','Show all language fields'))}" style="display:inline-flex;align-items:center;gap:5px;padding:4px 9px;border:1px solid var(--line);border-radius:999px;font-size:12px;background:#f8fafc;cursor:pointer"><b>ALL</b></span>`:'';
  cards+=langs.map(code=>{
    const fixed=(code==='en'),nm=languageName(code);
    return `<span class="lang-card" data-lang="${esc(code)}" onclick="selectRuleLang('${esc(code)}')" title="${esc(nm)}" style="display:inline-flex;align-items:center;gap:5px;padding:4px 9px;border:1px solid var(--line);border-radius:999px;font-size:12px;background:#f8fafc;cursor:pointer"><b style="text-transform:uppercase">${esc(code)}</b><span style="color:var(--dim)">${esc(nm)}</span>`+
      (fixed?'':`<span onclick="event.stopPropagation();removeLang('${esc(code)}')" title="${esc(ui('remove','Remove'))}" style="cursor:pointer;color:var(--dim);font-weight:700">✕</span>`)+`</span>`;
  }).join('');
  return `<div style="display:flex;align-items:center;gap:6px;flex-wrap:wrap;margin:8px 0 10px"><span class="hint" style="margin-right:2px">${ui('languages_label','Languages:')}</span>${cards}<button class="btn ghost" style="padding:3px 9px;font-size:12px" onclick="addLang()">＋</button><span class="hint" style="width:100%;margin-top:2px">${ui('rule_languages_help','Click EN/PL/etc. to edit only that translation. In <b>--d / --debug</b>, ALL is also available so you can inspect every language together. Hidden language variants remain stored and are not lost on Save.')}</span></div>`;
}
function addLang(){
  const code=(prompt(ui('add_language_prompt','Add a language by its 2-letter code (e.g. de, es, fr):'),'')||'').trim().toLowerCase();
  if(!code)return;if(!/^[a-z]{2}$/.test(code)){toast(ui('use_two_letter_code','Use a 2-letter code, e.g. "de".'),false);return;}
  if((window._trLangs||[]).includes(code)){toast(ui('language_already_added','{code} already added.',{code:code.toUpperCase()}),false);return;}
  window._trLangs.push(code);window._trActiveLang=code;saveLangs();
}
function removeLang(code){if(code==='en')return;window._trLangs=(window._trLangs||[]).filter(c=>c!==code);saveLangs();}
async function saveLangs(){
  try{const rr=await api('/api/tags_langs',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name:(cur&&cur.name)||'',langs:window._trLangs})});
    if(rr&&rr.ok===false)toast(ui('could_not_save_languages','Could not save languages: {error}',{error:rr.error||''}),false);else toast(ui('languages_updated','Languages updated'));
  }catch(e){toast(ui('could_not_save_languages','Could not save languages.',{error:''}),false);}showTagEditor(window._trMode||'tags');
}
function _prioOptions(val){return '<option value=""'+(!val?' selected':'')+'>—</option>'+['P1!','P1','P2','P3','P4','P5'].map(p=>`<option value="${p}" ${val===p?'selected':''}>${p}</option>`).join('');}
function _whereLabel(w){
  const m={from:ui('rule_where_from','sender / From'),source:ui('rule_where_source','source / feed'),subject:ui('rule_where_subject','subject'),body:ui('rule_where_body','body'),tag:ui('rule_where_tag','existing tag'),all:ui('rule_where_all','all text fields')};
  return m[w]||w;
}
function _whereOptions(selected){return ['from','source','subject','body','tag','all'].map(w=>`<option value="${w}" ${selected===w?'selected':''}>${esc(_whereLabel(w))}</option>`).join('');}
function ruleSemanticsHTML(){
  return `<details open style="margin:9px 0 12px;border:1px solid var(--line);border-radius:8px;padding:7px 9px;background:#f8fafc"><summary style="cursor:pointer;font-weight:600;color:var(--acc)">${ui('how_rules_work','How these rules work')}</summary>
  <div class="hint" style="margin-top:7px;line-height:1.48">
    <b>${ui('rule_help_match','Match')}</b> — ${ui('rule_help_match_text','literal word, phrase, address, domain or tag that starts the rule.')}<br>
    <b>${ui('rule_help_where','Where')}</b> — ${ui('rule_help_where_text','which message field is searched: sender, source/feed, subject, body, existing tag, or all text fields.')}<br>
    <b>ANY / ALL</b> — ${ui('rule_help_logic_text','ANY = one listed cue is enough; ALL = every listed cue must match.')}<br>
    <b>${ui('floor','Floor')}</b> — ${ui('rule_help_floor_text','the final priority may not become less important than this value. Example: floor P2 allows P1!/P1/P2, but not P3–P5.')}<br>
    <b>${ui('ceiling','Ceiling')}</b> — ${ui('rule_help_ceiling_text','the final priority may not become more important than this value. Example: ceiling P3 allows P3–P5, but not P1!/P1/P2.')}<br>
    <b>${ui('always_show','Always show')}</b> — ${ui('rule_help_show_text','keeps a matching item visible instead of hiding it as noise; it does not by itself raise priority.')}<br>
    <b>${ui('stop','Stop')}</b> — ${ui('rule_help_stop_text','after this rule matches, no later exact/custom message rule is evaluated for this message. Earlier classifier results, built-in tags and actions from earlier matching rules remain in place. It does not stop the whole run or AI by itself.')}<br>
    <b>${ui('scope','Scope')}</b> — ${ui('rule_help_scope_text','all = every A-Tool; kind:reporter = every reporter; tool:NAME = only that saved preset/profile.')}<br>
    <b>${ui('order','Order')}</b> — ${ui('rule_help_order_text','rules are evaluated in saved order. Later matching floor/ceiling values can replace earlier bounds; tags and Always show accumulate. Stop prevents later exact/custom rules from running.')}<br>
    <b>${ui('test','Test')}</b> — ${ui('rule_help_test_text','read-only preview against the last report. It does not save a rule, fetch mail, or change a message.')}
  </div></details>`;
}
function _ruleRowHTML(rule,i){
  const where=rule.where||'all';
  const mode=rule.match_mode==='all'?'all':'any';
  return `<tr id="tr-row-${i}" data-rule-index="${i}">
    <td style="padding:4px"><input id="tr-tag-${i}" value="${esc(rule.tag||'')}" placeholder="${esc(ui('optional_tag','optional tag'))}" style="padding:5px;min-width:140px"></td>
    <td style="padding:4px">${matchCellHTML(rule,i)}</td>
    <td style="padding:4px"><select id="tr-where-${i}" style="padding:5px;min-width:90px">${_whereOptions(where)}</select><select id="tr-mode-${i}" style="padding:4px;min-width:90px;margin-top:3px" title="${esc(ui('match_logic_hint','ANY: each term triggers independently. ALL: every listed cue must match.'))}"><option value="any" ${mode==='any'?'selected':''}>ANY</option><option value="all" ${mode==='all'?'selected':''}>ALL</option></select></td>
    <td style="padding:4px;min-width:160px"><div style="display:flex;gap:4px;align-items:center"><span class="tag" title="${esc(ui('floor_title','Minimum importance: final P cannot be less important than this'))}">${ui('floor','floor')}</span><select id="tr-min-${i}" style="padding:4px">${_prioOptions(rule.min_priority||'')}</select></div><div style="display:flex;gap:4px;align-items:center;margin-top:3px"><span class="tag" title="${esc(ui('ceiling_title','Maximum importance: final P cannot be more important than this'))}">${ui('ceiling','ceiling')}</span><select id="tr-max-${i}" style="padding:4px">${_prioOptions(rule.max_priority||'')}</select></div></td>
    <td style="padding:4px;text-align:center"><input type="checkbox" id="tr-show-${i}" ${rule.show?'checked':''} title="${esc(ui('always_show_title','Always show; do not hide as noise'))}"></td>
    <td style="padding:4px;text-align:center"><input type="checkbox" id="tr-stop-${i}" ${rule.stop?'checked':''} title="${esc(ui('stop_rule_title','If this rule matches, stop evaluating later exact/custom message rules for this message. Earlier deterministic classification is not undone.'))}"></td>
    <td style="padding:4px"><input id="tr-scope-${i}" value="${esc(rule.scope||'all')}" list="rule-scopes" style="padding:5px;min-width:130px"></td>
    <td style="padding:4px;text-align:center;white-space:nowrap"><button class="btn ghost" style="padding:2px 6px;font-size:11px" title="${esc(ui('move_rule_earlier','Move rule earlier'))}" onclick="moveTagRule(${i},-1)">↑</button><button class="btn ghost" style="padding:2px 6px;font-size:11px" title="${esc(ui('move_rule_later','Move rule later'))}" onclick="moveTagRule(${i},1)">↓</button></td>
    <td style="padding:4px;white-space:nowrap"><button class="btn ghost" style="padding:3px 7px;font-size:11px" title="${esc(ui('rule_test_title','Preview only: count how many messages in the last report this condition would match. Nothing is saved or changed.'))}" onclick="previewRuleRow(${i})">${ui('test','Test')}</button> <button class="btn ghost" style="padding:3px 7px;font-size:11px;color:var(--red)" onclick="delTagRule(${i})">✕</button><div id="tr-prev-${i}" class="hint" style="min-width:90px"></div></td>
  </tr>`;
}
function _factoryRulesReadOnlyHTML(factory,mode){
  const list=(factory||[]).filter(r=>mode==='all'||!!r.tag||r.where==='tag');
  if(!list.length)return '<div class="hint">'+ui('no_factory_rules_here','No factory rules in this view.')+'</div>';
  let h='<div style="overflow-x:auto"><table style="width:100%;min-width:760px;font-size:11px;border-collapse:collapse"><thead><tr style="color:var(--dim)">'+
    '<th style="text-align:left;padding:4px">'+ui('match','Match')+'</th><th style="text-align:left;padding:4px">'+ui('where','Where')+'</th><th style="text-align:left;padding:4px">'+ui('actions','Actions')+'</th></tr></thead><tbody>';
  for(const r of list){const a=[];if(r.tag)a.push('tag='+r.tag);if(r.min_priority)a.push('floor='+r.min_priority);if(r.max_priority)a.push('ceiling='+r.max_priority);if(r.show)a.push('show');if(r.stop)a.push('stop');
    h+='<tr><td style="padding:4px;border-top:1px solid var(--line)">'+esc((r.match||[]).join(', '))+'</td><td style="padding:4px;border-top:1px solid var(--line)">'+esc(r.where||'all')+'</td><td style="padding:4px;border-top:1px solid var(--line)">'+esc(a.join(' + ')||'—')+'</td></tr>';}
  return h+'</tbody></table></div>';
}

function _factoryRuleRowHTML(rule,i){
  const where=rule.where||'all',mode=rule.match_mode==='all'?'all':'any';
  return `<tr id="fr-row-${i}">
    <td style="padding:4px"><input id="fr-tag-${i}" value="${esc(rule.tag||'')}" style="padding:5px;min-width:130px"></td>
    <td style="padding:4px"><input id="fr-match-${i}" value="${esc((rule.match||[]).join(', '))}" style="padding:5px;min-width:250px"></td>
    <td style="padding:4px"><select id="fr-where-${i}" style="padding:5px">${_whereOptions(where)}</select><select id="fr-mode-${i}" style="padding:4px;margin-top:3px"><option value="any" ${mode==='any'?'selected':''}>ANY</option><option value="all" ${mode==='all'?'selected':''}>ALL</option></select></td>
    <td style="padding:4px"><div style="display:flex;gap:4px"><span class="tag">${ui('floor','floor')}</span><select id="fr-min-${i}">${_prioOptions(rule.min_priority||'')}</select></div><div style="display:flex;gap:4px;margin-top:3px"><span class="tag">${ui('ceiling','ceiling')}</span><select id="fr-max-${i}">${_prioOptions(rule.max_priority||'')}</select></div></td>
    <td style="padding:4px;text-align:center"><input type="checkbox" id="fr-show-${i}" ${rule.show?'checked':''}></td>
    <td style="padding:4px;text-align:center"><input type="checkbox" id="fr-stop-${i}" ${rule.stop?'checked':''}></td>
    <td style="padding:4px"><input id="fr-scope-${i}" value="${esc(rule.scope||'all')}" style="padding:5px;min-width:120px"></td>
    <td style="padding:4px;white-space:nowrap"><button class="btn ghost" onclick="moveFactoryRule(${i},-1)">↑</button><button class="btn ghost" onclick="moveFactoryRule(${i},1)">↓</button><button class="btn ghost" style="color:var(--red)" onclick="deleteFactoryRule(${i})">✕</button></td>
  </tr>`;
}
function _readFactoryRule(i,base){
  const row=$('#fr-row-'+i);if(!row)return Object.assign({},base||{});
  const r=Object.assign({},base||{}),raw=(($('#fr-match-'+i)||{}).value||'').trim();
  r.match=raw.split(',').map(x=>x.trim()).filter(Boolean);r.tag=(($('#fr-tag-'+i)||{}).value||'').trim();
  r.where=(($('#fr-where-'+i)||{}).value||'all');r.match_mode=(($('#fr-mode-'+i)||{}).value||'any');r.scope=(($('#fr-scope-'+i)||{}).value||'all').trim()||'all';
  const mn=(($('#fr-min-'+i)||{}).value||''),mx=(($('#fr-max-'+i)||{}).value||'');if(mn)r.min_priority=mn;else delete r.min_priority;if(mx)r.max_priority=mx;else delete r.max_priority;
  r.show=!!(($('#fr-show-'+i)||{}).checked);r.stop=!!(($('#fr-stop-'+i)||{}).checked);if(!r.tag)delete r.tag;return r;
}
function _collectFactoryRules(){return (window._frRules||[]).map((r,i)=>_readFactoryRule(i,r)).filter(r=>(r.match||[]).length&&(r.tag||r.min_priority||r.max_priority||r.show||r.always_summary||r.never_summary));}
function renderFactoryRuleEditor(){
  const rows=(window._frRules||[]).map((r,i)=>_factoryRuleRowHTML(r,i)).join('')||`<tr><td colspan="8" class="hint">${ui('no_factory_rules_here','No factory rules.')}</td></tr>`;
  const over=window._frOverridden?ui('factory_override_active','Local factory override is active. Reset restores the factory rules shipped in the source.'):ui('factory_override_inactive','Using factory rules shipped in the source. Saving here creates a local AgentSystem override; it does not rewrite the source file.');
  openModal(`<div style="font-weight:700;color:var(--acc);font-size:16px">🛠 ${ui('factory_rule_editor','Factory rule editor')}</div><div class="hint" style="margin:5px 0 8px">${over}</div>${ruleSemanticsHTML()}<div style="overflow-x:auto"><table style="width:100%;min-width:1050px;font-size:12px"><thead><tr><th>${ui('tag','Tag')}</th><th>${ui('match','Match')}</th><th>${ui('where','Where')}</th><th>${ui('priority_action','Priority')}</th><th>${ui('show','Show')}</th><th>${ui('stop','Stop')}</th><th>${ui('scope','Scope')}</th><th>${ui('actions','Actions')}</th></tr></thead><tbody>${rows}</tbody></table></div><div class="bar" style="margin-top:9px"><button class="btn ghost" onclick="addFactoryRule()">＋ ${ui('factory_rule_add','Factory rule')}</button><button class="btn" onclick="saveFactoryRules()">${ui('save_factory_override','Save factory override')}</button><button class="btn ghost" onclick="resetFactoryRulesDev()">↺ ${ui('restore_source_factory','Restore source factory')}</button>${backBtn()}<span class="hint" id="frstat"></span></div>`);
}
async function showFactoryRuleEditor(){
  if(!window._devMode){toast(ui('developer_mode_required','Start panel.py with --d to edit factory rules.'),false);return;}
  const r=await api('/api/tags?name='+encodeURIComponent((cur&&cur.name)||''));if(!r||r._offline)return;
  window._frRules=(r.preset_rules||[]).map(x=>Object.assign({},x));window._frOverridden=!!r.factory_overridden;renderFactoryRuleEditor();
}
function addFactoryRule(){window._frRules=_collectFactoryRules();window._frRules.push({match:[],where:'subject',scope:'all'});renderFactoryRuleEditor();}
function deleteFactoryRule(i){window._frRules=_collectFactoryRules().filter((_,n)=>n!==i);renderFactoryRuleEditor();}
function moveFactoryRule(i,dir){let a=_collectFactoryRules(),j=i+dir;if(i<0||i>=a.length||j<0||j>=a.length)return;const t=a[i];a[i]=a[j];a[j]=t;window._frRules=a;renderFactoryRuleEditor();}
async function saveFactoryRules(){
  const rules=_collectFactoryRules(),st=$('#frstat');if(st)st.textContent=ui('saving','saving…');
  const rr=await api('/api/factory_tags_save',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name:(cur&&cur.name)||'',rules})});
  if(rr&&rr.ok){window._frRules=rules;window._frOverridden=true;toast(ui('factory_override_saved','Factory override saved.'));renderFactoryRuleEditor();}else if(st)st.textContent=(rr&&rr.error)||ui('save_failed','Save failed');
}
async function resetFactoryRulesDev(){
  if(!confirm(ui('restore_source_factory_confirm','Remove the local factory override and restore the factory rules shipped with this version?')))return;
  const rr=await api('/api/factory_tags_save',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({reset:true,name:(cur&&cur.name)||''})});
  if(rr&&rr.ok){toast(ui('source_factory_restored','Source factory rules restored.'));showFactoryRuleEditor();}
}

async function showTagEditor(mode){
  mode=mode||'tags';window._trMode=mode;enterPanel('showTagEditor');
  openModal('<div class="hint">'+ui('loading_message_rules','⏳ loading message rules…')+'</div>');
  const r=await api('/api/tags?name='+encodeURIComponent(cur&&cur.name||''));
  if(r&&r._offline){openModal('<div class="hint">'+ui('panel_not_responding','⚠ Panel not responding — run <code>python3 panel.py</code>')+'</div><div class="bar">'+backBtn()+'</div>');return;}
  const rules=(r&&r.custom)||[];window._trRules=rules;
  window._trLangs=(r&&r.langs&&r.langs.length)?r.langs.slice():['en'];
  if(window._devMode){if(!window._trActiveLang||(!window._trLangs.includes(window._trActiveLang)&&window._trActiveLang!=='*'))window._trActiveLang='*';}
  else if(!window._trActiveLang||!window._trLangs.includes(window._trActiveLang)){const gl=((window._globalSettings||{}).lang||'en');window._trActiveLang=window._trLangs.includes(gl)?gl:(window._trLangs[0]||'en');}
  const indexed=rules.map((rule,i)=>({rule,i}));
  const tagRules=indexed.filter(x=>!!x.rule.tag||x.rule.where==='tag');
  const generalRules=indexed.filter(x=>!x.rule.tag&&x.rule.where!=='tag');
  const factory=(r&&r.preset_rules)||[];
  const factoryTag=factory.filter(x=>!!x.tag||x.where==='tag');
  const factoryGeneral=factory.filter(x=>!x.tag&&x.where!=='tag');
  const _ruleTable=(rows)=>{let z=`<div style="overflow-x:auto"><table style="width:100%;min-width:1180px;font-size:12px"><thead><tr style="color:var(--dim)"><th>${ui('tag','tag')}</th><th>${ui('match_language','match / language')}</th><th>${ui('where','where')}</th><th>${ui('priority_action','priority action')}</th><th>${ui('show','show')}</th><th>${ui('stop','stop')}</th><th>${ui('scope','scope')}</th><th>${ui('order','order')}</th><th>${ui('test_delete','test / delete')}</th></tr></thead><tbody>`;rows.forEach(x=>{z+=_ruleRowHTML(x.rule,x.i);});if(!rows.length)z+=`<tr><td colspan="9" class="hint" style="padding:10px">${ui('no_rules_view','No rules in this view yet.')}</td></tr>`;return z+'</tbody></table></div>';};
  let h=`<div style="font-weight:700;color:var(--acc);font-size:16px;margin-bottom:4px">${mode==='tags'?ui('tags_rules_title','🏷 Tags & tag rules'):ui('rules_title','⚖ Rules')}</div>`+langCardsHTML();
  h+=`<div class="hint">${mode==='tags'?ui('tags_rules_intro','Tags are labels attached to messages. This view focuses on rules that create a tag or react to an existing tag. General rules use the same rule engine but do not create a tag; they are folded below so you can still inspect the complete ordered rule set. Built-in semantic recognition creates standard tags before these exact/custom rules run.'):ui('rules_intro','Rules are exact/custom conditions applied after the built-in classifier. General rules change priority/visibility without creating a tag. Tag rules create a tag or react to an existing tag. Both are one ordered rule list: the Tags and Rules screens are only two views of the same saved rules. Engine-behaviour settings such as AI correction limits are separate settings, not message rules.')}</div>`;
  h+=`<div class="bar" style="margin:7px 0"><button class="btn ghost" onclick="showClassificationSettings()">${ui('engine_behaviour_button','⚙ Engine behaviour')}</button></div>`;
  h+=ruleSemanticsHTML();
  if(mode==='tags'){
    const built=(r&&r.builtin)||[];
    h+=`<div style="font-weight:600;margin:10px 0 4px">${ui('factory_tag_catalog','Factory tag catalog')}</div>`;
    h+=built.length?'<div style="display:flex;gap:4px;flex-wrap:wrap">'+built.map(t=>'<span class="tag">'+esc(t)+'</span>').join('')+'</div>':'<div class="hint">'+ui('no_factory_tags','No factory tag catalog was returned.')+'</div>';
    h+=`<div style="font-weight:600;margin:12px 0 4px">${ui('your_tag_rules','Your tag rules')}</div>`+_ruleTable(tagRules);
    h+=`<details style="margin-top:12px"><summary style="cursor:pointer;font-weight:600;color:var(--acc)">${ui('general_rules_folded','⚖ General rules (no tag action)')} · ${generalRules.length}</summary><div style="padding-top:7px"><div class="hint">${ui('general_rules_folded_hint','These rules do not create a tag. They can constrain priority, keep a message visible, limit themselves to a scope, and optionally stop evaluation of later exact/custom rules after a match.')}</div>${_factoryRulesReadOnlyHTML(factoryGeneral,'all')}${_ruleTable(generalRules)}</div></details>`;
    h+=`<details style="margin-top:10px"><summary style="cursor:pointer;color:var(--dim)">${ui('factory_tag_rules','Factory tag rules')} · ${factoryTag.length}</summary><div style="padding-top:7px">${_factoryRulesReadOnlyHTML(factoryTag,'all')}${window._devMode?`<div class="bar" style="margin-top:7px"><button class="btn ghost" onclick="showFactoryRuleEditor()">${ui('edit_factory_rules_dev','🛠 Edit factory rules (--d)')}</button></div>`:''}</div></details>`;
  }else{
    h+=`<div style="font-weight:600;margin:10px 0 4px">${ui('general_rules','General rules')}</div><div class="hint">${ui('general_rules_hint','Rules without a tag action. Use them for exact conditions that constrain priority, force visibility, or control later exact/custom rule evaluation without adding another label.')}</div>`+_ruleTable(generalRules);
    h+=`<details style="margin-top:12px"><summary style="cursor:pointer;font-weight:600;color:var(--acc)">${ui('tag_rules_folded','🏷 Tag rules')} · ${tagRules.length}</summary><div style="padding-top:7px"><div class="hint">${ui('tag_rules_folded_hint','Rules that assign a tag or use an existing tag as the condition. They are folded here so the Rules view still contains the complete rule set without duplicating the Tags view.')}</div>${_factoryRulesReadOnlyHTML(factoryTag,'all')}${_ruleTable(tagRules)}</div></details>`;
    h+=`<details style="margin-top:10px"><summary style="cursor:pointer;color:var(--dim)">${ui('factory_general_rules','Factory general exact rules')} · ${factoryGeneral.length}</summary><div style="padding-top:7px">${_factoryRulesReadOnlyHTML(factoryGeneral,'all')}${window._devMode?`<div class="bar" style="margin-top:7px"><button class="btn ghost" onclick="showFactoryRuleEditor()">${ui('edit_factory_rules_dev','🛠 Edit factory rules (--d)')}</button></div>`:''}</div></details>`;
  }
  h+=`<details style="margin-top:10px"><summary style="cursor:pointer;color:var(--acc)">${ui('add_rule','＋ Add a rule')}</summary><div style="padding:8px;border:1px solid var(--line);border-radius:8px;margin-top:5px"><div class="hint" style="margin-bottom:6px">${ui('manual_add_safe_hint','Manual rules are validated before saving. Prefer a distinctive phrase; use ALL when several cues must occur together.')}</div><div class="row"><div><label>${ui('tag_optional','Tag (optional)')}</label><input id="tr-tag-new" placeholder="🏷 client"></div><div><label>${ui('match','Match')}</label><input id="tr-match-new" placeholder="payment completed, order confirmed"></div></div><div class="row"><div><label>${ui('where','Where')}</label><select id="tr-where-new">${_whereOptions('subject')}</select></div><div><label>${ui('match_logic','Match logic')}</label><select id="tr-mode-new"><option value="any">ANY — ${ui('any_term','any term')}</option><option value="all">ALL — ${ui('all_terms','all terms together')}</option></select></div></div><div class="row"><div><label>${ui('scope','Scope')}</label><input id="tr-scope-new" list="rule-scopes" value="tool:${esc((cur&&cur.name)||'')}"></div><div></div></div><div class="row"><div><label>${ui('floor','Floor')}</label><select id="tr-min-new">${_prioOptions('')}</select></div><div><label>${ui('ceiling','Ceiling')}</label><select id="tr-max-new">${_prioOptions('')}</select></div></div><label><input type="checkbox" id="tr-show-new"> ${ui('always_show','always show')}</label> <label style="margin-left:12px"><input type="checkbox" id="tr-stop-new"> ${ui('stop_after_match','stop after match')}</label><div class="bar"><button class="btn" onclick="addTagRule()">${ui('add_save','Validate + add')}</button></div></div></details>`;
  h+=`<div class="bar"><button class="btn" onclick="saveTagRules()">${ui('save_rules','Save rules')}</button><button class="btn ghost" onclick="translateTagRules()">${ui('translate_rules','🌐 Translate match words')}</button><button class="btn ghost" onclick="askResetTags()">🗑 ${ui('reset_factory','Reset to factory defaults')}</button>${backBtn()}<span class="hint" id="trstat"></span></div>`;
  openModal(h);setTimeout(applyRuleLangVisibility,0);
}
function delTagRule(i){const row=$('#tr-row-'+i);if(!row)return;row.dataset.deleted='1';row.style.opacity='.35';row.style.textDecoration='line-through';const st=$('#trstat');if(st)st.textContent=ui('marked_for_removal','marked for removal — click Save');}
function _readRuleRow(i,base){
  const row=$('#tr-row-'+i);if(!row)return base;if(row.dataset.deleted==='1')return null;
  const mc=readMatchCell(i);if(!mc.flat.length)return null;
  const rule=Object.assign({},base||{});rule.match=mc.flat;if(mc.bylang)rule.match_lang=mc.bylang;else delete rule.match_lang;
  rule.tag=(($('#tr-tag-'+i)||{}).value||'').trim();rule.where=(($('#tr-where-'+i)||{}).value||'all');const mm=(($('#tr-mode-'+i)||{}).value||'any');if(mm==='all'||Object.prototype.hasOwnProperty.call(base||{},'match_mode'))rule.match_mode=mm;else delete rule.match_mode;rule.scope=(($('#tr-scope-'+i)||{}).value||'all').trim()||'all';
  const mn=(($('#tr-min-'+i)||{}).value||''),mx=(($('#tr-max-'+i)||{}).value||'');if(mn)rule.min_priority=mn;else delete rule.min_priority;if(mx)rule.max_priority=mx;else delete rule.max_priority;
  rule.show=!!(($('#tr-show-'+i)||{}).checked);rule.stop=!!(($('#tr-stop-'+i)||{}).checked);
  if(!rule.tag&&!mn&&!mx&&!rule.show)return null;return rule;
}
async function moveTagRule(i,dir){
  const orig=(window._trRules||[]),current=[];
  for(let n=0;n<orig.length;n++){const row=$('#tr-row-'+n);current.push(row?_readRuleRow(n,orig[n]):Object.assign({},orig[n]));}
  let arr=current.filter(Boolean),pos=arr.findIndex(x=>x===current[i] || x===orig[i]);
  // Object identity changes after _readRuleRow, so resolve by original full index when needed.
  if(pos<0){pos=current.slice(0,i+1).filter(Boolean).length-1;}
  const np=pos+dir;if(pos<0||np<0||np>=arr.length)return;
  const tmp=arr[pos];arr[pos]=arr[np];arr[np]=tmp;
  try{const rr=await api('/api/tags_save',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({rules:arr,name:(cur&&cur.name)||''})});
    if(rr&&rr.ok===false){toast(ui('reorder_failed','Reorder failed'),false);return;}window._trRules=arr;toast(ui('rule_order_updated','Rule order updated'));showTagEditor('all');
  }catch(e){toast(ui('reorder_failed','Reorder failed'),false);}
}
async function previewRuleRow(i){
  const mc=readMatchCell(i),box=$('#tr-prev-'+i);if(!mc.flat.length){if(box)box.textContent=ui('no_match','no match');return;}
  if(box)box.textContent=ui('checking','checking…');
  const rr=await api('/api/rule_preview',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name:(cur&&cur.name)||'',match:mc.flat.join(', '),where:(($('#tr-where-'+i)||{}).value||'all'),match_mode:(($('#tr-mode-'+i)||{}).value||'any')})});
  if(!box)return;if(!rr||rr.ok===false){box.textContent=(rr&&rr.error)||'failed';return;}box.innerHTML=`<b>${rr.matched}</b>/${rr.scanned}`+(rr.examples&&rr.examples[0]?`<br>${esc(rr.examples[0].addr||rr.examples[0].from||'')}`:'');
}
async function addTagRule(){
  const tag=(($('#tr-tag-new')||{}).value||'').trim(),match=(($('#tr-match-new')||{}).value||'').trim();
  const mn=(($('#tr-min-new')||{}).value||''),mx=(($('#tr-max-new')||{}).value||''),show=!!(($('#tr-show-new')||{}).checked),stop=!!(($('#tr-stop-new')||{}).checked);
  if(!match){alert(ui('give_match_value','Give at least one match value.'));return;}const _newWhere=(($('#tr-where-new')||{}).value||'subject');if((window._trMode||'tags')==='tags'&&!tag&&_newWhere!=='tag'){alert(ui('tag_view_requires_tag','Tag-focused view accepts rules that assign a tag or use an existing tag as the condition. Enter a tag, or set Where = tag.'));return;}if(!tag&&!mn&&!mx&&!show){alert(ui('choose_rule_action','Choose at least one action: tag, priority floor/ceiling, or always show.'));return;}
  window._trNewRule={tag,match:match.split(',').map(x=>x.trim()).filter(Boolean),where:_newWhere,match_mode:(($('#tr-mode-new')||{}).value||'any'),scope:(($('#tr-scope-new')||{}).value||'all'),show,stop};
  if(mn)window._trNewRule.min_priority=mn;if(mx)window._trNewRule.max_priority=mx;await saveTagRules();
}
async function translateTagRules(){
  const st=$('#trstat'),langs=(window._trLangs||['en','pl']);if(st)st.innerHTML='<span style="color:var(--acc)">'+ui('translating_rules','🌐 Translating your exact/custom match words to {languages}… Built-in semantic tags are already multilingual.',{languages:langs.map(c=>c.toUpperCase()).join('/')})+'</span>';
  try{
    let r=await api('/api/tags_translate_all',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name:(cur&&cur.name)||'',langs})});
    if(r&&r.stale_rules&&confirm(ui('translations_stale','Some translations are outdated. Regenerate them? Existing variants will be replaced.'))){
      r=await api('/api/tags_translate_all',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name:(cur&&cur.name)||'',langs,regenerate:true})});
    }
    if(r&&r.ok){const msg=(r.languages_generated||0)?('✓ '+(r.translated_rules||0)+' rules · '+(r.languages_generated||0)+' languages generated'):ui('translations_current','Translations are already up to date.');if(st)st.textContent=msg;toast(msg);}else if(st)st.textContent=(r&&r.error)||'translation failed';setTimeout(()=>showTagEditor(window._trMode||'tags'),900);
  }catch(e){if(st)st.textContent=ui('failed_with_error','Failed: {error}',{error:e});}
}
async function saveTagRules(){
  const orig=(window._trRules||[]),rules=[];
  for(let i=0;i<orig.length;i++){const row=$('#tr-row-'+i);rules.push(row?_readRuleRow(i,orig[i]):Object.assign({},orig[i]));}
  let finalRules=rules.filter(Boolean);if(window._trNewRule){finalRules.push(window._trNewRule);window._trNewRule=null;}
  const st=$('#trstat');if(st)st.textContent=ui('saving','saving…');
  let payload={rules:finalRules,name:(cur&&cur.name)||''};
  try{let rr=await api('/api/tags_save',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});
    if(rr&&rr.needs_confirmation){if(!confirm(_ruleRiskConfirmText(rr.validation))){if(st)st.textContent=ui('save_cancelled','Save cancelled — refine the rule if needed.');return;}payload.confirm_risk=true;rr=await api('/api/tags_save',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});}
    if(rr&&rr.ok===false){const ve=rr.validation&&rr.validation.errors?(rr.validation.errors.join('; ')):'';if(st)st.textContent=ui('save_failed_error','save failed: {error}',{error:ve||rr.error||''});toast(ui('save_failed','Save failed'),false);return;}if(st)st.textContent=ui('saved_next_run','✓ saved — applies on the next Run');toast(ui('rules_saved','Rules saved'));setTimeout(()=>showTagEditor(window._trMode||'tags'),600);
  }catch(e){if(st)st.textContent=ui('save_failed','save failed');}
}


boot();
// Desktop popup timing/display is owned by wake.py, not the browser panel.
if('serviceWorker' in navigator){navigator.serviceWorker.register('/sw.js',{updateViaCache:'none'}).then(r=>r.update()).catch(()=>{});}

// ── WYMUS globalna dostepnosc funkcji dla inline onclick ──────────────────
// W niektorych warunkach ladowania (defer + osobny plik) deklaracje funkcji nie
// staja sie automatycznie property window widzianym przez inline onclick.
// Jawne przypisanie gwarantuje, ze onclick="foo()" zawsze znajdzie foo.
(function(){
  // Scan script scope for ALL declared functions and expose them on window so
  // dynamically inserted onclick="fn()" always resolves. A manual list missed
  // 23+ functions (showRawLog, addTagRule, delTagRule, toggleHidden…) causing
  // dead buttons after DOM updates. This auto-detect replaces the old list.
  var src;
  try { src = document.querySelector('script[src*="ui-frame"]'); } catch(e){}
  // Names from the old explicit list + auto-detected: try eval first, fall
  // through silently on ReferenceError. Covers both function decls and vars.
  var _seen = {};
  function _expose(n){
    if(_seen[n]) return; _seen[n]=1;
    try{ var fn = eval(n); if(typeof fn==='function') window[n]=fn; }catch(e){}
  }
  // Auto-detect: scan own <script> text for `function NAME(` and
  // `async function NAME(` at statement level (col 0 or after newline).
  try{
    var scripts = document.querySelectorAll('script');
    for(var si=0;si<scripts.length;si++){
      var txt=scripts[si].textContent||'';
      if(txt.indexOf('function api(')<0) continue;
      var re=/(?:^|[\n;{}])\s*(?:async\s+)?function\s+(\w+)\s*\(/g, mm;
      while((mm=re.exec(txt))) _expose(mm[1]);
      break;
    }
  }catch(e){}
  [showRules,showClassificationSettings,saveRules,showTagEditor,saveTagRules,addTagRule,delTagRule,moveTagRule,previewRuleRow,selectRuleLang,onAiLevelChange].forEach(function(fn){try{if(fn&&fn.name)window[fn.name]=fn;}catch(e){}});
  // Static map for header-bar buttons (no inline onclick, just IDs)
  var map={'hb-about':showAbout,'hb-profile':editContext,'hb-opps':showSettings,
           'hintbtn':cycleHints,'hb-admin':showAdmin,'hb-docs':showDocs};
  Object.keys(map).forEach(function(id){
    var el=document.getElementById(id);
    if(el) el.addEventListener('click', map[id]);
  });
  // delegacja klik na .pval badge → prio-popover z danymi wiersza
  document.addEventListener('click', function(ev){
    var pv=ev.target.closest&&ev.target.closest('.pval');
    if(!pv) return;
    var cell=pv.closest('.prio-cell')||pv.parentNode;
    if(!cell||!cell.dataset) return;
    var from=cell.dataset.from||'';
    var addr=cell.dataset.addr||'';
    var tags=[]; try{ tags=JSON.parse(cell.dataset.tags||'[]'); }catch(_){}
    var title=cell.dataset.title||'';
    var mid=cell.dataset.mid||'';
    var src=cell.dataset.src||'';
    var prio=pv.dataset.p||'P3';
    if(!from) return;
    openPrioPop(ev, from, prio, tags, title, addr, mid, src);
  });
})();
