#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# file-version: 0.930 | updated: 2026-09-14
"""Stable UI translation API backed by optional locale packs.

English is deliberately not a pack: its copy lives inline in ui-frame.js and
ui-reporter.html, so the panel always works when every file in transl/ is
missing or broken. Only non-English locales are loaded from transl/.
"""

import language_packs as _LP

_PACK_VERSION = None

LANG_META = {
    "en": {"name": "English", "native": "English"},
    "pl": {"name": "Polish", "native": "Polski"},
    "de": {"name": "German", "native": "Deutsch"},
    "es": {"name": "Spanish", "native": "Español"},
    "fr": {"name": "French", "native": "Français"},
    "it": {"name": "Italian", "native": "Italiano"},
    "pt": {"name": "Portuguese", "native": "Português"},
    "nl": {"name": "Dutch", "native": "Nederlands"},
    "cs": {"name": "Czech", "native": "Čeština"},
    "uk": {"name": "Ukrainian", "native": "Українська"},
}

# Compatibility for older imports. English copy is owned by browser markup.
UI = {"en": {}}


def configure(engine_version):
    """Panel passes engine.VERSION; it is the release-version authority."""
    global _PACK_VERSION
    _PACK_VERSION = str(engine_version or "")


def all_for(lang="en"):
    """Return only a non-English overlay; English is the browser fallback."""
    lang = str(lang or "en").strip().lower()
    if lang == "en" or not _PACK_VERSION:
        return {}
    return _LP.section(lang, _PACK_VERSION, "ui")


def t(key, lang="en"):
    """Compatibility helper: locale value or the stable key."""
    return all_for(lang).get(key) or key


def languages():
    """English plus complete, valid non-English panel packs."""
    out = ["en"]
    if _PACK_VERSION:
        for code in _LP.complete_languages(_PACK_VERSION):
            if code != "en" and code not in out:
                out.append(code)
    return out


def language_meta():
    """Metadata for UI selectors and arbitrary rule-language cards."""
    out = {code: dict(meta) for code, meta in LANG_META.items()}
    if _PACK_VERSION:
        for code in languages():
            if code == "en":
                continue
            meta = (_LP.load_pack(code, _PACK_VERSION) or {}).get("_meta") or {}
            if meta.get("name") or meta.get("native"):
                out.setdefault(code, {}).update(
                    {key: meta[key] for key in ("name", "native") if meta.get(key)}
                )
    return out
