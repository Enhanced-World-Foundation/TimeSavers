# ============================================================================
#  scheduler.py  —  HARMONOGRAM agentów (na APScheduler, open-source)
# ============================================================================
#  CO TO JEST:
#  Odpala agentów automatycznie (np. 2× dziennie) bez pisania własnego cron.
#  Twoje agenty biegają 1-2× dziennie (nie ciągły watcher) — to jest do tego.
#
#  DLACZEGO APScheduler a nie własny time.sleep:
#  - obsługuje "codziennie o 8:00 i 18:00", "co 6 godzin", cron-y
#  - przetrwa restart jeśli damy trwały jobstore (na razie w pamięci)
#  - zero utrzymania — dojrzała biblioteka
#
#  UŻYCIE (z panelu albo osobno):
#    from scheduler import schedule_agent, start, list_jobs
#    schedule_agent("reporter", run_fn, times=["08:00","18:00"])
#    start()   # nieblokująco — działa w tle
# ============================================================================

try:
    from apscheduler.schedulers.background import BackgroundScheduler
    from apscheduler.triggers.cron import CronTrigger
    from apscheduler.triggers.interval import IntervalTrigger
    _HAS_APS = True
except Exception as _e:
    # Dependency installation belongs to the shared first-run preflight in
    # system_setup.py. Importing this module never mutates the system.
    _HAS_APS = False
    print(f"[Scheduler] APScheduler unavailable ({_e}). First-run setup/wake will install it.")

try:
    from apscheduler.jobstores.sqlalchemy import SQLAlchemyJobStore
    _HAS_SQLSTORE = True
except Exception:
    _HAS_SQLSTORE = False

from events import bus, AGENT_START, AGENT_DONE
import os

_sched = None

# TRWALY JOBSTORE: bez tego zaplanowane zadania gina po restarcie panelu
# (APScheduler domyslnie trzyma joby w pamieci). SQLite w ~/agentsystem/data
# sprawia, ze "codziennie o 8:00" przezywa zamkniecie i ponowne otwarcie panelu.
# WAZNE: trwaly jobstore serializuje FUNKCJE po sciezce modul:nazwa i argumenty
# przez pickle. Dlatego joby musza wskazywac funkcje modulowe (np. "panel:do_run")
# z argumentami-stringami, a NIE lambdy/domkniecia. Gdy przekazana jest lambda,
# automatycznie spadamy na jobstore w pamieci dla tego uruchomienia (bezpiecznie).
_HOME = os.path.expanduser(os.environ.get("ENGINE_HOME", "~/agentsystem"))
_DB_PATH = os.path.join(_HOME, "data", "scheduler_jobs.sqlite")
_persist_ok = False


def _get():
    global _sched, _persist_ok
    if _sched is None and _HAS_APS:
        _store = None
        if _HAS_SQLSTORE:
            try:
                os.makedirs(os.path.dirname(_DB_PATH), exist_ok=True)
                _store = SQLAlchemyJobStore(url="sqlite:///" + _DB_PATH)
                _persist_ok = True
            except Exception:
                _store = None
                _persist_ok = False
        # KLUCZOWE (Py3.14/nowe APS): NIGDY nie przekazuj jobstores=None ani pustego
        # dicta jako named arg — APScheduler robi config.get("jobstores",{}).items()
        # i pada gdy dostanie None. Budujemy scheduler bez argumentu, a jobstore
        # dokladamy PO utworzeniu (add_jobstore) — to omija buggy config path.
        try:
            _sched = BackgroundScheduler(daemon=True)
            if _store is not None:
                try:
                    _sched.add_jobstore(_store, alias="default")
                except Exception:
                    _persist_ok = False   # zostajemy przy pamieci
        except Exception:
            _sched = None
    return _sched


def persistent():
    """Czy scheduler ma trwaly jobstore (przezyje restart)."""
    _get()
    return bool(_persist_ok)


def schedule_once(name, run_fn, date_str, time_str):
    """Jednorazowe uruchomienie o konkretnej dacie i godzinie.
      date_str : 'YYYY-MM-DD' (z <input type=date>)
      time_str : 'HH:MM'      (z <input type=time>)
    Np. "odpal rano w dniu, gdy wypada deadline"."""
    s = _get()
    if not s or not date_str:
        return False
    try:
        from apscheduler.triggers.date import DateTrigger
        import datetime as _dt
        hh, mm = (time_str or "08:00").split(":")[:2]
        y, mo, d = date_str.split("-")
        when = _dt.datetime(int(y), int(mo), int(d), int(hh), int(mm))
        if when < _dt.datetime.now():
            return False                      # data w przeszlosci — pomijamy
        s.add_job(run_fn, DateTrigger(run_date=when),
                  id=f"{name}__once", replace_existing=True)
        return True
    except Exception:
        return False


def schedule_agent(name, run_fn, times=None, every_hours=None, func_ref=None, func_args=None):
    """Zaplanuj agenta.
      name        : nazwa agenta (id zadania)
      run_fn      : funkcja bezargumentowa (fallback, zawsze NIE-trwaly)
      times       : lista godzin "HH:MM" (codziennie o tych porach)
      every_hours : LUB co ile godzin (jesli times nie podane)
      func_ref    : OPCJONALNIE "modul:funkcja" (np. "panel:do_run") -> job TRWALY,
                    przezyje restart. Wymaga func_args.
      func_args   : lista argumentow dla func_ref (picklowalne: str/int/bool)
    WAŻNE: Fallback (lambda bez func_ref) NIE DA SIE SERIALIZOWAC.
    Gdy scheduler ma trwały jobstore (SQL), lambdy nie mogą być dodane bez func_ref.
    Jeśli chcesz trwałości => podaj func_ref="modul:func" + func_args=[...].
    Jeśli fallback to lambda => job ginie po restarcie, ale działa teraz."""
    s = _get()
    if not s:
        return False

    # TRWALY: podana referencja modulowa do funkcji
    if func_ref and _persist_ok:
        target, tkw = func_ref, {"args": list(func_args or [])}
    elif func_ref:
        # func_ref podany, ale brak SQL jobstore — ok, dziala w pamieci
        target, tkw = func_ref, {"args": list(func_args or [])}
    else:
        # Fallback: lambda. NIE można je serializować — jeśli SQL jobstore,
        # będzie błąd i job nie zostanie dodany. To zmusza użytkownika do
        # podania func_ref gdy scheduler ma SQL. W panelu panel.py używa
        # func_ref="panel:do_run" dla scheduled, więc powinno działać.
        if _persist_ok:
            # Błąd: lambda + SQL jobstore — nie mogą żyć razem
            return False  # Odrzuć, zamiast válić się przy add_job
        def _wrapped():
            bus.emit(AGENT_START, sender=name)
            try:
                run_fn()
            finally:
                bus.emit(AGENT_DONE, sender=name)
        target, tkw = _wrapped, {}

    # Remove the whole previous series. When a schedule shrinks from e.g. three
    # slots to one, leaving name_1/name_2 behind would create ghost wake runs.
    try:
        for j in list(s.get_jobs()):
            if j.id == name or j.id.startswith(str(name) + "_"):
                try: s.remove_job(j.id)
                except Exception: pass
    except Exception:
        pass

    if times:
        for i, t in enumerate(times):
            hh, mm = t.split(":")
            s.add_job(target, CronTrigger(hour=int(hh), minute=int(mm)),
                      id=f"{name}" if i == 0 else f"{name}_{i}", replace_existing=True,
                      misfire_grace_time=3600,  # przegapiony run (do 1h) i tak sie odpali
                      coalesce=True, **tkw)      # kilka przegapionych = jeden run, nie seria
    elif every_hours:
        s.add_job(target, IntervalTrigger(hours=int(every_hours)),
                  id=name, replace_existing=True,
                  misfire_grace_time=3600, coalesce=True, **tkw)
    return True


def start():
    """Wystartuj scheduler w tle (nieblokująco). Bezpieczne wielokrotnie.
    Gdy APScheduler wewnetrznie padnie (np. Py3.14 config bug), lapiemy — panel
    dziala dalej z run-on-start, tylko godziny nie beda pilnowane w tej sesji."""
    try:
        s = _get()
        if s and not s.running:
            s.start()
    except Exception as e:
        print(f"[Scheduler] start failed ({e}) — hourly runs off this session, run-on-start OK")


def stop():
    s = _get()
    if s and s.running:
        s.shutdown(wait=False)


def list_jobs():
    """Lista zaplanowanych zadań (id + następne uruchomienie jeśli wystartowany)."""
    s = _get()
    if not s:
        return []
    return [{"id": j.id, "next": str(getattr(j, "next_run_time", None))} for j in s.get_jobs()]
