#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
l4m_popup.py - UNIWERSALNY popup dla calej rodziny 1-Click (Locally4Me).

Ten sam popup we wszystkich produktach: LocalAI, Knowledge Downloader itd.
Wrzuc ten plik OBOK glownego skryptu 1-clicka i zawolaj:

    import l4m_popup
    l4m_popup.show(lang="pl")          # albo lang="en"; brak -> auto

Popup NATYWNY (tkinter) tam gdzie sie da - zamyka sie przyciskiem naprawde.
Gdy tkinter niedostepny (np. Linux bez python3-tk) -> fallback do przegladarki.

Zaleznosci: TYLKO standardowa biblioteka. Zero pip install.
Obrazki 1.png/2.png/3.png (opcjonalne) - klatki animacji, leza obok tego pliku
lub obok glownego programu (podaj base_dir jesli inny katalog).
"""
import os, sys, json, random
from datetime import datetime, timedelta, timezone

# domyslne linki - edytuj tu RAZ, dziala we wszystkich produktach
# Kolejnosc = priorytet wyswietlania (ECS pierwszy, zgodnie z glownym celem).
DEFAULT_LINKS = [
    ("🎯 Essential Crisis Software — main mission", "https://enhanced.world/ecs/"),
    ("☕ Support / Ko-Fi Marketplace", "https://ko-fi.com/4community/shop"),
    ("Locally4Me — other projects", "https://locally4me.org"),
]

ANIM_INTERVAL_MS = 8393   # celowo dlugi: obrazki nie rozpraszaja
POPUP_VERSION = 1   # podbijaj przy zmianie tresci — wybudzacz wybiera najwyzsza wersje w rodzinie

# ── REGULA CZASOWA (ze starego popup_scheduler.py) ──────────────────────────
# Pierwsze pokazanie krotko po starcie; kolejne LOSOWO miedzy MIN a MAX, zeby
# popup nie byl natretny i nie pojawial sie regularnie.
INITIAL_DELAY_S = 6 * 60                   # first display: 6 minutes after registration/start
MIN_DELAY_S = 4 * 60 * 60                 # later: no sooner than 4 hours
MAX_DELAY_S = 5 * 24 * 60 * 60            # and no later than 5 days
DEFAULT_VISIBLE_S = 25                     # native window auto-closes; wake_config.json can override
STATE_FILE = os.path.join(os.path.expanduser("~"), ".l4m_popup_state.json")

# teksty EN baza, PL opcja. Latwo dodac kolejne jezyki - dopisz klucz.
# Uklad tresci (wg briefu): GLOWNY CEL na gorze (ECS, jedno mocne zdanie) ->
# nizej pozostale projekty OGOLNIE (jedna linia, bez wyliczania) -> wezwanie
# do wsparcia + element pozytywny na koniec. Krotko, bez sciany tekstu.
TEXTS = {
    "head":  {"en": "Essential Crisis Software — open-source, life-saving tools",
              "pl": "Essential Crisis Software — otwarte narzędzia ratujące życie"},
    "l1":    {"en": "My main mission: building free, open-source software for crisis response — code that helps when it matters most.",
              "pl": "Mój główny cel: darmowe, otwarte oprogramowanie na wypadek kryzysu — kod, który pomaga, gdy liczy się najbardziej."},
    "l2":    {"en": "Alongside it, I build practical local-first tools for everyday work — this app is one of them.",
              "pl": "Obok tego tworzę praktyczne narzędzia do codziennej pracy, lokalne i prywatne — ta aplikacja jest jednym z nich."},
    "l3":    {"en": "If it saves you time, a coffee or a share keeps this going. Thank you for being here — you're part of it. 🙏",
              "pl": "Jeśli oszczędza Ci to czas, kawa albo udostępnienie napędza dalszą pracę. Dzięki, że tu jesteś — to ma znaczenie. 🙏"},
    "close": {"en": "Close", "pl": "Zamknij"},
    "hint":  {"en": "If it does not close, close it manually (Ctrl+W).",
              "pl": "Jeśli okno się nie zamknie, zamknij je ręcznie (Ctrl+W)."},
}


def _auto_lang():
    import locale
    env = os.environ.get("L4M_LANG", "").lower()
    if env in TEXTS["head"]:
        return env
    probe = ""
    for var in ("LC_ALL", "LC_MESSAGES", "LANG", "LANGUAGE"):
        probe = os.environ.get(var, "")
        if probe:
            break
    if not probe:
        try:
            probe = (locale.getlocale()[0] or "") or (locale.getdefaultlocale()[0] or "")
        except Exception:
            probe = ""
    probe = probe.lower()
    return "pl" if probe.startswith("pl") else "en"


def _t(key, lang):
    d = TEXTS.get(key, {})
    return d.get(lang) or d.get("en") or key


def _has_gui_session():
    if sys.platform.startswith("win") or sys.platform == "darwin":
        return True
    return bool(os.environ.get("DISPLAY") or os.environ.get("WAYLAND_DISPLAY"))



# ── STAN + REGULA CZASOWA ───────────────────────────────────────────────────

def _load_state():
    if os.path.exists(STATE_FILE):
        try:
            return json.load(open(STATE_FILE, encoding="utf-8"))
        except Exception:
            pass
    return {"has_been_shown": False, "next_run_at": None}


def _save_state(state):
    try:
        os.makedirs(os.path.dirname(STATE_FILE), exist_ok=True)
        json.dump(state, open(STATE_FILE, "w", encoding="utf-8"), indent=2)
    except Exception:
        pass


def _next_delay(state):
    """Pierwszy raz -> INITIAL_DELAY_S; potem losowo MIN..MAX (jak stary scheduler)."""
    if not state.get("has_been_shown"):
        return INITIAL_DELAY_S
    return random.randint(MIN_DELAY_S, MAX_DELAY_S)


def _is_due(state):
    """Czy wypada pokazac popup TERAZ wg zapisanego next_run_at.
    PIERWSZY raz (brak next_run_at): NIE pokazuj od razu — zaplanuj za INITIAL_DELAY_S.
    Popup pojawi sie dopiero gdy ten czas minie (przy kolejnym starcie/tick)."""
    nra = state.get("next_run_at")
    if not nra:
        return False        # pierwszy raz: nie pokazuj, tylko zaplanuj (patrz maybe_show)
    try:
        return datetime.now(timezone.utc).timestamp() >= float(nra)
    except Exception:
        return False


def _schedule_first(state):
    """Ustaw pierwszy termin (teraz + INITIAL_DELAY_S) bez pokazywania."""
    state["next_run_at"] = (datetime.now(timezone.utc) + timedelta(seconds=INITIAL_DELAY_S)).timestamp()
    _save_state(state)


def _reschedule(state):
    delay = _next_delay(state)
    state["next_run_at"] = (datetime.now(timezone.utc) + timedelta(seconds=delay)).timestamp()
    state["has_been_shown"] = True
    _save_state(state)


def maybe_show(lang=None, links=None, base_dir=None):
    """Pokaz popup TYLKO jesli minal zaplanowany czas. Wolaj przy KAZDYM starcie.
    Pierwszy raz: NIE pokazuje, planuje za INITIAL_DELAY_S (6 min).
    Kolejne starty: pokaze gdy czas minie, potem losowy odstep."""
    state = _load_state()
    if not state.get("next_run_at"):
        _schedule_first(state)          # pierwszy raz: zaplanuj, nie pokazuj
        return False
    if not _is_due(state):
        return False
    show(lang=lang, links=links, base_dir=base_dir)
    _reschedule(state)
    return True


def show(lang=None, links=None, base_dir=None, force_browser=False, visible_s=None):
    """Show immediately. Desktop/native is the default; browser is debug-only.

    visible_s controls the auto-close countdown.  Wake passes the effective value
    from wake_config.json, so the popup has one source of truth for timing.
    """
    lang = lang or _auto_lang()
    links = links or DEFAULT_LINKS
    base_dir = base_dir or os.path.dirname(os.path.abspath(__file__))
    visible_s = int(visible_s or os.environ.get("L4M_POPUP_VISIBLE_S", DEFAULT_VISIBLE_S))
    if force_browser:
        _show_browser(lang, links, base_dir)
        return
    try:
        import tkinter  # noqa
        if _has_gui_session():
            _show_tk(lang, links, base_dir, visible_s=visible_s)
            return
    except Exception:
        pass
    _show_native_notification(lang, links, visible_s)


def _show_tk(lang, links, base_dir, visible_s=DEFAULT_VISIBLE_S):
    import tkinter as tk
    import webbrowser as _wb
    root = tk.Tk()
    root.title("Practical Tools")
    root.configure(bg="#f3f4f6")
    root.resizable(False, False)
    root.attributes("-topmost", True)

    frame = tk.Frame(root, bg="#f3f4f6", padx=22, pady=20)
    frame.pack(fill="both", expand=True)
    tk.Label(frame, text=_t("head", lang), font=("Segoe UI", 15, "bold"),
             bg="#f3f4f6", fg="#111827").pack(anchor="w", pady=(0, 12))

    frames = []
    try:
        for n in ("1.png", "2.png", "3.png"):
            p = os.path.join(base_dir, n)
            if os.path.exists(p):
                frames.append(tk.PhotoImage(file=p))
    except Exception:
        frames = []
    if frames:
        img_lbl = tk.Label(frame, image=frames[0], bg="#f3f4f6")
        img_lbl.image = frames
        img_lbl.pack(pady=(0, 12))
        if len(frames) > 1:
            state = {"i": 0}
            def _tick():
                if not root.winfo_exists():
                    return
                state["i"] = (state["i"] + 1) % len(frames)
                img_lbl.configure(image=frames[state["i"]])
                root.after(ANIM_INTERVAL_MS, _tick)
            root.after(ANIM_INTERVAL_MS, _tick)

    for key in ("l1", "l2", "l3"):
        tk.Label(frame, text=_t(key, lang), font=("Segoe UI", 10), bg="#f3f4f6",
                 fg="#374151", justify="left", anchor="w",
                 wraplength=520).pack(anchor="w", pady=1)

    tk.Frame(frame, bg="#d1d5db", height=1).pack(fill="x", pady=12)
    for label_text, url in links:
        lk = tk.Label(frame, text=label_text, fg="#2563eb", bg="#f3f4f6",
                      cursor="hand2", font=("Segoe UI", 10, "underline"), anchor="w")
        lk.pack(anchor="w", pady=2)
        lk.bind("<Button-1>", lambda _e, u=url: _wb.open(u))

    countdown = tk.StringVar(value="")
    tk.Label(frame, textvariable=countdown, font=("Segoe UI", 8), bg="#f3f4f6",
             fg="#6b7280").pack(anchor="w", pady=(10, 2))
    tk.Label(frame, text=_t("hint", lang), font=("Segoe UI", 8), bg="#f3f4f6",
             fg="#9ca3af").pack(anchor="w", pady=(0, 4))
    tk.Button(frame, text=_t("close", lang), width=14, font=("Segoe UI", 10, "bold"),
              command=root.destroy).pack(anchor="e", pady=(4, 0))

    end_at = __import__("time").time() + max(1, int(visible_s or DEFAULT_VISIBLE_S))
    def _close_tick():
        if not root.winfo_exists():
            return
        left = max(0, int(end_at - __import__("time").time()) + 1)
        countdown.set(("Auto-close in " if lang != "pl" else "Automatyczne zamknięcie za ") + str(left) + " s")
        if left <= 0:
            root.destroy(); return
        root.after(250, _close_tick)
    root.after(100, _close_tick)

    root.update_idletasks()
    w, h = root.winfo_width(), root.winfo_height()
    x = (root.winfo_screenwidth() // 2) - (w // 2)
    y = (root.winfo_screenheight() // 2) - (h // 2)
    root.geometry(f"+{x}+{y}")
    root.protocol("WM_DELETE_WINDOW", root.destroy)
    root.mainloop()


def _show_native_notification(lang, links, visible_s=DEFAULT_VISIBLE_S):
    """Non-browser fallback.  Prefer notify-py, then OS-native notification tools."""
    title = _t("head", lang)
    body = _t("l1", lang) + "\n" + _t("l3", lang)
    try:
        from notifypy import Notify
        n = Notify(); n.title = title; n.message = body; n.send(); return True
    except Exception:
        pass
    try:
        import subprocess
        if sys.platform == "darwin":
            script = 'display notification ' + json.dumps(body) + ' with title ' + json.dumps(title)
            subprocess.Popen(["osascript", "-e", script], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL); return True
        if sys.platform.startswith("win"):
            # Windows fallback is intentionally simple and does not open a browser.
            ps = f"Add-Type -AssemblyName PresentationFramework;[System.Windows.MessageBox]::Show({json.dumps(body)},{json.dumps(title)})"
            subprocess.Popen(["powershell", "-NoProfile", "-Command", ps], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL); return True
        if __import__("shutil").which("notify-send"):
            subprocess.Popen(["notify-send", title, body], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL); return True
    except Exception:
        pass
    print("[Popup]", title, "-", body)
    return False


def _show_browser(lang, links, base_dir):
    import tempfile, html as _html, webbrowser
    t_head = _t("head", lang)
    t_intro = _t("l1", lang) + "<br>" + _t("l2", lang) + "<br>" + _html.escape(_t("l3", lang))
    t_close = _t("close", lang)
    t_hint = _t("hint", lang)

    imgs = [os.path.join(base_dir, n) for n in ("1.png", "2.png", "3.png")]
    imgs = [p for p in imgs if os.path.exists(p)]
    img_tags = ""
    if imgs:
        srcs = ",".join('"file://' + p.replace("\\", "/") + '"' for p in imgs)
        img_tags = (f'<img id="anim" src="file://{imgs[0]}" style="width:240px;'
                    f'height:auto;max-width:100%;display:block;margin:0 auto 14px;'
                    f'border-radius:8px">'
                    f'<script>var _f=[{srcs}],_i=0;if(_f.length>1)setInterval('
                    f'function(){{_i=(_i+1)%_f.length;'
                    f"document.getElementById('anim').src=_f[_i];}},{ANIM_INTERVAL_MS});</script>")
    links_html = "".join(
        f'<a href="{_html.escape(u)}" target="_blank" style="display:block;'
        f'margin:8px 0;color:#2563eb;font-weight:600;text-decoration:none;'
        f'word-break:break-word">{_html.escape(lbl)}</a>' for lbl, u in links)

    page = f'''<!doctype html><html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Practical Tools</title></head>
<body style="margin:0;padding:20px;box-sizing:border-box;background:#111827;
     font-family:Segoe UI,system-ui,sans-serif;min-height:100vh">
<div style="max-width:640px;width:100%;margin:0 auto;background:#f3f4f6;
     border-radius:14px;padding:28px;box-sizing:border-box;
     box-shadow:0 20px 60px #0009;overflow-wrap:break-word">
  <h2 style="margin:0 0 14px;color:#111827">{t_head}</h2>
  {img_tags}
  <div style="color:#374151;font-size:15px;line-height:1.6;margin-bottom:16px">
    {t_intro}
  </div>
  <div style="border-top:1px solid #d1d5db;padding-top:14px">{links_html}</div>
  <div style="margin-top:22px;display:flex;gap:12px;align-items:center;flex-wrap:wrap">
    <button onclick="try{{window.close();}}catch(e){{}};window.open('','_self');window.close();"
       style="padding:10px 22px;border:0;border-radius:8px;background:#2563eb;
       color:#fff;font-weight:700;font-size:15px;cursor:pointer">{t_close}</button>
    <span style="color:#6b7280;font-size:13px">{t_hint}</span>
  </div>
</div>
</body></html>'''
    fd, path = tempfile.mkstemp(suffix=".html", prefix="l4m_popup_")
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        f.write(page)
    webbrowser.open("file://" + path)


if __name__ == "__main__":
    # wake.py calls: l4m_popup.py --show-now --timeout 45 [--lang pl]
    args = sys.argv[1:]
    if "--show-now" in args:
        timeout = DEFAULT_VISIBLE_S
        lang = None
        if "--timeout" in args:
            try: timeout = int(args[args.index("--timeout") + 1])
            except Exception: pass
        if "--lang" in args:
            try: lang = args[args.index("--lang") + 1]
            except Exception: pass
        show(lang=lang, visible_s=timeout)
    elif "maybe" in args:
        lang = next((x for x in args if x in ("pl","en")), None)
        print("shown:", maybe_show(lang=lang))
    else:
        lang = next((x for x in args if x in ("pl","en")), None)
        show(lang=lang)
