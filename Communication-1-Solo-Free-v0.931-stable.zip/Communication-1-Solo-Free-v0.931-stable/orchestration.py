# ============================================================================
#  orchestration.py  —  NADRZEDNY ZARZADZACZ AI dla A-Tools  (PLACEHOLDER)
# ============================================================================
#  STATUS: to jest SZKIELET. Nic tu nic nie WYMUSZA i niczego nie zmienia w
#  enginie. Sluzy jako punkt zaczepienia dla przyszlego "AI schedulera /
#  orkiestracji". Kazdy A-Tool moze go wolac opcjonalnie — brak pliku
#  orchestration.json = wszyscy dzialaja po staremu na wlasnym modelu.
#
#  PO CO ISTNIEJE (wg ustalen z Karolem):
#  Kazdy A-Tool trzyma WLASNE klucze i wybrany model lokalnie w swoim presecie
#  — to sie NIE zmienia. Dodatkowo, przy zapisie profilu, narzedzie MOZE dopisac
#  deklaracje swojego modelu do wspolnej listy (~/agentsystem/orchestration.json
#  albo ../.eco_data/orchestration.json). Dzieki temu przyszly agent moze przy
#  starcie odczytac, jakie modele sa REALNIE dostepne w ekosystemie (np. ze ktos
#  postawil lokalnie mocny qwen2.5:14b dobry do polskiego) i "wypozyczyc" lepszy
#  model do zadania wrazliwego na jakosc (draft pisma urzedowego), zostawiajac
#  slaby model do tanich operacji (klasyfikacja, tagowanie).
#
#  KONTRAKT WPISU (jeden element listy):
#    {
#      "tool": "inbox-reporter",
#      "provider": "ollama",
#      "model": "qwen2.5:14b",
#      "kind": "reporter",
#      "quality_tier": "high",          # high | mid | low
#      "languages": ["pl", "en"],
#      "endpoint": "http://localhost:11434",
#      "added": "<ISO8601>"
#    }
#  Dolaczanie po kluczu (tool, model):
#  ostatni wpis wygrywa dla danej pary. Brak globalnego nadpisania stanu.
#
#  ZASADA: nic nie jest wymuszane.
#    brak pliku      -> kazdy dziala po staremu na swoim modelu
#    obecnosc pliku  -> OPCJONALNY upgrade jakosci bez dublowania kluczy
#
#  CO TU JESZCZE NIE JEST ZROBIONE (swiadomie — to placeholder):
#    - realny wybor modelu do zadania (borrow_model ponizej tylko filtruje liste)
#    - kolejkowanie/arbitraz gdy dwa A-Tools chca ten sam lokalny model naraz
#      (to bedzie warstwa 'broker' obok hq.py — patrz AI_ORCHESTRATION.md)
#    - budzet tokenow per klucz (Groq 8000 TPM) wspoldzielony miedzy A-Tools
#    - UI ustawien (na razie brak; docelowo core-ui albo popup)
#  Powyzsze zostaje do osobnej tury "AI scheduler".
# ============================================================================

import os, json, datetime

FORMAT_VERSION = 1


def _path():
    """Gdzie lezy orchestration.json. Priorytet: katalog nadrzedny ekosystemu
    (.eco_data), fallback: ~/agentsystem. Dzieki temu w ekosystemie wpisy sa
    wspolne, a standalone i tak dziala (lokalnie)."""
    here = os.path.dirname(os.path.abspath(__file__))
    parent_eco = os.path.join(os.path.dirname(here), ".eco_data")
    if os.path.isdir(parent_eco):
        return os.path.join(parent_eco, "orchestration.json")
    home = os.path.expanduser(os.environ.get("ENGINE_HOME", "~/agentsystem"))
    os.makedirs(home, exist_ok=True)
    return os.path.join(home, "orchestration.json")


def read_pool():
    """Zwraca liste dostepnych modeli w ekosystemie. [] gdy pliku brak."""
    p = _path()
    if not os.path.exists(p):
        return []
    try:
        data = json.load(open(p, encoding="utf-8"))
        return data.get("models", []) if isinstance(data, dict) else []
    except Exception:
        return []


def declare_model(tool, provider, model, kind=None, quality_tier="mid",
                  languages=None, endpoint=None):
    """A-Tool DEKLARUJE swoj model do wspolnej puli. Wolane opcjonalnie przy
    zapisie profilu. Dolaczanie po kluczu (tool, model) — ostatni wygrywa.
    NIC nie wymusza; to tylko ogloszenie 'mam taki model, mozecie skorzystac'."""
    p = _path()
    try:
        data = json.load(open(p, encoding="utf-8")) if os.path.exists(p) else {}
    except Exception:
        data = {}
    if not isinstance(data, dict):
        data = {}
    data.setdefault("v", FORMAT_VERSION)
    models = data.get("models", [])
    entry = {
        "tool": tool, "provider": provider, "model": model,
        "kind": kind, "quality_tier": quality_tier,
        "languages": languages or [], "endpoint": endpoint,
        "added": datetime.datetime.now().isoformat(timespec="seconds"),
    }
    models = [m for m in models if not (m.get("tool") == tool and m.get("model") == model)]
    models.append(entry)
    data["models"] = models
    try:
        os.makedirs(os.path.dirname(p), exist_ok=True)
        json.dump(data, open(p, "w", encoding="utf-8"), indent=2, ensure_ascii=False)
        return True
    except Exception:
        return False


def borrow_model(quality_tier=None, language=None, kind=None):
    """[PLACEHOLDER doboru] Zwraca liste kandydatow z puli pasujacych do
    wymagan, posortowana wg jakosci. NIE laczy sie z modelem, NIE wymusza —
    tylko podpowiada. Reporter moglby zawolac:
        borrow_model(quality_tier='high', language='pl')  # do drafta
    i jesli cos wroci, uzyc tego zamiast wlasnego slabego modelu.
    Gdy pula pusta lub brak dopasowania -> [] (agent zostaje przy swoim)."""
    order = {"high": 0, "mid": 1, "low": 2}
    out = []
    for m in read_pool():
        if quality_tier and m.get("quality_tier") != quality_tier:
            continue
        if language and language not in (m.get("languages") or []):
            continue
        if kind and m.get("kind") and m.get("kind") != kind:
            continue
        out.append(m)
    out.sort(key=lambda m: order.get(m.get("quality_tier"), 9))
    return out


# Szybki podglad z CLI:  python3 orchestration.py
if __name__ == "__main__":
    print("orchestration.json ->", _path())
    print("pula modeli:", json.dumps(read_pool(), indent=2, ensure_ascii=False))


# ============================================================================
#  PLACEHOLDERY DO ROZBUDOWY (patrz AI_ORCHESTRATION.md §9)
#  Nic z ponizszego niczego nie wymusza. To szkielety pod przyszla orkiestracje.
# ============================================================================

# §9.7 Presety zarzadzania — 3 tryby, do wyboru w kreatorze setupu.
MANAGEMENT_PRESETS = {
    "solo_free": {
        "label": "Solo / Free (wszystko lokalnie)",
        "default_provider": "ollama", "budgets": False, "server": False,
        "shared_cache": False,
    },
    "balanced": {
        "label": "Balanced (API free + lokalny fallback)",
        "default_provider": "groq", "fallback": "ollama", "budgets": True,
        "server": False, "shared_cache": True,
    },
    "premium_server": {
        "label": "Premium / Server (serwer AI + Wake-on-LAN + paid API)",
        "default_provider": "server", "paid_api_for": ["high"], "budgets": True,
        "server": True, "wake_on_lan": True, "shared_cache": True,
    },
}

# §9.2 Domyslny bukiet parametrow a-toola (dokumentacyjny — realnie w profilu).
ATOOL_PARAM_DEFAULTS = {
    "runtime":   {"expected_seconds": 60, "runs_per_day": 2, "complexity": "low"},
    "resources": {"uses_local_model": False, "uses_api": True,
                  "api_tier": "free", "key_shared": True},
    "schedule":  {"preferred_windows": ["08:00", "18:00"], "flexible": True,
                  "min_gap_min": 5},
    "data":      {"cache_scope": "shared", "cache_ttl_min": 1440,
                  "retention_days": 30},
    "priority":  {"base_priority": 3},
    "cost":      {"token_budget_day": 0, "cost_ceiling_eur_month": 0},
}


def atool_trust(atool_id):
    """[PLACEHOLDER §9.1] Zwraca 'pending'|'accepted'|'blocked' z ecosystem.json.
    Dzis brak pola trust -> traktujemy jako 'accepted' (zgodnosc wstecz)."""
    try:
        import atool_sync
        for a in atool_sync.read_ecosystem().get("atools", []):
            if a.get("id") == atool_id:
                return a.get("trust", "accepted")
    except Exception:
        pass
    return "accepted"


def may_run(atool_id):
    """[PLACEHOLDER §9.1] Czy a-tool wolno odpalic wg akceptacji usera.
    wake.py powinien to sprawdzac, gdy pojawi sie 2. a-tool. Dzis: True."""
    return atool_trust(atool_id) != "blocked"
