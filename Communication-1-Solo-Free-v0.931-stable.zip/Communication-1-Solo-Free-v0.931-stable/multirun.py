# ============================================================================
#  multirun.py — MACIERZ WIELU RUNOW: jeden agent, wiele konfiguracji, obok siebie
# ============================================================================
#  ZAKRES: JEDEN a-tool, wiele runow TEGO SAMEGO a-toola. To NIE jest porownanie
#  roznych a-tooli.
#
#  CEL MODULU: ocena, ktora konfiguracja daje najlepszy wynik dla deva —
#  czytelnosc, accuracy, efektywnosc. Wykrycie rozjazdow (ten sam mail dostaje
#  inny tag/priorytet w innym runie) to NARZEDZIE do tej oceny, nie cel sam w sobie.
#
#  GENERYCZNY: silnik NIC nie wie o poczcie. Bierze liste selektorow jako WEJSCIE
#  (multirun_selectors_reporter.py dla Reportera). Inny a-tool podaje wlasny plik
#  selektorow o tym samym ksztalcie i uzywa tego samego silnika bez zmian.
#
#  JAK UKLADAMY KOMBINACJE (spec, punkt 2):
#    - BAZA = opcje glownego selektora silnika (ENGINE): script / ai_free / ai_deep.
#      Jeden run bazowy na kazda opcje => zwykle 3 runy.
#    - POZOSTALE selektory (OTHERS) NIE sa mnozone kartezjansko. Ich opcje
#      rozdzielamy ROTACYJNIE miedzy runy bazowe, zeby w MINIMALNEJ liczbie runow
#      wyprobowac jak najwiecej roznych ustawien.
#    - MAKSIMUM kombinacji = liczba opcji najliczniejszego selektora (zwykle 4).
#    - Selektor z flaga invoke=True (agent -> agent) to OSOBNY mechanizm (punkt 5):
#      nie miesza sie do rotacji zakresu; jego opcja "on" nakladana jest jako
#      dodatkowy wymiar na baze.
#
#  PROBKA (spec, punkt 1):
#    - Jedno konto: skrzynka/feed o najwiekszej liczbie wiadomosci.
#    - 4 maile o ROZNYCH priorytetach i ROZNYCH tagach (P1! / P2 / bulk / neutralny).
#    - Te same 4 maile przechodza przez WSZYSTKIE kombinacje.
#    - Probka trzymana w pamieci tymczasowej runu (multirun temp), nie w stalym stanie.
#    - Multi-run ZAWSZE dziala tylko na tym wycinku, nigdy na calej skrzynce (TPM Groqa).
#    - REGULA DOMKNIETA: jesli na wybranym koncie brak maila danego typu, szukamy
#      na innych skrzynkach; jesli NIGDZIE go nie ma, piszemy to WPROST w probce
#      (placeholder z powodem) i NIE dobieramy duplikatow, byle dopelnic do 4.
# ============================================================================

import os, json, copy, time


# ---------------------------------------------------------------------------
#  1. UKLADANIE KOMBINACJI
# ---------------------------------------------------------------------------
def build_combos(engine, others):
    """Z listy selektorow uklada kombinacje wg reguly rotacyjnej (nie kartezjanskiej).

      engine  — glowny selektor (dict z .options)
      others  — lista pozostalych selektorow (kazdy z .options)

    Zwraca liste kombinacji. Kazda: {key, name, desc, outputs, invoke}.
    """
    eng_opts = engine.get("options", [])
    base_n = len(eng_opts) or 1

    # OTHERS bez selektora invoke (ten idzie osobnym wymiarem)
    rot = [s for s in others if not s.get("invoke")]
    invoke_sel = next((s for s in others if s.get("invoke")), None)

    # MAKSIMUM = liczba opcji najliczniejszego selektora
    all_counts = [base_n] + [len(s.get("options", [])) for s in others]
    max_combos = max(all_counts) if all_counts else base_n
    n = max(base_n, min(max_combos, max(base_n, max([len(s.get("options", [])) for s in rot], default=0) or base_n)))
    # co najmniej tyle runow, ile opcji silnika
    n = max(n, base_n)

    combos = []
    for i in range(n):
        eng = eng_opts[i % base_n]
        out = dict(eng.get("out", {}))
        parts = [eng["label"]]
        descs = [eng.get("desc", "")]
        # RUN 0 = CZYSTA BAZA: wszystkie pozostale selektory na pierwszej (domyslnej)
        # opcji. Bez tego baza byla okaleczona (np. deadline OFF) i porownanie
        # nie mialo punktu odniesienia.
        # RUN >0 = wlaczamy PO JEDNYM wariancie na run, przesuwajac sie po liscie
        # wszystkich nie-domyslnych opcji. Dzieki temu zaden run sie nie powtarza.
        if i == 0:
            for sel in rot:
                opts = sel.get("options", [])
                if opts:
                    out.update(opts[0].get("out", {}))
        else:
            # plaska lista wariantow: (selektor, opcja) dla kazdej opcji != domyslna
            variants = []
            for sel in rot:
                for opt in sel.get("options", [])[1:]:
                    variants.append((sel, opt))
            # najpierw domyslne dla wszystkich...
            for sel in rot:
                opts = sel.get("options", [])
                if opts:
                    out.update(opts[0].get("out", {}))
            # ...potem nakladamy warianty przypadajace na ten run (round-robin)
            if variants:
                per = max(1, len(variants) // max(1, n - 1))
                start = (i - 1) * per
                # ostatni run zgarnia RESZTE, zeby zaden wariant nie wypadl
                chunk = variants[start:] if i == n - 1 else variants[start:start + per]
                for sel, opt in chunk:
                    out.update(opt.get("out", {}))
                    parts.append(opt["label"])
                    descs.append(opt.get("desc", ""))
        combos.append({
            "key": f"c{i}_{eng['key']}",
            "name": " · ".join(parts) if len(parts) > 1 else parts[0] + " · defaults",
            "desc": " ".join(d for d in descs if d),
            "outputs": out,
            "invoke": False,
        })

    # WYMIAR AGENT -> AGENT (osobny mechanizm): dodaj wariant "on" jako
    # dodatkowa kombinacje na bazie pierwszego runu z AI, jesli selektor istnieje.
    if invoke_sel:
        on = next((o for o in invoke_sel.get("options", []) if o["key"] == "on"), None)
        if on:
            base = next((c for c in combos if c["outputs"].get("ai_level", "off") != "off"), combos[0])
            out = dict(base["outputs"]); out.update(on.get("out", {}))
            combos.append({
                "key": f"c{len(combos)}_invoke",
                "name": base["name"] + " · " + on["label"],
                "desc": base["desc"] + " " + on.get("desc", ""),
                "outputs": out,
                "invoke": True,
            })

    return combos


# ---------------------------------------------------------------------------
#  2. PROBKA — 4 maile o roznych priorytetach i tagach (spec punkt 1)
# ---------------------------------------------------------------------------
def _classify_slot(row):
    """Do ktorego 'slotu' probki pasuje mail: p1 / p2 / bulk / neutral."""
    pri = row.get("priority", "")
    tags = [t.lower() for t in row.get("tags", [])]
    cat = (row.get("cat", "") or "").lower()
    if pri in ("P1!", "P1"):
        return "p1"
    if pri == "P2":
        return "p2"
    if cat in ("ads", "marketing", "social", "system") or any(
            t in ("promo", "bulk", "newsletter", "ads", "social") for t in tags):
        return "bulk"
    return "neutral"


def pick_sample(snapshots):
    """Wybiera 4 maile o ROZNYCH priorytetach i ROZNYCH tagach.

    snapshots — {combo_key: snapshot} z pierwszego przebiegu (baza).
    Szuka najpierw na koncie o najwiekszej liczbie wiadomosci; brakujace typy
    dobiera z innych skrzynek. Jesli typu NIGDZIE nie ma — placeholder z powodem
    (regula domknieta: bez dobierania duplikatow).

    Zwraca liste 4 pozycji: {slot, mid, from, title, missing, reason}.
    """
    # Zbierz wszystkie wiersze ze wszystkich runow bazy, per konto (src).
    by_src = {}
    for snap in snapshots.values():
        for r in snap.get("rows", []):
            by_src.setdefault(r.get("src", "?"), []).append(r)
    if not by_src:
        return [{"slot": s, "missing": True,
                 "reason": "brak jakichkolwiek wiadomosci w tym runie"}
                for s in ("p1", "p2", "bulk", "neutral")]

    # Konto o najwiekszej liczbie wiadomosci = glowne
    main_src = max(by_src, key=lambda s: len(by_src[s]))
    order = [main_src] + [s for s in by_src if s != main_src]

    wanted = ["p1", "p2", "bulk", "neutral"]
    sample, used_mids = [], set()
    for slot in wanted:
        found = None
        for src in order:                      # najpierw glowne konto, potem reszta
            for r in by_src[src]:
                mid = r.get("mid") or (r.get("from", "") + r.get("title", ""))
                if mid in used_mids:
                    continue
                if _classify_slot(r) == slot:
                    found = (mid, r); break
            if found:
                break
        if found:
            mid, r = found
            used_mids.add(mid)
            sample.append({"slot": slot, "mid": mid,
                           "from": r.get("from", ""), "title": (r.get("title", "") or r.get("summary", ""))[:70],
                           "src": r.get("src", ""), "missing": False})
        else:
            # REGULA DOMKNIETA: nigdzie nie ma -> wpisz wprost, nie dobieraj duplikatu
            sample.append({"slot": slot, "missing": True,
                           "reason": f"na zadnym koncie nie ma maila typu '{slot}' "
                                     f"— nie dobieram duplikatu, zeby probka byla uczciwa"})
    return sample


# ---------------------------------------------------------------------------
#  3. SNAPSHOT jednego runu — bez wchodzenia w szczegoly a-toola
# ---------------------------------------------------------------------------
def _snapshot(name, data_dir):
    out = {"tokens": 0, "summaries": 0, "elapsed": 0, "rows": [],
           "folders": 0, "reach": 0}
    p = os.path.join(data_dir, f"{name}_report.json")
    if not os.path.exists(p):
        return out
    try:
        rj = json.load(open(p, encoding="utf-8"))
    except Exception:
        return out
    import re
    note = str(rj.get("note", ""))
    m = re.search(r"(\d+).*?~?(\d+)\s*tok", note)
    if m:
        out["summaries"] = int(m.group(1)); out["tokens"] = int(m.group(2))
    boxes = rj.get("mailboxes", [])
    out["folders"] = len(boxes)
    for mb in boxes:
        out["reach"] += mb.get("total", 0)
        for r in mb.get("rows", []) + mb.get("hidden_rows", []):
            out["rows"].append({
                "mid": r.get("mid", ""), "src": mb.get("mailbox", r.get("src", "")),
                "from": r.get("from", ""), "title": (r.get("summary", "") or "")[:70],
                "tags": r.get("tags", []), "priority": r.get("priority", "?"),
                "summary": (r.get("summary", "") or "")[:200], "cat": r.get("cat", ""),
            })
    return out


# ---------------------------------------------------------------------------
#  4. GLOWNY WEJSCIE — odpal kombinacje i zbuduj macierz
# ---------------------------------------------------------------------------
def load_selectors(selectors_module="multirun_selectors_reporter"):
    """Laduje (ENGINE, OTHERS) z pliku konfiguracyjnego a-toola."""
    mod = __import__(selectors_module)
    return mod.selectors()


def run_matrix(profile, combo_keys=None, no_memory=True, log=None,
               selectors_module="multirun_selectors_reporter"):
    """Odpala wybrane kombinacje TEGO SAMEGO a-toola i buduje macierz.

      profile      — profil a-toola (dowolnego!)
      combo_keys   — ktore kombinacje uruchomic (None = wszystkie)
      no_memory    — czysc pamiec przed kazdym runem, by kazdy dostal te same maile
      selectors_module — plik z lista selektorow (inny a-tool podaje swoj)
    """
    import engine as E
    engine_sel, others = load_selectors(selectors_module)
    combos = build_combos(engine_sel, others)
    if combo_keys:
        combos = [c for c in combos if c["key"] in combo_keys]
    if not combos:
        return {"combos": [], "sample": [], "matrix": {}}

    name = profile["name"]
    seen_path = os.path.join(E.HOME, "data", f"{name}_seen.json")
    seen_backup = None
    if os.path.exists(seen_path):
        try:
            seen_backup = open(seen_path, encoding="utf-8").read()
        except Exception:
            pass

    snapshots = {}
    try:
        prev_ai = False
        for combo in combos:
            outs = combo["outputs"]
            uses_ai = outs.get("ai_level", "off") != "off"
            # PAUZA miedzy runami z AI (Groq: 8000 tok/min -> HTTP 429 bez pauzy)
            if prev_ai and uses_ai:
                prov = (profile.get("llm", {}) or {}).get("provider", "")
                wait = 0 if prov == "ollama" else 65
                if wait:
                    if log:
                        log(f"multirun: waiting {wait}s before [{combo['key']}] — free-tier limit resets each minute")
                    time.sleep(wait)

            prof = copy.deepcopy(profile)
            prof.setdefault("outputs", {}).update(outs)
            # PROBKA w pamieci tymczasowej runu — ogranicz zaciag do wycinka.
            # Multi-run NIGDY nie chodzi po calej skrzynce (limit TPM Groqa):
            # tniemy per-run limit do malej liczby, zeby zawsze pracowac na wycinku.
            prof["outputs"]["multirun_temp"] = True
            prof.setdefault("schedule", {})["max_per_run"] = min(
                prof.get("schedule", {}).get("max_per_run", 20), 6)

            if no_memory and os.path.exists(seen_path):
                try:
                    os.remove(seen_path)
                except Exception:
                    pass

            # Capture this run's own logs for the dev matrix. The normal tool log is
            # append-only, so remember the byte offset; the debug trace is reset by
            # each real run and can be snapshotted after it finishes.
            import re as _re
            _safe_name = _re.sub(r"[^A-Za-z0-9._ -]+", "_", str(name or "system"))[:120] or "system"
            _plain_path = os.path.join(E.HOME, "logs", f"{_safe_name}.log")
            try:
                _plain_offset = os.path.getsize(_plain_path) if os.path.exists(_plain_path) else 0
            except Exception:
                _plain_offset = 0

            t0 = time.time()
            try:
                if prof.get("kind") == "collector":
                    E.run_collector(prof)
                else:
                    E.run_reporter(prof)
                err = ""
            except Exception as ex:
                err = str(ex)[:120]
            snap = _snapshot(name, os.path.join(E.HOME, "data"))
            snap["elapsed"] = round(time.time() - t0, 1)
            try:
                with open(_plain_path, "r", encoding="utf-8", errors="replace") as _fh:
                    _fh.seek(_plain_offset)
                    snap["plain_log"] = _fh.read()[-20000:]
            except Exception:
                snap["plain_log"] = ""
            try:
                snap["debug_log"] = E.debug_read(name)[-40000:]
            except Exception:
                snap["debug_log"] = ""
            snap["error"] = err
            snap["name"] = combo["name"]
            snap["desc"] = combo["desc"]
            if uses_ai and snap["tokens"] == 0 and snap["summaries"] == 0 and not err:
                snap["error"] = ("provider hit its per-minute limit — this run returned script-only "
                                 "results. Use fewer combos at once, or a local model.")
            snapshots[combo["key"]] = snap
            prev_ai = uses_ai
            if log:
                log(f"multirun [{combo['key']}]: {len(snap['rows'])} rows, "
                    f"{snap['tokens']} tok, {snap['elapsed']}s")
    finally:
        if seen_backup is not None:
            try:
                open(seen_path, "w", encoding="utf-8").write(seen_backup)
            except Exception:
                pass
        elif os.path.exists(seen_path) and no_memory:
            try:
                os.remove(seen_path)
            except Exception:
                pass

    sample = pick_sample(snapshots)
    matrix = _build_matrix(combos, snapshots, sample)
    return {"combos": [{"key": c["key"], "name": c["name"], "desc": c["desc"],
                        "invoke": c["invoke"]} for c in combos],
            "sample": sample, "matrix": matrix,
            "base_key": combos[0]["key"]}


# ---------------------------------------------------------------------------
#  5. MACIERZ: wiersze = kombinacje, kolumny = 4 maile probki
# ---------------------------------------------------------------------------
def _build_matrix(combos, snapshots, sample):
    """Buduje tabele wynikowa.

    Komorka = {title, tags, priority, from, summary}. Dla kazdego maila:
      - same_as_prev: True jesli ABSOLUTNIE identyczna jak w poprzednim runie
        (wyswietlamy raz, dalej znacznik "=").
      - flag: True jesli inny TAG lub inny PRIORYTET niz w innym runie (podswietl).
    Do tego Δ vs base dla glebokosci/penetracji folderow (spec punkt 6).
    """
    mids = [s["mid"] for s in sample if not s.get("missing")]
    rows = []       # per kombinacja
    prev_cells = {} # mid -> ostatnia (niepusta) komorka, do znacznika "="
    # zbierz warianty per mail, by wykryc rozjazdy tag/priorytet
    variants = {mid: {"pri": set(), "tags": set()} for mid in mids}

    base_key = combos[0]["key"]
    base_snap = snapshots.get(base_key, {})
    base_reach = base_snap.get("reach", 0)
    base_folders = base_snap.get("folders", 0)

    for combo in combos:
        snap = snapshots.get(combo["key"], {})
        by_mid = {}
        for r in snap.get("rows", []):
            mid = r.get("mid") or (r.get("from", "") + r.get("title", ""))
            by_mid[mid] = r
        cells = {}
        for mid in mids:
            r = by_mid.get(mid)
            if not r:
                cells[mid] = {"present": False}
                continue
            cell = {"present": True, "title": r.get("title", ""),
                    "tags": r.get("tags", []), "priority": r.get("priority", "?"),
                    "from": r.get("from", ""), "summary": r.get("summary", "")}
            variants[mid]["pri"].add(cell["priority"])
            variants[mid]["tags"].add(tuple(sorted(cell["tags"])))
            # "=" gdy ABSOLUTNIE identyczna jak poprzednia niepusta komorka
            prev = prev_cells.get(mid)
            cell["same_as_prev"] = bool(prev and prev == {
                "title": cell["title"], "tags": cell["tags"],
                "priority": cell["priority"], "from": cell["from"],
                "summary": cell["summary"]})
            prev_cells[mid] = {"title": cell["title"], "tags": cell["tags"],
                               "priority": cell["priority"], "from": cell["from"],
                               "summary": cell["summary"]}
            cells[mid] = cell
        # Δ vs base — glebokosc/penetracja folderow (punkt 6)
        d_reach = snap.get("reach", 0) - base_reach
        d_folders = snap.get("folders", 0) - base_folders
        rows.append({
            "key": combo["key"], "name": combo["name"], "desc": combo["desc"],
            "invoke": combo.get("invoke", False),
            "cells": cells,
            "tokens": snap.get("tokens", 0), "elapsed": snap.get("elapsed", 0),
            "error": snap.get("error", ""),
            "reach": snap.get("reach", 0), "folders": snap.get("folders", 0),
            "d_reach": d_reach, "d_folders": d_folders,
            "is_base": combo["key"] == base_key,
            "plain_log": snap.get("plain_log", ""),
            "debug_log": snap.get("debug_log", ""),
        })

    # oznacz komorki do podswietlenia: ten sam mail, inny tag lub priorytet
    flagged = {mid for mid in mids
               if len(variants[mid]["pri"]) > 1 or len(variants[mid]["tags"]) > 1}
    for row in rows:
        for mid, cell in row["cells"].items():
            if cell.get("present"):
                cell["flag"] = mid in flagged

    return {"rows": rows, "flagged_mids": sorted(flagged),
            "base_reach": base_reach, "base_folders": base_folders}
