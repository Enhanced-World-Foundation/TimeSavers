#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# file-version: 0.931 | engine: 0.931 | updated: 2026-09-20
"""
PANEL — a clickable UI over engine.py. No commands.
All by mouse: pick an agent, enter mailbox/key in the fields, click Run, see the report.

Start:  python3 panel.py     ->  opens http://localhost:8800
(engine.py must be next to it)
"""
import release_guard as _release_guard
_release_guard.enforce(__file__)

import os, sys, json, csv, threading, urllib.parse, subprocess, secrets, hmac, re
# Capture true first AgentSystem boot BEFORE importing engine.py: engine import may
# initialize small data files, which would otherwise make a fresh machine look old.
_FIRST_AGENTSYSTEM_BOOT = not os.path.exists(os.path.expanduser(os.environ.get("ENGINE_HOME", "~/agentsystem")))
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import engine as E
import lang_ui as LUI
import secret_store as SS
LUI.configure(E.VERSION)
# Full source contains every capability, but the everyday UI stays uncluttered.
# --d/--dev only REVEALS developer/diagnostic controls that are already present
# in this source tree; it cannot restore code physically stripped by Builder.
FULL_SOURCE = True
# On a completely fresh machine AgentSystem does not exist yet. Reveal the
# setup/diagnostic controls on that one first launch so the user can discover
# configuration without already knowing the --d flag. Later normal launches
# return to the everyday UI; explicit --d remains available.
FIRST_AGENTSYSTEM_RUN = _FIRST_AGENTSYSTEM_BOOT
DEV_UI = FIRST_AGENTSYSTEM_RUN or any(f in sys.argv for f in ("--dev", "--debug", "--d", "-d"))
DIAGNOSTICS = DEV_UI
UI_PREVIEW = "--ui-preview" in sys.argv
NO_OPEN = "--no-open" in sys.argv
LAN_MODE = "--lan" in sys.argv or os.environ.get("L4M_PANEL_LAN", "").strip().lower() in ("1","true","yes","on")
LAN_TOKEN = secrets.token_urlsafe(32) if LAN_MODE else ""
MAX_API_BODY = 10 * 1024 * 1024

PORT = int(os.environ.get("PANEL_PORT", "8800"))
PROF_DIR = os.path.join(E.HOME, "profiles")
HOME = E.HOME          # katalog danych (~/agentsystem) — potrzebny w endpointach tagów
HERE = os.path.dirname(os.path.abspath(__file__))   # katalog panelu — pliki UI (ui-frame.*, ui-reporter.html)

_UI_REQUIRED_MARKERS = (
    "function showTable(", "function cycleHints(", "function applyHints(",
    "function toggleHidden(", "function toggleAllAdvanced(", "function toggleView(",
    "function webmailLink(", "function loadTagRules(", "function resetTags(",
    "function showTagEditor(", "function openTagPop(",
)

def _ui_asset_info():
    """Return the exact UI build currently present next to this panel.

    This is intentionally based on the files actually served, not E.VERSION.  It
    makes mixed/partial updates visible immediately instead of letting an old
    ui-frame.js fail later with ReferenceError.
    """
    import hashlib
    info = {"ok": False, "token": "missing", "missing": [], "lines": 0, "path": os.path.join(HERE, "ui-frame.js")}
    try:
        parts = []
        texts = {}
        for fn in ("ui-reporter.html", "ui-frame.css", "ui-frame.js"):
            fp = os.path.join(HERE, fn)
            if not os.path.exists(fp):
                info["missing"].append(fn)
                continue
            data = open(fp, "rb").read()
            parts.append(fn.encode("utf-8") + b"\0" + data)
            if fn.endswith((".js", ".html")):
                texts[fn] = data.decode("utf-8", "replace")
        if info["missing"]:
            return info
        js = texts.get("ui-frame.js", "")
        missing_markers = [m for m in _UI_REQUIRED_MARKERS if m not in js]
        if missing_markers:
            info["missing"] = missing_markers
            info["reason"] = "ui-frame.js is incomplete or from a mismatched patch"
            return info
        info["token"] = hashlib.sha256(b"\n".join(parts)).hexdigest()[:12]
        info["lines"] = js.count("\n") + 1
        info["ok"] = True
        return info
    except Exception as exc:
        info["reason"] = str(exc)
        return info

def _system_ui_lang():
    """Use the OS locale only when the user has not saved a panel language yet."""
    supported = {str(x).lower() for x in LUI.languages()}
    candidates = [os.environ.get("LC_ALL", ""), os.environ.get("LC_MESSAGES", ""),
                  os.environ.get("LANG", "")]
    try:
        import locale
        candidates.append((locale.getlocale()[0] or ""))
    except Exception:
        pass
    for raw in candidates:
        code = str(raw or "").split(".", 1)[0].split("@", 1)[0].replace("-", "_").split("_", 1)[0].lower()
        if code in supported:
            return code
    return "en"

def _atool_json_path():
    """Znajdz atool.json. Szuka po kolei: katalog panelu (HERE), potem katalog
    danych agentsystem (HOME) i ../.eco_data — bo Karol trzyma czesc jsonow w
    agentsystem, nie obok panelu. Zwraca pierwsza istniejaca sciezke, a gdy nigdzie
    nie ma — domyslnie HERE (zeby stary kod dzialal jak wczesniej)."""
    cands = [
        os.path.join(HERE, "atool.json"),
        os.path.join(HOME, "atool.json"),
        os.path.join(os.path.dirname(HERE), ".eco_data", "atool.json"),
        os.path.join(HOME, ".eco_data", "atool.json"),
    ]
    for c in cands:
        if os.path.exists(c):
            return c
    return cands[0]
# PyInstaller: w spakowanym .exe pliki dodane przez --add-data leza w sys._MEIPASS,
# a NIE obok binarki. Bez tego panel nie znajduje ui-frame.js/css i leci na fallback.
if getattr(sys, "frozen", False) and hasattr(sys, "_MEIPASS"):
    HERE = sys._MEIPASS
DATA_DIR = os.path.join(E.HOME, "data")
LOG_DIR = os.path.join(E.HOME, "logs")
os.makedirs(PROF_DIR, exist_ok=True)
os.makedirs(LOG_DIR, exist_ok=True)

_SCHED_LOG_LOCK = threading.Lock()

def _sched_log(message, force=False):
    """One scheduler diagnostic sink for startup, APScheduler and the UI endpoint."""
    import datetime as _dt
    line = f"[{_dt.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] {message}"
    try:
        with _SCHED_LOG_LOCK:
            with open(os.path.join(LOG_DIR, "scheduler_debug.log"), "a", encoding="utf-8") as fh:
                fh.write(line + "\n")
    except Exception:
        pass
    if DIAGNOSTICS:
        print(f"  [sched] {message}")
    elif force:
        low = str(message or "").lower()
        if any(word in low for word in ("critical", "error", "failed", "missing")):
            print(f"  [sched] {message}")

RUNNING = {}   # name -> True while running


def _ollama_models_local():
  """Lista zainstalowanych modeli Ollama (tagi), albo [] gdy brak/blad."""
  try:
    p = subprocess.run(["ollama", "list"], text=True, capture_output=True, timeout=8)
    if p.returncode != 0:
      return []
    out = []
    for line in (p.stdout or "").splitlines()[1:]:
      line = line.strip()
      if not line:
        continue
      out.append(line.split()[0])
    return out
  except Exception:
    return []


def _find_runtime_json_candidates():
  home = os.path.expanduser("~")
  return [
    os.path.join(HERE, "KatalogiPro", "runtime.json"),
    os.path.join(home, "KatalogiPro", "runtime.json"),
    os.path.join(home, "porownanie", "k-26", "KatalogiPro", "runtime.json"),
    os.path.join(HOME, "runtime.json"),
  ]


def _read_runtime_json_local():
  for p in _find_runtime_json_candidates():
    if os.path.exists(p):
      try:
        data = json.load(open(p, encoding="utf-8"))
        return p, data
      except Exception:
        return p, {}
  return "", {}


def backup_dir():
    """Katalog backupow — jedno miejsce, zeby nie powtarzac sciezki w 4 endpointach."""
    d = os.path.join(HOME, "data", "backups")
    os.makedirs(d, exist_ok=True)
    return d


def _rule_samples(name):
    """Recent-message corpus used only for rule preview/validation/suggestions."""
    if not name:
        return []
    rp = os.path.join(DATA_DIR, f"{name}_report.json")
    bp = os.path.join(DATA_DIR, f"{name}_bodies.json")
    try:
        report = json.load(open(rp, encoding="utf-8")) if os.path.exists(rp) else {}
    except Exception:
        report = {}
    try:
        bodies = json.load(open(bp, encoding="utf-8")) if os.path.exists(bp) else {}
    except Exception:
        bodies = {}
    if not isinstance(bodies, dict):
        bodies = {}
    out, seen = [], set()
    for mb in report.get("mailboxes", []) if isinstance(report, dict) else []:
        src_default = mb.get("mailbox", "") if isinstance(mb, dict) else ""
        for row in (mb.get("rows", []) + mb.get("hidden_rows", [])) if isinstance(mb, dict) else []:
            mid = str(row.get("mid", "") or "")
            key = mid or (str(row.get("addr", "")), str(row.get("summary", "")), str(row.get("date", "")))
            if key in seen:
                continue
            seen.add(key)
            cached = bodies.get(mid, {}) if mid else {}
            if not isinstance(cached, dict): cached = {}
            out.append({
                "mid": mid,
                "from": cached.get("from") or row.get("addr") or row.get("from", ""),
                "src": cached.get("src") or row.get("src") or src_default,
                "title": cached.get("title") or row.get("title") or row.get("summary", ""),
                "body": cached.get("body") or "",
                "tags": cached.get("tags") or row.get("tags") or [],
                "priority": cached.get("priority") or row.get("priority", ""),
            })
    # Body cache can contain messages not rendered in the current report rows. They are
    # still useful validation history and already local, so include them without I/O.
    for mid, cached in bodies.items():
        if mid in seen or not isinstance(cached, dict):
            continue
        out.append({"mid": mid, "from": cached.get("from", ""), "src": cached.get("src", ""),
                    "title": cached.get("title", ""), "body": cached.get("body", ""),
                    "tags": cached.get("tags") or [], "priority": cached.get("priority", "")})
    return out


def _rule_target_message(name, mid="", fallback=None):
    """Find the exact clicked message in the local last-run cache; never guess one."""
    mid = str(mid or "")
    if mid:
        for m in _rule_samples(name):
            if str(m.get("mid", "")) == mid:
                return m
    return fallback if isinstance(fallback, dict) else None


# REGULA CZYSZCZENIA BACKUPOW.
# Wczesniej backupy rosly bez konca: kazdy zapis profilu, reset tagow i import
# dokladal plik i nic ich nie usuwalo. Po miesiacu uzywania to setki plikow.
BACKUP_KEEP_PLAIN = 10      # tyle NAJNOWSZYCH trzymamy nieskompresowanych (szybki restore)
BACKUP_KEEP_TOTAL = 60      # tyle w sumie (reszta kasowana, od najstarszych)
BACKUP_MAX_AGE_DAYS = 90    # starsze niz tyle dni — kasowane niezaleznie od liczby


def prune_backups(keep_plain=BACKUP_KEEP_PLAIN, keep_total=BACKUP_KEEP_TOTAL,
                  max_age_days=BACKUP_MAX_AGE_DAYS, dry_run=False, compress_only=False):
    """Kompresuje starsze backupy i kasuje nadmiar. Zwraca podsumowanie dla UI.

    dry_run=True      — NIC nie rusza, tylko raportuje co BY zrobil (podglad
                        przed potwierdzeniem, zeby user nie stracil pliku).
    compress_only=True— tylko kompresuje, NIE kasuje nic (bezpieczny wariant).

    Kolejnosc: (1) skasuj przeterminowane, (2) spakuj gzipem wszystko poza
    najnowszymi, (3) jesli nadal za duzo — kasuj od najstarszych.
    Nigdy nie rusza najnowszego backupu.
    """
    import gzip, shutil as _sh, time
    d = backup_dir()
    out = {"compressed": 0, "deleted": 0, "kept": 0, "freed_kb": 0,
           "to_delete": [], "to_compress": [], "dry_run": bool(dry_run)}
    try:
        files = [os.path.join(d, f) for f in os.listdir(d)]
        files = [f for f in files if os.path.isfile(f)]
    except Exception:
        return out
    files.sort(key=lambda f: os.path.getmtime(f), reverse=True)   # najnowsze pierwsze

    now = time.time()
    survivors = []
    for i, f in enumerate(files):
        age_days = (now - os.path.getmtime(f)) / 86400
        # (1) za stare — kasuj (ale nigdy najnowszego)
        if i > 0 and max_age_days and age_days > max_age_days and not compress_only:
            out["to_delete"].append({"name": os.path.basename(f),
                                     "kb": os.path.getsize(f) // 1024,
                                     "why": f"older than {max_age_days} days"})
            if not dry_run:
                try:
                    out["freed_kb"] += os.path.getsize(f) // 1024
                    os.remove(f); out["deleted"] += 1
                except Exception:
                    pass
            continue
        # (2) poza najnowszymi — spakuj gzipem (kompresja NIE traci danych)
        if i >= keep_plain and not f.endswith(".gz"):
            out["to_compress"].append(os.path.basename(f))
            if not dry_run:
                try:
                    before = os.path.getsize(f)
                    with open(f, "rb") as src, gzip.open(f + ".gz", "wb") as dst:
                        _sh.copyfileobj(src, dst)
                    os.remove(f)
                    out["freed_kb"] += max(0, (before - os.path.getsize(f + ".gz")) // 1024)
                    out["compressed"] += 1
                    f = f + ".gz"
                except Exception:
                    pass
        survivors.append(f)

    # (3) nadal za duzo — kasuj od najstarszych
    if keep_total and len(survivors) > keep_total and not compress_only:
        for f in survivors[keep_total:]:
            try:
                out["to_delete"].append({"name": os.path.basename(f),
                                         "kb": os.path.getsize(f) // 1024,
                                         "why": f"over the {keep_total}-file limit"})
                if not dry_run:
                    out["freed_kb"] += os.path.getsize(f) // 1024
                    os.remove(f); out["deleted"] += 1
            except Exception:
                pass
        if not dry_run:
            survivors = survivors[:keep_total]

    out["kept"] = len(survivors)
    return out


_SAFE_NAME_RE = re.compile(r"^[^/\\\x00-\x1f]{1,120}$")
_SECRET_KEYS = {"password", "passwd", "pass", "api_key", "apikey", "token", "secret", "authorization"}
_SECRET_SENTINEL = SS.SAVED_SECRET

def _is_secret_key(key):
    return SS.is_secret_key(key)

def _redact_secrets_for_ui(value, key=""):
    """Keep profile shape for the editor, but never return stored secret material."""
    if _is_secret_key(key):
        return _SECRET_SENTINEL if value not in (None, "", False, []) else ""
    if isinstance(value, dict):
        return {k: _redact_secrets_for_ui(v, k) for k, v in value.items()}
    if isinstance(value, list):
        return [_redact_secrets_for_ui(v, key) for v in value]
    return value

def _restore_secret_sentinels(existing, incoming):
    """Replace UI sentinel values with the already-stored local secret before saving."""
    if incoming == _SECRET_SENTINEL:
        return existing
    if isinstance(incoming, dict):
        old = existing if isinstance(existing, dict) else {}
        return {k: _restore_secret_sentinels(old.get(k), v) for k, v in incoming.items()}
    if isinstance(incoming, list):
        old_list = existing if isinstance(existing, list) else []
        out = []
        for i, item in enumerate(incoming):
            old_item = old_list[i] if i < len(old_list) else None
            if isinstance(item, dict) and all(isinstance(x, dict) for x in old_list):
                # Prefer stable source identity over list position (mailbox reorder/add).
                identity_keys = ("imap", "host", "user", "login", "url", "type", "phone", "chat_id")
                wanted = {k: item.get(k) for k in identity_keys if item.get(k) not in (None, "", _SECRET_SENTINEL)}
                if wanted:
                    match = next((x for x in old_list if all(x.get(k) == v for k, v in wanted.items())), None)
                    if match is not None: old_item = match
            out.append(_restore_secret_sentinels(old_item, item))
        return out
    return incoming

def _private_path(path, is_dir=False):
    """Best-effort POSIX privacy for AgentSystem state; Windows ACL is handled at packaging/runtime."""
    try:
        if os.name == "posix":
            os.chmod(path, 0o700 if is_dir else 0o600)
    except Exception:
        pass
    return path

def _safe_agent_name(name):
    name = str(name or "").strip()
    if not _SAFE_NAME_RE.fullmatch(name) or name in (".", "..") or ".." in name:
        raise ValueError("invalid agent name")
    return name

def _safe_join(root, *parts):
    root = os.path.realpath(root)
    path = os.path.realpath(os.path.join(root, *parts))
    if os.path.commonpath([root, path]) != root:
        raise ValueError("path outside allowed directory")
    return path

def _strip_secrets(value, key=""):
    if _is_secret_key(key):
        return None
    if isinstance(value, dict):
        out = {}
        for k, v in value.items():
            vv = _strip_secrets(v, k)
            if vv is not None:
                out[k] = vv
        return out
    if isinstance(value, list):
        return [_strip_secrets(v, key) for v in value]
    return value

def _deep_merge_keep_existing(existing, incoming):
    """Merge safe exports without erasing local secrets omitted from the backup."""
    if isinstance(existing, dict) and isinstance(incoming, dict):
        out = dict(existing)
        for k, v in incoming.items():
            if _is_secret_key(k):
                continue
            out[k] = _deep_merge_keep_existing(existing.get(k), v)
        return out
    if isinstance(existing, list) and isinstance(incoming, list):
        # Mailboxes need identity-aware merge so a safe export cannot wipe saved passwords.
        if all(isinstance(x, dict) for x in incoming):
            old_by_id = {}
            for x in existing or []:
                if isinstance(x, dict):
                    ident = (x.get("imap") or x.get("host") or "", x.get("user") or x.get("login") or "")
                    old_by_id[ident] = x
            merged = []
            for x in incoming:
                ident = (x.get("imap") or x.get("host") or "", x.get("user") or x.get("login") or "")
                merged.append(_deep_merge_keep_existing(old_by_id.get(ident, {}), x))
            return merged
        return incoming
    return incoming

def _atomic_json_write(path, data):
    """Atomic, private JSON write so an interrupted Save cannot leave a half profile."""
    import tempfile
    os.makedirs(os.path.dirname(path), exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix=".profile-", dir=os.path.dirname(path))
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            json.dump(data, fh, indent=2, ensure_ascii=False)
            fh.flush()
            try: os.fsync(fh.fileno())
            except Exception: pass
        _private_path(tmp)
        os.replace(tmp, path)
        _private_path(path)
    finally:
        try:
            if os.path.exists(tmp): os.remove(tmp)
        except Exception: pass

def _load_profile_public(name):
    p = prof_path(name)
    if not os.path.exists(p):
        return {}
    raw = json.load(open(p, encoding="utf-8"))
    return raw if isinstance(raw, dict) else {}

def _load_profile_full(name, migrate=True):
    """Backend-only profile loader. Browser/API never receives hydrated secrets."""
    name=_safe_agent_name(name)
    with SS.profile_lock(name):
        raw=_load_profile_public(name)
        if not raw: return raw
        if SS.contains_plain_secret(raw):
            if migrate:
                try: _write_profile_secure(name,raw); raw=_load_profile_public(name)
                except Exception: return raw
            else: return raw
        return SS.hydrate_profile(raw,SS.get(name))

def _write_profile_secure(name, full_profile):
    """Pair public profile and credential revision under one per-profile lock."""
    name=_safe_agent_name(name)
    with SS.profile_lock(name):
        full_profile=dict(full_profile or {}); full_profile["name"]=name
        secret_tree=SS.extract_secret_tree(full_profile); public=SS.redact_for_profile(full_profile)
        if secret_tree:
            if not SS.set(name,secret_tree): raise RuntimeError("could not save credentials in the local secret store")
        else: SS.delete(name)
        _atomic_json_write(prof_path(name),public); return public

def _migrate_legacy_profile(name):
    """One-way migration of plaintext profile secrets to the protected secret store."""
    try:
        raw = _load_profile_public(name)
        if raw and SS.contains_plain_secret(raw):
            _write_profile_secure(name, raw)
            return True
    except Exception:
        return False
    return False

def _sanitize_legacy_backups():
    """Remove plaintext credentials from old JSON profile backups in-place.

    Backups are configuration recovery, not a password vault. Existing live credentials
    stay in the secret store; restoring an old backup keeps/requires local credentials.
    """
    import gzip
    d = backup_dir()
    try: names = list(os.listdir(d))
    except Exception: return 0
    changed = 0
    for fn in names:
        path = os.path.join(d, fn)
        if not os.path.isfile(path) or not (fn.endswith('.json') or fn.endswith('.json.gz')):
            continue
        try:
            if fn.endswith('.gz'):
                with gzip.open(path, 'rt', encoding='utf-8') as fh: obj=json.load(fh)
            else:
                obj=json.load(open(path, encoding='utf-8'))
            if not isinstance(obj, dict) or not SS.contains_plain_secret(obj):
                continue
            safe=SS.redact_for_profile(obj)
            if fn.endswith('.gz'):
                tmp=path+'.tmp'
                with gzip.open(tmp,'wt',encoding='utf-8') as fh: json.dump(safe,fh,indent=2,ensure_ascii=False)
                os.replace(tmp,path); _private_path(path)
            else:
                _atomic_json_write(path,safe)
            changed+=1
        except Exception:
            continue
    return changed

def prof_path(name):
    name = _safe_agent_name(name)
    return _safe_join(PROF_DIR, name + ".json")

def _wake_run_status(name):
    """Cross-process truth for runs owned by central Wake."""
    try:
        import hashlib
        name=_safe_agent_name(name)
        meta=json.load(open(_atool_json_path(),encoding="utf-8")) or {}
        tool_id=str(meta.get("id") or "communication_1")
        token=hashlib.sha256(f"{tool_id}::{name}".encode("utf-8","ignore")).hexdigest()[:24]
        path=_safe_join(DATA_DIR,"run_status",token+".json")
        if not os.path.exists(path):
            path=_safe_join(DATA_DIR,f"{name}_run_status.json")
        if not os.path.exists(path): return {}
        with open(path,encoding="utf-8") as f: st=json.load(f)
        if not isinstance(st,dict): return {}
        age=max(0.0,__import__("time").time()-float(st.get("updated_at") or 0))
        state=str(st.get("state") or ""); pid=int(st.get("pid") or 0)
        alive=False
        if pid>0:
            try:
                if os.name=="nt":
                    r=subprocess.run(["tasklist","/FI",f"PID eq {pid}"],capture_output=True,text=True,timeout=2,check=False); alive=str(pid) in (r.stdout or "")
                else:
                    os.kill(pid,0); alive=True
            except Exception: alive=False
        st["running"] = bool((state=="queued" and age<90) or (state in ("starting","running") and (alive or age<10)))
        st["age_s"]=round(age,1); return st
    except Exception:
        return {}

def list_agents():
    out = []
    for f in sorted(os.listdir(PROF_DIR)):
        if f.endswith(".json"):
            try:
                p = json.load(open(os.path.join(PROF_DIR, f), encoding="utf-8"))
                out.append({"name": p.get("name"), "kind": p.get("kind"),
                            "preset": p.get("preset"),
                            "running": bool(RUNNING.get(p.get("name"), False) or _wake_run_status(p.get("name")).get("running"))})
                break
            except Exception:
                pass
    return out


def do_run(name, offline, run_source=None, run_slot=None):
    # SLOT RODZINY A-TOOLS: user ma priorytet, wake.py ustepuje.
    # Zrodlo bierzemy ze zmiennej srodowiskowej — wake.py ustawia ja w procesie
    # potomnym, panel nie ustawia nic (czyli 'user').
    _src = run_source or os.environ.get("ECO_RUN_SOURCE", "user")
    _slot = run_slot or os.environ.get("ECO_RUN_SLOT", "")
    _tool = "this"
    try:
        import atool_sync as _as
        _tool = (json.load(open(_atool_json_path(), encoding="utf-8"))
                 or {}).get("id", "this")
        if not _as.claim_eco_slot(_tool, _src):
            held = (_as.eco_slot_status(_tool) or {}).get("tool", "?")
            E.log(name, f"SKIP ({_src}): A-Tool jest już uruchomiony przez '{held}'")
            return
    except Exception:
        pass
    RUNNING[name] = True
    try:
        E.OFFLINE = bool(offline)
        prof = _load_profile_full(name)
        if DIAGNOSTICS:
            # --d means FULL effective run configuration, not a hand-picked subset.
            # Secrets are redacted, but every UI-backed profile field remains visible.
            def _dbg_safe(v, key=""):
                if SS.is_secret_key(key):
                    return "<set>" if v not in (None, "", False, []) else "<empty>"
                if isinstance(v, dict):
                    return {k: _dbg_safe(x, k) for k, x in v.items()}
                if isinstance(v, list):
                    return [_dbg_safe(x, key) for x in v]
                return v
            _debug_profile = _dbg_safe(prof)
            print("  " + "─" * 60)
            print(f"  [run details/full] agent='{name}' source={_src} offline={bool(offline)}")
            print(json.dumps(_debug_profile, ensure_ascii=False, indent=2))
            print("  " + "─" * 60)
        prof["_run_context"] = {"source": _src, "slot": _slot}
        (E.run_collector if prof["kind"] == "collector" else E.run_reporter)(prof)
        try:
            import time as _t
            open(os.path.join(DATA_DIR, f"{name}_lastrun.txt"), "w").write(str(_t.time()))
        except Exception:
            pass
        # WYBUDZANIE PANELU/PRZEGLADARKI po runie a-toola z tla (wake.py).
        # TYLKO gdy uruchomil to scheduler (_src=='wake') i user wlaczyl wake_browser.
        # Popup NIGDY nie wybudza — to osobny mechanizm (l4m_popup), tego tu nie ma.
        try:
            if _src == "wake":
                import json as _j
                pref_p = os.path.join(HOME, "scheduler_prefs.json")
                _pref = _j.load(open(pref_p, encoding="utf-8")) if os.path.exists(pref_p) else {}
                if _pref.get("wake_browser"):
                    import webbrowser
                    webbrowser.open(f"http://localhost:{PORT}")
        except Exception:
            pass
    except Exception as ex:
        E.log(name, f"PANEL blad: {ex}")
    finally:
        E.OFFLINE = False
        try:
            import atool_sync as _as2
            _as2.release_eco_slot(_tool)
        except Exception:
            pass
        RUNNING[name] = False

def do_scheduled_run(name):
    """APScheduler entrypoint. Mark the run as scheduled and expose the exact slot to RSS filtering."""
    slot = __import__("datetime").datetime.now().strftime("%H:%M")
    return do_run(name, False, "scheduler", slot)


def publish_profile_schedule(name, prof):
    """Publish the scheduling fields saved by this A-Tool UI to the one Wake manager."""
    sch = dict((prof or {}).get("schedule") or {})
    if "scheduled" not in sch and sch.get("mode"):
        sch["scheduled"] = sch.get("mode") == "schedule"
        sch.setdefault("catchup", sch.get("mode") == "autostart")
    windows = sch.get("windows") or ["08:00", "18:00"]
    feed_windows = E.feed_schedule_windows(prof) if hasattr(E, "feed_schedule_windows") else []
    wake_windows = list(dict.fromkeys((windows if sch.get("scheduled") else []) + feed_windows))
    import atool_sync as _as
    _ai_mode = (prof.get("llm", {}) or {}).get("ai_level") or sch.get("ai_mode")
    ok = _as.publish_schedule(
        runs=wake_windows, ai_mode=_ai_mode,
        active_from=sch.get("active_from"), active_until=sch.get("active_until"),
        extra={
            "agent": name, "mail_runs": windows if sch.get("scheduled") else [],
            "feed_runs": feed_windows, "once_date": sch.get("once_date") or None,
            "once_time": sch.get("once_time") or None, "catchup": sch.get("catchup", True),
            "run_on_start": bool(sch.get("run_on_start")),
            "run_on_start_min": sch.get("run_on_start_min", 5),
            "scheduled": bool(sch.get("scheduled")), "background": bool(sch.get("background")),
            "times_per_day": sch.get("times_per_day", 1),
            "network_required": bool(sch.get("network_required", False)),
            "retry_when_online": bool(sch.get("retry_when_online", False)),
        })
    if ok:
        # The persistent Wake may have scanned the previous contract a moment before
        # this panel republished it. Nudge the one manager to re-evaluate immediately
        # instead of leaving a stale hash-blocked catch-up job until a later cycle.
        try:
            import wake as _wk
            _wk.request_due_scan()
        except Exception:
            pass
    return {"ok": bool(ok), "runs": wake_windows, "feed_runs": feed_windows, "windows": windows}


def read_result(name):
    """Reporter -> raport txt. Collector -> wiersze CSV."""
    prof = json.load(open(prof_path(name), encoding="utf-8"))
    if prof["kind"] == "reporter":
        p = os.path.join(DATA_DIR, f"{name}_report.txt")
        return {"type": "report", "text": open(p, encoding="utf-8").read() if os.path.exists(p) else ""}
    table = prof.get("outputs", {}).get("table", "contacts")
    p = os.path.join(DATA_DIR, f"{table}.csv")
    rows = []
    if os.path.exists(p):
        with open(p, encoding="utf-8") as f:
            rows = list(csv.reader(f))
    return {"type": "table", "rows": rows[:200]}

def tail_log(name, n=40):
    name=_safe_agent_name(name)
    p=_safe_join(LOG_DIR,f"{name}.log")
    if not os.path.exists(p):
        return ""
    return "".join(open(p, encoding="utf-8").readlines()[-n:])


class H(BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def _s(self, code, body, ct="application/json"):
        b = body.encode("utf-8") if isinstance(body, str) else body
        self.send_response(code); self.send_header("Content-Type", ct)
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("Cross-Origin-Opener-Policy", "same-origin")
        self.send_header("Permissions-Policy", "camera=(), microphone=(), geolocation=(), payment=()")
        self.send_header("Content-Security-Policy", "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self' https://script.google.com https://script.googleusercontent.com; object-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'")
        # BEZ TEGO Chrome cachowal HTML razem z inline JS. Numer wersji szedl z /api
        # (zawsze swiezy), ale SKRYPT byl stary — user widzial "7.22" i bledy z 7.20.
        self.send_header("Cache-Control", "no-store, no-cache, must-revalidate, max-age=0")
        self.send_header("Pragma", "no-cache")
        self.send_header("Expires", "0")
        self.send_header("Content-Length", str(len(b))); self.end_headers()
        # PELNY zapis: przy duzym ui-frame.js (~190 KB) pojedynczy wfile.write potrafil
        # nie wyslac calosci -> przegladarka dostawala uciety skrypt i "Unexpected end of
        # input (line 1)". Piszemy w petli az do konca i flushujemy.
        try:
            mv = memoryview(b)
            sent = 0
            while sent < len(mv):
                n = self.wfile.write(mv[sent:])
                if not n:
                    break
                sent += n
            self.wfile.flush()
        except (BrokenPipeError, ConnectionResetError):
            pass
    def _remote_is_loopback(self):
        host = str((self.client_address or ("",))[0] or "")
        return host in ("127.0.0.1", "::1") or host.startswith("127.")

    def _host_authorized(self):
        """Reject DNS-rebinding style requests with an unrelated Host header."""
        import ipaddress
        raw = str(self.headers.get("Host") or "").strip()
        if not raw:
            return False
        host = raw
        if raw.startswith("[") and "]" in raw:
            host = raw[1:raw.index("]")]
        elif raw.count(":") == 1:
            host = raw.rsplit(":", 1)[0]
        host = host.strip().rstrip(".").lower()
        if host in ("localhost", "127.0.0.1", "::1"):
            return True
        try:
            ip = ipaddress.ip_address(host)
            # LAN mode is deliberately accessed by the literal private IP printed by panel.py.
            return bool(LAN_MODE and (ip.is_private or ip.is_loopback))
        except ValueError:
            return False

    def _lan_authorized(self, u=None):
        if not LAN_MODE or self._remote_is_loopback():
            return True
        if u is None:
            u = urllib.parse.urlparse(self.path)
        q = urllib.parse.parse_qs(u.query)
        supplied = (q.get("token") or [""])[0]
        if supplied and hmac.compare_digest(str(supplied), LAN_TOKEN):
            return True
        cookie = str(self.headers.get("Cookie") or "")
        for part in cookie.split(";"):
            k, sep, v = part.strip().partition("=")
            if sep and k == "L4MLAN" and hmac.compare_digest(v, LAN_TOKEN):
                return True
        return False

    def _accept_lan_token(self, u):
        if not LAN_MODE or self._remote_is_loopback():
            return False
        q = urllib.parse.parse_qs(u.query)
        supplied = (q.get("token") or [""])[0]
        if not supplied or not hmac.compare_digest(str(supplied), LAN_TOKEN):
            return False
        self.send_response(302)
        self.send_header("Location", u.path or "/")
        self.send_header("Set-Cookie", f"L4MLAN={LAN_TOKEN}; HttpOnly; SameSite=Strict; Path=/")
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        return True

    def _body(self):
        try:
            n = int(self.headers.get("Content-Length", 0))
        except Exception:
            raise ValueError("invalid content length")
        if n < 0 or n > MAX_API_BODY:
            raise ValueError("request body too large")
        raw = self.rfile.read(n) if n else b"{}"
        return json.loads(raw or b"{}")

    def do_GET(self):
        u = urllib.parse.urlparse(self.path); q = urllib.parse.parse_qs(u.query)
        if not self._host_authorized():
            return self._s(403, json.dumps({"error":"invalid Host header"}))
        if self._accept_lan_token(u):
            return
        if not self._lan_authorized(u):
            return self._s(403, json.dumps({"error":"LAN access requires the private URL printed by panel.py"}))
        if u.path == "/favicon.ico":
            return self._s(204, b"")
        if u.path == "/manifest.json":       # PWA — pozwala "zainstalowac" na telefonie
            man = {"name": "Locally4Me Agents", "short_name": "L4M",
                   "start_url": "/", "display": "standalone",
                   "background_color": "#f5f6f8", "theme_color": "#2563eb",
                   "icons": [{"src": "/icon.svg", "sizes": "any", "type": "image/svg+xml"}]}
            return self._s(200, json.dumps(man), "application/manifest+json")
        if u.path == "/icon.svg":
            svg = ('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100">'
                   '<rect width="100" height="100" rx="22" fill="#2563eb"/>'
                   '<text x="50" y="66" font-size="46" font-family="Arial" font-weight="bold" '
                   'fill="#fff" text-anchor="middle">L4</text></svg>')
            return self._s(200, svg, "image/svg+xml")
        if u.path == "/sw.js":
            # Keep PWA/install support, but do NOT install a no-op fetch handler.
            # Chrome warns about it and it adds navigation overhead without caching anything.
            sw = ("self.addEventListener('install',e=>self.skipWaiting());"
                  "self.addEventListener('activate',e=>e.waitUntil(self.clients.claim()));")
            return self._s(200, sw, "application/javascript")
        if u.path in ("/", "/index.html"):
            # One coherent UI build only.  A partial/old ui-frame.js used to make
            # the page look half-alive and then fail with cycleHints/applyHints/showTable
            # ReferenceError.  Refuse to serve such a mixture and show the exact path.
            info = _ui_asset_info()
            if not info.get("ok"):
                missing = ", ".join(info.get("missing") or [])
                reason = info.get("reason") or "required UI assets are missing"
                return self._s(500,
                    "<h3>UI build mismatch</h3>"
                    "<p>The panel found an incomplete or mixed UI update and stopped before loading it.</p>"
                    f"<p><b>Reason:</b> {reason}<br><b>Missing:</b> {missing or 'unknown'}<br>"
                    f"<b>Path:</b> {info.get('path','')}</p>"
                    "<p>Copy the complete release into one folder and restart panel.py.</p>",
                    "text/html; charset=utf-8")
            try:
                p = os.path.join(HERE, "ui-reporter.html")
                html = open(p, encoding="utf-8").read()
                token = info.get("token") or "ui"
                # Cache-bust the two mutable assets with the hash of the files actually
                # present on disk.  This also protects against a browser keeping an old
                # ui-frame.js after an update.
                html = html.replace('href="/ui-frame.css"', f'href="/ui-frame.css?v={token}"')
                html = html.replace('src="/ui-frame.js"', f'src="/ui-frame.js?v={token}"')
                html = html.replace('</head>', f'<meta name="l4m-ui-build" content="{token}"></head>', 1)
                return self._s(200, html, "text/html; charset=utf-8")
            except Exception as exc:
                return self._s(500, f"<h3>UI assets unavailable</h3><p>{exc}</p>", "text/html; charset=utf-8")
        if u.path in ("/logo.png", "/logo2.png"):
            # Logo uzytkownika — wrzuc logo.png / logo2.png obok panel.py.
            # Gdy pliku nie ma, UI samo wraca do kafelka 4Me (onerror w img).
            try:
                p = os.path.join(HERE, u.path.lstrip("/"))
                data = open(p, "rb").read()
                self.send_response(200)
                self.send_header("Content-Type", "image/png")
                self.send_header("Content-Length", str(len(data)))
                self.end_headers()
                return self.wfile.write(data)
            except Exception:
                # Never return a transparent "successful" image here: that suppresses
                # <img onerror> and leaves both the custom logo and its placeholder
                # invisible.  Serve a visible built-in fallback instead.
                label = "4Me" if u.path.endswith("logo2.png") else "L4M"
                fs = "28" if label == "4Me" else "32"
                svg = (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100">'
                       f'<rect width="100" height="100" rx="22" fill="#2563eb"/>'
                       f'<text x="50" y="61" font-size="{fs}" font-family="Arial" font-weight="bold" '
                       f'fill="#fff" text-anchor="middle">{label}</text></svg>')
                return self._s(200, svg, "image/svg+xml")
        if u.path == "/ui-frame.css":
            try:
                return self._s(200, open(os.path.join(HERE, "ui-frame.css"), encoding="utf-8").read(),
                               "text/css; charset=utf-8")
            except Exception:
                return self._s(404, "/* not found */", "text/css")
        if u.path == "/ui-frame.js":
            try:
                return self._s(200, open(os.path.join(HERE, "ui-frame.js"), encoding="utf-8").read(),
                               "application/javascript; charset=utf-8")
            except Exception:
                return self._s(404, "// not found", "application/javascript")
        if u.path == "/api/exportconfig":
            # SAFE export: configuration only. Passwords/API keys/tokens stay on this computer.
            out = {"exported": __import__("time").strftime("%Y-%m-%d %H:%M:%S"),
                   "version": E.VERSION, "safe_export": True, "profiles": {}, "files": {}}
            try:
                for f in sorted(os.listdir(PROF_DIR)):
                    if f.endswith(".json"):
                        nm = f[:-5]
                        try:
                            _safe_agent_name(nm)
                            raw = json.load(open(prof_path(nm), encoding="utf-8"))
                            out["profiles"][nm] = _strip_secrets(raw)
                        except Exception:
                            continue
            except Exception:
                pass
            for fn in ("tags_custom.json", "rules_custom.json", "settings.json",
                       "USER_CONTEXT.md", "calendar.json"):
                try:
                    p = _safe_join(HOME, fn)
                    if os.path.exists(p):
                        out["files"][fn] = open(p, encoding="utf-8").read()
                except Exception:
                    pass
            try:
                for fn in sorted(os.listdir(DATA_DIR)):
                    if fn.endswith("_threads.json"):
                        p = _safe_join(DATA_DIR, fn)
                        out["files"]["data/" + fn] = open(p, encoding="utf-8").read()
            except Exception:
                pass
            body = json.dumps(out, ensure_ascii=False, indent=1).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Disposition",
                             'attachment; filename="atools-config-safe-%s.json"'
                             % __import__("time").strftime("%Y%m%d-%H%M%S"))
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            return self.wfile.write(body)
        if u.path == "/api/presets":
            _all = E.get_presets()
            _pr = {k: {"kind": v.get("kind", "reporter")} for k, v in _all.items()}
            _ui = _ui_asset_info()
            return self._s(200, json.dumps({"version": E.VERSION,
                "dev": bool(FULL_SOURCE and DEV_UI),
                "ui_build": _ui.get("token", ""),
                "ui_lines": _ui.get("lines", 0),
                "presets": _pr}))
        if u.path == "/api/seen_status":
            # Podglad pamieci 'juz raportowane' — ile maili agent pamieta, gdzie plik.
            nm = q.get("name", [""])[0]
            p = os.path.join(DATA_DIR, f"{nm}_seen.json")
            cnt = 0
            try:
                if os.path.exists(p):
                    data = json.load(open(p, encoding="utf-8"))
                    cnt = len(data) if isinstance(data, (list, dict)) else 0
            except Exception:
                pass
            return self._s(200, json.dumps({"count": cnt, "path": p, "exists": os.path.exists(p)}))

        if u.path == "/api/tags":
            # Pełny obraz tagów: wbudowane (preset), z pliku (custom), dodane przez AI, użyte w raporcie
            nm = q.get("name", [""])[0]
            used, ai_tags = set(), set()
            try:
                rp = os.path.join(DATA_DIR, f"{nm}_report.json")
                if os.path.exists(rp):
                    rj = json.load(open(rp, encoding="utf-8"))
                    for mb in rj.get("mailboxes", []):
                        for r in list(mb.get("rows", [])) + list(mb.get("hidden_rows", [])):
                            for t in r.get("tags", []):
                                used.add(t)
                                if t.startswith("🤖"):       # legacy/provenance-prefixed AI tags
                                    ai_tags.add(t)
            except Exception:
                pass
            custom = []
            try:
                cp = os.path.join(HOME, "tags_custom.json")
                if os.path.exists(cp):
                    custom = json.load(open(cp, encoding="utf-8"))
            except Exception:
                pass
            # Factory tag catalog is broader than CAT_LABEL/PROJECT_TAGS: semantic
            # tags such as court/payment due/statement are produced directly by the
            # deterministic tagger and must be visible in the tag-focused UI too.
            builtin = []
            try:
                builtin = sorted(
                    set(getattr(E, "BUILTIN_TAG_CATALOG", []) or []) |
                    {v for v in E.CAT_LABEL.values() if v} |
                    {v for v in E.PROJECT_TAGS.values() if v} |
                    {str(r.get("tag", "")).strip() for r in getattr(E, "DEFAULT_CUSTOM_TAGS", []) if str(r.get("tag", "")).strip()}
                )
            except Exception:
                pass
            # domyślne reguły presetu (żeby user widział co jest "fabryczne")
            preset_rules = []
            try:
                preset_rules = E._factory_tag_rules()
            except Exception:
                pass
            langs = E.effective_rule_langs()
            try:
                _p = json.load(open(prof_path(nm), encoding="utf-8"))
                langs = E.effective_rule_langs(_p)
            except Exception:
                pass
            return self._s(200, json.dumps({
                "used": sorted(used), "custom": custom,
                "builtin": builtin, "preset_rules": preset_rules,
                "factory_overridden": os.path.exists(getattr(E, "FACTORY_RULES_OVERRIDE_PATH", "")),
                "ai": sorted(ai_tags), "langs": langs}))
        if u.path == "/api/backups":
            # Lista kopii zapasowych (profile + tagi) — do przywracania z panelu admin
            bdir = backup_dir()
            items = []
            total_kb = 0
            all_files = []
            if os.path.isdir(bdir):
                all_files = [f for f in os.listdir(bdir)
                             if os.path.isfile(os.path.join(bdir, f))]
                for fn in all_files:
                    try:
                        total_kb += os.path.getsize(os.path.join(bdir, fn)) // 1024
                    except Exception:
                        pass
                for fn in sorted(all_files, reverse=True)[:40]:
                    full = os.path.join(bdir, fn)
                    try:
                        import time as _t
                        when = _t.strftime("%Y-%m-%d %H:%M", _t.localtime(os.path.getmtime(full)))
                        size_kb = os.path.getsize(full) // 1024
                    except Exception:
                        when = ""; size_kb = 0
                    items.append({"name": fn, "id": fn, "when": when,
                                  "kb": size_kb, "gz": fn.endswith(".gz")})
            return self._s(200, json.dumps({
                "items": items, "total": len(all_files), "total_kb": total_kb,
                "shown": len(items),
                "policy": {"keep_plain": BACKUP_KEEP_PLAIN,
                           "keep_total": BACKUP_KEEP_TOTAL,
                           "max_age_days": BACKUP_MAX_AGE_DAYS}}))
        if u.path == "/api/backups_prune":
            # GET is preview-only. Any mutation belongs to POST so browser pages cannot
            # trigger cleanup through a cross-site image/link/navigation.
            return self._s(200, json.dumps({"ok": True,
                                            **prune_backups(dry_run=True, compress_only=False)}))
        if u.path == "/api/help":
            try:
                import help_texts as HT
                HT.configure(E.VERSION)
                lang = q.get("lang", ["en"])[0]
                return self._s(200, json.dumps(HT.all_for(lang)))
            except Exception:
                return self._s(200, json.dumps({}))
        if u.path == "/api/ui-text":
            # UI strings live in lang_ui.py.  Keeping this endpoint separate from
            # help_texts makes adding a language a data-only change.
            lang = q.get("lang", ["en"])[0]
            return self._s(200, json.dumps({"language": lang,
                                            "languages": LUI.languages(),
                                            "language_meta": LUI.language_meta(),
                                            "text": LUI.all_for(lang)}))
        if u.path == "/api/local_ollama":
            runtime_path, runtime_cfg = _read_runtime_json_local()
            models = _ollama_models_local()
            runtime_model = (runtime_cfg or {}).get("model") or ""
            suggested = runtime_model or (models[0] if models else "llama3.2:3b")
            return self._s(200, json.dumps({
                "runtime_found": bool(runtime_path),
                "runtime_path": runtime_path,
                "runtime_model": runtime_model,
                "installed_models": models,
                "suggested_model": suggested,
                "provider": "ollama",
                "base_url": "",
                "api_key": "",
            }))
        if u.path == "/api/rerender":
            # RAPORT NA ZADANIE z tym, co normalnie ukryte (ads/marketing/social).
            # NIE pobiera poczty ponownie, NIE wola AI — przebudowuje z ostatniego runu.
            # Dzieki temu "pokaz mi jednak wszystko" nic nie kosztuje.
            nm = q.get("name", [""])[0]
            want_social = q.get("social", ["0"])[0] == "1"
            want_hidden = q.get("hidden", ["0"])[0] == "1"
            try:
                rp = os.path.join(DATA_DIR, f"{nm}_report.json")
                if not os.path.exists(rp):
                    return self._s(200, json.dumps({"ok": False,
                        "error": "no report yet — click Run once"}))
                rj = json.load(open(rp, encoding="utf-8"))
                out = []
                for mb in rj.get("mailboxes", []):
                    lines = [f"═══ {mb.get('mailbox','')} "
                             f"({mb.get('total',0)} new · {mb.get('hidden',0)} hidden) ═══"]
                    for r in mb.get("rows", []):
                        tg = " ".join(r.get("tags", []))
                        lines.append(f"  {r.get('priority','')} · {r.get('date','')} · "
                                     f"{r.get('from','')}: {r.get('summary','')}"
                                     f"{'  [' + tg + ']' if tg else ''}")
                    if want_hidden or want_social:
                        hid = mb.get("hidden_rows", [])
                        show = [h for h in hid
                                if (want_hidden and h.get("cat") in ("ads", "marketing", "system"))
                                or (want_social and h.get("cat") == "social")]
                        if show:
                            lines.append("  ── normally hidden ──")
                            for h in show:
                                tg = " ".join(h.get("tags", []))
                                lines.append(f"    {h.get('date','')} · {h.get('from','')}: "
                                             f"{h.get('summary','')}"
                                             f"{'  [' + tg + ']' if tg else ''}")
                    out.append("\n".join(lines))
                txt = "\n\n".join(out) or "(nothing in the last report)"
                return self._s(200, json.dumps({"ok": True, "text": txt}))
            except Exception as ex:
                return self._s(200, json.dumps({"ok": False, "error": str(ex)[:120]}))
        if u.path == "/api/signup":
            try:
                import opportunities as OP
                return self._s(200, json.dumps({"kit": OP.load_signup(),
                                                "fields": list(OP.DEFAULT_SIGNUP.keys())}))
            except Exception as ex:
                return self._s(200, json.dumps({"kit": {}, "error": str(ex)}))
        if u.path == "/api/signupkit":
            try:
                import opportunities as OP
                txt = OP.signup_kit(
                    profile_text=E.load_user_context() or "",
                    email=q.get("email", [""])[0],
                    name=q.get("name", [""])[0],
                    location=q.get("loc", [""])[0],
                    links=q.get("links", [""])[0])
                return self._s(200, json.dumps({"text": txt}))
            except Exception as ex:
                return self._s(200, json.dumps({"text": f"(error: {ex})"}))
        if u.path == "/api/finder_presets":
            try:
                import finder_presets as FP
                return self._s(200, json.dumps({"presets": FP.all_presets()}))
            except Exception:
                return self._s(200, json.dumps({"presets": []}))
        if u.path == "/api/opps":
            try:
                import opportunities as OP
                return self._s(200, json.dumps({
                    "categories": {k: v.get("label", k) for k, v in OP.load_platforms().items()
                                   if not k.startswith("_")},
                    "notes": {k: v.get("note", "") for k, v in OP.load_platforms().items()
                              if not k.startswith("_")},
                    "items": OP.rank_for_me(q.get("cat", [None])[0])}))
            except Exception as ex:
                return self._s(200, json.dumps({"error": str(ex), "items": []}))
        if u.path == "/api/rules":
            return self._s(200, json.dumps({"rules": E.load_rules(),
                                            "defaults": E.DEFAULT_RULES}))
        if u.path == "/api/modes":
            # DWA SILNIKI DO WYBORU:
            #  classic — stare tryby (MODES) + flagi (FLAGS), nakladane na kazdy tryb
            #  matrix  — nowa macierz: kombinacje z listy selektorow, 4-mailowa probka
            try:
                import multirun as MR
                eng, others = MR.load_selectors()
                combos = [{"key": c["key"], "name": c["name"], "desc": c["desc"],
                           "invoke": c["invoke"]}
                          for c in MR.build_combos(eng, others)]
            except Exception:
                combos = []
            try:
                import multirun_classic as MC
                modes = [{"key": k, "label": v["label"], "note": v["note"]}
                         for k, v in MC.MODES.items()]
                flags = [{"key": k, "label": v[0]} for k, v in MC.FLAGS.items()]
            except Exception:
                modes, flags = [], []
            try:
                import connectors as CN
                conns = CN.ui_schema()
            except Exception:
                conns = []
            return self._s(200, json.dumps({"combos": combos, "modes": modes,
                                            "flags": flags, "connectors": conns}))
        if u.path == "/api/usage":
            # Statystyki uzycia AI — ile tokenow, ile streszczen, efektywnosc
            nm = q.get("name", [""])[0]
            out = {"total_tokens": 0, "last_tokens": 0, "last_summaries": 0,
                   "per_summary": 0, "overflow": 0}
            try:
                out["total_tokens"] = E._token_total()
            except Exception:
                pass
            try:
                rp = os.path.join(DATA_DIR, f"{nm}_report.json")
                if os.path.exists(rp):
                    rj = json.load(open(rp, encoding="utf-8"))
                    note = str(rj.get("note", ""))
                    import re as _re
                    m = _re.search(r"AI summarized (\d+).*?~?(\d+)\s*tok", note)
                    if m:
                        out["last_summaries"] = int(m.group(1))
                        out["last_tokens"] = int(m.group(2))
                        if out["last_summaries"]:
                            out["per_summary"] = out["last_tokens"] / out["last_summaries"]
            except Exception:
                pass
            try:
                op = os.path.join(DATA_DIR, f"{nm}_overflow.json")
                if os.path.exists(op):
                    out["overflow"] = len(json.load(open(op, encoding="utf-8")) or [])
            except Exception:
                pass
            return self._s(200, json.dumps(out))
        if u.path == "/api/docs":
            # Czytanie dokumentacji lezacej obok panel.py — SKANUJEMY katalog,
            # zeby nowe pliki .md/.txt pojawialy sie same (bez dopisywania do listy).
            here = os.path.dirname(os.path.abspath(__file__))
            try:
                known = sorted([fn for fn in os.listdir(here)
                                if fn.lower().endswith((".md", ".txt"))
                                and not fn.startswith(".")])
            except Exception:
                known = []
            f = q.get("file", [""])[0]
            if f:
                if f not in known:
                    return self._s(200, json.dumps({"text": "(not allowed)"}))
                p = os.path.join(here, f)
                if not os.path.exists(p):
                    return self._s(200, json.dumps({"text": "(file not found)"}))
                try:
                    return self._s(200, json.dumps({"text": open(p, encoding="utf-8").read()[:60000]}))
                except Exception as ex:
                    return self._s(200, json.dumps({"text": f"(could not read: {ex})"}))
            files = [k for k in known if os.path.exists(os.path.join(here, k))]
            return self._s(200, json.dumps({"files": files}))
        if u.path == "/api/calendar":
            return self._s(200, json.dumps({"items": E.hq.calendar_list()}))
        if u.path == "/api/agents":
            return self._s(200, json.dumps(list_agents()))
        if u.path == "/api/preset":
          try:
            nm = q["name"][0]
            return self._s(200, json.dumps(E.make_profile(nm)))
          except KeyError:
            return self._s(404, json.dumps({"error": "preset not found"}))
        if u.path == "/api/profile":
            p = prof_path(q["name"][0])
            if not os.path.exists(p):
                return self._s(200, "{}")
            try:
                _migrate_legacy_profile(q["name"][0])
                raw = _load_profile_public(q["name"][0])
                return self._s(200, json.dumps(_redact_secrets_for_ui(raw), ensure_ascii=False))
            except Exception as ex:
                return self._s(500, json.dumps({"error": str(ex)}))
        if u.path == "/api/debug":
            # PELNY slad ostatniego runu — kazdy krok, kazdy blad, kazde wywolanie LLM.
            # To jest to, czego brakowalo: bledy w tle ginely bezpowrotnie.
            return self._s(200, json.dumps({"text": E.debug_read(q.get("name", [""])[0])}))
        if u.path == "/api/security_status":
            try:
                st = SS.backend_status()
                # Non-sensitive status only; never return vault paths or credentials.
                st["saved_profiles"] = sum(1 for a in list_agents() if a.get("name") and SS.SAVED_SECRET in json.dumps(_load_profile_public(a.get("name")), ensure_ascii=False))
                if sys.platform.startswith("linux") and st.get("fallback"):
                    try:
                        import system_setup as _ss
                        st["harden_available"] = True
                        st["harden_command"] = ((_ss.status().get("secret_store") or {}).get("manual_hardening") or "")
                    except Exception:
                        st["harden_available"] = True
                else:
                    st["harden_available"] = False
                return self._s(200, json.dumps(st))
            except Exception as ex:
                return self._s(200, json.dumps({"backend":"unknown","error":str(ex)}))
        if u.path == "/api/deps_status":
            try:
                import system_setup as _ss
                st = _ss.status()
                missing = [f"{x['module']} ({x['purpose']})" for x in st.get('python', []) if not x.get('present')]
                sysst = st.get('system') or {}
                missing.extend(st.get('missing_system') or [])
                st["missing"] = list(dict.fromkeys(missing))
                st["pip_cmd"] = (sys.executable + " -m pip install --user " + " ".join(st.get('missing_python') or [])) if st.get('missing_python') else ""
                st["linux_system"] = " ".join(sysst.get('recommended_packages') or []) if sys.platform.startswith('linux') else ""
                return self._s(200, json.dumps(st))
            except Exception as ex:
                return self._s(200, json.dumps({"missing": [], "error": str(ex)}))
        if u.path == "/api/deps_install_status":
            try:
                import system_setup as _ss
                st = _ss.status(); lp = st.get("log_path") or ""
                txt = open(lp, encoding="utf-8", errors="replace").read()[-4000:] if lp and os.path.exists(lp) else ""
                return self._s(200, json.dumps({"done": not bool(st.get("missing_python")), "error": False, "log": txt, "status": st}))
            except Exception as ex:
                return self._s(200, json.dumps({"done": False, "error": True, "log": str(ex)}))
        if u.path == "/api/schedule_status":
            # PODGLAD SCHEDULERA: zaplanowane zadania (kiedy jaki tool), aktywne joby,
            # i ostatnie linie debug logu — zebys widzial co sie dzieje.
            out = {"jobs": [], "planned": [], "local_agents": [], "debug": [], "paths": {}, "seen_atools": 0}
            try:
                import scheduler as _sch
                out["jobs"] = _sch.list_jobs()
            except Exception as ex:
                out["jobs_error"] = str(ex)
            try:
                import wake as _wk
                _ws = _wk.status()
                out["wake"] = _ws
                out["next_popup"] = _ws.get("next_popup")
            except Exception:
                out["next_popup"] = None
            try:
                import atool_sync as _as
                p = os.path.join(_as.eco_dir(), "ecosystem.json")
                out["paths"]["ecosystem"] = p
                out["paths"]["eco_exists"] = os.path.exists(p)
                out["paths"]["eco_dir"] = _as.eco_dir()
                if os.path.exists(p):
                    eco = json.load(open(p, encoding="utf-8"))
                    atools = (eco.get("atools") or [])
                    out["seen_atools"] = len(atools)
                    for at in atools:
                        sl = at.get("schedule_live") or {}
                        # pokaz KAZDY a-tool; jesli nie ma schedule_live, powiedz to wprost
                        out["planned"].append({
                            "tool": at.get("id") or at.get("name") or "?",
                            "name": at.get("name") or "",
                            "port": at.get("port"),
                            "path": at.get("path") or "",
                            "version": at.get("core_version") or at.get("version") or "",
                            "runs": sl.get("runs") if sl else None,
                            "mail_runs": sl.get("mail_runs") if sl else None,
                            "feed_runs": sl.get("feed_runs") if sl else None,
                            "once_date": sl.get("once_date") if sl else None,
                            "once_time": sl.get("once_time") if sl else None,
                            "launch": sl.get("launch") if sl else None,
                            "ai_mode": sl.get("ai_mode") if sl else None,
                            "next": (sl.get("active_from") or "-") if sl else "-",
                            "scheduled": bool(sl)})
            except Exception as ex:
                out["planned_error"] = str(ex)
            # Local profiles are editable in THIS Communication panel.  Expose their
            # actual persisted schedule separately from the ecosystem-level A-Tool plan.
            try:
                for a in list_agents():
                    nm = a.get("name") or ""
                    if not nm:
                        continue
                    pp = prof_path(nm)
                    pr = json.load(open(pp, encoding="utf-8")) if os.path.exists(pp) else {}
                    sc = pr.get("schedule") or {}
                    out["local_agents"].append({
                        "name": nm, "kind": pr.get("kind") or a.get("kind") or "",
                        "scheduled": bool(sc.get("scheduled")),
                        "run_on_start": bool(sc.get("run_on_start")),
                        "catchup": sc.get("catchup", True) is not False,
                        "times_per_day": sc.get("times_per_day"),
                        "windows": list(sc.get("windows") or []),
                        "once_date": sc.get("once_date") or "",
                        "once_time": sc.get("once_time") or "",
                        "every_hours": sc.get("every_hours"),
                    })
            except Exception as ex:
                out["local_agents_error"] = str(ex)
            try:
                dl = os.path.join(LOG_DIR, "scheduler_debug.log")
                out["paths"]["debug_log"] = dl
                if os.path.exists(dl):
                    out["debug"] = open(dl, encoding="utf-8").read().splitlines()[-40:]
            except Exception:
                pass
            return self._s(200, json.dumps(out))

        if u.path == "/api/log":
            try: _nm=_safe_agent_name((q.get("name") or [""])[0])
            except Exception: return self._s(400,json.dumps({"error":"invalid log name"}))
            _wst=_wake_run_status(_nm)
            return self._s(200,json.dumps({"log":tail_log(_nm),
                                           "running":bool(RUNNING.get(_nm,False) or _wst.get("running")),
                                           "wake_run":_wst}))
        if u.path == "/api/result":
            try:
                return self._s(200, json.dumps(read_result(q["name"][0])))
            except Exception as ex:
                return self._s(200, json.dumps({"type": "report", "text": f"(brak wyniku: {ex})"}))
        if u.path == "/api/context":
            return self._s(200, json.dumps({"text": E.load_user_context() or E.DEFAULT_USER_CONTEXT}))
        if u.path == "/api/stats":
            try:
                return self._s(200, json.dumps(E.load_stats()))
            except Exception:
                return self._s(200, json.dumps({}))
        if u.path == "/api/settings":
            s = {}
            try:
                sp = os.path.join(HOME, "settings.json")
                if os.path.exists(sp):
                    s = json.load(open(sp, encoding="utf-8"))
            except Exception:
                pass
            if not s.get("lang"):
                s["lang"] = _system_ui_lang()
                s["lang_auto"] = True
            if not s.get("lang_mode"):
                s["lang_mode"] = "force" if str(s.get("summary_lang_mode", "")).lower() == "force" else "adapt"
            if not isinstance(s.get("rule_langs"), list) or not s.get("rule_langs"):
                s["rule_langs"] = E.effective_rule_langs(settings=s)
            return self._s(200, json.dumps(s))
        if u.path == "/api/settings_snapshot":
            name = (q.get("name") or [""])[0]
            snap = {"agent": name, "generated_at": __import__("datetime").datetime.now().isoformat(timespec="seconds"),
                    "sources": {}, "resolved_profile": {}, "raw": {},
                    "secret_store": SS.backend_status()}
            def _read_json_file(path):
                try: return json.load(open(path, encoding="utf-8")) if os.path.exists(path) else None
                except Exception as ex: return {"_read_error": str(ex)}
            # Persisted profile is merged only with its real preset object; the UI adds no defaults.
            pp = prof_path(name) if name else ""
            prof = _read_json_file(pp) if pp else None
            snap["sources"]["profile"] = pp or None; snap["raw"]["profile"] = prof
            if isinstance(prof, dict):
                try:
                    base = E.make_profile(prof.get("preset")) if prof.get("preset") else {}
                except Exception:
                    base = {}
                snap["preset_base"] = base
                def _merge(a,b):
                    out=dict(a or {})
                    for k,v in (b or {}).items():
                        out[k]=_merge(out.get(k),v) if isinstance(v,dict) and isinstance(out.get(k),dict) else v
                    return out
                snap["resolved_profile"] = _merge(base, prof)
                try:
                    snap["effective_language_policy"] = E.resolve_language_policy(prof)
                except Exception as ex:
                    snap["effective_language_policy"] = {"_error": str(ex)}
            files = ["settings.json","tags_custom.json","factory_rules_override.json","rules_custom.json","USER_CONTEXT.md","scheduler_prefs.json",
                     "wake_config.json","wake_state.json","wake_approved.json","dependency_state.json",
                     "ecosystem.json","runtime.json","calendar.json"]
            try:
                import atool_sync as _as
                eco_dir = _as.eco_dir()
            except Exception:
                eco_dir = HOME
            mapping = {
                "settings.json": os.path.join(HOME,"settings.json"),
                "tags_custom.json": os.path.join(HOME,"tags_custom.json"),
                "factory_rules_override.json": os.path.join(HOME,"factory_rules_override.json"),
                "rules_custom.json": os.path.join(HOME,"rules_custom.json"),
                "USER_CONTEXT.md": os.path.join(HOME,"USER_CONTEXT.md"),
                "scheduler_prefs.json": os.path.join(HOME,"scheduler_prefs.json"),
                "wake_config.json": os.path.join(eco_dir,"wake_config.json"),
                "wake_state.json": os.path.join(eco_dir,"wake_state.json"),
                "wake_approved.json": os.path.join(eco_dir,"wake_approved.json"),
                "dependency_state.json": os.path.join(HOME,"dependency_state.json"),
                "ecosystem.json": os.path.join(eco_dir,"ecosystem.json"),
                "runtime.json": os.path.join(os.path.dirname(os.path.abspath(__file__)),"runtime.json"),
                "calendar.json": os.path.join(HOME,"calendar.json"),
            }
            for key,path in mapping.items():
                snap["sources"][key]=path
                if key.endswith(".md"):
                    try: snap["raw"][key]=open(path,encoding="utf-8").read() if os.path.exists(path) else None
                    except Exception as ex: snap["raw"][key]={"_read_error":str(ex)}
                else: snap["raw"][key]=_read_json_file(path)
            # Effective values come from the same engine loaders used by a real run.
            # They are intentionally not reconstructed with UI-side fallback constants.
            try: snap["effective_classification_rules"] = E.load_rules()
            except Exception as ex: snap["effective_classification_rules"] = {"_error": str(ex)}
            try: snap["effective_tag_rules"] = E._custom_tag_rules()
            except Exception as ex: snap["effective_tag_rules"] = {"_error": str(ex)}
            try:
                atp = os.path.join(os.path.dirname(os.path.abspath(__file__)), "atool.json")
                snap["sources"]["atool.json"] = atp
                snap["raw"]["atool.json"] = _read_json_file(atp)
            except Exception: pass
            try:
                if name:
                    rp = os.path.join(DATA_DIR, f"{name}_report.json")
                    dp = os.path.join(LOG_DIR, f"{name}_debug.log")
                    snap["sources"]["last_report"] = rp
                    snap["sources"]["last_debug"] = dp
                    if os.path.exists(rp):
                        rr = _read_json_file(rp)
                        snap["last_run"] = {k: rr.get(k) for k in ("generated_at","run_source","run_slot","mode","mailboxes") if isinstance(rr,dict) and k in rr}
            except Exception as ex: snap["last_run"] = {"_error": str(ex)}
            try:
                import atool_sync as _as2
                eco = _as2.read_ecosystem()
                own = []
                for rec in eco.get("atools", []):
                    sl = rec.get("schedule_live") or {}
                    if name and (sl.get("agent") == name or rec.get("id") == name): own.append(rec)
                snap["published_schedule"] = own
            except Exception as ex: snap["published_schedule"] = {"_error": str(ex)}
            try:
                import system_setup as _ss; snap["dependencies"]=_ss.status()
            except Exception as ex: snap["dependencies"]={"error":str(ex)}
            try:
                import wake as _wk; snap["wake_runtime"]=_wk.status()
            except Exception as ex: snap["wake_runtime"]={"error":str(ex)}

            # Normal UI gets a readable truth snapshot: the complete resolved profile
            # (all values edited in the Agent/Sources/Schedule/Outputs UI) plus the
            # important shared/runtime settings.  Raw files and diagnostics stay
            # available from the SAME button when panel.py was started with --d.
            want_full = str((q.get("detail") or ["compact"])[0]).lower() == "full"
            if not (DEV_UI and want_full):
                secret_keys = ("password", "passwd", "pass", "token", "api_key", "apikey", "secret")
                def _safe(v, key=""):
                    lk = str(key).lower()
                    if any(x in lk for x in secret_keys):
                        return "<set>" if v not in (None, "", False, []) else "<empty>"
                    if isinstance(v, dict):
                        return {k: _safe(x, k) for k, x in v.items()}
                    if isinstance(v, list):
                        return [_safe(x, key) for x in v]
                    return v
                wr = snap.get("wake_runtime") if isinstance(snap.get("wake_runtime"), dict) else {}
                deps = snap.get("dependencies") if isinstance(snap.get("dependencies"), dict) else {}
                cr = snap.get("effective_classification_rules")
                tr = snap.get("effective_tag_rules")
                rp = snap.get("resolved_profile") or {}
                ro = rp.get("outputs", {}) if isinstance(rp, dict) else {}
                ra = rp.get("agent", {}) if isinstance(rp, dict) else {}
                rs = rp.get("schedule", {}) if isinstance(rp, dict) else {}
                compact = {
                    "view": "current settings",
                    "agent": name,
                    "important": _safe({
                        "goal": ra.get("goal"),
                        "priority_model": ro.get("priority_model") or ("model4" if ro.get("ai_extract") else ("classic_ai" if ro.get("ai_priority") else "script")),
                        "ai_level": ro.get("ai_level", "off"),
                        "ai_can_edit_tags": bool(ro.get("ai_tag_correction")),
                        "summary": {"selection": ro.get("ai_select_mode", "script"), "length": ro.get("summary_depth", "auto"), "p2": bool(ro.get("always_summary"))},
                        "language": snap.get("effective_language_policy") or {},
                        "scan": {"mode": ro.get("scan_mode", "unread"), "days": ro.get("scan_days", 7), "tight": bool(ro.get("tight_scan")),
                                 "spam": bool(ro.get("scan_spam")), "promotions": bool(ro.get("scan_promo"))},
                        "auto_calendar": bool(ro.get("auto_calendar")),
                        "schedule": {"run_on_start": rs.get("run_on_start"), "windows": rs.get("windows") or [], "scheduled": rs.get("scheduled")},
                    }),
                    # All settings editable in the ordinary A-Tool UI, still sanitized.
                    "all_ui_settings": _safe({
                        "agent": rp.get("agent", {}) if isinstance(rp, dict) else {},
                        "sources": rp.get("sources", {}) if isinstance(rp, dict) else {},
                        "schedule": rp.get("schedule", {}) if isinstance(rp, dict) else {},
                        "outputs": rp.get("outputs", {}) if isinstance(rp, dict) else {},
                        "llm": rp.get("llm", {}) if isinstance(rp, dict) else {},
                        "priority": rp.get("priority") if isinstance(rp, dict) else None,
                        "hide_prio_arrows": rp.get("hide_prio_arrows") if isinstance(rp, dict) else None,
                    }),
                    "global_settings": _safe((snap.get("raw") or {}).get("settings.json") or {}),
                    "rules": {"classification_count": len(cr) if isinstance(cr, list) else None,
                              "tag_count": len(tr) if isinstance(tr, list) else None},
                    "last_run": _safe((lambda lr: {
                        "generated_at": lr.get("generated_at"),
                        "run_source": lr.get("run_source"),
                        "run_slot": lr.get("run_slot"),
                        "mode": lr.get("mode"),
                        "mailbox_count": len(lr.get("mailboxes") or []),
                        "new_count": sum(int((mb or {}).get("total") or 0) for mb in (lr.get("mailboxes") or [])),
                        "hidden_count": sum(len((mb or {}).get("hidden_rows") or []) for mb in (lr.get("mailboxes") or [])),
                    })(snap.get("last_run") or {})),
                    "developer_hint": "Start panel.py with --d and press Show current settings for the full raw/effective diagnostic snapshot.",
                }
                return self._s(200, json.dumps(compact, ensure_ascii=False))
            return self._s(200, json.dumps(snap, ensure_ascii=False))
        if u.path == "/api/reportjson":
            nm = q.get("name", ["report"])[0]
            p = os.path.join(DATA_DIR, f"{nm}_report.json")
            if os.path.exists(p):
                return self._s(200, open(p, encoding="utf-8").read())
            return self._s(200, json.dumps({"mailboxes": []}))
        if u.path == "/api/has_report":
            # Czy agent ma ZAPISANY wynik ostatniego runu (tez z run-on-start/tla)?
            # UI uzywa tego, by po wejsciu w agenta pokazac efekt ostatniego runu
            # (maile gotowe do draftu), zamiast pustego ekranu. Zwraca tez czas runu.
            nm = q.get("name", ["report"])[0]
            pj = os.path.join(DATA_DIR, f"{nm}_report.json")
            pl = os.path.join(DATA_DIR, f"{nm}_lastrun.txt")
            out = {"has": os.path.exists(pj), "when": None}
            try:
                if os.path.exists(pl):
                    out["when"] = float(open(pl).read().strip() or "0")
            except Exception:
                pass
            return self._s(200, json.dumps(out))
        if u.path == "/api/export":
            nm = q.get("name", ["report"])[0]
            p = os.path.join(DATA_DIR, f"{nm}_report.txt")
            data = open(p, "rb").read() if os.path.exists(p) else b"(no report yet)"
            self.send_response(200)
            self.send_header("Content-Type", "text/plain; charset=utf-8")
            self.send_header("Content-Disposition", f'attachment; filename="{nm}_report.txt"')
            self.end_headers()
            return self.wfile.write(data)
        return self._s(404, "{}")

    def do_POST(self):
        try:
            return self._do_POST(u=urllib.parse.urlparse(self.path))
        except Exception as ex:
            # Never drop the connection: the browser then shows a dead button
            # with no message at all. Report the fault as JSON instead.
            try:
                import traceback; traceback.print_exc()
            except Exception:
                pass
            try:
                return self._s(200, json.dumps({"ok": False, "error": f"{type(ex).__name__}: {ex}"[:300]}))
            except Exception:
                return

    def _do_POST(self, u=None):
        u = u or urllib.parse.urlparse(self.path)
        if not self._host_authorized():
            return self._s(403, json.dumps({"error":"invalid Host header"}))
        if not self._lan_authorized(u):
            return self._s(403, json.dumps({"error":"unauthorized"}))
        # Same-origin request marker.  JSON alone usually causes a CORS preflight, but
        # requiring our own header also protects localhost from simple cross-site forms
        # and accidental state-changing requests made outside the shipped UI.
        if str(self.headers.get("X-L4M-Request") or "") != "1":
            return self._s(403, json.dumps({"ok": False, "error": "missing local request marker"}))
        try:
            b = self._body()
        except Exception as ex:
            return self._s(400, json.dumps({"ok": False, "error": str(ex)}))
        if u.path == "/api/backups_prune":
            q = urllib.parse.parse_qs(u.query)
            comp_only = q.get("compress_only", ["0"])[0] == "1"
            return self._s(200, json.dumps({"ok": True,
                                            **prune_backups(dry_run=False, compress_only=comp_only)}))
        if u.path == "/api/wake_ui":
            try:
                import wake as _wk
                ok = bool(_wk.show_control_panel())
                return self._s(200, json.dumps({"ok": ok}))
            except Exception as ex:
                return self._s(200, json.dumps({"ok": False, "error": str(ex)}))
        if u.path == "/api/secrets_harden":
            try:
                import system_setup as _ss
                res = _ss.install_secret_store_backend()
                moved = 0
                if res.get("ok"):
                    for _a in list_agents():
                        try:
                            if _a.get("name") and SS.promote_private_fallback(_a["name"]):
                                moved += 1
                        except Exception:
                            pass
                return self._s(200, json.dumps({"ok": bool(res.get("ok")), "result": res, "promoted": moved, "status": SS.backend_status()}))
            except Exception as ex:
                return self._s(200, json.dumps({"ok": False, "error": str(ex)}))
        if u.path == "/api/deps_install":
            try:
                import system_setup as _ss
                # Explicit user action only. Automatic first-run and background Wake
                # never enter this path.
                res = _ss.install_missing(include_system=True)
                return self._s(200, json.dumps({"ok": bool(res.get('ok')), "result": res,
                                                "msg": "dependency install/verification finished"}))
            except Exception as ex:
                return self._s(200, json.dumps({"ok": False, "error": str(ex)}))
        if u.path == "/api/importconfig":
            # Import a SAFE export. Existing local passwords/API keys are retained by merge.
            data = b.get("data") if isinstance(b, dict) else None
            if data is None and isinstance(b, dict) and "profiles" in b:
                data = b  # backwards-compatible direct payload
            if not isinstance(data, dict) or not isinstance(data.get("profiles"), dict):
                return self._s(400, json.dumps({"ok": False, "error": "not a valid config export"}))
            _free_existing_names = {str(x.get("name") or "").strip() for x in list_agents() if x.get("name")}
            _free_incoming_names = {str(x).strip() for x in (data.get("profiles") or {}).keys() if str(x).strip()}
            if len(_free_existing_names | _free_incoming_names) > 1:
                return self._s(400, json.dumps({
                    "ok": False,
                    "error": "Solo Free can import configuration for one Communication profile only.",
                    "code": "free_single_profile"
                }))
            import time as _t, shutil as _sh
            bdir = backup_dir(); ts = _t.strftime("%Y%m%d-%H%M%S")
            n_prof = n_file = 0
            try:
                for nm, incoming in (data.get("profiles") or {}).items():
                    nm = _safe_agent_name(nm)
                    if not isinstance(incoming, dict):
                        raise ValueError("profile must be an object")
                    p = prof_path(nm)
                    existing = {}
                    if os.path.exists(p):
                        try:
                            _migrate_legacy_profile(nm)
                            existing = _load_profile_public(nm)
                            _sh.copy2(p, _safe_join(bdir, f"{nm}_{ts}.json"))
                        except Exception:
                            existing = {}
                    # Incoming secrets are ignored by _deep_merge_keep_existing; imports
                    # are configuration-only and cannot replace the local credential vault.
                    merged = _deep_merge_keep_existing(existing, incoming)
                    merged["name"] = nm
                    _atomic_json_write(p, SS.redact_for_profile(merged))
                    n_prof += 1
                allowed = {"tags_custom.json", "factory_rules_override.json", "rules_custom.json", "settings.json",
                           "USER_CONTEXT.md", "calendar.json"}
                for fn, txt in (data.get("files") or {}).items():
                    if not isinstance(txt, str):
                        continue
                    if fn.startswith("data/") and fn.endswith("_threads.json"):
                        base = os.path.basename(fn)
                        if base != fn.split("/", 1)[1] or ".." in base:
                            continue
                        p = _safe_join(DATA_DIR, base)
                    elif fn in allowed:
                        p = _safe_join(HOME, fn)
                    else:
                        continue
                    if os.path.exists(p):
                        try:
                            _sh.copy2(p, _safe_join(bdir, f"{os.path.basename(fn)}_{ts}.bak"))
                        except Exception:
                            pass
                    os.makedirs(os.path.dirname(p), exist_ok=True)
                    with open(p, "w", encoding="utf-8") as fh:
                        fh.write(txt)
                    _private_path(p); n_file += 1
                E._CUSTOM_TAGS_CACHE[0] = None
                return self._s(200, json.dumps({"ok": True, "profiles": n_prof, "files": n_file}))
            except Exception as ex:
                return self._s(400, json.dumps({"ok": False, "error": str(ex)}))
        if u.path == "/api/rename":
            old = (b.get("old") or "").strip()
            new = (b.get("new") or "").strip()
            if not old or not new:
                return self._s(400, json.dumps({"error": "brak nazwy"}))
            po, pn = prof_path(old), prof_path(new)
            if not os.path.exists(po):
                return self._s(200, json.dumps({"ok": False, "error": "old profile not found"}))
            if os.path.exists(pn):
                return self._s(200, json.dumps({"ok": False, "error": "a profile with the new name already exists"}))
            try:
                import shutil as _sh, time as _t, json as _j
                bdir = backup_dir()
                _sh.copy2(po, os.path.join(bdir, f"{old}_{_t.strftime('%Y%m%d-%H%M%S')}.json"))
                data = _load_profile_full(old)
                data["name"] = new
                _write_profile_secure(new, data)
                SS.delete(old)
                os.remove(po)                       # przenies, nie kopiuj — zero sierot
                return self._s(200, json.dumps({"ok": True, "name": new}))
            except Exception as ex:
                return self._s(200, json.dumps({"ok": False, "error": str(ex)}))
        if u.path == "/api/save":
            name = (b.get("name") or "").strip()
            if not name:
                return self._s(400, json.dumps({"error": "brak nazwy"}))
            # Bezpiecznik anty-duplikat: nowy profil z istniejaca nazwa ma byc blokowany,
            # a nadpisanie wolno tylko przy jawnej edycji TEGO SAMEGO profilu.
            existing_name = (b.get("_existing_name") or "").strip()
            allow_overwrite = bool(b.get("_allow_overwrite"))

            # WALIDACJA NAZWY: znaki, ktore psuja sciezki plikow i wyszukiwanie logow
            # (& rozbijal query, / \ tworzyly podkatalogi). Blokujemy u zrodla.
            _bad = set('/\\<>:"|?*&')
            if any(c in _bad for c in name):
                return self._s(200, json.dumps({
                    "ok": False,
                    "error": "The name cannot contain / \\ < > : \" | ? * &  — please use letters, "
                             "digits, spaces, - or _ (these characters break file names)."
                }))

            b["name"] = name
            p = prof_path(name)
            if not os.path.exists(p):
                _free_existing = [x for x in list_agents() if x.get("name")]
                if _free_existing:
                    return self._s(200, json.dumps({
                        "ok": False,
                        "error": "Solo Free allows one configured Communication profile. Delete the existing profile before creating another.",
                        "code": "free_single_profile"
                    }))

            # BACKUP PRZED NADPISANIEM — jesli profil o tej nazwie juz istnieje, zachowaj
            # jego POPRZEDNIA wersje w data/backups/ zanim cokolwiek zmienimy. Bez tego
            # edycja nazwy/pol i Save mogly cicho nadpisac pusty agent na pelny (utrata danych).
            if os.path.exists(p):
                if not (allow_overwrite and existing_name == name):
                    return self._s(200, json.dumps({
                        "ok": False,
                        "error": "a profile with this name already exists",
                        "code": "duplicate_name"
                    }))
                try:
                    import shutil as _sh, time as _t
                    bdir = os.path.join(HOME, "data", "backups")
                    os.makedirs(bdir, exist_ok=True)
                    _sh.copy2(p, os.path.join(bdir, f"{name}_{_t.strftime('%Y%m%d-%H%M%S')}.json"))
                except Exception:
                    pass   # backup to sasiedzki dodatek — nigdy nie blokuje zapisu

                # UI submits the fields it knows. Preserve future/legacy nested keys
                # (including language compatibility inputs) instead of erasing them.
                try:
                    previous = _load_profile_full(name)
                    b = _restore_secret_sentinels(previous, b)
                    def _merge_profile(old, new):
                        out = dict(old or {})
                        for key, value in (new or {}).items():
                            out[key] = (_merge_profile(out.get(key), value)
                                        if isinstance(value, dict) and isinstance(out.get(key), dict)
                                        else value)
                        return out
                    b = _merge_profile(previous, b)
                except Exception:
                    pass

            # Metadane sterujace zapisem nie powinny ladowac w profilu.
            b.pop("_existing_name", None)
            b.pop("_allow_overwrite", None)
            # A sentinel is only meaningful when an existing local value can be restored.
            # For a new profile it becomes an empty value, never persisted as a fake password.
            if not os.path.exists(p):
                b = _restore_secret_sentinels({}, b)

            _write_profile_secure(name, b)
            _wake_pub = None
            try:
                _wake_pub = publish_profile_schedule(name, b)
            except Exception as _pe:
                _wake_pub = {"ok": False, "error": str(_pe)}
            return self._s(200, json.dumps({"ok": True, "name": name, "wake_schedule": _wake_pub}))
        if u.path == "/api/run":
            name, off = b.get("name"), b.get("offline", False)
            if RUNNING.get(name):
                return self._s(200, json.dumps({"ok": False, "msg": "already running"}))
            # RUNY DZIELA GLOBALNY STAN (E.OFFLINE) — dwa naraz psulyby sie nawzajem.
            # Dlatego blokujemy KAZDY nowy run, gdy jakikolwiek inny trwa. To tez
            # znaczy, ze przelaczenie agenta w trakcie nie zabija biezacego runu:
            # on leci w tle do konca, a nowy po prostu czeka na swoja kolej.
            if any(RUNNING.values()):
                busy = next((n for n, v in RUNNING.items() if v), "another agent")
                return self._s(200, json.dumps({"ok": False,
                    "msg": f"'{busy}' is still running — let it finish, then run this one"}))
            threading.Thread(target=do_run, args=(name, off), daemon=True).start()
            return self._s(200, json.dumps({"ok": True}))
        if u.path == "/api/restore":
            # Browser supplies only a backup id/basename; never a filesystem path.
            backup_id = os.path.basename(str((b or {}).get("id") or "").strip())
            if not backup_id or backup_id in (".", "..") or ".." in backup_id:
                return self._s(400, json.dumps({"ok": False, "error": "invalid backup id"}))
            try:
                import shutil as _sh, time as _t, gzip as _gz
                bdir = backup_dir(); src = _safe_join(bdir, backup_id)
                if not os.path.isfile(src):
                    return self._s(404, json.dumps({"ok": False, "error": "backup not found"}))
                logical = backup_id[:-3] if backup_id.endswith(".gz") else backup_id
                if logical.startswith("tags_custom"):
                    dst = _safe_join(HOME, "tags_custom.json")
                elif logical.startswith("USER_CONTEXT"):
                    dst = _safe_join(HOME, os.path.basename(E.USER_CONTEXT_PATH))
                else:
                    # Profile backups are named <agent>_<timestamp>...json; recover the
                    # longest existing profile prefix, then fall back to the first segment.
                    candidates = []
                    try:
                        candidates = [x[:-5] for x in os.listdir(PROF_DIR) if x.endswith(".json")]
                    except Exception:
                        pass
                    agent = next((x for x in sorted(candidates, key=len, reverse=True)
                                  if logical.startswith(x + "_")), logical.split("_", 1)[0])
                    dst = prof_path(agent)
                if os.path.exists(dst):
                    _sh.copy2(dst, _safe_join(bdir, f"{os.path.basename(dst).split('.')[0]}_{_t.strftime('%Y%m%d-%H%M%S')}_before-restore.json"))
                if backup_id.endswith(".gz"):
                    with _gz.open(src, "rb") as fi, open(dst, "wb") as fo:
                        _sh.copyfileobj(fi, fo)
                else:
                    _sh.copy2(src, dst)
                _private_path(dst)
                if dst.startswith(os.path.realpath(PROF_DIR) + os.sep) or os.path.dirname(os.path.realpath(dst)) == os.path.realpath(PROF_DIR):
                    try: _migrate_legacy_profile(os.path.basename(dst)[:-5])
                    except Exception: pass
                E._CUSTOM_TAGS_CACHE[0] = None
                return self._s(200, json.dumps({"ok": True, "restored_to": os.path.basename(dst)}))
            except Exception as ex:
                return self._s(400, json.dumps({"ok": False, "error": str(ex)}))
        if u.path == "/api/testnotify":
            kind, name = b.get("kind", "desktop"), b.get("name", "")
            if kind == "ourpopup":
                try:
                    import wake as _wk
                    ok, msg = _wk.show_popup_now()
                    return self._s(200, json.dumps({"ok": bool(ok), "msg": "native popup requested: " + str(msg)}))
                except Exception as ex:
                    return self._s(200, json.dumps({"ok": False, "msg": f"popup error: {ex}"}))
            if kind == "desktop":
                ok = E.hq.notify_desktop("Locally4Me — test",
                                         "If you can see this, desktop notifications work.")
                if ok:
                    return self._s(200, json.dumps({"ok": True,
                        "msg": "sent — check the corner of your screen"}))
                return self._s(200, json.dumps({"ok": False, "msg":
                    "Not installed. To turn desktop popups on:\\n"
                    "1. Close the panel (Ctrl+C in the terminal)\\n"
                    "2. Run:  pip install notify-py\\n"
                    "   (Windows: py -m pip install notify-py)\\n"
                    "3. Start the panel again and press this button.\\n\\n"
                    "Without it, urgent mail is still logged and still shows in the report — "
                    "you just don't get the popup."}))
            # KOMUNIKATOR: uzyj kanalu skonfigurowanego w Outputs (Discord/Telegram/WhatsApp)
            try:
                prof = _load_profile_full(name)
            except Exception:
                return self._s(200, json.dumps({"ok": False, "msg": "pick an a-tool first (needs its channel settings)"}))
            ch = (prof.get("outputs", {}) or {}).get("report_channel", {}) or {}
            if ch.get("type", "stdout") == "stdout":
                return self._s(200, json.dumps({"ok": False,
                    "msg": "channel is 'stdout' — pick Discord/Telegram/WhatsApp in Outputs first"}))
            try:
                E.send_report(ch, "Locally4Me — test message. Your channel works.", name)
                return self._s(200, json.dumps({"ok": True, "msg": f"sent to {ch.get('type')}"}))
            except Exception as ex:
                return self._s(200, json.dumps({"ok": False, "msg": f"{ch.get('type')} failed: {ex}"}))
        if u.path == "/api/signup_save":
            try:
                import opportunities as OP
                return self._s(200, json.dumps({"ok": OP.save_signup(b.get("kit", {}))}))
            except Exception as ex:
                return self._s(200, json.dumps({"ok": False, "error": str(ex)}))
        if u.path == "/api/signup_sheet":
            try:
                import opportunities as OP
                return self._s(200, json.dumps({"ok": True,
                    "sheet": OP.signup_sheet(b.get("platform", {}))}))
            except Exception as ex:
                return self._s(200, json.dumps({"ok": False, "error": str(ex)}))
        if u.path == "/api/opp_draft":
            try:
                import opportunities as OP
                plat = b.get("platform", {})
                llm = {}
                if b.get("name"):
                    try:
                        llm = _load_profile_full(b["name"]).get("llm", {})
                    except Exception:
                        pass
                txt = OP.draft_application(plat, llm=llm, ask_llm=E.ask_llm,
                                           extra=b.get("extra", ""))
                return self._s(200, json.dumps({"ok": True, "text": txt}))
            except Exception as ex:
                return self._s(200, json.dumps({"ok": False, "error": str(ex)[:150]}))
        if u.path == "/api/opp_status":
            try:
                import opportunities as OP
                ok = OP.save_status(b.get("platform", ""), b.get("state", "not_started"),
                                    b.get("note", ""))
                return self._s(200, json.dumps({"ok": ok}))
            except Exception as ex:
                return self._s(200, json.dumps({"ok": False, "error": str(ex)}))
        if u.path == "/api/rules_save":
            ok = E.save_rules(b.get("rules", {}))
            return self._s(200, json.dumps({"ok": ok}))
        if u.path == "/api/multirun":
            # WYBOR SILNIKA: engine=classic (stare tryby) | matrix (nowa macierz).
            # Domyslnie matrix — ale classic zostaje dostepny, nie zostal usuniety.
            try:
                nm = b.get("name", "")
                prof = _load_profile_full(nm)
                which = b.get("engine", "matrix")
                if which == "classic":
                    import multirun_classic as MC
                    res = MC.run_matrix(prof,
                                        modes=b.get("modes", ["script", "ai_fast"]),
                                        flags=b.get("flags", []),
                                        no_memory=b.get("no_memory", True),
                                        log=lambda s: E.log(nm, s))
                    return self._s(200, json.dumps({"ok": True, "engine": "classic", **res}))
                import multirun as MR
                res = MR.run_matrix(prof,
                                    combo_keys=b.get("combos") or None,
                                    no_memory=b.get("no_memory", True),
                                    log=lambda s: E.log(nm, s))
                return self._s(200, json.dumps({"ok": True, "engine": "matrix", **res}))
            except Exception as ex:
                return self._s(200, json.dumps({"ok": False, "error": str(ex)[:200]}))
        if u.path == "/api/calendar_clear":
            try:
                E.hq.calendar_clear()
                return self._s(200, json.dumps({"ok": True}))
            except Exception as ex:
                return self._s(200, json.dumps({"ok": False, "error": str(ex)}))
        if u.path == "/api/wake_test":
            # Three deliberately separate tests: manager tick, selected A-Tool run, or both.
            try:
                action = str(b.get("action") or "wake")
                name = str(b.get("name") or "")
                import wake as _wk
                started, pid = _wk.ensure_background_process(with_tray=True)
                result = {"ok": bool(started), "action": action, "wake_pid": pid}
                if action in ("wake", "both"):
                    result["due_started"] = bool(_wk.run_due_once())
                if action in ("agent", "both"):
                    if not name:
                        return self._s(200, json.dumps({"ok": False, "error": "pick an a-tool first"}))
                    threading.Thread(target=lambda n=name: do_run(n, False, "user-test", None), daemon=True).start()
                    result["agent_started"] = name
                return self._s(200, json.dumps(result))
            except Exception as ex:
                return self._s(200, json.dumps({"ok": False, "error": str(ex)}))
        if u.path == "/api/wake_settings":
            try:
                import wake as _wk
                st = _wk.update_settings(b)
                return self._s(200, json.dumps({"ok": True, "wake": st}))
            except Exception as ex:
                return self._s(200, json.dumps({"ok": False, "error": str(ex)}))
        if u.path == "/api/autostart":
            # Klient wlacza/wylacza autostart z systemem JEDNYM klikiem w UI —
            # bez terminala. Deleguje do wake.install_autostart (per-OS).
            try:
                enable = bool(b.get("enable", True))
                import wake as _wk
                ok, where = _wk.install_autostart(enable=enable)
                # zapisz tez preferencje, by tray/panel byly zgodne
                try:
                    pp = os.path.join(HOME, "scheduler_prefs.json")
                    pr = json.load(open(pp)) if os.path.exists(pp) else {}
                    pr["autostart"] = enable
                    os.makedirs(os.path.dirname(pp), exist_ok=True)
                    json.dump(pr, open(pp, "w"), indent=2)
                except Exception:
                    pass
                return self._s(200, json.dumps({"ok": bool(ok), "where": str(where), "enabled": enable}))
            except Exception as ex:
                return self._s(200, json.dumps({"ok": False, "error": str(ex)}))
        if u.path == "/api/calendar_export":
            # Explicitly separate the user's main deadline calendar from the wake/scheduler calendar.
            try:
                kind = str(b.get("kind") or "main")
                if kind == "wake":
                    import wake as _wk; p = _wk.export_wake_ics()
                else:
                    p = E.hq.export_ics()
                return self._s(200, json.dumps({"ok": bool(p), "path": p or "", "kind": kind}))
            except Exception as ex:
                return self._s(200, json.dumps({"ok": False, "error": str(ex)}))
        if u.path == "/api/calendar_add":
            try:
                ok = E.hq.calendar_add(b.get("agent", "me"), b.get("kind", "note"),
                                       b.get("title", ""), when=b.get("when", ""),
                                       note=b.get("note", ""), time=b.get("time", ""),
                                       lead_days=b.get("lead_days", [1]),
                                       remind_2h=b.get("remind_2h", True))
                return self._s(200, json.dumps({"ok": ok}))
            except Exception as ex:
                return self._s(200, json.dumps({"ok": False, "error": str(ex)}))
        if u.path == "/api/tags_reset":
            # Reset custom rules: BACKUP, then clear user overrides; factory rules stay live in code.
            cp = os.path.join(HOME, "tags_custom.json")
            try:
                if os.path.exists(cp):
                    import time as _t, shutil as _sh
                    bdir = backup_dir()
                    _sh.copy2(cp, os.path.join(bdir, f"tags_custom_{_t.strftime('%Y%m%d-%H%M%S')}.json"))
                # Factory rules live in code and are always active. Reset means remove user overrides.
                json.dump([], open(cp, "w", encoding="utf-8"), ensure_ascii=False, indent=2)
                E._CUSTOM_TAGS_CACHE[0] = None      # patrz komentarz w /api/tags_save
                return self._s(200, json.dumps({"ok": True}))
            except Exception as ex:
                return self._s(200, json.dumps({"ok": False, "error": str(ex)}))
        if u.path == "/api/tags_translate_all":
            # Canonical match is immutable here. AI output lives only in match_lang.
            cp = os.path.join(HOME, "tags_custom.json")
            try:
                with open(prof_path(b.get("name", "")), encoding="utf-8") as fh:
                    prof = json.load(fh)
                llm = prof.get("llm", {})
            except Exception:
                llm = {}
            try:
                if os.path.exists(cp):
                    with open(cp, encoding="utf-8") as fh:
                        rules = json.load(fh)
                else:
                    rules = []
                if not isinstance(rules, list):
                    rules = []
                _langs = b.get("langs") or E.effective_rule_langs(prof if 'prof' in locals() else None)
                _langs = E.effective_rule_langs(settings={"rule_langs": _langs})
                regenerate = bool(b.get("regenerate"))
                checked = translated = up_to_date = stale = generated = failed = 0
                changed = False
                for r in rules:
                    if isinstance(r, dict) and r.get("match"):
                        checked += 1
                        # Sender/source identifiers and tags are canonical data, not prose.
                        # Never translate them. Also remove stale translations written by
                        # older versions so they cannot broaden a rule at runtime.
                        if str(r.get("where", "all") or "all").lower() in ("from", "source", "tag"):
                            if r.pop("match_lang", None) is not None:
                                changed = True
                            if r.pop("match_lang_meta", None) is not None:
                                changed = True
                            up_to_date += 1
                            continue
                        source_hash = E.canonical_match_hash(r["match"])
                        existing = r.get("match_lang") if isinstance(r.get("match_lang"), dict) else {}
                        existing = {str(k): list(v) for k, v in existing.items() if isinstance(v, list)}
                        meta = r.get("match_lang_meta") if isinstance(r.get("match_lang_meta"), dict) else {}
                        current = (meta.get("schema") == E.TRANSLATOR_SCHEMA and
                                   meta.get("translator_version") == E.TRANSLATOR_VERSION and
                                   meta.get("source_hash") == source_hash)
                        complete = all(existing.get(code) for code in _langs)
                        if current and complete and not regenerate:
                            up_to_date += 1
                            continue
                        if existing and not current and not regenerate:
                            stale += 1
                            if not meta.get("stale") or meta.get("current_source_hash") != source_hash:
                                meta.update({"stale": True, "current_source_hash": source_hash})
                                r["match_lang_meta"] = meta; changed = True
                            continue
                        targets = _langs if regenerate or not current else [c for c in _langs if not existing.get(c)]
                        bylang = E.expand_match_bylang(r["match"], llm, langs=tuple(targets), match_mode=r.get("match_mode", "any"))
                        made = 0
                        for code in targets:
                            vals = bylang.get(code) or []
                            if vals:
                                existing[code] = vals; made += 1; generated += 1
                            else:
                                failed += 1
                        if made:
                            translated += 1; changed = True
                            r["match_lang"] = existing
                            r["match_lang_meta"] = {
                                "schema": E.TRANSLATOR_SCHEMA, "source_hash": source_hash,
                                "translator_version": E.TRANSLATOR_VERSION,
                                "generated_at": __import__("datetime").datetime.now(
                                    __import__("datetime").timezone.utc).isoformat(timespec="seconds"),
                                "languages": [c for c in _langs if existing.get(c)],
                            }
                if changed:
                    import time as _t, shutil as _sh
                    if os.path.exists(cp):
                        _sh.copy2(cp, os.path.join(backup_dir(), f"tags_custom_{_t.strftime('%Y%m%d-%H%M%S')}.json"))
                    tmp = cp + ".tmp"
                    with open(tmp, "w", encoding="utf-8") as fh:
                        json.dump(rules, fh, ensure_ascii=False, indent=2)
                        fh.flush(); os.fsync(fh.fileno())
                    os.replace(tmp, cp)
                    E._CUSTOM_TAGS_CACHE[0] = None
                return self._s(200, json.dumps({"ok": True, "rules": checked,
                                                "translated_rules": translated,
                                                "up_to_date": up_to_date,
                                                "stale_rules": stale,
                                                "languages_generated": generated,
                                                "failed": failed}))
            except Exception as ex:
                return self._s(200, json.dumps({"ok": False, "error": str(ex)}))
        if u.path == "/api/tags_langs":
            langs = E.effective_rule_langs(settings={"rule_langs": b.get("langs") or []})
            try:
                E.update_settings({"rule_langs": langs})
                return self._s(200, json.dumps({"ok": True, "langs": langs}))
            except Exception as ex:
                return self._s(200, json.dumps({"ok": False, "error": str(ex)}))
        if u.path == "/api/rule_validate":
            rule = b.get("rule") if isinstance(b.get("rule"), dict) else {}
            result = E.validate_user_rule(rule, samples=_rule_samples(str(b.get("name") or "")),
                                          allow_broad=bool(b.get("expert_override")))
            return self._s(200, json.dumps(result, ensure_ascii=False))
        if u.path == "/api/rule_guide":
            name, mid = str(b.get("name") or ""), str(b.get("mid") or "")
            target = _rule_target_message(name, mid)
            if not target:
                return self._s(200, json.dumps({"ok": False,
                    "error": "The clicked message is not in the latest local cache. Run once, then open the rule builder again."}))
            samples = _rule_samples(name)
            return self._s(200, json.dumps({"ok": True, "message": {
                "mid": target.get("mid", ""), "from": target.get("from", ""),
                "title": target.get("title", ""), "tags": target.get("tags") or [],
                "priority": target.get("priority", "")},
                "candidates": E.guided_rule_candidates(target, samples=samples)}, ensure_ascii=False))
        if u.path == "/api/rule_suggest":
            name, mid = str(b.get("name") or ""), str(b.get("mid") or "")
            target = _rule_target_message(name, mid)
            if not target:
                return self._s(200, json.dumps({"ok": False,
                    "error": "The clicked message is not in the latest local cache. Run once before AI-assisted rule learning."}))
            try:
                prof = _load_profile_full(name)
                llm = prof.get("llm", {})
            except Exception:
                llm = {}
            result = E.ai_suggest_rule(target, b.get("correction") or {}, llm, samples=_rule_samples(name))
            return self._s(200, json.dumps(result, ensure_ascii=False))
        if u.path == "/api/factory_tags_save":
            # --d only: edit the local effective factory exact/custom rule baseline.
            # This never rewrites operational.py; Reset removes the override and
            # immediately restores the source factory defaults.
            if not DEV_UI:
                return self._s(403, json.dumps({"ok": False, "error": "developer diagnostics mode required"}))
            cp = getattr(E, "FACTORY_RULES_OVERRIDE_PATH", os.path.join(HOME, "factory_rules_override.json"))
            if b.get("reset"):
                try:
                    if os.path.exists(cp):
                        import time as _t, shutil as _sh
                        _sh.copy2(cp, os.path.join(backup_dir(), f"factory_rules_override_{_t.strftime('%Y%m%d-%H%M%S')}.json"))
                        os.remove(cp)
                    E._CUSTOM_TAGS_CACHE[0] = None
                    return self._s(200, json.dumps({"ok": True, "reset": True}))
                except Exception as ex:
                    return self._s(200, json.dumps({"ok": False, "error": str(ex)}))
            rules = b.get("rules", [])
            if not isinstance(rules, list):
                return self._s(200, json.dumps({"ok": False, "error": "rules must be a list"}))
            name = str(b.get("name") or "")
            samples = _rule_samples(name) if name else []
            clean = []
            for idx, raw in enumerate(rules):
                nr = E.normalize_user_rule(raw)
                if not nr or not nr.get("match"):
                    continue
                if not (nr.get("tag") or nr.get("min_priority") or nr.get("max_priority")
                        or nr.get("show") or nr.get("always_summary") or nr.get("never_summary")):
                    return self._s(200, json.dumps({"ok": False, "error": "factory rule has no action", "rule_index": idx}))
                vr = E.validate_user_rule(nr, samples=samples, allow_broad=True)
                if not vr.get("ok"):
                    return self._s(200, json.dumps({"ok": False, "error": "factory rule validation failed",
                                                    "rule_index": idx, "validation": vr}, ensure_ascii=False))
                clean.append(nr)
            try:
                if os.path.exists(cp):
                    import time as _t, shutil as _sh
                    _sh.copy2(cp, os.path.join(backup_dir(), f"factory_rules_override_{_t.strftime('%Y%m%d-%H%M%S')}.json"))
                with open(cp, "w", encoding="utf-8") as fh:
                    json.dump(clean, fh, ensure_ascii=False, indent=2)
                E._CUSTOM_TAGS_CACHE[0] = None
                return self._s(200, json.dumps({"ok": True, "count": len(clean)}))
            except Exception as ex:
                return self._s(200, json.dumps({"ok": False, "error": str(ex)}))
        if u.path == "/api/tags_save":
            # Zapisz reguły custom tagów (z okna edycji)
            rules = b.get("rules", [])
            name = str(b.get("name") or "")
            cp = os.path.join(HOME, "tags_custom.json")
            try:
                _old_rules = json.load(open(cp, encoding="utf-8")) if os.path.exists(cp) else []
            except Exception:
                _old_rules = []
            if not isinstance(_old_rules, list): _old_rules = []
            _old_fps = {E.rule_fingerprint(x) for x in _old_rules if isinstance(x, dict)}
            _samples = _rule_samples(name) if name else []
            # DEDUP: usun powtorzone reguly (ten sam match+where+scope+tag+priorytety).
            # Strzalki ▲▼ i „mark promo" dokladaly wpisy — bez tego lista puchla
            # (widziales zop×4, quora×6). Zachowujemy PIERWSZE wystapienie.
            _seen, _clean = set(), []
            for _idx, r in enumerate(rules):
                if not isinstance(r, dict):
                    continue
                r = E.normalize_user_rule(r)
                if not r:
                    continue
                # Do not retroactively block an untouched legacy rule. New/edited rules
                # must pass the same validator regardless of whether they came from AI,
                # the guided builder, the full editor, or a quick report action.
                if E.rule_fingerprint(r) not in _old_fps:
                    _confirmed = bool(b.get("confirm_risk") or b.get("expert_override"))
                    _vr = E.validate_user_rule(r, samples=_samples, allow_broad=_confirmed)
                    if not _vr.get("ok"):
                        return self._s(200, json.dumps({"ok": False, "error": "rule validation failed",
                            "rule_index": _idx, "validation": _vr}, ensure_ascii=False))
                    if _vr.get("requires_confirmation"):
                        return self._s(200, json.dumps({"ok": False, "needs_confirmation": True,
                            "error": "rule needs confirmation", "rule_index": _idx,
                            "validation": _vr}, ensure_ascii=False))
                _fp, _mp, _ = E._normalize_priority_bounds(
                    r.get("min_priority", ""), r.get("max_priority", "")
                )
                if _fp: r["min_priority"] = _fp
                else: r.pop("min_priority", None)
                if _mp: r["max_priority"] = _mp
                else: r.pop("max_priority", None)
                _ml = r.get("match_lang") if isinstance(r.get("match_lang"), dict) else {}
                _ml_key = tuple((str(k), tuple(str(x).lower() for x in (_ml.get(k) or [])))
                                for k in sorted(_ml))
                key = (tuple(sorted(str(x).lower() for x in (r.get("match") or []))),
                       _ml_key, r.get("where", "all"), r.get("match_mode", "any"), r.get("scope", "all"),
                       r.get("tag", ""), r.get("max_priority", ""), r.get("min_priority", ""),
                       bool(r.get("show")), bool(r.get("stop")))
                if key in _seen:
                    continue
                _seen.add(key)
                if "stop" in r: r["stop"] = bool(r.get("stop"))
                _clean.append(r)
            rules = _clean
            try:
                if os.path.exists(cp):
                    import time as _t, shutil as _sh
                    _sh.copy2(cp, os.path.join(backup_dir(), f"tags_custom_{_t.strftime('%Y%m%d-%H%M%S')}.json"))
                json.dump(rules, open(cp, "w", encoding="utf-8"),
                          ensure_ascii=False, indent=2)
                # BEZ TEGO run uzywal STARYCH regul do restartu panelu — reguly
                # sa czytane raz i trzymane w pamieci procesu.
                E._CUSTOM_TAGS_CACHE[0] = None
                return self._s(200, json.dumps({"ok": True}))
            except Exception as ex:
                return self._s(200, json.dumps({"ok": False, "error": str(ex)}))
        if u.path == "/api/rule_preview":
            # PODGLAD: ile maili z OSTATNIEGO raportu ta regula dotknie. Zero AI,
            # zero IMAP — czyta gotowy _report.json. Chroni przed regula za szeroka.
            nm = b.get("name", "")
            match = [w.strip().lower() for w in str(b.get("match", "")).split(",") if w.strip()]
            where = b.get("where", "from")
            if not match:
                return self._s(200, json.dumps({"ok": False, "error": "no match"}))
            hits, total = [], 0
            try:
                rp = os.path.join(HOME, "data", f"{nm}_report.json")
                bp = os.path.join(HOME, "data", f"{nm}_bodies.json")
                rj = json.load(open(rp, encoding="utf-8"))
                bodies = json.load(open(bp, encoding="utf-8")) if os.path.exists(bp) else {}
                preview_rule = {"match": match, "where": where, "match_mode": b.get("match_mode", "any"), "scope": "all"}
                for mb in rj.get("mailboxes", []):
                    for r in mb.get("rows", []) + mb.get("hidden_rows", []):
                        total += 1
                        cached = bodies.get(r.get("mid", ""), {}) if isinstance(bodies, dict) else {}
                        frm_raw = cached.get("from") or r.get("addr") or r.get("from", "")
                        title_raw = cached.get("title") or r.get("title", "")
                        body_raw = (cached.get("body") or "")[:400]
                        tags_raw = " ".join(str(t) for t in (r.get("tags") or []))
                        source_raw = cached.get("src") or r.get("src", "")
                        preview_msg = {"from": frm_raw, "src": source_raw, "title": title_raw,
                                       "body": body_raw, "tags": r.get("tags") or []}
                        if E.rule_matches_message(preview_rule, preview_msg):
                            hits.append({"from": r.get("from", ""), "addr": r.get("addr", ""),
                                         "title": title_raw[:70], "priority": r.get("priority", "?")})
            except Exception as ex:
                return self._s(200, json.dumps({"ok": False, "error": str(ex)[:80]}))
            by_sender = {}
            for h in hits:
                by_sender[h["from"]] = by_sender.get(h["from"], 0) + 1
            return self._s(200, json.dumps({
                "ok": True, "matched": len(hits), "scanned": total,
                "senders": sorted(by_sender.items(), key=lambda x: -x[1])[:8],
                "examples": hits[:12]}))
        if u.path == "/api/message_tags":
            # Immediate correction of tags shown for ONE message in the current report.
            # This does not silently create a future rule; the tag popover has a separate
            # explicit Save rule action for that.  Reordering is presentation-only for the
            # current report and is marked so the UI preserves the user's chosen order.
            name, mid = str(b.get("name") or ""), str(b.get("mid") or "")
            src = str(b.get("src") or "")
            raw_tags = b.get("tags") or []
            if not name or not mid or not isinstance(raw_tags, list):
                return self._s(200, json.dumps({"ok": False, "error": "name, mid and tags are required"}))
            tags, seen = [], set()
            for value in raw_tags:
                value = str(value or "").strip()[:80]
                if not value or value.startswith("💰") or (value.startswith("⏰") and value != "⏰ deadline"):
                    continue
                key = value.casefold()
                if key not in seen:
                    seen.add(key); tags.append(value)
            rp = os.path.join(DATA_DIR, f"{name}_report.json")
            try:
                data = json.load(open(rp, encoding="utf-8"))
                changed = 0
                for mb in data.get("mailboxes", []):
                    for bucket in ("rows", "hidden_rows"):
                        for row in mb.get(bucket, []) or []:
                            if str(row.get("mid") or "") != mid:
                                continue
                            if src and str(row.get("src") or mb.get("mailbox") or "") not in (src, ""):
                                continue
                            row["tags"] = tags
                            row["tag_order_manual"] = True
                            changed += 1
                if not changed:
                    return self._s(200, json.dumps({"ok": False, "error": "message not found in current report"}))
                tmp = rp + ".tmp"
                with open(tmp, "w", encoding="utf-8") as fh:
                    json.dump(data, fh, ensure_ascii=False, indent=2)
                    fh.flush(); os.fsync(fh.fileno())
                os.replace(tmp, rp)
                # Keep the body/explanation cache in step, otherwise "Why?" keeps
                # explaining the tag the user has just replaced.
                try:
                    bp = os.path.join(DATA_DIR, f"{name}_bodies.json")
                    if os.path.exists(bp):
                        bodies = json.load(open(bp, encoding="utf-8"))
                        entry = bodies.get(mid) if isinstance(bodies, dict) else None
                        if isinstance(entry, dict):
                            entry["tags"] = tags
                            entry["tag_source"] = "user"
                            btmp = bp + ".tmp"
                            with open(btmp, "w", encoding="utf-8") as fh:
                                json.dump(bodies, fh, ensure_ascii=False)
                                fh.flush(); os.fsync(fh.fileno())
                            os.replace(btmp, bp)
                except Exception:
                    pass
                return self._s(200, json.dumps({"ok": True, "changed": changed, "tags": tags}, ensure_ascii=False))
            except Exception as ex:
                return self._s(200, json.dumps({"ok": False, "error": str(ex)}))
        if u.path == "/api/tags_remove_index":
            idx = b.get("index")
            try: idx = int(idx)
            except Exception: idx = -1
            cp = os.path.join(HOME, "tags_custom.json")
            try:
                rules = json.load(open(cp, encoding="utf-8")) if os.path.exists(cp) else []
            except Exception:
                rules = []
            if not isinstance(rules, list) or idx < 0 or idx >= len(rules):
                return self._s(200, json.dumps({"ok": False, "error": "rule index not found"}))
            rules.pop(idx)
            try:
                json.dump(rules, open(cp, "w", encoding="utf-8"), ensure_ascii=False, indent=2)
                E._CUSTOM_TAGS_CACHE[0] = None
                return self._s(200, json.dumps({"ok": True, "rules": len(rules)}))
            except Exception as ex:
                return self._s(200, json.dumps({"ok": False, "error": str(ex)}))
        if u.path == "/api/tags_remove_for":
            match_val = (b.get("match") or "").strip().lower()
            mode = str(b.get("mode") or "all").strip().lower()
            where_filter = str(b.get("where") or "").strip().lower()
            if not match_val:
                return self._s(200, json.dumps({"ok": False, "error": "no match"}))
            cp = os.path.join(HOME, "tags_custom.json")
            try:
                rules = json.load(open(cp, encoding="utf-8")) if os.path.exists(cp) else []
            except Exception:
                rules = []
            if not isinstance(rules, list): rules = []
            changed = removed = 0
            out_rules = []
            for raw in rules:
                if not isinstance(raw, dict):
                    out_rules.append(raw); continue
                exact = match_val in [str(x).strip().lower() for x in (raw.get("match") or [])]
                if where_filter and str(raw.get("where", "all")).lower() != where_filter:
                    exact = False
                if not exact:
                    out_rules.append(raw); continue
                if mode == "all":
                    removed += 1; changed += 1; continue
                r = dict(raw)
                if mode == "tag":
                    if r.get("tag"):
                        r.pop("tag", None); changed += 1
                elif mode == "hide":
                    # Hide is still the existing combination of promo tag + P5 ceiling; no new field.
                    if str(r.get("tag", "")).strip().lower() in ("🏷 promo", "promo", "🏷 ads", "ads"):
                        r.pop("tag", None); changed += 1
                    if str(r.get("max_priority", "")).upper() == "P5":
                        r.pop("max_priority", None); changed += 1
                if not (r.get("tag") or r.get("max_priority") or r.get("min_priority") or r.get("show")):
                    removed += 1
                else:
                    out_rules.append(r)
            try:
                json.dump(out_rules, open(cp, "w", encoding="utf-8"), ensure_ascii=False, indent=2)
                E._CUSTOM_TAGS_CACHE[0] = None
                return self._s(200, json.dumps({"ok": True, "removed": removed, "changed": changed, "mode": mode}))
            except Exception as ex:
                return self._s(200, json.dumps({"ok": False, "error": str(ex)}))
        if u.path == "/api/tag_rule":
            # Interaktywna korekta tagu Z WIADOMOSCI: dopisz regule per-nadawca LUB per-slowo.
            # match_on: "from" (nadawca) | "subject" (slowo z tematu). tag: nowy tag.
            match_val, match_on = b.get("match", ""), b.get("match_on", "from")
            mp = str(b.get("max_priority", "") or "").strip().upper()
            fp = str(b.get("min_priority", "") or "").strip().upper()
            scope = str(b.get("scope", "all") or "all")
            where = match_on if match_on in ("from", "source", "subject", "body", "tag", "all") else "subject"
            if not match_val:
                return self._s(200, json.dumps({"ok": False, "error": "brak match"}))
            cp = os.path.join(HOME, "tags_custom.json")
            try:
                rules = json.load(open(cp, encoding="utf-8")) if os.path.exists(cp) else []
            except Exception:
                rules = []
            # Preserve the canonical spelling/case entered by the user (important for
            # names/identifiers and translation protection). Matching/merge keys remain
            # case-insensitive through the engine normalizer.
            if isinstance(match_val, list):
                _match = [str(x).strip() for x in match_val if str(x).strip()]
            else:
                _match = [x.strip() for x in str(match_val).split(",") if x.strip()]
            if not _match:
                return self._s(200, json.dumps({"ok": False, "error": "brak match"}))
            def _quick_rule_key(r):
                return (tuple(E._norm(str(x)) for x in (r.get("match") or [])),
                        str(r.get("where", "all") or "all").lower(),
                        str(r.get("match_mode", "any") or "any").lower(),
                        str(r.get("scope", "all") or "all").lower())
            _mode = "all" if str(b.get("match_mode", "any")).lower() == "all" else "any"
            _mk = (tuple(E._norm(x) for x in _match), where.lower(), _mode, scope.lower())
            try:
                _replace_index = int(b.get("replace_index")) if b.get("replace_index") is not None else -1
            except Exception:
                _replace_index = -1
            _replace_index = _replace_index if 0 <= _replace_index < len(rules) else -1
            if _replace_index >= 0 and isinstance(rules[_replace_index], dict):
                existing = rules[_replace_index]
            else:
                existing = next((r for r in rules if isinstance(r, dict) and _quick_rule_key(r) == _mk), {})
            # Merge instead of rebuilding: editing a rule must preserve metadata not shown
            # by the compact builder. replace_index allows the condition itself to change
            # without leaving the old rule behind.
            rule = dict(existing) if isinstance(existing, dict) else {}
            rule.update({"match": _match, "where": where, "scope": scope})
            if "tag" in b:
                tag = str(b.get("tag", "") or "").strip()[:40]
                if tag: rule["tag"] = tag
                else: rule.pop("tag", None)
            if "show" in b:
                rule["show"] = bool(b.get("show"))
            if "stop" in b:
                rule["stop"] = bool(b.get("stop"))
            # "always / never summarize" is a rule action of its own, bound to a
            # sender, a tag or a keyword like every other action — not a priority hack.
            for _k in ("always_summary", "never_summary"):
                if _k in b:
                    if bool(b.get(_k)): rule[_k] = True
                    else: rule.pop(_k, None)
            if rule.get("always_summary") and rule.get("never_summary"):
                rule.pop("always_summary", None)
            if "max_priority" in b:
                if mp in ("P1!", "P1", "P2", "P3", "P4", "P5"): rule["max_priority"] = mp
                else: rule.pop("max_priority", None)
            if "min_priority" in b:
                if fp in ("P1!", "P1", "P2", "P3", "P4", "P5"): rule["min_priority"] = fp
                else: rule.pop("min_priority", None)
            _fp, _mp, _ = E._normalize_priority_bounds(
                rule.get("min_priority", ""), rule.get("max_priority", "")
            )
            if _fp: rule["min_priority"] = _fp
            else: rule.pop("min_priority", None)
            if _mp: rule["max_priority"] = _mp
            else: rule.pop("max_priority", None)
            if not (rule.get("tag") or rule.get("max_priority") or rule.get("min_priority")
                    or rule.get("show") or rule.get("always_summary") or rule.get("never_summary")):
                return self._s(200, json.dumps({"ok": False, "error": "regula nie ma zadnej akcji"}))
            rule["match_mode"] = _mode
            _confirmed = bool(b.get("confirm_risk") or b.get("expert_override"))
            _vr = E.validate_user_rule(rule, samples=_rule_samples(str(b.get("name") or "")),
                                       allow_broad=_confirmed)
            if not _vr.get("ok"):
                return self._s(200, json.dumps({"ok": False, "error": "rule validation failed",
                                                "validation": _vr}, ensure_ascii=False))
            if _vr.get("requires_confirmation"):
                return self._s(200, json.dumps({"ok": False, "needs_confirmation": True,
                                                "error": "rule needs confirmation",
                                                "validation": _vr}, ensure_ascii=False))
            rule = _vr.get("rule") or rule
            translated_count = 0
            if bool(b.get("translate")) and rule.get("where") not in ("from", "source", "tag"):
                try:
                    name = str(b.get("name") or "")
                    prof = _load_profile_full(name) if name else {}
                    llm = prof.get("llm", {}) if isinstance(prof, dict) else {}
                    langs = E.effective_rule_langs(prof if isinstance(prof, dict) else None)
                    bylang = E.expand_match_bylang(rule.get("match") or [], llm, langs=tuple(langs), match_mode=rule.get("match_mode", "any"))
                    if bylang:
                        rule["match_lang"] = bylang
                        rule["match_lang_meta"] = {
                            "schema": E.TRANSLATOR_SCHEMA,
                            "source_hash": E.canonical_match_hash(rule.get("match") or []),
                            "translator_version": E.TRANSLATOR_VERSION,
                            "generated_at": __import__("datetime").datetime.now(
                                __import__("datetime").timezone.utc).isoformat(timespec="seconds"),
                            "languages": sorted(bylang),
                        }
                        translated_count = len(bylang)
                except Exception:
                    translated_count = 0
            # Preserve file-order precedence. Editing by index replaces that exact rule
            # even if its match/where changed; a genuinely new rule appends.  Remove any
            # duplicate with the NEW key so an edit cannot accidentally create two copies.
            old_index = _replace_index if _replace_index >= 0 else next((i for i,r in enumerate(rules)
                              if isinstance(r, dict) and _quick_rule_key(r) == _mk), None)
            kept = []
            for i, r in enumerate(rules):
                if old_index is not None and i == old_index:
                    continue
                if isinstance(r, dict) and _quick_rule_key(r) == _mk:
                    continue
                kept.append(r)
            rules = kept
            if old_index is None or old_index >= len(rules):
                rules.append(rule); _saved_index = len(rules) - 1
            else:
                rules.insert(old_index, rule); _saved_index = old_index
            try:
                json.dump(rules, open(cp, "w", encoding="utf-8"), ensure_ascii=False, indent=2)
                try:
                    E._CUSTOM_TAGS_CACHE[0] = None      # cache musi zobaczyc nowa regule
                except Exception:
                    pass
                return self._s(200, json.dumps({"ok": True, "rules": len(rules),
                                                "index": _saved_index,
                                                "translated": translated_count}))
            except Exception as ex:
                return self._s(200, json.dumps({"ok": False, "error": str(ex)}))
        if u.path == "/api/autoconfig":
            import autoconfig as AC
            txt = b.get("text", "")
            links = b.get("links", "")
            files = b.get("files", "")
            uploads = b.get("uploads", [])      # [{'name','b64'}] — wgrane pliki PDF/DOCX/ODT/TXT
            # Linki i wgrane pliki NIE sa doklejane jako goly tekst — fetch_materials
            # je POBIERA/PARSUJE (i w AI, i w skrypcie). Dzieki temu _sources mowi
            # prawde w obu trybach: co realnie wczytano, a co nie.
            use_ai, name = b.get("ai", False), b.get("name", "")
            if use_ai and name:
                try:
                    prof = _load_profile_full(name)
                    sug = AC.ai_suggest(txt, prof.get("llm", {}), E.ask_llm,
                                        links=links, files_text=files, uploads=uploads,
                                        log=lambda m: E.log(name, m)) \
                          or AC.script_suggest(txt, links=links, files_text=files,
                                               uploads=uploads, log=lambda m: E.log(name, m))
                except Exception:
                    sug = AC.script_suggest(txt, links=links, files_text=files, uploads=uploads)
            else:
                sug = AC.script_suggest(txt, links=links, files_text=files, uploads=uploads)
            return self._s(200, json.dumps({"suggestion": sug}))
        if u.path == "/api/autoapply":
            import autoconfig as AC
            name, sug, fields = b.get("name", ""), b.get("suggestion", {}), b.get("fields")
            ok, backup, applied = AC.apply_suggestion(name, sug, fields)
            return self._s(200, json.dumps({"ok": ok, "backup": backup, "applied": applied}))
        if u.path == "/api/mailaction":
            # Akcja na żądanie dla JEDNEGO maila: 'summary' lub 'draft' (interaktywny raport A7)
            name, mid, src, kind = b.get("name"), b.get("mid"), b.get("src"), b.get("kind", "summary")
            variant = int(b.get("variant", 0) or 0)
            try:
                prof = _load_profile_full(name)
            except Exception:
                return self._s(200, json.dumps({"result": "(agent not found)"}))
            # znajdź mail w ostatnim raporcie (cache treści) lub pobierz świeżo z IMAP
            try:
                res = E.mail_action_single(prof, src, mid, kind, variant=variant)
            except Exception as ex:
                res = f"(error: {ex})"
            return self._s(200, json.dumps({"result": res}))
        if u.path == "/api/test_imap":
            host = (b.get("imap") or "").strip()
            user = (b.get("user") or "").strip()
            pw   = (b.get("pass") or "").strip()
            if not host or not user or not pw:
                return self._s(200, json.dumps({"ok": False, "error": "host, user and password are required"}))
            try:
                import imaplib
                M = imaplib.IMAP4_SSL(host, timeout=15)
                M.login(user, pw)
                M.logout()
                return self._s(200, json.dumps({"ok": True}))
            except Exception as ex:
                es = str(ex)
                hint = ""
                if "AUTHENTICATIONFAILED" in es or "auth" in es.lower():
                    if "gmail" in host.lower():
                        hint = "Gmail needs a 16-character App Password (Google Account > Security > App passwords), not your normal password."
                    elif "o2" in host.lower():
                        hint = "o2.pl: use your login WITHOUT @o2.pl."
                    elif "privateemail" in host.lower():
                        hint = "Use the mailbox password, not your Namecheap account password."
                    else:
                        hint = "Check username and password."
                elif "getaddrinfo" in es.lower() or "name or service" in es.lower():
                    hint = "Cannot reach server — check the host name."
                elif "timed out" in es.lower() or "timeout" in es.lower():
                    hint = "Connection timed out — server may be down or blocked."
                return self._s(200, json.dumps({"ok": False, "error": es[:200], "hint": hint}))
        if u.path == "/api/test_feed":
            feed = b.get("feed") if isinstance(b.get("feed"), dict) else {}
            url = str(feed.get("url") or "").strip()
            if not url:
                return self._s(200, json.dumps({"ok": False, "error": "feed URL is required"}))
            try:
                items = E.read_feed(url, min(10, max(1, int(feed.get("max_items") or 5))), "feed-test")
                samples = [{"title": str((x or {}).get("title") or "")[:240]}
                           for x in (items or [])[:3] if isinstance(x, dict)]
                return self._s(200, json.dumps({"ok": True, "count": len(items or []), "samples": samples},
                                               ensure_ascii=False))
            except Exception as ex:
                return self._s(200, json.dumps({"ok": False, "error": str(ex)[:300]}, ensure_ascii=False))
        if u.path == "/api/testllm":
            llm = b.get("llm", {})
            _sent_sentinel = bool(isinstance(llm, dict) and llm.get("api_key") == _SECRET_SENTINEL)
            _profile_named = bool(str(b.get("name") or "").strip())
            if _sent_sentinel:
                try:
                    nm = _safe_agent_name(b.get("name") or "")
                    saved = _load_profile_full(nm) if nm else {}
                    llm = _restore_secret_sentinels(saved.get("llm") or {}, llm)
                except Exception:
                    llm = dict(llm); llm["api_key"] = ""
            if not isinstance(llm, dict):
                llm = {}
            _prov = str(llm.get("provider") or "").lower()
            _key_now = str(llm.get("api_key") or "").strip()
            if not _key_now and _prov != "ollama":
                # NOT a provider rejection. Say which of the two situations it is.
                if _sent_sentinel and not _profile_named:
                    _msg = ("the saved key could not be read: this check did not say which "
                            "A-Tool profile to read it from")
                elif _sent_sentinel:
                    _msg = "no key is stored in this A-Tool profile"
                else:
                    _msg = "no key was entered"
                return self._s(200, json.dumps({
                    "ok": False, "code": "NO_KEY", "result": _msg,
                    "debug": {"provider": llm.get("provider"), "model": llm.get("model"),
                              "base_url": llm.get("base_url", ""), "key_present": False},
                    "hint": "Paste the key in the LLM/Keys tab and SAVE the A-Tool, then test again."},
                    ensure_ascii=False))
            E.OFFLINE = False
            base = llm.get("base_url", "")
            dbg = {"provider": llm.get("provider"), "model": llm.get("model"),
                   "base_url": base, "key_present": bool((llm.get("api_key") or "").strip())}
            try:
                r = E.ask_llm("Reply with exactly: OK", llm, max_tokens=16)
            except Exception as ex:
                r = f"[error: {ex}]"
            ok = not E._llm_failed(r)
            _meta = dict(getattr(E, "LAST_LLM_META", {}) or {})
            dbg["finish_reason"] = _meta.get("finish_reason")
            dbg["remaining_tokens"] = _meta.get("remaining_tokens")
            # podpowiedzi diagnostyczne
            hint = ""
            if not dbg["key_present"]:
                hint = "Brak klucza w polu api_key."
            elif "x.ai" in base and (llm.get("api_key") or "").startswith("gsk_"):
                hint = "Klucz gsk_ (Groq) + base_url x.ai — niezgodne. Zmien base_url na https://api.groq.com/openai/v1"
            elif "403" in r:
                hint = "403 = klucz odrzucony. Utworz nowy pelny klucz na console.groq.com i sprawdz base_url."
            elif "401" in r:
                hint = "401 = nieprawidlowy klucz."
            return self._s(200, json.dumps({"ok": ok, "code": "OK" if ok else "PROVIDER",
                                            "result": r[:300], "debug": dbg, "hint": hint},
                                           ensure_ascii=False))
        if u.path == "/api/context":
            try:
                open(E.USER_CONTEXT_PATH, "w", encoding="utf-8").write(b.get("text", ""))
                return self._s(200, json.dumps({"ok": True}))
            except Exception as ex:
                return self._s(200, json.dumps({"ok": False, "msg": str(ex)}))
        if u.path == "/api/settings":
            try:
                merged = E.update_settings(b)
                return self._s(200, json.dumps({"ok": True, "settings": merged}))
            except Exception as ex:
                return self._s(200, json.dumps({"ok": False, "msg": str(ex)}))
        if u.path == "/api/resetseen":
            try:
                nm = _safe_agent_name(b.get("name", ""))
            except Exception:
                nm = ""
            if not nm:
                return self._s(200, json.dumps({"ok": False, "msg": "no A-Tool name"}))
            try:
                cleared = 0
                p = os.path.join(DATA_DIR, f"{nm}_seen.json")
                if os.path.exists(p):
                    try: cleared = len(json.load(open(p, encoding="utf-8")) or [])
                    except Exception: cleared = 0
                    os.remove(p)
                # The pending-AI queue holds message ids from the state we just
                # dropped. Leaving it behind makes the next run look stuck.
                queued = 0
                try:
                    import hq as _hq
                    queued = len(_hq.overflow_load(nm) or [])
                    _hq.overflow_save(nm, [])
                except Exception:
                    pass
                return self._s(200, json.dumps({"ok": True, "cleared": cleared, "queued_cleared": queued}))
            except Exception as ex:
                return self._s(200, json.dumps({"ok": False, "msg": str(ex)}))
        if u.path == "/api/delete":
            nm = _safe_agent_name(b.get("name", ""))
            p = prof_path(nm)
            if os.path.exists(p): os.remove(p)
            SS.delete(nm)
            try:
                import atool_sync as _as
                _as.unpublish_schedule(nm)
            except Exception:
                pass
            return self._s(200, json.dumps({"ok": True}))
        return self._s(404, "{}")


# ── USUNIETY WBUDOWANY FALLBACK UI ──────────────────────────────────────────
# Stary inline UI (kopie funkcji JS) rozjezdzal sie z ui-frame.js i powodowal ciche
# bledy. Usuniety; zarchiwizowany w _archiwum/panel_inline_UI_fallback.txt.
# Zrodlo prawdy UI: ui-reporter.html + ui-frame.css + ui-frame.js (obok panel.py).
UI = None  # brak wbudowanego fallbacku — pliki UI sa wymagane

# Security migration is intentionally local and silent: it never asks for sudo/pkexec.
# A failed vault write leaves the legacy profile untouched rather than losing credentials.
try:
    for _a in list_agents():
        if _a.get("name"):
            _migrate_legacy_profile(_a["name"])
            try: SS.promote_private_fallback(_a["name"])
            except Exception: pass
    _sanitize_legacy_backups()
except Exception:
    pass

def _lan_ip():
    import socket
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80)); ip = s.getsockname()[0]; s.close(); return ip
    except Exception:
        return None


def _autostart_check():
    """Honoruje NIEZALEŻNE opcje schedule (mogą łączyć się):
    run_on_start (odpal raz teraz), scheduled (APScheduler o godzinach),
    catchup (run missed slot), background (scheduler stays active)."""
    import time as _t
    _sched_log("=== autostart start ===")
    try:
        import scheduler as _sch
    except Exception as e:
        _sched_log(f"scheduler import error: {e} — scheduler NOT running", force=True)
        return
    sched_started = False
    try:
        try:
            import wake as _wake_owner
            wake_owns_schedule = bool((_wake_owner.status() or {}).get("running"))
        except Exception:
            wake_owns_schedule = False
        agents = list_agents()
        _names = [a.get("name") if isinstance(a, dict) else a for a in agents]
        _names = [n for n in _names if n]
        _sched_log(f"agents to check: {len(_names)} ({', '.join(_names) or 'none'})")
        for name in _names:
            try:
                prof = json.load(open(prof_path(name), encoding="utf-8"))
            except Exception as e:
                _sched_log(f"'{name}': cannot load profile: {e}")
                continue
            sch = (prof or {}).get("schedule", {})
            if not sch:
                _sched_log(f"'{name}': no schedule section in profile — skipping")
                continue
            if "scheduled" not in sch and sch.get("mode"):
                sch = dict(sch, scheduled=(sch["mode"] == "schedule"),
                           catchup=(sch["mode"] == "autostart"))
            windows = sch.get("windows") or ["08:00", "18:00"]
            feed_windows = E.feed_schedule_windows(prof) if hasattr(E, "feed_schedule_windows") else []
            wake_windows = list(dict.fromkeys((windows if sch.get("scheduled") else []) + feed_windows))
            _sched_log(f"'{name}': options = run_on_start={sch.get('run_on_start')}, "
                       f"scheduled={sch.get('scheduled')}, catchup={sch.get('catchup')}, "
                       f"background={sch.get('background')}, windows={windows}")

            # Publish on every start so Wake reflects the A-Tool UI even if there are
            # no recurring slots. Saves publish immediately too.
            try:
                _pub = publish_profile_schedule(name, prof)
                _sched_log(f"'{name}': full schedule published to Wake (runs={_pub['runs']}, feed={_pub['feed_runs']})")
            except Exception as _e:
                _sched_log(f"'{name}': publish schedule skipped: {_e}")

            # SCHEDULED — Wake owns recurring execution. APScheduler is a fallback
            # only when the system Wake manager is unavailable.
            if sch.get("scheduled") or feed_windows or sch.get("once_date"):
                # APScheduler is only a compatibility fallback. The one Wake
                # manager normally owns all recurring schedules to prevent doubles.
                if wake_owns_schedule:
                    _sched_log(f"'{name}': recurring execution owned by Wake; APScheduler mirror not started")
                else:
                    try:
                        if wake_windows and _sch.schedule_agent(name, lambda n=name: do_scheduled_run(n), times=wake_windows,
                                               func_ref="panel:do_scheduled_run", func_args=[name]):
                            sched_started = True
                            try:
                                _persist = " (persistent)" if _sch.persistent() else " (in-memory)"
                            except Exception:
                                _persist = ""
                            _sched_log(f"'{name}': fallback APScheduler at {', '.join(wake_windows)}{_persist}")
                        elif wake_windows:
                            _sched_log(f"'{name}': fallback schedule_agent returned false")
                    except Exception as e:
                        _sched_log(f"'{name}': fallback APScheduler error: {e}")

            # RUN-TERAZ: on-start (z dlawikiem antypowtorkowym), albo catch-up gdy minal slot.
            # W OSOBNYM try — niezalezne od scheduled, zeby zawsze dzialalo.
            try:
                run_now = False
                last_f = os.path.join(DATA_DIR, f"{name}_lastrun.txt")
                last = 0
                if os.path.exists(last_f):
                    try: last = float(open(last_f).read().strip() or "0")
                    except Exception: last = 0
                if sch.get("run_on_start"):
                    if wake_owns_schedule:
                        # run_on_start means BOTH a new persistent Wake/OS session and
                        # an actual A-Tool panel start.  The central Wake owns execution
                        # in both cases and applies the same anti-duplicate guard.
                        try:
                            import wake as _wake_panel_start
                            _tool_id = (json.load(open(_atool_json_path(), encoding="utf-8")) or {}).get("id", "this")
                            _queued = _wake_panel_start.request_panel_start(_tool_id, name)
                            _sched_log(f"'{name}': RUN-ON-START panel event -> Wake ({'queued' if _queued else 'not queued'})")
                        except Exception as _e:
                            _sched_log(f"'{name}': RUN-ON-START panel event failed: {_e}")
                    else:
                        guard_min = float(sch.get("run_on_start_min", 5) or 5)
                        if last and _t.time() - last < guard_min * 60:
                            _sched_log(f"'{name}': RUN-ON-START pominiety (ostatni run {int((_t.time()-last)/60)} min temu < {guard_min:g} min)")
                        else:
                            run_now = True
                            _sched_log(f"'{name}': fallback RUN-ON-START -> running now")
                elif (not wake_owns_schedule) and sch.get("catchup", True) and (sch.get("scheduled") or feed_windows):
                    per_day = max(1, int(sch.get("times_per_day", 1) or 1))
                    if last and _t.time() - last >= 86400 / per_day:
                        run_now = True
                        _sched_log(f"'{name}': CATCH-UP (missed slot) -> running")
                    else:
                        _sched_log(f"'{name}': catch-up not needed (last run recent)")
                if run_now:
                    threading.Thread(target=lambda n=name: do_run(n, False), daemon=True).start()
                    _sched_log(f"'{name}': run thread started")
            except Exception as e:
                _sched_log(f"'{name}': run-now error: {e}")

            if sch.get("background") and not wake_owns_schedule:
                sched_started = True
                _sched_log(f"'{name}': background ON — fallback scheduler stays active")
        if sched_started:
            _sch.start()
            _sched_log("scheduler RUNNING in background", force=True)
        else:
            _sched_log("scheduler NOT started (no option required it)")
    except Exception as e:
        import traceback
        _sched_log(f"CRITICAL autostart error: {e}")
        _sched_log(traceback.format_exc())

def _daemon_timer(delay, fn):
    """Start a Timer that never blocks interpreter shutdown / Ctrl+C."""
    t = threading.Timer(delay, fn)
    t.daemon = True
    t.start()
    return t


class _PanelHTTPServer(ThreadingHTTPServer):
    daemon_threads = True
    block_on_close = False


def main():
    import time as _t0mod
    _boot = _t0mod.time()
    def _boot_ms(label):
        if DIAGNOSTICS:
            print(f"  [boot] {label}: {(_t0mod.time()-_boot)*1000:.0f}ms")
    try:
        import system_setup as _ss
        _dep = _ss.first_run_preflight(auto_install=not UI_PREVIEW, include_system=not UI_PREVIEW)
        if _dep.get("changed"):
            _boot_ms("dependency preflight/install")
    except Exception as _de:
        print(f"  [Setup] dependency preflight failed: {_de}")

    # UI preview runs on a disposable data clone. It never registers a second
    # communication_1, publishes schedules or starts another Wake.
    if not UI_PREVIEW:
        try:
            import atool_sync
            _rdy = atool_sync.ensure_ready()
            if DIAGNOSTICS and _rdy.get("created"):
                print(f"  [Ecosystem] created: {', '.join(_rdy['created'])}")
            if DIAGNOSTICS:
                for _n in _rdy.get("notes", []): print(f"  [Ecosystem] {_n}")
            atool_sync.register_in_ecosystem()
            _boot_ms("ecosystem ready")
            try:
                import l4m_popup
                _pr = atool_sync.maybe_show_popup(l4m_popup)
                if DIAGNOSTICS: print(f"  [popup] release registered with Wake: {'ok' if _pr else 'failed'}")
            except Exception as _pe:
                if DIAGNOSTICS: print(f"  [popup] registration failed: {_pe}")
            try:
                import wake as _wk
                ok, pid = _wk.ensure_background_process(with_tray=True)
                if DIAGNOSTICS: print(f"  [wake] background {'ready' if ok else 'failed'}: {pid}")
            except Exception as _we:
                if DIAGNOSTICS: print(f"  [wake] background start failed: {_we}")
        except Exception as e:
            if DIAGNOSTICS:
                print(f"  [Ecosystem] not active: {e}")
    else:
        print("  UI PREVIEW: disposable data copy; Wake/Scheduler publication disabled")

    global PORT
    srv = None
    for cand in [PORT, PORT + 1, PORT + 2, PORT + 3, 0]:
        try:
            srv = _PanelHTTPServer((("0.0.0.0" if LAN_MODE else "127.0.0.1"), cand), H); PORT = srv.server_address[1]; break
        except OSError as e:
            if e.errno in (98, 48):
                print(f"  Port {cand} busy (another panel already running?) — trying next...")
                continue
            raise
    if srv is None:
        print("  Could not bind a port. Close the other panel (Ctrl+C) and retry."); return
    ip = _lan_ip() if LAN_MODE else None
    if DIAGNOSTICS:
        _ui = _ui_asset_info()
        print(f"  [ui] source={os.path.join(HERE, 'ui-frame.js')} · build={_ui.get('token','?')} · lines={_ui.get('lines',0)} · ok={_ui.get('ok',False)}")
    print(f"\n  PANEL  ->  http://localhost:{PORT}")
    if ip:
        print(f"  PHONE  ->  http://{ip}:{PORT}/?token={LAN_TOKEN}   (private same-Wi-Fi link; --lan)")
    else:
        print("  PHONE  ->  off (safer default; start with --lan only when you need same-Wi-Fi access)")
    print(f"  Data:  {E.HOME}")
    print("  Everything is configured in the browser. Press Ctrl+C to stop.\n")
    if not NO_OPEN:
        try:
            import webbrowser
            _daemon_timer(1.0, lambda: webbrowser.open(f"http://localhost:{PORT}"))
        except Exception:
            pass
    if not UI_PREVIEW:
        _daemon_timer(2.0, _autostart_check)
    # Tray/background is owned by standalone wake.py; main() ensured it above.
    # PRZYPOMNIENIA przy starcie: pokaz nadchodzace deadline'y (dzis/jutro) od razu,
    # zeby user widzial je nawet gdy nie bylo runu w tle.
    def _startup_reminders():
        try:
            n = E.hq.calendar_notify_due(days_before=1)
            if n:
                print(f"  [reminders] {n} upcoming deadline(s) — desktop notification sent")
        except Exception:
            pass
    _daemon_timer(3.0, _startup_reminders)
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print("\n  Stopped.")
    finally:
        try:
            srv.shutdown()
        except Exception:
            pass
        try:
            srv.server_close()
        except Exception:
            pass


if __name__ == "__main__":
    main()
