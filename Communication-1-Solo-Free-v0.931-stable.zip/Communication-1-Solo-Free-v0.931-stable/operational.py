# ============================================================================
#  operational.py  —  SŁOWNIKI, TAGI, STAŁE KLASYFIKACJI, PRESETY
# ============================================================================
# file-version: 0.930 | engine: 0.930 | updated: 2026-09-04
#  TU EDYTUJESZ (laik/ekspert): słowa-klucze, tagi, presety agentów.
#  Zmiana tutaj = zmiana zachowania klasyfikacji BEZ dotykania logiki w engine.py.
#
#  ZASADY (żeby nie zepsuć):
#  - Słowa-klucze pisz MAŁYMI literami, BEZ polskich ogonków (ą→a, ł→l, ż→z).
#    Silnik normalizuje maile tak samo, więc "platnosc" złapie "płatność".
#  - Tagi mają mówić KONKRETNĄ rzecz ("💸 payment due"), nie kategorię ("bank").
#  - PRESETS na końcu = szablony agentów (Reporter, Grant Watcher itd.).
#
#  Importowane przez engine.py: `from operational import *`
# ============================================================================

import os
HOME = os.path.expanduser(os.environ.get("ENGINE_HOME", "~/agentsystem"))

# Ścieżka pliku z Twoimi własnymi tagami (edytowalny JSON, tworzony automatycznie)
CUSTOM_TAGS_PATH = os.path.join(HOME, "tags_custom.json")

# Centralny rejestr SEMANTYCZNYCH tagow.
#
# Zasada architektury: canonical tag jest STABILNY i zawsze po EN / w jednym
# identyfikatorze niezaleznie od jezyka wiadomosci. Wielojezyczne sa tylko
# sygnaly/evidence rozpoznania. Priorytet i widocznosc nie sa wyprowadzane
# z przypadkowego fragmentu nazwy taga (np. slowa "spam" albo "newsletter"),
# lecz z tej jawnej polityki. Dzięki temu dodanie nowego taga nie zmienia
# przypadkiem HIDDEN/P bez testu i wpisu tutaj.
#
# visibility:
#   normal  -> nie wymusza ani pokazania, ani ukrycia; decyduje kategoria/reguly
#   visible -> ten semantyczny typ ma byc domyslnie widoczny mimo kategorii noise
#   hidden  -> domyslnie trafia do HIDDEN, chyba ze user jawnie go odchowa
#
# detector to dokumentacyjny kontrakt: gdzie zyje detekcja. Nie jest wykonywany
# dynamicznie; pozwala testom i przyszlym refactorom objac KAZDY fabryczny tag.
TAG_POLICY = {
    "⚠ suspicious":              {"visibility": "visible", "detector": "classifier"},
    "‼ debt":                    {"visibility": "normal",  "detector": "transaction_state"},
    "‼ debt: bailiff":           {"visibility": "normal",  "detector": "transaction_state"},
    "‼ debt: collection":        {"visibility": "normal",  "detector": "transaction_state"},
    "↩ refund/dispute":          {"visibility": "normal",  "detector": "transaction_state"},
    "✅ paid":                    {"visibility": "normal",  "detector": "transaction_state", "default_priority": "P3", "facet": "transaction_state", "specificity": 98},
    "💸 payment due":            {"visibility": "normal",  "detector": "transaction_state", "default_priority": "P2", "facet": "transaction_state", "specificity": 98},
    "🧾 invoice":                {"visibility": "normal",  "detector": "transaction_state", "default_priority": "P2", "facet": "transaction_state", "specificity": 92},
    "📊 statement":              {"visibility": "normal",  "detector": "transaction_state", "default_priority": "P3", "facet": "transaction_state", "specificity": 84},
    "🛡 insurance":               {"visibility": "normal",  "detector": "semantic_keywords"},
    "🏦 loan":                    {"visibility": "normal",  "detector": "semantic_keywords"},
    "🏦 bank":                    {"visibility": "normal",  "detector": "classifier"},
    "💳 transaction":            {"visibility": "normal",  "detector": "transaction_state", "default_priority": "P3", "facet": "transaction_state", "specificity": 84},
    "📦 order":                  {"visibility": "visible", "detector": "transaction_state", "default_priority": "P3", "facet": "commerce_state", "specificity": 88},
    "📦 shipment":               {"visibility": "visible", "detector": "semantic_keywords", "default_priority": "P3", "facet": "commerce_state", "specificity": 96},
    "🏦 financial notice":       {"visibility": "normal",  "detector": "classifier", "default_priority": "P3", "facet": "financial_context", "specificity": 25, "fallback": True},
    # Secondary information for a generic financial notice. These do not change
    # priority by themselves; they explain what kind of financial change/value it is.
    "🏷 discount":                {"visibility": "normal",  "detector": "financial_detail", "facet": "financial_detail", "specificity": 78},
    "🎁 bonus":                   {"visibility": "normal",  "detector": "financial_detail", "facet": "financial_detail", "specificity": 78},
    "💵 cashback":                {"visibility": "normal",  "detector": "financial_detail", "facet": "financial_detail", "specificity": 82},
    "🎁 freebie":                 {"visibility": "normal",  "detector": "financial_detail", "facet": "financial_detail", "specificity": 76},
    "💸 fee":                     {"visibility": "normal",  "detector": "financial_detail", "facet": "financial_detail", "specificity": 82},
    "📈 price increase":          {"visibility": "normal",  "detector": "financial_detail", "facet": "financial_detail", "specificity": 86},
    "⚖ court":                   {"visibility": "normal",  "detector": "institution"},
    "⚖ lawyer":                  {"visibility": "normal",  "detector": "institution"},
    "⚖ prosecutor":              {"visibility": "normal",  "detector": "institution"},
    "🚓 police":                 {"visibility": "normal",  "detector": "institution"},
    "🏛 authority":              {"visibility": "normal",  "detector": "institution"},
    "🏛 tax office":             {"visibility": "normal",  "detector": "institution"},
    "🪖 military":               {"visibility": "normal",  "detector": "institution"},
    "✍ contract":                {"visibility": "normal",  "detector": "semantic_keywords", "default_priority": "P3", "facet": "topic", "specificity": 74},
    "⏰ deadline":               {"visibility": "normal",  "detector": "deadline"},
    "📅 appointment":            {"visibility": "normal",  "detector": "semantic_keywords"},
    "📅 interview":              {"visibility": "normal",  "detector": "semantic_keywords"},
    "🎓 study/academic":         {"visibility": "normal",  "detector": "semantic_keywords"},
    "⭐ feedback request":        {"visibility": "normal",  "detector": "semantic_keywords", "default_priority": "P4", "facet": "message_intent", "specificity": 88},
    "❓ question":                {"visibility": "normal",  "detector": "semantic_keywords"},
    "✅ application accepted":    {"visibility": "visible", "detector": "semantic_keywords", "default_priority": "P3"},
    "⚠ new device":              {"visibility": "visible", "detector": "security"},
    "⚠ password reset":          {"visibility": "visible", "detector": "security"},
    "⚠ new sign-in":             {"visibility": "visible", "detector": "security"},
    "⚠ verification":            {"visibility": "visible", "detector": "security"},
    "⚠ account":                 {"visibility": "visible", "detector": "security"},
    "📰 newsletter":             {"visibility": "visible", "detector": "message_type", "default_priority": "P3",
                                  "evidence": {
                                      "en": ["newsletter", "news digest", "email digest", "weekly digest", "monthly digest"],
                                      "pl": ["newsletter", "biuletyn", "tygodniowy biuletyn", "miesieczny biuletyn"],
                                      "de": ["newsletter", "rundbrief", "wochenrundbrief", "monatsrundbrief"],
                                      "es": ["newsletter", "boletin", "boletin semanal", "boletin mensual"],
                                  }},
    "🏷 promo":                   {"visibility": "hidden",  "detector": "classifier", "default_priority": "P5", "facet": "intent", "specificity": 94},
    "🏷 job spam":               {"visibility": "hidden",  "detector": "semantic_keywords", "default_priority": "P5", "facet": "intent", "specificity": 98},
    "🏷 spam-nieruchomości":     {"visibility": "hidden",  "detector": "semantic_keywords", "default_priority": "P5"},
    "💬 comment":                {"visibility": "normal",  "detector": "social"},
    "✉ message":                 {"visibility": "normal",  "detector": "social"},
    "👍 reaction/polubienie":    {"visibility": "normal",  "detector": "social"},
    "📢 notification":           {"visibility": "normal",  "detector": "social"},
    "🤝 invitation":             {"visibility": "normal",  "detector": "social"},
    "📈 profil: wyświetlenia":   {"visibility": "normal",  "detector": "social"},
    "🔔 auto-notice":             {"visibility": "normal",  "detector": "classifier", "default_priority": "P3", "facet": "message_type", "specificity": 28, "fallback": True},
    "✉ from a person":           {"visibility": "normal",  "detector": "classifier", "default_priority": "P3", "facet": "message_type", "specificity": 24, "fallback": True},
}


# Fabryczny katalog widoczny w UI jest teraz generowany z JEDNEGO zrodla prawdy.
BUILTIN_TAG_CATALOG = list(TAG_POLICY.keys())

def canonical_tag_id(tag):
    """Return the stable catalog id for dynamic display variants of a semantic tag.

    Runtime may decorate a canonical semantic tag for presentation (for example
    ``📰 newsletter: Working Nomads`` or ``💬 comment (LinkedIn)``). Policy and
    exact tag rules must still see one stable canonical id. Facts such as amounts,
    dates and project labels are intentionally not folded into this registry.
    """
    t = str(tag or "").strip()
    if t.startswith("📰 newsletter:"):
        return "📰 newsletter"
    if t in TAG_POLICY:
        return t
    # Social/platform rendering appends `` (Platform)`` to the semantic tag.
    # Resolve only against known built-ins, never by chopping arbitrary custom tags.
    for base in TAG_POLICY:
        if t.startswith(base + " (") and t.endswith(")"):
            return base
    return t

def tag_policy(tag):
    """Policy lookup used by runtime visibility/priority code."""
    return TAG_POLICY.get(canonical_tag_id(tag), {"visibility": "normal", "detector": "custom"})

def tag_evidence(tag, languages=None):
    """Normalized multilingual evidence for built-in semantic message types.

    This is independent from the UI 'Translate match words' button: built-in
    semantic tags already carry their own deterministic EN/PL/DE/ES evidence.
    """
    ev = tag_policy(tag).get("evidence") or {}
    langs = list(languages or ev.keys())
    out = []
    for code in langs:
        out.extend(ev.get(code) or [])
    return out


# ── Twoje własne tagi (szablon tworzony przy pierwszym starcie) ──
# Format: match=[terms], where=from|source|subject|body|tag|all; actions: tag/min_priority/max_priority/show; control: stop

DEFAULT_CUSTOM_TAGS = [
    # Factory exact/custom rules are intentionally tiny.  Brand/platform/topic
    # recognition belongs to the deterministic multilingual classifier above,
    # not to a handful of sender shortcuts that would only fit one user's inbox.
    # This one rule is policy, not recognition: once the classifier/user/AI has
    # produced the canonical institution tag, the generic rule layer keeps it at
    # least P2.  User rules run afterwards and may deliberately narrow/override it.
    {"match": ["🏛 authority", "🏛 tax office"], "where": "tag", "min_priority": "P2"},
]

# ── PRESETY AGENTÓW — szablony z których panel buduje listę "nowy agent" ──

PRESETS = {'inbox_reporter': {'kind': 'reporter',
                    'agent': {'goal': 'krotki raport z nieprzeczytanych maili: sedno+od kogo+priorytet'},
                    'sources': {'inbox': []},
                    'schedule': {'times_per_day': 2, 'windows': ['08:00', '18:00'], 'max_per_run': 20},
                    'outputs': {'report_channel': {'type': 'stdout'}}}}

# ── ETYKIETY RAPORTU w językach (EN/PL/ES) — przełącznik języka w panelu ──

REPORT_LABELS = {
    "en": {"new": "new", "mailbox": "mailbox", "mailboxes": "mailboxes",
           "need": "need attention", "noise": "promo/spam/social hidden",
           "nothing": "Nothing new worth attention.", "already": "already reported",
           "excluded": "excluded by filters", "whyzero": "Why zero (diagnostics)",
           "focus": "emails from people, partners, banks, universities", "also":"Also worth a glance","hidden_noise":"hidden","hidden_list":"folder contents","summary":"SUMMARY","nothing_urgent":"nothing urgent","start":"Start with","social":"Social activity","todo":"TO DO TODAY","worth":"Worth a look","checked":"Checked","resethint": "Not broken — nothing arrived since last report. Click Reset memory to see all again.",
           "critical_line":"⚠ {count} critical (P1!): {items}", "urgent_line":"• {count} urgent (P1) — handle today.", "routine_line":"• Nothing urgent — routine only.", "hidden_line":"↪ +{count} more not shown (per-run limit).", "do_critical":"✅ Do now: deal with the critical ones first — the rest can wait.", "do_urgent":"✅ Do today: review the urgent ones and reply to anything with a deadline.", "do_hidden":"✅ Nothing urgent — run again to pull in the rest.", "attention_line":"• {count} need attention (P2) — important, not an emergency.", "do_attention":"✅ Nothing urgent — clear the {count} flagged item(s) when you have a moment.", "do_none":"✅ Nothing needs action — you can close your inbox."},
    "pl": {"new": "nowych", "mailbox": "skrzynka", "mailboxes": "skrzynki",
           "need": "wymaga uwagi", "noise": "reklamy/spam/social ukryte",
           "nothing": "Nic nowego wartego uwagi.", "already": "juz zaraportowane",
           "excluded": "odsiane filtrami", "whyzero": "Dlaczego zero (diagnostyka)",
           "focus": "maile od ludzi, partnerow, bankow, uczelni", "also":"Warto rzucic okiem","hidden_noise":"ukryte","hidden_list":"zawartosc folderu","summary":"PODSUMOWANIE","nothing_urgent":"nic pilnego","start":"Zacznij od","social":"Aktywnosc social","todo":"DO ZROBIENIA DZIS","worth":"Warto zobaczyc","checked":"Sprawdzono","resethint": "To nie blad — nic nie przyszlo od ostatniego raportu. Kliknij Reset pamieci, by zobaczyc wszystko.",
           "critical_line":"⚠ {count} krytyczne (P1!): {items}", "urgent_line":"• {count} pilnych (P1) — do zrobienia dzis.", "routine_line":"• Nic pilnego — same rutynowe.", "hidden_line":"↪ +{count} poza raportem (limit na run).", "do_critical":"✅ Zrob teraz: odpowiedz/zaplac na krytycznych, reszta moze poczekac.", "do_urgent":"✅ Zrob dzis: przejrzyj pilne i odpisz na te z terminem.", "do_hidden":"✅ Nic pilnego teraz — odpal ponownie, by dociagnac reszte.", "attention_line":"• {count} wymaga uwagi (P2) — wazne, ale nie pilne.", "do_attention":"✅ Nic pilnego — zalatw {count} oznaczonych, gdy bedziesz mial chwile.", "do_none":"✅ Nic nie wymaga dzialania — mozesz zamknac skrzynke."},
    "de": {"new":"neu", "mailbox":"Postfach", "mailboxes":"Postfächer", "need":"erfordern Aufmerksamkeit", "noise":"Werbung/Spam/Soziales ausgeblendet", "nothing":"Nichts Neues, das Aufmerksamkeit erfordert.", "already":"bereits gemeldet", "excluded":"durch Filter ausgeschlossen", "whyzero":"Warum null (Diagnose)", "focus":"E-Mails von Personen, Partnern, Banken und Hochschulen", "also":"Auch einen Blick wert", "hidden_noise":"ausgeblendet", "hidden_list":"Ordnerinhalt", "summary":"ZUSAMMENFASSUNG", "nothing_urgent":"nichts Dringendes", "start":"Beginnen mit", "social":"Soziale Aktivitäten", "todo":"HEUTE ZU ERLEDIGEN", "worth":"Einen Blick wert", "checked":"Geprüft", "resethint":"Kein Fehler — seit dem letzten Bericht ist nichts eingegangen. Setzen Sie den Speicher zurück, um alles erneut zu sehen.", "critical_line":"⚠ {count} kritisch (P1!): {items}", "urgent_line":"• {count} dringend (P1) — heute erledigen.", "routine_line":"• Nichts Dringendes — nur Routine.", "hidden_line":"↪ +{count} weitere nicht angezeigt (Limit pro Lauf).", "do_critical":"✅ Jetzt: zuerst die kritischen Punkte erledigen — der Rest kann warten.", "do_urgent":"✅ Heute: Dringendes prüfen und bei Fristen antworten.", "do_hidden":"✅ Nichts Dringendes — erneut ausführen, um den Rest zu laden.", "attention_line":"• {count} erfordern Aufmerksamkeit (P2) — wichtig, aber kein Notfall.", "do_attention":"✅ Nichts Dringendes — erledigen Sie die {count} markierten Punkte bei Gelegenheit.", "do_none":"✅ Keine Aktion erforderlich — Sie können den Posteingang schließen."},
    "es": {"new": "nuevos", "mailbox": "buzon", "mailboxes": "buzones",
           "need": "requieren atencion", "noise": "promociones/spam/social ocultos",
           "nothing": "Nada nuevo que merezca atencion.", "already": "ya reportados",
           "excluded": "excluidos por filtros", "whyzero": "Por que cero (diagnostico)",
           "focus": "correos de personas, socios, bancos, universidades", "also":"Vale la pena ojear","hidden_noise":"ocultos","hidden_list":"contenido","summary":"RESUMEN","nothing_urgent":"nada urgente","start":"Empieza por","social":"Actividad social","todo":"HACER HOY","worth":"Vale la pena ver","checked":"Revisado","resethint": "No es un error — nada nuevo desde el ultimo informe. Pulsa Reset para ver todo.", "critical_line":"⚠ {count} críticos (P1!): {items}", "urgent_line":"• {count} urgentes (P1) — gestionar hoy.", "routine_line":"• Nada urgente — solo rutina.", "hidden_line":"↪ +{count} más no mostrados (límite por ejecución).", "do_critical":"✅ Ahora: atiende primero los críticos; el resto puede esperar.", "do_urgent":"✅ Hoy: revisa los urgentes y responde a los que tengan fecha límite.", "do_hidden":"✅ Nada urgente — ejecuta de nuevo para cargar el resto.", "attention_line":"• {count} requieren atención (P2) — importante, no urgente.", "do_attention":"✅ Nada urgente — resuelve los {count} marcados cuando puedas.", "do_none":"✅ No hay nada que requiera acción; puedes cerrar la bandeja."},
}


def report_labels(lang="en", engine_version=None):
    """Report copy with English fallback per key, never whole-locale fallback."""
    out = dict(REPORT_LABELS["en"])
    if engine_version:
        try:
            import language_packs as _lp
            out.update(_lp.section("en", engine_version, "report"))
        except Exception:
            pass
    out.update(REPORT_LABELS.get(lang) or {})
    if engine_version:
        try:
            out.update(_lp.section(lang, engine_version, "report"))
        except Exception:
            pass
    return out

# ── WAGI KATEGORII (score bazowy 0-1) ──

CAT_WEIGHT = {"security": 1.0, "financial": 0.95, "login": 0.9, "personal": 0.8,
              "system": 0.55, "news": 0.5, "social": 0.3, "marketing": 0.12, "ads": 0.0}

# Classic does NOT convert CAT_WEIGHT into priority. Those weights remain available
# for secondary/ranking experiments, while the publication Classic path uses this
# explicit deterministic category baseline plus concrete message signals.
CLASSIC_PRIORITY_BY_CATEGORY = {
    "security": "P2", "financial": "P2", "login": "P2", "personal": "P3",
    "system": "P4", "news": "P4", "social": "P5", "marketing": "P5", "ads": "P5",
    "suspicious": "P3",
}

# Semantic institution terms. These create TAGS only; priority is attached separately
# through DEFAULT_CUSTOM_TAGS (where=tag -> min_priority). This keeps classification
# and priority policy decoupled and language-independent.
TAX_OFFICE_TERMS = [
    "urzad skarbowy", "urzedu skarbowego", "krajowa administracja skarbowa",
    "tax office", "revenue service", "finanzamt", "steueramt",
    "agencia tributaria", "administracion tributaria", "hacienda",
]

AUTHORITY_TERMS = [
    # PL
    "urzad", "urzedu", "urzad miasta", "urzad gminy", "urzad wojewodzki",
    "ambasada", "ambasady", "konsulat", "konsulatu", "konsul", "ministerstwo",
    # EN
    "authority", "government office", "public office", "embassy", "consulate",
    "ministry", "municipality",
    # DE
    "behorde", "behoerde", "behorden", "behoerden", "amt", "botschaft",
    "konsulat", "ministerium", "stadtverwaltung", "gemeinde",
    # ES
    "autoridad", "oficina publica", "administracion publica", "embajada",
    "consulado", "ministerio", "ayuntamiento",
]

# ── ETYKIETY KATEGORII w raporcie ──

CAT_LABEL = {"security": "⚠ security", "financial": "💰 bank/money", "login": "⚠ login",
             "personal": "✉ from a person", "system": "🔔 auto-notice", "news": "📰 news",
             "social": "💬 social", "marketing": "🏷 promo", "ads": "🏷 ad"}

# ── SŁOWA REKLAMOWE → kategoria ads/marketing ──

ADS_KW = ["offer", "discount", "buy now", "promotion", "promocja", "promo", "jubeln",
          "deal", "cashback", "sale", "rabat", "zwrot", "znizka", "zniżka", "% off",
          "-50%", "wyprzedaz", "kupuj", "odbierz", "zgarnij", "zyskaj", "prezent",
          "cena", "kod rabatowy", "voucher", "newsletter", "oferta", "okazja",
          # promocje polecajace / sklepowe / pracowe — czesty szum Karola
          "earn ", "for each friend", "zapros", "poleć", "polec znajom", "referral",
          "cheap", "taniej", "save your", "in app", "w aplikacji",
          "jobs", "praca", "serwis pracy", "hiring", "rekrutacj", "oferty pracy",
          "aktywuj", "activate", "activate your", "activate account",
          # auto / leasing / kredyt — reklamy (Mazda/Skoda/Volvo "od X zl/mies")
          "netto/mies", "netto /mies", "zl/mies", "zl /mies", "zl netto", "/miesiecznie",
          "miesiecznie", "leasing", "raty", "0%", "rrso", "kredyt", "pozyczk",
          "credit card", "karta kredytow", "subskrypcj", "subscription", "odnow", "renew",
          "superceny", "supercen", "atrakcyjn", "od 7", "od 9", "juz od"]

# ── NADAWCY SOCIAL → kategoria social ──

SOCIAL_SRC = ["facebook", "instagram", "linkedin", "twitter", "x.com", "tiktok",
              "reddit", "pinterest", "snapchat", "quora"]
# quora: digesty "New from recommended & followed writers" to social/notyfikacja,
# nie finanse. Bez tego wpadaly jako 'financial' -> tag 💳 payment -> "warto zobaczyc".

# ── ZNANI NADAWCY MARKETINGOWI ──

MARKETING_SRC = ["mediaexpert", "media expert", "t-mobile", "tmobile", "link4", "blablacar",
                 "toyota", "mazda", "volvo", "skoda", "škoda", "renault", "opel", "kia", "hyundai",
                 "ford", "peugeot", "citroen", "bmw", "audi", "volkswagen", "nissan", "uniqa", "pzu",
                 "mubi", "triverna", "superprof", "allegro", "temu", "aliexpress",
                 "booking", "ceneo", "empik", "x-kom", "morele", "zalando", "kancelaria",
                 "newsletter", "noreply", "no-reply", "powiadomien", "marketing@", "info@",
                 "deals@", "news@", "promo@", "hello@", "team@", "mcafee", "norton", "remington"]

# ── DODATKOWE SŁOWA PROMO (leasing, nieruchomości, spam-inwestycje) ──

PROMO_KW2 = ["odkup", "wymien na nowy", "smartfon", "internet ktory", "oc+ac", "oc + ac",
             "netto/mies", "netto/ mies", "zl/mies", "zl/rok", "leasing", "raty 0%", "od 0 zl",
             "assistance", "stluczk", "freelance", "venture", "revolut pro", "article",
             "artykul", "sytuacji", "trac pieniadze", "lose money", "regulamin",
             # nieruchomosci / resort / condo / inwestycje-spam
             "condo", "apartament", "nieruchomos", "mieszkan", "inwestycj",
             "resort", "deweloper", "dzialka", "dzialki", "rynek nieruch",
             "jako pierwszy", "sprawdz nowosc", "zmieni rynek", "nie przegap"]

# ── KONTEKST WIADOMOŚCI (PL + EN) ────────────────────────────────────────
# Te listy NIE są tagami ani priorytetami. Odpowiadają na wcześniejsze pytanie:
# „czy to jest transakcja dla odbiorcy, czy treść *o* pieniądzach / nauce / usłudze?”
# Dzięki temu szkolenie „o płatnościach” nie staje się płatnością, a cold mail SEO
# nie staje się mailem osobistym lub akademickim. Wszystkie frazy są celowo
# normalizowane przez engine._norm (bez polskich znaków, małe litery).
EDU_NEWSLETTER_KW = [
    # PL
    "szkolenie", "webinar", "kurs ", "kursu", "poradnik", "masterclass",
    "dowiedz sie", "jak uniknac", "jak zarabiac", "strategia", "case study",
    "ebook", "zapisz sie", "rejestracja na", "odcinek", "newsletter",
    "nowy wpis", "blogu", "podcast", "poznaj zasady", "temat wyplacania",
    "temat platnosci", "w spolce", "w firmie",
    # EN
    "training", "webinar", "course", "masterclass", "learn how", "free guide",
    "case study", "ebook", "sign up", "register now", "newsletter", "podcast",
    "how to", "business payments", "payments in your company",
]

COLD_OUTREACH_KW = [
    # PL — oferty SEO/marketing/B2B wysyłane pozornie „od osoby”
    "pozycjonowania wizytowek", "wizytowki google", "pozycje w wyszukiwarce",
    "badania konkurencji", "optymalizacje tekstu", "fraz kluczowych",
    "wiekszej liczby klientow", "panstwa firme", "panstwa firma",
    "indywidualna propozycje", "prosze o odpowiedz zgoda",
    # EN
    "google business profile", "google listing", "search ranking", "search rankings",
    "keyword optimisation", "keyword optimization", "more customers", "increase your visibility",
    "i noticed your company", "complimentary audit", "free audit", "book a quick call",
]

# Tylko te sygnały uzasadniają etykietę finansową przy nadawcy, który NIE jest
# zaufaną instytucją finansową. Samo słowo „płatność/payment/money” nie wystarcza.
FIN_TRANSACTION_KW = [
    # PL
    "faktura", "e-faktura", "rachunek nr", "rachunek do zaplaty", "kwota do zaplaty",
    "termin platnosci", "potwierdzenie przelewu", "polecenie przelewu",
    "zestawienie operacji", "wyciag bankowy", "saldo konta", "obciazenie rachunku",
    "pobrano z konta", "przelew przychodzacy", "wplynely srodki", "zwrot srodkow",
    # EN
    "invoice", "invoice number", "amount due", "payment due", "due date",
    "transfer confirmation", "bank statement", "account statement", "account balance",
    "direct debit", "charged to your account", "incoming transfer", "refund issued",
]

# Informacyjne wiadomości bankowe nie są prośbą o działanie. Nadal dostają
# przejrzysty tag, ale nie mogą zyskać priorytetu P2 wyłącznie dlatego, że
# pochodzą z banku.
FIN_STATEMENT_KW = [
    "zestawienie operacji", "dzienny wykaz operacji", "wykaz operacji",
    "wyciag bankowy", "wyciag z konta", "saldo konta", "historia operacji",
    "bank statement", "account statement", "daily account activity",
    "account balance", "transaction history",
]

# ── BOOST PRIORYTETU dla słów krytycznych ──

KW_BOOST = {"alert bezpiecz": 0.6, "unauthorized": 0.6, "verification code": 0.5,
            "zajecie": 0.7, "windykacja": 0.7, "deadline": 0.5, "termin": 0.4,
            "pilne": 0.6, "urgent": 0.6, "abschluss": 0.4, "completion": 0.4}

# ── WZORCE SCAM/419 → kategoria ads (odsiew) ──

SCAM_KW = ["drogi przyjacielu", "dear friend", "dear beloved", "kontakt z rapha",
           "raphael johnson", "spadek", "inheritance", "lottery", "western union",
           "money gram", "consignment", "nigeria", "barrister", "next of kin",
           "fund transfer", "investment opportunity", "compensation fund",
           "akredytywa", "pilna sprawa biznes", "atm card", "claim your prize",
           # dating/spam
           "portal randkowy", "serwis randkowy", "darmowy portal randk", "zakochana",
           "lets throw a party", "come over and lets", "only you and i",
           "hot singles", "meet singles", "meet local"]

# ── SŁOWA KRYTYCZNE → P1 (komornik, sąd, windykacja, breach) ──

CRITICAL_KW = ["do zaplaty", "zaleglos", "zaleg ", "naleznos", "egzekucj", "wierzytelnos",
               "komornik", "windykacj", "zajecie wierzytel", "urzad skarbowy", "skarbowy",
               "policj", "prokuratur", " sadu", "sadow", "sadzie", "z sadu", "do sadu",
               "wyrok", "pozew", "rozpraw", "wezwanie do", "ostateczne wezwanie",
               "termin platnosci", "ostrzezenie o", "pilne dzialanie",
               "unauthorized", "nowe urzadzenie", "new device sign", "naruszenie", "blokada konta"]

# ── TAGI TWOICH PROJEKTÓW (z tematu/nadawcy, NIGDY z treści) ──

PROJECT_TAGS = {"ecs": "⭐ ECS", "ecb": "⭐ ECB", "l4m": "⭐ L4M", "locally4me": "⭐ L4M",
                "f4m": "⭐ F4M", "food4me": "⭐ F4M"}
