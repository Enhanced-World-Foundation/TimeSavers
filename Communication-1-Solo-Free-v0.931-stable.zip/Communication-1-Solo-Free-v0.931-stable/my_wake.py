#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Stable AgentSystem Wake bootstrap.

This file is intentionally tiny. It does not schedule jobs, show popups or own UI.
It verifies the selected central Wake release and execs it so exactly one Wake
runtime process remains.
"""
from __future__ import annotations
import hashlib, json, os, sys

BOOTSTRAP_RELEASE = 1
HOME = os.path.expanduser(os.environ.get("ENGINE_HOME", "~/agentsystem"))
ROOT = os.path.join(HOME, "system", "wake")
ACTIVE = os.path.join(ROOT, "active.json")


def _sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _load_active():
    with open(ACTIVE, "r", encoding="utf-8") as f:
        data = json.load(f)
    if not isinstance(data, dict):
        raise RuntimeError("invalid active Wake metadata")
    return data


def _validated_entry(meta):
    rel = str(meta.get("version_dir") or "")
    if not rel or os.path.isabs(rel) or ".." in rel.replace("\\", "/").split("/"):
        raise RuntimeError("unsafe active Wake directory")
    version_dir = os.path.realpath(os.path.join(ROOT, rel))
    versions_root = os.path.realpath(os.path.join(ROOT, "versions"))
    if os.path.commonpath([versions_root, version_dir]) != versions_root:
        raise RuntimeError("active Wake outside versions directory")
    manifest = meta.get("files") or {}
    if not isinstance(manifest, dict) or not manifest:
        raise RuntimeError("missing Wake manifest")
    for name, expected in manifest.items():
        if not isinstance(name, str) or "/" in name or "\\" in name or ".." in name:
            raise RuntimeError("unsafe Wake manifest entry")
        path = os.path.join(version_dir, name)
        if not os.path.isfile(path) or _sha256(path) != expected:
            raise RuntimeError(f"Wake integrity check failed: {name}")
    entry = os.path.join(version_dir, "wake.py")
    if not os.path.isfile(entry):
        raise RuntimeError("wake.py missing from active Wake release")
    return version_dir, entry


def main():
    meta = _load_active()
    version_dir, entry = _validated_entry(meta)
    os.chdir(version_dir)
    os.execv(sys.executable, [sys.executable, entry, *sys.argv[1:]])


if __name__ == "__main__":
    main()
