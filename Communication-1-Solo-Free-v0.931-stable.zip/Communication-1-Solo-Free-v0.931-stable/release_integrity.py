# Generated release integrity verifier.
from __future__ import annotations
import hashlib, json
from pathlib import Path
class IntegrityError(RuntimeError): pass
def _sha(path: Path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for c in iter(lambda:f.read(1024*1024), b''): h.update(c)
    return h.hexdigest()
def verify(root=None):
    root=Path(root or Path(__file__).resolve().parent)
    manifest=root/'release_manifest.json'
    if not manifest.exists(): return True
    data=json.loads(manifest.read_text(encoding='utf-8'))
    bad=[]
    for rel, expected in data.get('protected_files', {}).items():
        p=root/rel
        if not p.is_file() or _sha(p) != expected: bad.append(rel)
    if bad: raise IntegrityError('Release integrity check failed: '+', '.join(bad[:12]))
    return True
