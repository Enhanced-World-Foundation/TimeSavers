#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Tiny data-only EN/PL translator for the central Wake UI."""
import json, os
HOME = os.path.expanduser(os.environ.get("ENGINE_HOME", "~/agentsystem"))

PL = {
"window_title":"Time Savers — Centrum sterowania Wake","loading":"Ładowanie…","overview":"Przegląd","tools":"A-Toole i harmonogramy","calendars":"Kalendarze","settings":"Ustawienia Wake","log":"Log",
"effective_schedule":"Efektywny harmonogram","source":"Źródło","execution":"Uruchamianie","trust":"Zaufanie","select_tool":"Wybierz A-Tool","may_run":"Wake może uruchamiać ten A-Tool","daily_times":"Godziny dzienne (HH:MM, rozdzielone przecinkami)","once_date":"Data jednorazowego runu","time":"czas","active_from":"Aktywny od","until":"do","catchup":"Nadrób pominięte runy harmonogramu / jednorazowe","network_required":"Wymaga sieci","retry_network":"Ponów, gdy sieć wróci","run_when_online":"Uruchom, gdy sieć stanie się dostępna","cooldown":"Przerwa po odzyskaniu sieci (s)","ui_after":"UI po runie w tle","ui_after_help":"inherit = wspólne ustawienie Wake; never = tylko headless; open = użyj/uruchom i podnieś UI A-Toola","notify_after":"Powiadomienie po runie w tle","notify_after_help":"inherit = wspólne ustawienie Wake; never = bez powiadomienia; notify = pokaż systemowe powiadomienie po zakończeniu tego wpisu","published_effective":"Opublikowane przez A-Tool / efektywne w Wake",
"calendar_note":"Kalendarz główny = terminy/notatki ze wszystkich A-Tooli. Kalendarz Wake = efektywne harmonogramy Wake + popup.","main_calendar":"Kalendarz główny","wake_calendar":"Kalendarz Wake","date":"Data","title":"Tytuł","type":"Typ","when":"Kiedy","details":"Szczegóły",
"wake_manager":"Manager Wake","check_interval":"Interwał sprawdzania (sekundy)","due_window":"Okno wykonania harmonogramu (minuty)","retry_pending":"Ponawiaj oczekujące zadania sieciowe po powrocie sieci","open_ui_after":"Otwórz/podnieś UI A-Toola po runie w tle","notify_runs":"Powiadom systemowo po runie w tle","start_system":"Uruchamiaj Wake ze startem systemu","single_manager_help":"Wake jest jedynym stale działającym managerem w tle. Zamknięcie tego okna ustawień go nie zatrzymuje.","shared_popup":"Wspólny popup — zwycięzca ustala timing","enable_popup":"Włącz wspólny popup","popup_help":"Timing pochodzi z najnowszej zarejestrowanej wersji popupu. Wake pokazuje następny termin i nie nadpisuje polityki tej wersji.",
"select_first":"Najpierw wybierz A-Tool.","saved_override":"Zapisano centralny override Wake.","schedule_title":"Harmonogram Wake","reset_confirm":"Przywrócić harmonogram publikowany przez ten A-Tool?","run_queued":"Run headless dodany do kolejki jednego managera Wake.","run_failed":"Nie udało się dodać runu; sprawdź log Wake.","opened_ui":"Otwarto/użyto UI A-Toola: ","open_failed":"Nie udało się otworzyć UI A-Toola: ","save_override":"Zapisz override Wake","use_published":"Użyj harmonogramu A-Toola","queue_run":"Uruchom headless","open_reuse":"Otwórz / użyj UI A-Toola","save_settings":"Zapisz ustawienia Wake","saved":"Zapisano.","autostart_error":"Ustawienia zapisano, błąd autostartu: {error}","single_process_note":"Planowanie i wykonanie pozostają w jednym procesie Wake w tle.",
"calendar_item":"Element kalendarza","kind":"Rodzaj","note":"Notatka","cancel":"Anuluj","save":"Zapisz","calendar":"Kalendarz","delete_calendar":"Usunąć wybrany element kalendarza?","select_calendar":"Najpierw wybierz element do edycji.","add_event":"Dodaj wydarzenie / termin","edit_selected":"Edytuj wybrane","delete_selected":"Usuń wybrane","export_main":"Eksportuj główny .ics","export_wake":"Eksportuj Wake .ics","refresh":"Odśwież","open_log":"Otwórz plik logu",
"running":"DZIAŁA","stopped":"ZATRZYMANY","winner":"Zwycięzca","next":"Następny","not_scheduled":"nie zaplanowano","shown_times":"pokazano {count} raz(y)","policy":"Polityka","first_min":"pierwszy za {n} min","next_random":"kolejny losowo {a} h – {b} h","visible_s":"widoczny {n} s","no_popup":"Brak poprawnej zarejestrowanej wersji popupu.","registered_tools":"Zarejestrowane A-Toole","tray_backend":"Backend tray","autostart":"Autostart","main_calendar_status":"Kalendarz główny","shared_popup_status":"Wspólny popup","wake_only":"Wake jest jedynym schedulerem w tle. To okno jest tylko UI sterującym i nie uruchamia drugiego schedulera.","publish_help":"A-Toole publikują harmonogramy do wspólnego ekosystemu; centralne override Wake działają bez otwartego panel.py.","published":"opublikowany","override":"override","daily":"codziennie","once":"jednorazowo","popup":"popup","shared_popup_short":"wspólny popup","no_log":"Brak logu Wake.",
"wake_column":"Wake","agent_source":"A-Tool / źródło","run_on_start_edit":"Uruchom przy starcie sesji Wake / systemu","guard_min":"ochrona min","date_format":"Data (RRRR-MM-DD lub DD.MM.RRRR)","time_hhmm":"Czas HH:MM",
"export_main_title":"Eksportuj główny kalendarz","export_wake_title":"Eksportuj kalendarz Wake","calendar_item_default":"Element kalendarza",
"wake_manager_status":"Manager Wake","mode":"tryb","installed":"zainstalowany","registered_tools":"Zarejestrowane A-Toole","upcoming":"nadchodzących",
"source_override":"override Wake","source_published":"opublikowane przez A-Tool","unknown":"nieznane","path":"ścieżka","execution_label":"uruchamianie","trust_label":"zaufanie",
"atool_published":"A-Tool opublikował:","effective_in_wake":"Efektywne w Wake:","scheduled":"zaplanowane","run_on_start":"uruchom przy starcie","guard":"ochrona","background":"tło",
"mail_times":"mail","feed_times":"RSS","times_day":"razy/dzień","wake_runs":"runy Wake","active":"aktywny","runner":"runner","enabled":"włączony","network":"sieć","retry":"ponów",
"policy_line":"Polityka: pierwszy za {first} min · kolejny losowo {minh} h – {maxh} h · widoczny {visible} s",
"popup_status_line":"Wspólny popup: zwycięzca={winner} v{version} · następny {next}","calendar_status_line":"Kalendarz główny: {count} nadchodzących",
"next_item":"następny {at} — {title}","central_override":"centralny override","atool_published_source":"opublikowane przez A-Tool","one_time_run":"jednorazowy run Wake",
"wake_settings_title":"Ustawienia Wake",
"on":"WŁ","off":"WYŁ"
}

def language():
    try:
        p=os.path.join(HOME,"settings.json")
        d=json.load(open(p,encoding="utf-8")) if os.path.exists(p) else {}
        raw=str(d.get("lang") or d.get("language") or "en").lower()
        return "pl" if raw.startswith("pl") else "en"
    except Exception:
        return "en"

def t(key, fallback=None, **kwargs):
    text = PL.get(key, fallback if fallback is not None else key) if language()=="pl" else (fallback if fallback is not None else key)
    try: return str(text).format(**kwargs)
    except Exception: return str(text)
