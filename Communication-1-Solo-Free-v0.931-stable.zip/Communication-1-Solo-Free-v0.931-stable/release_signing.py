# ============================================================================
#  release_signing.py — publisher signing / verification  (file-version 0.931)
# ============================================================================
#  Split of responsibility:
#
#    EDITION BUILDER (release step, offline private key)
#        sign_release(staging_dir, seed_hex, key_id, release)
#      -> writes manifest.json + release.sig into the built package.
#      Called in the builder's last phase, next to identity / SHA / watermark,
#      AFTER edition policy and the test/translation/documentation gates.
#
#    SHIPPED PRODUCT (this machine, public key only)
#        verify_release(dir)  -> {"ok", "key_id", "release", "reason"}
#      Wake and atool_sync call this before promoting a central Wake.
#
#  A private key NEVER ships. publisher_keys.json holds public keys only.
#  Ed25519 (RFC 8032). Uses `cryptography` when present; otherwise a compact
#  RFC 8032 verifier so a signed release verifies on a bare Python install —
#  the feature must not silently degrade to "trusted" because a dependency is
#  missing.
# ============================================================================

import base64
import hashlib
import json
import os

SIGNING_SCHEMA = 1
KEYS_NAME = "publisher_keys.json"
HERE = os.path.dirname(os.path.abspath(__file__))

# Files that are part of a signed release manifest. The signature covers their
# content hashes, so replacing any of them invalidates the release.
SIGNED_GLOB_SKIP = {"__pycache__", ".git", ".pytest_cache", ".mypy_cache", ".idea", ".vscode"}
# Runtime debris that legitimately appears after installation and is therefore
# not part of a release manifest. Everything else present but unsigned is an
# injected file and fails verification.
IGNORABLE_SUFFIXES = (".pyc", ".pyo", ".tmp", ".log", ".swp", ".orig", ".rej")
IGNORABLE_NAMES = {MANIFEST_NAME := "manifest.json", SIGNATURE_NAME := "release.sig",
                   ".DS_Store", "Thumbs.db", "desktop.ini"}


def _ignorable(rel):
    parts = rel.split("/")
    if any(p in SIGNED_GLOB_SKIP for p in parts):
        return True
    if parts[-1] in IGNORABLE_NAMES:
        return True
    return rel.endswith(IGNORABLE_SUFFIXES)


# Unlisted files Python can execute or import on its own. An injected
# sitecustomize.py / .pth runs on every interpreter start in that directory —
# that is code execution, not clutter. A stray notes.txt is clutter.
EXECUTABLE_SUFFIXES = (".py", ".pyw", ".pth", ".so", ".pyd", ".dll", ".dylib")


def unsigned_files(directory, files, executable_only=False):
    """Files present on disk that the signed manifest does not cover.

    executable_only=True keeps the check on what actually matters at runtime,
    so a user's own note next to the program does not invalidate the release
    while an injected module still does.
    """
    out = []
    root = os.path.abspath(directory)
    for base, dirs, names in os.walk(root):
        dirs[:] = [d for d in dirs if d not in SIGNED_GLOB_SKIP]
        for fn in names:
            rel = os.path.relpath(os.path.join(base, fn), root).replace(os.sep, "/")
            if rel in files or _ignorable(rel):
                continue
            if executable_only and not rel.lower().endswith(EXECUTABLE_SUFFIXES):
                continue
            out.append(rel)
    return sorted(out)


# ─────────────────────── Ed25519 (verify only, pure python) ────────────────
_P = 2 ** 255 - 19
_L = 2 ** 252 + 27742317777372353535851937790883648493
_D = (-121665 * pow(121666, _P - 2, _P)) % _P
_I = pow(2, (_P - 1) // 4, _P)


def _recover_x(y, sign):
    if y >= _P:
        return None
    xx = (y * y - 1) * pow(_D * y * y + 1, _P - 2, _P)
    x = pow(xx, (_P + 3) // 8, _P)
    if (x * x - xx) % _P != 0:
        x = (x * _I) % _P
    if (x * x - xx) % _P != 0:
        return None
    if x % 2 != sign:
        x = _P - x
    return x


def _point_add(p, q):
    x1, y1, z1, t1 = p
    x2, y2, z2, t2 = q
    a = ((y1 - x1) * (y2 - x2)) % _P
    b = ((y1 + x1) * (y2 + x2)) % _P
    c = (2 * t1 * t2 * _D) % _P
    d = (2 * z1 * z2) % _P
    e, f, g, h = b - a, d - c, d + c, b + a
    return ((e * f) % _P, (g * h) % _P, (f * g) % _P, (e * h) % _P)


def _point_mul(s, p):
    q = (0, 1, 1, 0)
    while s > 0:
        if s & 1:
            q = _point_add(q, p)
        p = _point_add(p, p)
        s >>= 1
    return q


_GY = (4 * pow(5, _P - 2, _P)) % _P
_GX = _recover_x(_GY, 0)
_G = (_GX, _GY, 1, (_GX * _GY) % _P)


def _point_equal(p, q):
    x1, y1, z1, _ = p
    x2, y2, z2, _ = q
    return (x1 * z2 - x2 * z1) % _P == 0 and (y1 * z2 - y2 * z1) % _P == 0


def _decompress(b):
    if len(b) != 32:
        return None
    y = int.from_bytes(b, "little")
    sign = y >> 255
    y &= (1 << 255) - 1
    x = _recover_x(y, sign)
    if x is None:
        return None
    return (x, y, 1, (x * y) % _P)


def _ed25519_verify_pure(public_key, signature, message):
    if len(public_key) != 32 or len(signature) != 64:
        return False
    a = _decompress(public_key)
    if a is None:
        return False
    rs, s = signature[:32], int.from_bytes(signature[32:], "little")
    if s >= _L:
        return False
    r = _decompress(rs)
    if r is None:
        return False
    k = int.from_bytes(hashlib.sha512(rs + public_key + message).digest(), "little") % _L
    return _point_equal(_point_mul(s, _G), _point_add(r, _point_mul(k, a)))


def ed25519_verify(public_key, signature, message):
    """True only for a real signature. Never raises, never defaults to True."""
    try:
        from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
        from cryptography.exceptions import InvalidSignature
        try:
            Ed25519PublicKey.from_public_bytes(public_key).verify(signature, message)
            return True
        except InvalidSignature:
            return False
        except Exception:
            pass                      # malformed key material -> fall through
    except Exception:
        pass
    try:
        return bool(_ed25519_verify_pure(public_key, signature, message))
    except Exception:
        return False


# ───────────────────────────── manifest ────────────────────────────────────
def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def hash_tree(root, names=None):
    """{relative path: sha256} for the files a release manifest covers."""
    out = {}
    root = os.path.abspath(root)
    if names is not None:
        for n in names:
            p = os.path.join(root, n)
            if os.path.isfile(p):
                out[n.replace(os.sep, "/")] = sha256_file(p)
        return out
    for base, dirs, files in os.walk(root):
        dirs[:] = [d for d in dirs if d not in SIGNED_GLOB_SKIP]
        for fn in files:
            if fn in (MANIFEST_NAME, SIGNATURE_NAME):
                continue
            p = os.path.join(base, fn)
            rel = os.path.relpath(p, root).replace(os.sep, "/")
            out[rel] = sha256_file(p)
    return out


def canonical_manifest(files, release=None, edition="", key_id="", extra=None):
    """Byte-exact manifest. This exact serialization is what gets signed."""
    body = {
        "schema": SIGNING_SCHEMA,
        "edition": str(edition or ""),
        "key_id": str(key_id or ""),
        "release": (int(release) if release is not None else None),
        "files": {k: files[k] for k in sorted(files)},
    }
    if isinstance(extra, dict):
        for k in sorted(extra):
            if k not in body:
                body[k] = extra[k]
    return json.dumps(body, sort_keys=True, separators=(",", ":"),
                      ensure_ascii=True).encode("utf-8")


# ─────────────────────────── publisher keys ────────────────────────────────
def load_publisher_keys(path=None):
    """Pinned public keys. Missing/empty file = no publisher trust, not 'allow'."""
    p = path or os.path.join(HERE, KEYS_NAME)
    try:
        with open(p, encoding="utf-8") as f:
            data = json.load(f)
    except Exception:
        return {}
    out = {}
    for rec in (data.get("keys") or []) if isinstance(data, dict) else []:
        if not isinstance(rec, dict):
            continue
        kid = str(rec.get("key_id") or "").strip()
        alg = str(rec.get("alg") or "ed25519").strip().lower()
        raw = str(rec.get("public_key") or "").strip()
        if not kid or alg != "ed25519" or not raw or rec.get("revoked"):
            continue
        try:
            pk = base64.b64decode(raw, validate=True)
        except Exception:
            continue
        if len(pk) == 32:
            out[kid] = pk
    return out


# ───────────────────────────── verification ────────────────────────────────
def verify_release(directory, keys=None, keys_path=None, strict=True):
    """Verify a built package or a staged Wake version directory.

    Returns {"ok", "signed", "key_id", "release", "edition", "reason"}.
    ok=True only when the signature is valid for a pinned publisher key AND
    every file listed in the manifest still hashes to the signed value.
    """
    res = {"ok": False, "signed": False, "key_id": "", "release": None,
           "edition": "", "reason": ""}
    mpath = os.path.join(directory, MANIFEST_NAME)
    spath = os.path.join(directory, SIGNATURE_NAME)
    if not os.path.isfile(mpath) or not os.path.isfile(spath):
        res["reason"] = "unsigned release (no manifest/signature)"
        return res
    res["signed"] = True
    try:
        raw = open(mpath, "rb").read()
        man = json.loads(raw.decode("utf-8"))
    except Exception as ex:
        res["reason"] = f"unreadable manifest: {ex}"
        return res
    if int(man.get("schema") or 0) != SIGNING_SCHEMA:
        res["reason"] = "unsupported manifest schema"
        return res
    res["key_id"] = str(man.get("key_id") or "")
    res["edition"] = str(man.get("edition") or "")
    try:
        res["release"] = int(man.get("release")) if man.get("release") is not None else None
    except Exception:
        res["release"] = None

    # The manifest is signed byte-exactly as the builder produced it, but it must
    # also be canonical — otherwise two different byte strings could describe the
    # same release and only one of them would be checkable.
    if canonical_manifest(man.get("files") or {}, man.get("release"),
                          man.get("edition"), man.get("key_id")) != raw:
        res["reason"] = "manifest is not in canonical form"
        return res

    pool = keys if keys is not None else load_publisher_keys(keys_path)
    if not pool:
        res["reason"] = "no pinned publisher key on this installation"
        return res
    pk = pool.get(res["key_id"])
    if not pk:
        res["reason"] = f"unknown publisher key_id {res['key_id']!r}"
        return res
    try:
        sig = base64.b64decode(open(spath, "rb").read().strip(), validate=True)
    except Exception:
        res["reason"] = "unreadable signature"
        return res
    if not ed25519_verify(pk, sig, raw):
        res["reason"] = "signature does not match this manifest"
        return res

    files = man.get("files") or {}
    if not isinstance(files, dict) or not files:
        res["reason"] = "manifest lists no files"
        return res
    for rel, want in files.items():
        if ".." in rel.split("/") or rel.startswith("/"):
            res["reason"] = f"unsafe path in manifest: {rel}"
            return res
        fp = os.path.join(directory, rel.replace("/", os.sep))
        if not os.path.isfile(fp):
            res["reason"] = f"signed file missing: {rel}"
            return res
        if sha256_file(fp) != want:
            res["reason"] = f"signed file modified: {rel}"
            return res
    # strict=True   -> nothing unlisted at all (use when checking a fresh package)
    # strict="code"  -> only unlisted importable/executable files are fatal
    #                   (use at runtime: the user may keep their own files there)
    # strict=False   -> signed files only
    if strict:
        extra = unsigned_files(directory, files, executable_only=(strict == "code"))
        if extra:
            res["reason"] = ("unsigned executable file present: " if strict == "code"
                             else "unsigned file present: ") + ", ".join(extra[:3]) \
                            + (f" (+{len(extra) - 3} more)" if len(extra) > 3 else "")
            res["unsigned_files"] = extra
            return res
    res["ok"] = True
    res["reason"] = "verified"
    return res


# ─────────────────────── builder side (release step) ───────────────────────
def sign_release(directory, seed_hex, key_id, release=None, edition="", names=None):
    """Called by the edition builder in its identity/SHA/watermark phase.

    `seed_hex` is the 32-byte Ed25519 private seed, kept offline by the
    publisher and never shipped. Writes manifest.json + release.sig into the
    built package and returns the manifest dict.
    """
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    seed = bytes.fromhex(str(seed_hex).strip())
    if len(seed) != 32:
        raise ValueError("Ed25519 seed must be 32 bytes (64 hex chars)")
    sk = Ed25519PrivateKey.from_private_bytes(seed)
    files = hash_tree(directory, names)
    raw = canonical_manifest(files, release, edition, key_id)
    sig = sk.sign(raw)
    with open(os.path.join(directory, MANIFEST_NAME), "wb") as f:
        f.write(raw)
    with open(os.path.join(directory, SIGNATURE_NAME), "wb") as f:
        f.write(base64.b64encode(sig))
    return json.loads(raw.decode("utf-8"))


def public_key_b64(seed_hex):
    """Publisher helper: the public key to pin in publisher_keys.json."""
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    from cryptography.hazmat.primitives import serialization
    sk = Ed25519PrivateKey.from_private_bytes(bytes.fromhex(str(seed_hex).strip()))
    pub = sk.public_key().public_bytes(serialization.Encoding.Raw,
                                       serialization.PublicFormat.Raw)
    return base64.b64encode(pub).decode("ascii")

# ============================================================================
#  CENTRAL TRUST ANCHOR
# ============================================================================
#  A package must never certify itself. Both the pinned keys AND the verifier
#  have to live outside the artefact being verified, otherwise a hostile A-Tool
#  folder simply ships its own publisher_keys.json (and its own release_signing)
#  and signs itself. That is what these functions exist for.
#
#  The store is established ONCE, on first install (trust on first use), and is
#  never re-read from a candidate afterwards. Changing it later is a deliberate
#  act by the user, not something an installed package can do on its own.
#
#  Honest limit: this is integrity + provenance, not a sandbox. Everything here
#  runs as the user's own account, so code already running as that user can
#  overwrite the store. See docs/SECURITY-MODEL.md — read it before promising a
#  buyer anything stronger.
# ============================================================================

def agent_home():
    return os.path.expanduser(os.environ.get("ENGINE_HOME", "~/agentsystem"))


def trust_store_path():
    return os.path.join(agent_home(), "system", "wake", KEYS_NAME)


def load_trusted_keys():
    """Pinned keys from the CENTRAL store only. Never from a candidate folder."""
    return load_publisher_keys(trust_store_path())


def trust_store_state():
    p = trust_store_path()
    keys = load_publisher_keys(p)
    return {"path": p, "exists": os.path.isfile(p), "key_ids": sorted(keys),
            "count": len(keys)}


def bootstrap_trust(candidate_keys_path):
    """Establish the central store once, from the first installation.

    Returns one of: "established" (store created), "present" (already
    established — the candidate is ignored), "empty" (nothing to pin, so this
    installation trusts no publisher), "failed".
    """
    dst = trust_store_path()
    if os.path.isfile(dst):
        # An editable source workspace deliberately has an empty trust store.
        # The first signed Builder product may establish trust there.  A store
        # that already contains any key is immutable to candidate packages.
        if load_publisher_keys(dst):
            return "present"
    try:
        src_keys = load_publisher_keys(candidate_keys_path)
    except Exception:
        src_keys = {}
    if not src_keys:
        return "empty"
    try:
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        payload = {"_comment": "Central publisher trust store. Established on first "
                               "install and not taken from any package afterwards.",
                   "established_at": __import__("datetime").datetime.now().isoformat(timespec="seconds"),
                   "keys": []}
        raw = json.load(open(candidate_keys_path, encoding="utf-8"))
        for rec in (raw.get("keys") or []):
            kid = str((rec or {}).get("key_id") or "").strip()
            if kid in src_keys:
                payload["keys"].append({"key_id": kid, "alg": "ed25519",
                                        "public_key": rec.get("public_key")})
        tmp = f"{dst}.{os.getpid()}.tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, ensure_ascii=False)
        try:
            if os.name == "posix":
                os.chmod(tmp, 0o400)
        except Exception:
            pass
        os.replace(tmp, dst)
        # Pin a copy of this verifier beside the store. Without it, deleting
        # active.json made the fallback load the CANDIDATE's verifier, which a
        # hostile package replaces with "return ok=True".
        try:
            _self = os.path.abspath(__file__)
            _pin = os.path.join(os.path.dirname(dst), "release_signing.py")
            if not os.path.isfile(_pin):
                _t = f"{_pin}.{os.getpid()}.tmp"
                with open(_t, "wb") as _o, open(_self, "rb") as _i:
                    _o.write(_i.read())
                try:
                    if os.name == "posix":
                        os.chmod(_t, 0o500)
                except Exception:
                    pass
                os.replace(_t, _pin)
        except Exception:
            pass
        return "established"
    except Exception:
        return "failed"
