# ============================================================================
#  file_parsers.py  —  wyciaganie CZYSTEGO TEKSTU z wgranych plikow
# ============================================================================
#  Po co: autoconfig ma czytac CV/projekty usera nie tylko jako wklejony tekst,
#  ale z realnego pliku (PDF, Word, ODT, RTF, TXT/MD). User wgrywa plik w UI,
#  panel przekazuje bajty tutaj, dostaje z powrotem tekst do budowy profilu.
#
#  ZASADA: MIEKKI IMPORT. Biblioteki (pypdf/python-docx/odfpy) sa opcjonalne.
#  Gdy ktoras brakuje — NIE crashujemy. Zwracamy czytelny komunikat z komenda
#  'pip install ...', zeby user wiedzial, co doinstalowac. TXT/MD/CSV dziala
#  zawsze (czysty stdlib), wiec profil da sie zbudowac nawet bez zadnej biblioteki.
#
#  Zwraca zawsze (text, note):
#    text — wyciagniety tekst ('' gdy sie nie udalo)
#    note — krotki opis do source-report ('resume.pdf: 8213 chars' / 'X: install pypdf')
# ============================================================================

import io, os, re, sys


def _install_hint(pkg):
    """Zwraca komunikat 'jak zainstalowac' dopasowany do systemu usera.
    Nie zakladamy, ze 'pip' jest w PATH — dajemy komende z tym samym interpreterem
    Pythona, ktory wlasnie dziala (sys.executable), plus wariant dla Windows."""
    py = sys.executable or "python3"
    if os.name == "nt":
        return (f"needs the {pkg} library — open Command Prompt and run:  "
                f'"{py}" -m pip install {pkg}')
    return (f"needs the {pkg} library — run:  {py} -m pip install {pkg}   "
            f"(on Debian/Ubuntu you may first need: sudo apt install python3-pip)")


def _ext(filename):
    return os.path.splitext(filename or "")[1].lower().lstrip(".")


def _from_pdf(raw, filename):
    try:
        import pypdf
    except Exception:
        return "", f"{filename}: PDF {_install_hint('pypdf')}"
    try:
        rd = pypdf.PdfReader(io.BytesIO(raw))
        pages = []
        for pg in rd.pages:
            t = pg.extract_text() or ""
            if t.strip():
                pages.append(t)
        text = "\n\n".join(pages).strip()
        if not text:
            return "", f"{filename}: PDF has no selectable text (scanned image? OCR needed)"
        return text, f"{filename}: {len(text)} chars read"
    except Exception as ex:
        return "", f"{filename}: could not read PDF ({str(ex)[:60]})"


def _from_docx(raw, filename):
    try:
        import docx
    except Exception:
        return "", f"{filename}: DOCX {_install_hint('python-docx')}"
    try:
        d = docx.Document(io.BytesIO(raw))
        parts = [p.text for p in d.paragraphs if p.text and p.text.strip()]
        # tabele tez niosa fakty (np. CV w tabeli)
        for tbl in d.tables:
            for row in tbl.rows:
                cells = [c.text.strip() for c in row.cells if c.text and c.text.strip()]
                if cells:
                    parts.append(" | ".join(cells))
        text = "\n".join(parts).strip()
        if not text:
            return "", f"{filename}: DOCX has no text"
        return text, f"{filename}: {len(text)} chars read"
    except Exception as ex:
        return "", f"{filename}: could not read DOCX ({str(ex)[:60]})"


def _from_odt(raw, filename):
    try:
        from odf.opendocument import load
        from odf import text as odftext, teletype
    except Exception:
        return "", f"{filename}: ODT {_install_hint('odfpy')}"
    try:
        doc = load(io.BytesIO(raw))
        paras = doc.getElementsByType(odftext.P)
        chunks = [teletype.extractText(p) for p in paras]
        text = "\n".join(c for c in chunks if c and c.strip()).strip()
        if not text:
            return "", f"{filename}: ODT has no text"
        return text, f"{filename}: {len(text)} chars read"
    except Exception as ex:
        return "", f"{filename}: could not read ODT ({str(ex)[:60]})"


def _from_rtf(raw, filename):
    # RTF bez biblioteki: zdejmij grupy kontrolne i \komendy. Prosto, ale skuteczne
    # dla zwyklego CV. Nie ruszamy tego zewnetrzna zaleznoscia.
    try:
        s = raw.decode("latin-1", "ignore")
        s = re.sub(r"\\'[0-9a-fA-F]{2}", " ", s)          # znaki hex
        s = re.sub(r"\\[a-zA-Z]+-?\d* ?", " ", s)          # komendy \b \fs24 itd.
        s = s.replace("{", " ").replace("}", " ")
        s = re.sub(r"[ \t]{2,}", " ", s)
        text = re.sub(r"\n{3,}", "\n\n", s).strip()
        if not text:
            return "", f"{filename}: RTF empty after cleanup"
        return text, f"{filename}: {len(text)} chars read"
    except Exception as ex:
        return "", f"{filename}: could not read RTF ({str(ex)[:60]})"


def _from_doc(raw, filename):
    """Stary binarny .doc (Word 97-2003). Nie ma dobrego czystego parsera w stdlib,
    ale zamiast twardo odrzucac — probujemy wyciagnac czytelny tekst. Jesli sie uda,
    user dostaje profil; jesli nie, mowimy wprost, zeby zapisal jako .docx/.txt."""
    # 1) sprobuj biblioteki, jesli user ma zainstalowana
    try:
        import textract  # opcjonalne
        text = textract.process(io.BytesIO(raw)).decode("utf-8", "ignore").strip()
        if text:
            return text, f"{filename}: {len(text)} chars read"
    except Exception:
        pass
    # 2) best-effort: wyciagnij czytelne ciagi z kontenera OLE (dziala dla wielu CV)
    try:
        s = raw.decode("latin-1", "ignore")
        runs = re.findall(r"[\x20-\x7e\xa0-\xff]{4,}", s)
        text = "\n".join(x.strip() for x in runs if len(x.strip()) >= 4)
        text = re.sub(r"\n{3,}", "\n\n", text).strip()
        if len(text) >= 40 and " " in text:
            return text, f"{filename}: {len(text)} chars read (best-effort .doc)"
    except Exception:
        pass
    return "", f"{filename}: old .doc format — save as .docx or .txt and re-upload for a clean read"


def _from_plain(raw, filename):
    for enc in ("utf-8", "utf-16", "latin-1"):
        try:
            text = raw.decode(enc).strip()
            if text:
                return text, f"{filename}: {len(text)} chars read"
        except Exception:
            continue
    return "", f"{filename}: could not decode text"


# ext -> handler. TXT/MD/CSV/LOG/JSON ida przez _from_plain (zawsze dziala).
_HANDLERS = {
    "pdf":  _from_pdf,
    "docx": _from_docx,
    "odt":  _from_odt,
    "rtf":  _from_rtf,
    "doc":  _from_doc,
}


def parse_file(raw_bytes, filename):
    """Wyciagnij tekst z JEDNEGO pliku. raw_bytes = bajty pliku, filename = nazwa
    (uzywana do rozpoznania typu po rozszerzeniu). Zwraca (text, note)."""
    if not raw_bytes:
        return "", f"{filename or 'file'}: empty"
    ext = _ext(filename)
    handler = _HANDLERS.get(ext, _from_plain)
    return handler(raw_bytes, filename or f"file.{ext or 'txt'}")


def parse_uploads(uploads):
    """Przerob liste wgranych plikow na (tekst, raport_zrodel).
    uploads = lista dictow {'name': str, 'b64': base64-tresc-pliku}.
    Zwraca (polaczony_tekst, lista_notatek) — spojne z fetch_materials."""
    import base64
    chunks, report = [], []
    for up in uploads or []:
        name = (up.get("name") or "file").strip()
        b64 = up.get("b64") or ""
        try:
            raw = base64.b64decode(b64)
        except Exception:
            report.append(f"{name}: could not decode upload")
            continue
        text, note = parse_file(raw, name)
        report.append(note)
        if text:
            chunks.append(f"--- from {name} ---\n{text}")
    return ("\n\n".join(chunks), report)
