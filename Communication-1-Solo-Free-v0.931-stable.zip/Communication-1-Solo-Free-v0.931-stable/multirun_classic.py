# ============================================================================
#  multirun.py — MACIERZ TESTOWA: jeden a-tool, wiele konfiguracji, obok siebie
# ============================================================================
#  PO CO: zanim sprzedasz, musisz wiedziec, czy AI faktycznie cos wnosi.
#  Ten modul odpala TEN SAM a-tool na TEJ SAMEJ poczcie w kilku trybach
#  i pokazuje roznice obok siebie:
#
#    script     — zero AI. Same reguly. Darmowe, natychmiastowe.
#    ai_fast    — AI streszcza (darmowy tier).
#    ai_hybrid  — AI streszcza + koryguje tagi + priorytet (z zabezpieczeniami).
#    ai_deep    — pelny kontekst, dluzsze streszczenia, bez limitu.
#
#  GENERYCZNE: dziala dla KAZDEGO a-toola. Nie ma tu nic o poczcie —
#  bierze profil, podmienia `outputs`, odpala, zbiera wynik.
#  Nowy a-tool dziala tu bez jednej linii zmiany.
#
#  PAMIEC: opcjonalnie wylaczana (no_memory=True), zeby porownac te same maile
#  w kazdym trybie — inaczej pierwszy run "zjadlby" poczte i reszta zobaczylaby zero.
# ============================================================================

import os, json, copy, time

# Predefiniowane tryby — to sa te "najwazniejsze techniczne kombinacje"
MODES = {
    "script": {
        "label": "Script only (no AI)",
        "note": "Rules alone. Free, instant, fully predictable. This is your baseline — "
                "if AI doesn't beat this, don't pay for AI.",
        "outputs": {"ai_level": "off", "ai_select_mode": "script",
                    "ai_priority": False, "summary_depth": "auto"},
    },
    "ai_fast": {
        "label": "AI summaries (free tier)",
        "note": "AI writes the summaries; the script still picks and ranks. "
                "This is the default a buyer gets.",
        "outputs": {"ai_level": "fast", "ai_select_mode": "script",
                    "ai_priority": False, "summary_depth": "auto"},
    },
    "ai_hybrid": {
        "label": "AI hybrid (AI fixes tags + priority)",
        "note": "AI also picks which mails matter and may nudge priority ±1 "
                "(guard rails on). The most 'intelligent' mode.",
        "outputs": {"ai_level": "fast", "ai_select_mode": "ai",
                    "ai_priority": True, "summary_depth": "auto"},
    },
    "ai_deep": {
        "label": "AI deep (paid / local, full context)",
        "note": "Full user profile in context, longer summaries, no 12-mail cap. "
                "Needs a paid key or a local model.",
        "outputs": {"ai_level": "deep", "ai_select_mode": "ai",
                    "ai_priority": True, "summary_depth": "detailed",
                    "background": True, "max_summaries": 999},
    },
}

# Dodatkowe przelaczniki, ktore mozna nalozyc na KAZDY tryb
FLAGS = {
    "scan_spam":   ("+ Spam folder",       {"scan_spam": True}),
    "scan_promo":  ("+ Promotions folder", {"scan_promo": True}),
    "show_social": ("+ Show social",       {"show_social": True}),
    "drafts":      ("+ Draft replies",     {"draft_replies": True}),
}


def _snapshot(name, data_dir):
    """Zbiera wynik runu do porownania — bez wchodzenia w szczegoly a-toola."""
    out = {"mails": 0, "important": 0, "tokens": 0, "summaries": 0,
           "priorities": {}, "tags": {}, "rows": []}
    p = os.path.join(data_dir, f"{name}_report.json")
    if not os.path.exists(p):
        return out
    try:
        rj = json.load(open(p, encoding="utf-8"))
    except Exception:
        return out
    import re
    note = str(rj.get("note", ""))
    m = re.search(r"AI summarized (\d+).*?~?(\d+)\s*tok", note)
    if m:
        out["summaries"] = int(m.group(1))
        out["tokens"] = int(m.group(2))
    for mb in rj.get("mailboxes", []):
        for r in mb.get("rows", []):
            out["mails"] += 1
            pri = r.get("priority", "?")
            out["priorities"][pri] = out["priorities"].get(pri, 0) + 1
            if pri in ("P1!", "P1", "P2"):
                out["important"] += 1
            for t in r.get("tags", []):
                out["tags"][t] = out["tags"].get(t, 0) + 1
            out["rows"].append({
                "from": r.get("from", ""), "title": r.get("title", "")[:60],
                "priority": pri, "summary": r.get("summary", "")[:160],
                "tags": r.get("tags", []), "mid": r.get("mid", ""),
            })
    return out


def run_matrix(profile, modes, flags=None, no_memory=True, log=None):
    """Odpala a-tool raz na kazdy tryb i zwraca porownanie.

      profile   — profil a-toola (dowolnego!)
      modes     — lista kluczy z MODES, np. ["script", "ai_fast", "ai_hybrid"]
      flags     — lista kluczy z FLAGS nakladanych na kazdy tryb
      no_memory — True: przed kazdym runem czysc pamiec "juz widzianych",
                  zeby kazdy tryb dostal TE SAME maile (inaczej porownanie
                  nie ma sensu — pierwszy run zjadlby poczte)
    """
    import engine as E
    name = profile["name"]
    results = {}
    seen_path = os.path.join(E.HOME, "data", f"{name}_seen.json")
    seen_backup = None
    if os.path.exists(seen_path):
        try:
            seen_backup = open(seen_path, encoding="utf-8").read()
        except Exception:
            pass

    try:
        prev_used_ai = False
        for idx, key in enumerate(modes):
            mode = MODES.get(key)
            if not mode:
                continue

            # PAUZA MIEDZY TRYBAMI Z AI.
            # Bez tego: 4 tryby x ~1600 tok = 6400 tok w 60s -> Groq HTTP 429,
            # trzeci i czwarty tryb dostawal "rate limit" i wracal pusty.
            # Pauzujemy TYLKO gdy poprzedni tryb faktycznie uzyl AI i nastepny tez uzyje.
            uses_ai = mode["outputs"].get("ai_level", "off") != "off"
            if prev_used_ai and uses_ai:
                # lokalny model (ollama) nie ma limitu minutowego — nie czekamy
                prov = (profile.get("llm", {}) or {}).get("provider", "")
                wait = 0 if prov == "ollama" else 65
                if wait:
                    if log:
                        log(f"multirun: waiting {wait}s before [{key}] — "
                            f"free tier resets its per-minute limit")
                    time.sleep(wait)

            prof = copy.deepcopy(profile)
            prof.setdefault("outputs", {}).update(mode["outputs"])
            for f in (flags or []):
                if f in FLAGS:
                    prof["outputs"].update(FLAGS[f][1])

            # PAMIEC: kazdy tryb ma widziec te same maile
            if no_memory and os.path.exists(seen_path):
                try:
                    os.remove(seen_path)
                except Exception:
                    pass

            t0 = time.time()
            try:
                if prof.get("kind") == "collector":
                    E.run_collector(prof)
                else:
                    E.run_reporter(prof)
                err = ""
            except Exception as ex:
                err = str(ex)[:120]
            snap = _snapshot(name, os.path.join(E.HOME, "data"))
            snap["elapsed"] = round(time.time() - t0, 1)
            snap["error"] = err
            snap["label"] = mode["label"]
            snap["note"] = mode["note"]
            # WYKRYJ RATE LIMIT — inaczej user widzi "0 tokenow" i mysli, ze AI nie dziala
            if uses_ai and snap["tokens"] == 0 and snap["summaries"] == 0:
                snap["error"] = snap["error"] or (
                    "the provider hit its per-minute limit — this mode returned script-only "
                    "results. Not a broken key. Use fewer modes at once, or a local model.")
            results[key] = snap
            prev_used_ai = uses_ai
            if log:
                log(f"multirun [{key}]: {snap['mails']} mails, "
                    f"{snap['important']} important, {snap['tokens']} tok, {snap['elapsed']}s")
    finally:
        # PRZYWROC pamiec — multirun nie moze zostawic a-toola w innym stanie
        if seen_backup is not None:
            try:
                open(seen_path, "w", encoding="utf-8").write(seen_backup)
            except Exception:
                pass
        elif os.path.exists(seen_path) and no_memory:
            try:
                os.remove(seen_path)
            except Exception:
                pass

    return {"modes": results, "diff": _diff(results)}


def _diff(results):
    """Co sie ROZNI miedzy trybami — tam siedzi odpowiedz, czy AI cokolwiek wnosi."""
    keys = list(results.keys())
    if len(keys) < 2:
        return {}
    base = results[keys[0]]
    by_mid = {}
    for k in keys:
        for r in results[k].get("rows", []):
            mid = r.get("mid") or (r["from"] + r["title"])
            by_mid.setdefault(mid, {})[k] = r
    changed = []
    for mid, per in by_mid.items():
        pris = {k: v["priority"] for k, v in per.items()}
        if len(set(pris.values())) > 1:
            any_row = list(per.values())[0]
            changed.append({"from": any_row["from"], "title": any_row["title"],
                            "priorities": pris,
                            "summaries": {k: v["summary"] for k, v in per.items()}})
    return {
        "priority_changed": changed[:25],
        "totals": {k: {"important": results[k]["important"],
                       "tokens": results[k]["tokens"],
                       "elapsed": results[k]["elapsed"]} for k in keys},
    }
