import security_net as SNET
# ============================================================================
#  connectors.py — ŹRÓDŁA JAKO PLUGINY
# ============================================================================
#  Problem który to rozwiązuje:
#  Silnik miał wpisane na sztywno "czytaj IMAP" i "czytaj RSS". Każdy nowy
#  a-tool (Legal Monitor, Grant Watcher) potrzebuje INNEGO źródła — dziennika
#  ustaw, portalu grantowego, API rządowego. Bez tego pliku trzeba by za każdym
#  razem grzebać w engine.py.
#
#  Teraz: nowy a-tool = nowy connector w tym pliku. Silnik się NIE ZMIENIA.
#
#  KONTRAKT — każdy connector zwraca listę wiadomości w JEDNYM formacie:
#    {
#      "mid":   unikalny identyfikator (do deduplikacji)   [wymagane]
#      "src":   z jakiego źródła (mailbox / url / nazwa)   [wymagane]
#      "from":  kto to nadał / autor / instytucja          [wymagane]
#      "title": temat / tytuł / nagłówek                   [wymagane]
#      "body":  treść (już jako czysty tekst)              [wymagane]
#      "date":  data, krótki format                        [opcjonalne]
#      "bulk":  True jeśli masówka (newsletter itp.)       [opcjonalne]
#      "attach": lista nazw załączników                    [opcjonalne]
#      "meta":  cokolwiek specyficznego dla źródła         [opcjonalne]
#    }
#
#  Dzięki temu KAŻDY a-tool używa tej samej klasyfikacji, tagów, priorytetów,
#  AI, kalendarza i raportów. Zmienia się tylko to, SKĄD leci strumień.
# ============================================================================

import os, re, json, hashlib, urllib.request, urllib.parse

REGISTRY = {}


def connector(kind, label, fields, note=""):
    """Dekorator rejestrujący connector.
      kind   — klucz techniczny ('imap', 'rss', 'web', 'api')
      label  — nazwa widoczna w UI
      fields — jakie pola konfiguracji potrzebuje (panel generuje je SAM)
      note   — podpowiedź dla użytkownika
    """
    def deco(fn):
        REGISTRY[kind] = {"kind": kind, "label": label, "fields": fields,
                          "note": note, "fn": fn}
        return fn
    return deco


def read_source(kind, cfg, limit=50, log=None):
    """Jedno wejście dla silnika. Silnik nie wie i nie musi wiedzieć,
    czy to poczta, RSS czy scrapowany dziennik ustaw."""
    c = REGISTRY.get(kind)
    if not c:
        if log:
            log(f"nieznany typ zrodla: {kind}")
        return []
    try:
        return c["fn"](cfg, limit, log) or []
    except Exception as e:
        if log:
            log(f"{kind} blad: {e}")
        return []


def _mid(*parts):
    """Stabilny identyfikator — ta sama pozycja nie zostanie zgłoszona dwa razy."""
    return hashlib.sha1("|".join(str(p) for p in parts).encode("utf-8",
                                                                "ignore")).hexdigest()[:16]


def _fetch(url, timeout=25, allow_private=False):
    raw, _final, _headers = SNET.open_public_url(
        url, timeout=timeout, max_bytes=5_000_000,
        headers={"User-Agent": "Mozilla/5.0 (compatible; Locally4Me-atool/1.0)"},
        allow_private=bool(allow_private))
    try:
        return raw.decode("utf-8", "ignore")
    except Exception:
        return raw.decode("latin-1", "ignore")


def _html_text(html):
    h = re.sub(r"(?is)<(script|style|head|nav|footer).*?</\1>", " ", html)
    h = re.sub(r"(?i)<br\s*/?>", "\n", h)
    h = re.sub(r"(?i)</(p|div|tr|li|h[1-6])>", "\n", h)
    h = re.sub(r"<[^>]+>", " ", h)
    import html as _h
    h = _h.unescape(h)
    h = re.sub(r"[ \t]+", " ", h)
    return re.sub(r"\n\s*\n+", "\n", h).strip()


# ── IMAP ────────────────────────────────────────────────────────────────────
@connector("imap", "Mailbox (IMAP)",
           fields=[("host", "IMAP server", "imap.gmail.com"),
                   ("user", "Login", "you@gmail.com"),
                   ("password", "Password", "app password for Gmail"),
                   ("priority", "Priority 1-5", "3")],
           note="Any IMAP server. Gmail needs a 16-char App Password (2FA on). "
                "o2.pl: login WITHOUT @o2.pl.")
def _imap(cfg, limit, log=None):
    """Poczta. Deleguje do engine.read_imap — zachowujemy jedną implementację."""
    import engine as E
    return E.read_imap(cfg, limit, cfg.get("_name", "reporter"), None,
                       scan_spam=cfg.get("scan_spam", False),
                       scan_promo=cfg.get("scan_promo", False))


# ── RSS / ATOM ──────────────────────────────────────────────────────────────
@connector("rss", "Feed (RSS / Atom)",
           fields=[("url", "Feed URL", "https://example.com/feed"),
                   ("priority", "Priority 1-5", "3")],
           note="Reddit: https://reddit.com/r/NAME/.rss · most blogs and portals "
                "have /feed or /.rss")
def _rss(cfg, limit, log=None):
    import engine as E
    url = cfg["url"] if isinstance(cfg, dict) else cfg
    return E.read_feed(url, limit, cfg.get("_name", "reporter") if isinstance(cfg, dict) else "reporter")


# ── WEB PAGE (scrape) ───────────────────────────────────────────────────────
@connector("web", "Web page (no feed)",
           fields=[("url", "Page URL", "https://dziennikustaw.gov.pl/DU"),
                   ("item_pattern", "Link pattern (regex)", r"/DU/\d{4}/\d+"),
                   ("priority", "Priority 1-5", "3")],
           note="For sites WITHOUT an RSS feed — official gazettes, government "
                "portals, tender boards. It reads the page, follows links matching "
                "your pattern, and treats each as an item.")
def _web(cfg, limit, log=None):
    """Strony bez RSS — dziennik ustaw, portale rządowe, tablice przetargowe.
    TO JEST connector dla Legal Monitora: dziennik ustaw NIE MA RSS."""
    url = cfg["url"]
    pat = cfg.get("item_pattern") or r"https?://[^\s\"']+"
    out = []
    try:
        page = _fetch(url, allow_private=bool(cfg.get("allow_private_network", False)))
    except Exception as e:
        if log:
            log(f"web {url}: {e}")
        return []
    base = "{0.scheme}://{0.netloc}".format(urllib.parse.urlsplit(url))
    links = []
    for m in re.finditer(r'href=["\']([^"\']+)["\']', page, re.I):
        href = m.group(1)
        if re.search(pat, href):
            links.append(href if href.startswith("http") else base + href)
    seen = set()
    for href in links[:limit]:
        if href in seen:
            continue
        seen.add(href)
        try:
            sub = _fetch(href, allow_private=bool(cfg.get("allow_private_network", False)))
        except Exception:
            continue
        text = _html_text(sub)
        tm = re.search(r"(?is)<title[^>]*>(.*?)</title>", sub)
        title = _html_text(tm.group(1)) if tm else href.rsplit("/", 1)[-1]
        out.append({"mid": _mid(href), "src": url, "from": urllib.parse.urlsplit(href).netloc,
                    "title": title[:200], "body": text[:4000], "bulk": False,
                    "meta": {"url": href}})
    return out


# ── JSON API ────────────────────────────────────────────────────────────────
@connector("api", "JSON API",
           fields=[("url", "API endpoint", "https://api.example.gov/calls?status=open"),
                   ("items_path", "Path to the list", "results"),
                   ("map_title", "Field for the title", "title"),
                   ("map_body", "Field for the text", "description"),
                   ("map_id", "Field for the id", "id"),
                   ("priority", "Priority 1-5", "3")],
           note="For portals with an open API — EU Funding & Tenders, national grant "
                "registries. You tell it which fields to use; it does the rest.")
def _api(cfg, limit, log=None):
    """Otwarte API — portale grantowe, rejestry. TO JEST connector dla Grant Watchera."""
    try:
        data = json.loads(_fetch(cfg["url"], allow_private=bool(cfg.get("allow_private_network", False))))
    except Exception as e:
        if log:
            log(f"api {cfg.get('url')}: {e}")
        return []
    node = data
    for key in (cfg.get("items_path") or "").split("."):
        if key and isinstance(node, dict):
            node = node.get(key, [])
    if not isinstance(node, list):
        node = [node] if node else []
    out = []
    for it in node[:limit]:
        if not isinstance(it, dict):
            continue
        title = str(it.get(cfg.get("map_title", "title"), ""))[:200]
        body = str(it.get(cfg.get("map_body", "description"), ""))[:4000]
        rid = str(it.get(cfg.get("map_id", "id"), "")) or _mid(title, body[:80])
        out.append({"mid": _mid(cfg["url"], rid), "src": cfg["url"],
                    "from": urllib.parse.urlsplit(cfg["url"]).netloc,
                    "title": title, "body": body, "bulk": False, "meta": it})
    return out


def ui_schema():
    """Panel generuje formularze SAM z tego opisu — nie trzeba dopisywać HTML
    dla każdego nowego typu źródła. To jest sedno: dodajesz connector, UI się
    pojawia samo."""
    return [{"kind": c["kind"], "label": c["label"], "note": c["note"],
             "fields": [{"key": k, "label": l, "hint": h} for k, l, h in c["fields"]]}
            for c in REGISTRY.values()]
