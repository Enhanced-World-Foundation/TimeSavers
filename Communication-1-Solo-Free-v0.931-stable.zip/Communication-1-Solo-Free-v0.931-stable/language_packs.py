#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# file-version: 0.930 | updated: 2026-09-14
"""Validated, data-only translation pack loader.

Filename contract: ``<tool>.<lang>.transl.<file-version>.json``.
The file version is the engine version current when that pack last changed.
Broken, mismatched or incompatible packs are ignored; built-in EN remains safe.
"""

import json
import os
import re
from functools import lru_cache

HERE = os.path.dirname(os.path.abspath(__file__))
PACK_DIR = os.path.join(HERE, "transl")
TOOL_SLUG = "communication-manager"
_LANG_RE = re.compile(r"^[a-z]{2,3}(?:-[a-z0-9]{2,8})?$")
_VERSION_RE = re.compile(r"^[0-9]+(?:\.[0-9]+)*$")


def pack_filename(language, version, tool=TOOL_SLUG):
    language = str(language or "").strip().lower()
    version = str(version or "").strip()
    tool = str(tool or "").strip().lower()
    if not _LANG_RE.match(language):
        raise ValueError("invalid language code")
    if not re.match(r"^[a-z0-9_-]+$", tool) or not re.match(r"^[0-9a-zA-Z._-]+$", version):
        raise ValueError("invalid tool/version")
    return f"{tool}.{language}.transl.{version}.json"


def _version_key(version):
    """Comparable numeric release key; trailing zero components are immaterial."""
    value = str(version or "").strip()
    if not _VERSION_RE.fullmatch(value):
        return None
    parts = [int(part) for part in value.split(".")]
    while len(parts) > 1 and parts[-1] == 0:
        parts.pop()
    return tuple(parts)


def _compatible(pack_version, engine_version):
    pack_key, engine_key = _version_key(pack_version), _version_key(engine_version)
    if pack_key is None or engine_key is None:
        return str(pack_version) == str(engine_version)
    width = max(len(pack_key), len(engine_key))
    return pack_key + (0,) * (width - len(pack_key)) <= engine_key + (0,) * (width - len(engine_key))


@lru_cache(maxsize=64)
def _read_cached(path, mtime_ns):
    del mtime_ns
    with open(path, encoding="utf-8") as fh:
        return json.load(fh)


def _load_exact(language, pack_version, tool):
    try:
        path = os.path.join(PACK_DIR, pack_filename(language, pack_version, tool))
        data = _read_cached(path, os.stat(path).st_mtime_ns)
        if not isinstance(data, dict) or not isinstance(data.get("_meta"), dict):
            return None
        meta = data["_meta"]
        expected = {"tool": tool, "tool_version": str(pack_version),
                    "language": str(language).lower()}
        if any(str(meta.get(key, "")).lower() != str(value).lower()
               for key, value in expected.items()):
            return None
        if int(meta.get("schema", 0) or 0) != 1:
            return None
        for name in ("ui", "help", "report", "tags"):
            if name in data and not isinstance(data[name], dict):
                return None
        return data
    except (OSError, ValueError, TypeError, json.JSONDecodeError):
        return None


def _candidates(language, engine_version, tool):
    """Newest compatible filenames first; a bad newest file may fall back safely."""
    prefix, suffix = f"{tool}.{language}.transl.", ".json"
    try:
        names = os.listdir(PACK_DIR)
    except OSError:
        return []
    found = []
    for filename in names:
        if not (filename.startswith(prefix) and filename.endswith(suffix)):
            continue
        pack_version = filename[len(prefix):-len(suffix)]
        key = _version_key(pack_version)
        if key is not None and _compatible(pack_version, engine_version):
            found.append((key, pack_version))
        elif pack_version == str(engine_version):
            found.append(((0,), pack_version))
    return [version for _, version in sorted(found, reverse=True)]


def load_pack(language, version, tool=TOOL_SLUG):
    """Return the newest validated pack compatible with this engine version."""
    language = str(language or "").strip().lower()
    tool = str(tool or "").strip().lower()
    # English is the fail-safe copy embedded in ui-frame.js / HTML. Never let
    # an external EN file override it or become required by the panel.
    if language == "en":
        return None
    if not _LANG_RE.match(language) or not re.match(r"^[a-z0-9_-]+$", tool):
        return None
    for pack_version in _candidates(language, version, tool):
        pack = _load_exact(language, pack_version, tool)
        if pack is not None:
            return pack
    return None


def section(language, version, name, tool=TOOL_SLUG):
    pack = load_pack(language, version, tool) or {}
    value = pack.get(name)
    return dict(value) if isinstance(value, dict) else {}


def complete_languages(version, tool=TOOL_SLUG):
    """Only complete, valid packs may become whole-panel languages."""
    out = []
    try:
        names = os.listdir(PACK_DIR)
    except OSError:
        return out
    prefix = tool + "."
    languages = set()
    for filename in sorted(names):
        if not (filename.startswith(prefix) and filename.endswith(".json") and ".transl." in filename):
            continue
        language = filename[len(prefix):].split(".transl.", 1)[0]
        if language != "en" and _LANG_RE.match(language):
            languages.add(language)
    for language in sorted(languages):
        pack = load_pack(language, version, tool)
        meta = (pack or {}).get("_meta") or {}
        if pack and meta.get("complete") is True and all(
                isinstance(pack.get(name), dict) for name in ("ui", "help", "report")):
            out.append(language)
    return out
