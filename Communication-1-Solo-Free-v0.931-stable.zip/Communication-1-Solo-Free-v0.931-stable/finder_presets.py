# ============================================================================
#  finder_presets.py — TEMATY DLA FINDERA
# ============================================================================
#  Finder to Reporter na odwrót: Reporter czyta, co PRZYSZŁO. Finder szuka,
#  czego JESZCZE NIE MASZ.
#
#  Każdy preset = jeden temat (gig, granty, fora, ogłoszenia, kancelarie...).
#  Każdy ma:
#    - własne pola edycji (jak zakładki w Reporterze)
#    - własne źródła (skąd szukać)
#    - własne słowa kluczowe (co jest dobrym trafieniem)
#    - własny szablon zgłoszenia/postu
#
#  GENERYCZNE: dodajesz preset tutaj → pojawia się w UI z własnymi polami.
#  Zero zmian w panelu, zero zmian w silniku.
# ============================================================================

PRESETS = {

"gig_platforms": {
    "label": "Gig / AI-training platforms",
    "note": "Places that pay per hour for judging AI output, annotation, or language work. "
            "You apply once, then get task queues.",
    "source_file": "platforms.json",
    "source_category": "gig_ai_training",
    "fields": [
        ("languages", "Languages you can work in", "Polish (native), English (fluent), German (B2)",
         "They route work by language pair. This is often the single highest-value field."),
        ("expertise", "Domains you can judge", "software engineering, Python, AI agents, LLM evaluation",
         "Coding and STEM queues pay 2-3x the base rate. Claim what you can actually defend."),
        ("hours", "Hours per week you can commit", "10-15",
         "Be honest. Most are flexible; overcommitting gets you dropped."),
        ("payout", "Payout method you have", "PayPal, bank transfer (EU)",
         "Some are PayPal-only. Check before you spend an hour on the assessment."),
    ],
    "apply_style": "Short, factual, technical. They want proof you can reason and write. "
                   "No enthusiasm — evidence.",
},

"dev_communities": {
    "label": "Developer communities (get users, not pay)",
    "note": "Where your first buyers actually are. Post the PROBLEM you solved, never the product.",
    "source_file": "platforms.json",
    "source_category": "dev_communities",
    "fields": [
        ("angle", "Your one-sentence hook", "Local-first email triage that works with the AI turned off",
         "This sentence IS your marketing. It must name the pain and the difference in one breath."),
        ("proof", "What you can show", "90-second demo video, screenshots, free edition",
         "No community accepts a bare link. You need something to look at."),
        ("story", "Why you built it", "My inbox was making me anxious and every AI tool wanted my password in their cloud",
         "Honest origin story outperforms any feature list. Indie Hackers and HN reward this."),
    ],
    "apply_style": "Blunt, honest, technical. State the limits before they find them. "
                   "Never write like a launch announcement.",
},

"grants": {
    "label": "Grants & non-dilutive funding",
    "note": "Money that does not take your equity. Estonian entity + local-first/privacy angle "
            "is a strong fit for EU programmes.",
    "source_file": "platforms.json",
    "source_category": "pro_bono_activist",
    "fields": [
        ("entity", "Your legal entity", "Locally4Me Group OÜ (Estonia), Enhanced.World Foundation (NL)",
         "Country of registration decides which programmes you may apply to. Estonia = full EU access."),
        ("angle", "Why your work fits their remit", "Privacy-preserving, local-first AI tooling; "
                                                    "user keeps control of their data",
         "NGI/NLnet fund exactly this. Say it in their words, not yours."),
        ("ask", "How much, and for what", "€15k — 6 months to build and open-source the agent framework",
         "Small, specific asks get funded. Vague big ones do not."),
        ("open_source", "What you would open-source", "the engine + one a-tool",
         "Most EU tech grants require an open component. Decide which part you can give away."),
    ],
    "apply_style": "Concrete, modest, verifiable. Name the deliverable and the date. "
                   "No hype — reviewers read hundreds of these.",
},

"job_boards": {
    "label": "Job boards & classifieds (post offers)",
    "note": "Where you post what you offer — services, tools, collaboration.",
    "source_file": "platforms.json",
    "source_category": "listing_portals",
    "fields": [
        ("offer", "What exactly you sell", "Local-first agent tools; custom a-tools for a client's workflow",
         "One clear offer beats three vague ones."),
        ("price", "Price or range", "Tools $15-25; custom builds from €500",
         "Post a number. 'Contact for pricing' halves your responses."),
        ("region", "Where you can work", "Remote, EU (Germany/Estonia)",
         "Some boards filter by region. Say it explicitly."),
    ],
    "apply_style": "Plain and specific. What it is, what it costs, who it is for.",
},

"legal_firms": {
    "label": "Law firms & compliance (B2B outreach)",
    "note": "For selling the Legal Monitor later. Build the list now; contact when the tool exists.",
    "source_file": "",
    "source_category": "",
    "fields": [
        ("countries", "Which countries' law you monitor", "Poland, Germany",
         "Each country needs its own gazette connector. Two is a realistic start."),
        ("areas", "Legal areas", "commercial law, data protection, employment",
         "Firms subscribe by area. Narrow beats broad."),
        ("firm_size", "Who you target", "small firms (2-15 lawyers), in-house counsel",
         "Big firms have their own tools. Small ones pay a junior to read gazettes — that is your wedge."),
        ("pitch", "Your one line to them", "Stop paying a junior to read the gazette. Get the changes that "
                                           "matter to your practice, every morning.",
         "Lead with the cost you remove, not the technology you use."),
    ],
    "apply_style": "Professional, short, no jargon. They buy time back, not AI.",
},

}


def get(key):
    return PRESETS.get(key)


def all_presets():
    return [{"key": k, "label": v["label"], "note": v["note"],
             "fields": [{"key": f[0], "label": f[1], "example": f[2], "hint": f[3]}
                        for f in v["fields"]]}
            for k, v in PRESETS.items()]
