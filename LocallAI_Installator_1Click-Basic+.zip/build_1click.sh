#!/usr/bin/env bash
# ============================================================
#  Build 1-Click LocalAI -> jedna binarka (bez Pythona u klienta)
#  Wymaga: Python + pip install pyinstaller  (tylko na TWOIM PC)
#  Uruchom NA DOCELOWEJ platformie (Linux buduje Linux, Mac buduje Mac).
# ============================================================
set -e

if ! command -v pyinstaller >/dev/null 2>&1; then
  echo "[*] Instaluje PyInstaller..."
  pip install pyinstaller || pip3 install pyinstaller
fi

echo "[*] Buduje atool_1click ..."
pyinstaller --onefile --console \
  --name "atool_1click" \
  --hidden-import _lang \
  --add-data "_lang.py:." \
  atool_1click.py

echo
echo "[+] GOTOWE: dist/atool_1click"
echo "    Obok binarki (opcjonalnie) dorzuc: runtime/ oraz 1.png 2.png 3.png"
