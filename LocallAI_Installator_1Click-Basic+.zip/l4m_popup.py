#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
l4m_popup.py - UNIWERSALNY popup dla calej rodziny 1-Click (Locally4Me).

Ten sam popup we wszystkich produktach: LocalAI, Knowledge Downloader itd.
Wrzuc ten plik OBOK glownego skryptu 1-clicka i zawolaj:

    import l4m_popup
    l4m_popup.show(lang="pl")          # albo lang="en"; brak -> auto

Popup NATYWNY (tkinter) tam gdzie sie da - zamyka sie przyciskiem naprawde.
Gdy tkinter niedostepny (np. Linux bez python3-tk) -> fallback do przegladarki.

Zaleznosci: TYLKO standardowa biblioteka. Zero pip install.
Obrazki 1.png/2.png/3.png (opcjonalne) - klatki animacji, leza obok tego pliku
lub obok glownego programu (podaj base_dir jesli inny katalog).
"""
import os, sys

# domyslne linki - edytuj tu RAZ, dziala we wszystkich produktach
DEFAULT_LINKS = [
    ("Karol's Own: Time Saving Digital Tools | Ko-Fi Marketplace", "https://ko-fi.com/4community/shop"),
    ("Essential Crisis Software Open-Source Initiative", "https://enhanced.world/ecs/"),
    ("Locally4Me Karol's Startup", "https://locally4me.org"),
]

ANIM_INTERVAL_MS = 8393   # celowo dlugi: obrazki nie rozpraszaja

# teksty EN baza, PL opcja. Latwo dodac kolejne jezyki - dopisz klucz.
TEXTS = {
    "head":  {"en": "Essential Crisis Software Initiative!",
              "pl": "Inicjatywa Essential Crisis Software!"},
    "l1":    {"en": "Let's code system that save lives!",
              "pl": ""},
    "l2":    {"en": "or checkout my other projects: 1. L4M an community ecosystem, 2-3. Information Protection & Cyber-physical validation formats",
              "pl": "lub sprawdż moje inne projekty: 1. L4M ekosystem społecznościowy, 2-4. Ochrona Informacji & formaty walidacji cyfrowo-fizyczne"},
    "l3":    {"en": "Consider supporting the projects. Be blessed!",
              "pl": "Wesprzyj naszą misję i prace:)"},
    "close": {"en": "Close", "pl": "Zamknij"},
    "hint":  {"en": "If it does not close, close it manually (Ctrl+W).",
              "pl": "Jesli okno sie nie zamknie, zamknij je ręcznie (Ctrl+W)."},
}


def _auto_lang():
    import locale
    env = os.environ.get("L4M_LANG", "").lower()
    if env in TEXTS["head"]:
        return env
    probe = ""
    for var in ("LC_ALL", "LC_MESSAGES", "LANG", "LANGUAGE"):
        probe = os.environ.get(var, "")
        if probe:
            break
    if not probe:
        try:
            probe = (locale.getlocale()[0] or "") or (locale.getdefaultlocale()[0] or "")
        except Exception:
            probe = ""
    probe = probe.lower()
    return "pl" if probe.startswith("pl") else "en"


def _t(key, lang):
    d = TEXTS.get(key, {})
    return d.get(lang) or d.get("en") or key


def _has_gui_session():
    if sys.platform.startswith("win") or sys.platform == "darwin":
        return True
    return bool(os.environ.get("DISPLAY") or os.environ.get("WAYLAND_DISPLAY"))


def show(lang=None, links=None, base_dir=None):
    """Glowna funkcja. lang: 'en'/'pl'/None(auto). links: nadpisz DEFAULT_LINKS.
    base_dir: gdzie szukac 1.png/2.png/3.png (domyslnie katalog tego pliku)."""
    lang = lang or _auto_lang()
    links = links or DEFAULT_LINKS
    base_dir = base_dir or os.path.dirname(os.path.abspath(__file__))
    try:
        import tkinter  # noqa
        if _has_gui_session():
            _show_tk(lang, links, base_dir)
            return
    except Exception:
        pass
    _show_browser(lang, links, base_dir)


def _show_tk(lang, links, base_dir):
    import tkinter as tk
    import webbrowser as _wb
    root = tk.Tk()
    root.title("Practical Tools")
    root.configure(bg="#f3f4f6")
    root.resizable(False, False)
    root.attributes("-topmost", True)

    frame = tk.Frame(root, bg="#f3f4f6", padx=22, pady=20)
    frame.pack(fill="both", expand=True)
    tk.Label(frame, text=_t("head", lang), font=("Segoe UI", 15, "bold"),
             bg="#f3f4f6", fg="#111827").pack(anchor="w", pady=(0, 12))

    frames = []
    try:
        for n in ("1.png", "2.png", "3.png"):
            p = os.path.join(base_dir, n)
            if os.path.exists(p):
                frames.append(tk.PhotoImage(file=p))
    except Exception:
        frames = []
    if frames:
        img_lbl = tk.Label(frame, image=frames[0], bg="#f3f4f6")
        img_lbl.image = frames
        img_lbl.pack(pady=(0, 12))
        if len(frames) > 1:
            state = {"i": 0}
            def _tick():
                if not root.winfo_exists():
                    return
                state["i"] = (state["i"] + 1) % len(frames)
                img_lbl.configure(image=frames[state["i"]])
                root.after(ANIM_INTERVAL_MS, _tick)
            root.after(ANIM_INTERVAL_MS, _tick)

    for key in ("l1", "l2", "l3"):
        tk.Label(frame, text=_t(key, lang), font=("Segoe UI", 10), bg="#f3f4f6",
                 fg="#374151", justify="left", anchor="w",
                 wraplength=520).pack(anchor="w", pady=1)

    tk.Frame(frame, bg="#d1d5db", height=1).pack(fill="x", pady=12)
    for label_text, url in links:
        lk = tk.Label(frame, text=label_text, fg="#2563eb", bg="#f3f4f6",
                      cursor="hand2", font=("Segoe UI", 10, "underline"), anchor="w")
        lk.pack(anchor="w", pady=2)
        lk.bind("<Button-1>", lambda _e, u=url: _wb.open(u))

    tk.Label(frame, text=_t("hint", lang), font=("Segoe UI", 8), bg="#f3f4f6",
             fg="#9ca3af").pack(anchor="w", pady=(10, 4))
    tk.Button(frame, text=_t("close", lang), width=14, font=("Segoe UI", 10, "bold"),
              command=root.destroy).pack(anchor="e", pady=(4, 0))

    root.update_idletasks()
    w, h = root.winfo_width(), root.winfo_height()
    x = (root.winfo_screenwidth() // 2) - (w // 2)
    y = (root.winfo_screenheight() // 2) - (h // 2)
    root.geometry(f"+{x}+{y}")
    root.protocol("WM_DELETE_WINDOW", root.destroy)
    root.mainloop()


def _show_browser(lang, links, base_dir):
    import tempfile, html as _html, webbrowser
    t_head = _t("head", lang)
    t_intro = _t("l1", lang) + "<br>" + _t("l2", lang) + "<br>" + _html.escape(_t("l3", lang))
    t_close = _t("close", lang)
    t_hint = _t("hint", lang)

    imgs = [os.path.join(base_dir, n) for n in ("1.png", "2.png", "3.png")]
    imgs = [p for p in imgs if os.path.exists(p)]
    img_tags = ""
    if imgs:
        srcs = ",".join('"file://' + p.replace("\\", "/") + '"' for p in imgs)
        img_tags = (f'<img id="anim" src="file://{imgs[0]}" style="width:240px;'
                    f'height:auto;max-width:100%;display:block;margin:0 auto 14px;'
                    f'border-radius:8px">'
                    f'<script>var _f=[{srcs}],_i=0;if(_f.length>1)setInterval('
                    f'function(){{_i=(_i+1)%_f.length;'
                    f"document.getElementById('anim').src=_f[_i];}},{ANIM_INTERVAL_MS});</script>")
    links_html = "".join(
        f'<a href="{_html.escape(u)}" target="_blank" style="display:block;'
        f'margin:8px 0;color:#2563eb;font-weight:600;text-decoration:none;'
        f'word-break:break-word">{_html.escape(lbl)}</a>' for lbl, u in links)

    page = f'''<!doctype html><html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Practical Tools</title></head>
<body style="margin:0;padding:20px;box-sizing:border-box;background:#111827;
     font-family:Segoe UI,system-ui,sans-serif;min-height:100vh">
<div style="max-width:640px;width:100%;margin:0 auto;background:#f3f4f6;
     border-radius:14px;padding:28px;box-sizing:border-box;
     box-shadow:0 20px 60px #0009;overflow-wrap:break-word">
  <h2 style="margin:0 0 14px;color:#111827">{t_head}</h2>
  {img_tags}
  <div style="color:#374151;font-size:15px;line-height:1.6;margin-bottom:16px">
    {t_intro}
  </div>
  <div style="border-top:1px solid #d1d5db;padding-top:14px">{links_html}</div>
  <div style="margin-top:22px;display:flex;gap:12px;align-items:center;flex-wrap:wrap">
    <button onclick="try{{window.close();}}catch(e){{}};window.open('','_self');window.close();"
       style="padding:10px 22px;border:0;border-radius:8px;background:#2563eb;
       color:#fff;font-weight:700;font-size:15px;cursor:pointer">{t_close}</button>
    <span style="color:#6b7280;font-size:13px">{t_hint}</span>
  </div>
</div>
</body></html>'''
    fd, path = tempfile.mkstemp(suffix=".html", prefix="l4m_popup_")
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        f.write(page)
    webbrowser.open("file://" + path)


if __name__ == "__main__":
    # test: python3 l4m_popup.py        -> auto jezyk
    #       python3 l4m_popup.py pl      -> wymus PL
    lang = sys.argv[1] if len(sys.argv) > 1 else None
    show(lang=lang)
