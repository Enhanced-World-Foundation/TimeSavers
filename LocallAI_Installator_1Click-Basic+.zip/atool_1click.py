#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
A-Tool 1-Click LocalAI Installer  (Windows / Linux / macOS, jeden plik)

CO ROBI SAM:
  Odlicza 17 s. Jak NIC nie wcisniesz -> instaluje z USB/ZIP (offline).
  Instaluje Ollame -> laduje model -> testuje -> mierzy REALNE tok/s (Ollama API)
  -> wykrywa RAM/GPU/VRAM (uczciwie) -> zapisuje runtime.json + benchmark.json
  -> pokazuje jak podpiac do A-Tool -> popup z linkami PRZY ZAMKNIECIU.

KLAWISZE w trakcie odliczania (nieobowiazkowe):
  [Enter] / nic -> USB offline (domyslnie)
  O             -> Online (pobiera z netu)
  3             -> tylko sprawdz komputer + rekomendacja

Zaleznosci: TYLKO standardowa biblioteka Pythona. Zadnego pip install.

Pliki obok programu (opcjonalne):
  runtime/                 - instalatory + modele do trybu offline
  1.png 2.png 3.png        - klatki animacji w popupie (jak brak -> bez obrazka)

Budowa binarki dla LAIKA (bez Pythona) - uruchom na DANEJ platformie:
  Windows : build_1click.bat   -> dist\\A-Tool LocalAI.exe
  Linux   : ./build_1click.sh   -> dist/atool_1click
  macOS   : ./build_1click.sh   -> dist/atool_1click
"""
import json, os, shutil, subprocess, sys, threading, time, urllib.request

try:
    import _lang
    _t = _lang.t
except Exception:                       # awaryjnie: brak _lang.py -> teksty EN wprost
    class _L:
        LANG = "en"
        def set_lang(self, c): pass
    _lang = _L()
    def _t(key, **kw): return key       # zwroci klucz; dziala, choc brzydko

# ---- USTAWIENIA (edytuj tylko tu) -----------------------------------------
DEFAULT_MODEL_TAG   = "qwen2.5:7b"     # nazwa w ollamie
DEFAULT_GGUF        = "qwen2.5.gguf"   # plik na USB (tryb offline)
COUNTDOWN_SECONDS   = 17
SHOW_POPUP          = True             # popup z linkami PRZY zamknieciu (False = wylacz)
POPUP_IDLE_SECONDS  = 120              # jak user zostawi okno otwarte -> popup po tylu s
ANIM_INTERVAL_MS    = 8393             # celowo dlugi: obrazki nie rozpraszaja
# ---------------------------------------------------------------------------

WIN = sys.platform.startswith("win")
MAC = sys.platform == "darwin"
LIN = sys.platform.startswith("linux")

HERE = os.path.dirname(os.path.abspath(
    sys.executable if getattr(sys, "frozen", False) else __file__))
CFG        = os.path.join(HERE, "runtime.json")
BENCH_JSON = os.path.join(HERE, "benchmark.json")
USB        = os.path.join(HERE, "runtime")
NAME       = DEFAULT_MODEL_TAG.split(":")[0]
OLLAMA_HOST = "http://localhost:11434"

MODEL_PRESETS = {
    "1": "qwen2.5:1.5b",
    "3": "qwen2.5:3b",
    "7": "qwen2.5:7b",
    "x": "qwen2.5:14b",
}

OFFLINE_GGUF_MAP = {
    "qwen2.5:1.5b": "qwen2.5-1.5b.gguf",
    "qwen2.5:3b": "qwen2.5-3b.gguf",
    "qwen2.5:7b": "qwen2.5.gguf",
    "qwen2.5:14b": "qwen2.5-14b.gguf",
    "mistral-nemo:12b": "mistral-nemo-12b.gguf",
}

def sh(cmd, cap=False):
    r = subprocess.run(cmd, shell=True, text=True, capture_output=cap)
    return (r.stdout or "") if cap else r.returncode

# ---- ODLICZANIE (cross-platform) ------------------------------------------
def _read_key_nonblocking_win():
    import msvcrt
    if msvcrt.kbhit():
        return msvcrt.getch().decode(errors="ignore").lower()
    return None

def _read_key_nonblocking_unix():
    import select
    dr, _, _ = select.select([sys.stdin], [], [], 0)
    if dr:
        return sys.stdin.read(1).lower()
    return None

def choose_with_countdown():
    """Zwraca: 'usb' | 'online' | 'check' | 'dev' | 'quit'. Bez wyboru po czasie -> 'usb'."""
    while True:
        print("\n==================================================")
        print("   A-Tool 1-Click LocalAI Installer")
        print("==================================================")
        print(_t("nothing"))
        print(_t("offline_hint"))
        dev_hint = _t("dev_hint") if os.path.exists(
            os.path.join(HERE, "developer.py")) else ""
        print(_t("keys", dev=dev_hint))
        print(_t("lang_key", lang=getattr(_lang, "LANG", "en").upper()))
        print(_t("quit_key") + "\n")

        old = None
        if not WIN:
            try:
                import termios, tty
                old = termios.tcgetattr(sys.stdin)
                tty.setcbreak(sys.stdin.fileno())
            except Exception:
                old = None
        try:
            end = time.time() + COUNTDOWN_SECONDS
            while time.time() < end:
                left = int(end - time.time()) + 1
                print("\r" + _t("start_in", s=left), end="", flush=True)
                try:
                    k = _read_key_nonblocking_win() if WIN else _read_key_nonblocking_unix()
                except Exception:
                    k = None
                if k is not None:
                    print("\r" + " " * 72 + "\r", end="")
                    if k == "l":
                        _lang.set_lang("en" if _lang.LANG == "pl" else "pl")
                        break
                    if k in ("o", "2"):
                        return "online"
                    if k == "3":
                        return "check"
                    if k == "d":
                        return "dev"
                    if k == "q":
                        return "quit"
                    if k in ("\n", "\r", "1", "u"):
                        return "usb"
                    continue
                time.sleep(0.2)
            else:
                print("\r" + " " * 72 + "\r", end="")
                print(_t("no_choice"))
                return "usb"
        finally:
            if old is not None:
                import termios
                termios.tcsetattr(sys.stdin, termios.TCSADRAIN, old)

# ---- SERWER ---------------------------------------------------------------
def server_up():
    try: urllib.request.urlopen(OLLAMA_HOST + "/", timeout=2); return True
    except Exception: return False

def start_server():
    if server_up(): return True
    subprocess.Popen("ollama serve", shell=True,
                     stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    for _ in range(25):
        time.sleep(1)
        if server_up(): return True
    print(_t("srv_retry"))
    subprocess.Popen("ollama serve", shell=True,
                     stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    for _ in range(15):
        time.sleep(1)
        if server_up(): return True
    return False

def has_ollama():
    if shutil.which("ollama"): return True
    if WIN:
        return os.path.exists(os.path.expandvars(
            r"%LOCALAPPDATA%\Programs\Ollama\ollama.exe"))
    if MAC:
        return os.path.exists("/Applications/Ollama.app/Contents/Resources/ollama") \
            or os.path.exists("/usr/local/bin/ollama")
    return False

# ---- INSTALACJA OLLAMY (per OS) -------------------------------------------
def install_ollama_usb():
    if has_ollama(): print(_t("oll_have")); return True
    if WIN:
        exe = os.path.join(USB, "OllamaSetup.exe")
        if not os.path.exists(exe):
            print(_t("oll_miss", p=exe)); return install_ollama_online()
        print(_t("oll_usb_win"))
        sh(f'"{exe}" /VERYSILENT /NORESTART'); time.sleep(4)
    elif MAC:
        dmg = os.path.join(USB, "Ollama.dmg")
        if not os.path.exists(dmg):
            print(_t("oll_miss", p=dmg)); return install_ollama_online()
        print(_t("oll_usb_mac"))
        sh(f'hdiutil attach "{dmg}" -nobrowse -mountpoint /Volumes/OllamaInst')
        sh('cp -R /Volumes/OllamaInst/Ollama.app /Applications/ 2>/dev/null')
        sh('hdiutil detach /Volumes/OllamaInst 2>/dev/null'); time.sleep(2)
    else:
        tgz = os.path.join(USB, "ollama-linux-amd64.tgz")
        if os.path.exists(tgz):
            print(_t("oll_usb_lin"))
            sh(f'sudo tar -C /usr -xzf "{tgz}"'); time.sleep(1)
        else:
            print(_t("oll_miss", p=tgz)); return install_ollama_online()
    return has_ollama()

def install_ollama_online():
    if has_ollama(): print(_t("oll_have")); return True
    print(_t("oll_online"))
    if WIN:
        if sh("winget install -e --id Ollama.Ollama --accept-package-agreements "
              "--accept-source-agreements") == 0:
            time.sleep(4)
    else:
        sh("curl -fsSL https://ollama.com/install.sh | sh"); time.sleep(2)
    if not has_ollama():
        print(_t("oll_manual"))
    return has_ollama()

# ---- MODEL ----------------------------------------------------------------
def _model_name_from_tag(model_tag):
    return (model_tag or DEFAULT_MODEL_TAG).split(":", 1)[0]


def model_present(model_tag=None):
    model_tag = model_tag or DEFAULT_MODEL_TAG
    raw = sh("ollama list", cap=True)
    for line in raw.splitlines()[1:]:
        line = line.strip()
        if not line:
            continue
        if line.split()[0] == model_tag:
            return True
    return False


def _gguf_candidates(model_tag):
    mapped = OFFLINE_GGUF_MAP.get(model_tag)
    name = _model_name_from_tag(model_tag)
    size = model_tag.split(":", 1)[1] if ":" in model_tag else ""
    out = []
    if mapped:
        out.append(mapped)
    if size:
        out.append(f"{name}-{size}.gguf")
        out.append(f"{name}_{size}.gguf")
    if model_tag == DEFAULT_MODEL_TAG:
        out.append(DEFAULT_GGUF)
    # usun duplikaty, zachowaj kolejnosc
    dedup = []
    seen = set()
    for x in out:
        if x not in seen:
            seen.add(x)
            dedup.append(x)
    return dedup


def _resolve_gguf_path(model_tag):
    for name in _gguf_candidates(model_tag):
        p = os.path.join(USB, "models", name)
        if os.path.exists(p):
            return p
    return None

def load_model_usb(model_tag=None, allow_online_fallback=True):
    model_tag = model_tag or DEFAULT_MODEL_TAG
    if model_present(model_tag):
        print(_t("mdl_have"))
        return True

    gguf = _resolve_gguf_path(model_tag)
    if not gguf:
        wanted = os.path.join(USB, "models", _gguf_candidates(model_tag)[0] if _gguf_candidates(model_tag) else DEFAULT_GGUF)
        print(_t("oll_miss", p=wanted))
        return load_model_online(model_tag) if allow_online_fallback else False

    mf = os.path.join(HERE, "_Modelfile")
    open(mf, "w").write(f'FROM "{gguf}"\n')
    print(_t("mdl_reg", n=model_tag))
    ok = sh(f'ollama create {model_tag} -f "{mf}"') == 0
    try: os.remove(mf)
    except OSError: pass
    return ok

def load_model_online(model_tag=None):
    model_tag = model_tag or DEFAULT_MODEL_TAG
    if model_present(model_tag):
        print(_t("mdl_have2"))
        return True
    print(_t("mdl_pull", m=model_tag))
    return sh(f"ollama pull {model_tag}") == 0

# ---- TEST / BENCHMARK (REALNE tokeny z Ollama API) ------------------------
def _api_generate(prompt, num_predict=None, model=None, timeout=600):
    body = {"model": model or DEFAULT_MODEL_TAG, "prompt": prompt, "stream": False}
    if num_predict is not None:
        body["options"] = {"num_predict": num_predict}
    data = json.dumps(body).encode("utf-8")
    req = urllib.request.Request(
        OLLAMA_HOST + "/api/generate", data=data,
        headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.loads(r.read().decode("utf-8"))
    except Exception as e:
        print(_t("api_err", e=e))
        return None

def test(model_tag=None):
    print(_t("test_run"))
    r = _api_generate("Say OK", num_predict=10, model=model_tag or DEFAULT_MODEL_TAG)
    return bool(r and "OK" in (r.get("response", "") or "").upper())

def _recommendation(tps):
    """Rekomendacja DO CZEGO sie nadaje przy danym tok/s."""
    if   tps > 30: return "Excellent", _t("rec_excellent")
    elif tps > 15: return "Good",      _t("rec_good")
    elif tps > 8:  return "Acceptable", _t("rec_ok")
    elif tps > 3:  return "Slow",      _t("rec_slow")
    else:          return "Very slow", _t("rec_vslow")

def benchmark(model=None, num_predict=300, timeout=600, prompt=None):
    """REALNY benchmark: Ollama zwraca eval_count (tokeny) i eval_duration (ns).
    model=None -> uzywa DEFAULT_MODEL_TAG (kompatybilnosc wsteczna)."""
    model = model or DEFAULT_MODEL_TAG
    print(_t("bench_run", m=model))
    prompt = prompt or "Write a 300 word story about the sea."
    r = _api_generate(prompt, num_predict=num_predict, model=model, timeout=timeout)
    if not r:
        print(_t("bench_fail"))
        return None

    eval_count    = r.get("eval_count", 0) or 0
    eval_duration = r.get("eval_duration", 0) or 0     # ns, samo generowanie
    tps = eval_count / (eval_duration / 1e9) if eval_duration else 0.0
    v, rec = _recommendation(tps)

    print(_t("bench_tps", tps=tps, v=v))
    print(_t("recommend", rec=rec))

    result = {
        "model": model,
        "tokens_per_second": round(tps, 2),
        "verdict": v,
        "recommendation": rec,
        "tokens_generated": eval_count,
        "eval_seconds": round(eval_duration / 1e9, 2),
    }
    try:
        json.dump(result, open(BENCH_JSON, "w"), indent=2)
        print(_t("bench_saved", p=BENCH_JSON))
    except Exception as e:
        print(_t("bench_nosave", e=e))
    return result

# ---- WYKRYWANIE SPRZETU (RAM / GPU / VRAM - UCZCIWIE) ---------------------
def _nvidia_vram_and_name():
    """nvidia-smi dziala tez na Windows. Zwraca (vram_GB, name) albo (0,'')."""
    vram = sh("nvidia-smi --query-gpu=memory.total --format=csv,noheader,nounits",
              cap=True).strip()
    if vram and vram.split()[0].isdigit():
        name = sh("nvidia-smi --query-gpu=name --format=csv,noheader",
                  cap=True).strip().splitlines()
        return round(int(vram.split()[0]) / 1024), (name[0] if name else "NVIDIA GPU")
    return 0, ""

def detect_hardware():
    """ram (GB), gpu (str), vram (GB lub 0 gdy nieznane - NIE zmyslamy)."""
    ram, gpu, vram = 0, "", 0
    try:
        # RAM + nazwa GPU per OS
        if WIN:
            ram_raw = sh('powershell -c "[math]::Round((Get-CimInstance '
                         'Win32_ComputerSystem).TotalPhysicalMemory/1GB)"', cap=True).strip()
            ram = int(ram_raw) if ram_raw.isdigit() else 0
            gpu = sh('powershell -c "(Get-CimInstance Win32_VideoController).Name '
                     '-join \',\'"', cap=True).strip()
        elif MAC:
            ram_raw = sh("sysctl -n hw.memsize", cap=True).strip()
            ram = round(int(ram_raw) / 1024**3) if ram_raw.isdigit() else 0
            gpu = sh("system_profiler SPDisplaysDataType | grep -m1 Chipset",
                     cap=True).strip()
            if "APPLE M" in gpu.upper():
                vram = ram  # pamiec zunifikowana - to prawda, nie zmyslenie
        else:
            ram_raw = sh("free -g | awk '/Mem:/{print $2}'", cap=True).strip()
            ram = int(ram_raw) if ram_raw.isdigit() else 0
            gpu = sh("lspci | grep -i -m1 vga", cap=True).strip()

        # VRAM: TYLKO gdy mamy pewne zrodlo. nvidia-smi = cross-platform i dokladny.
        nv_vram, nv_name = _nvidia_vram_and_name()
        if nv_vram:
            vram = nv_vram
            gpu = nv_name
        # inaczej vram zostaje 0 = "nieznane". NIE pokazujemy fejkowej liczby.
    except Exception as e:
        print(_t("hw_partial", e=e))
    return {"ram": ram, "gpu": gpu, "vram": vram}

def _vram_str(vram):
    return f"{vram} GB" if vram else _t("vram_na")


def _is_dedicated_gpu(gpu_name):
    g = (gpu_name or "").upper()
    return any(x in g for x in ("NVIDIA", "RTX", "GTX", "RADEON", "RX ", "APPLE M"))


def _installed_model_names():
    raw = sh("ollama list", cap=True)
    out = []
    for line in raw.splitlines()[1:]:
        line = line.strip()
        if line:
            out.append(line.split()[0])
    return out


def _pick_quick_benchmark_model(installed):
    preferred = [
        "qwen2.5:1.5b",
        "qwen2.5:3b",
        "llama3.2:3b",
        "phi3.5:3.8b",
        "gemma2:2b",
    ]
    for tag in preferred:
        if tag in installed:
            return tag
    return DEFAULT_MODEL_TAG


def _model_size_b(model_tag):
    try:
        size = (model_tag or "").split(":", 1)[1].lower().replace("b", "").strip()
        return float(size)
    except Exception:
        return 7.0


def _auto_model_from_hw(hw):
    """Auto-reguly (ustalone):
    - iGPU / brak VRAM: 1.5B (lub 3B przy RAM >= 16)
    - dedykowana karta + VRAM >= 8 i RAM >= 16: 7B
    - dedykowana karta + VRAM >= 12 i RAM >= 32: 14B
    """
    ram = int(hw.get("ram") or 0)
    vram = int(hw.get("vram") or 0)
    ded = _is_dedicated_gpu(hw.get("gpu", ""))

    if ded and vram >= 12 and ram >= 32:
        return "qwen2.5:14b", "high"
    if ded and vram >= 8 and ram >= 16:
        return "qwen2.5:7b", "mid"
    if ram >= 16:
        return "qwen2.5:3b", "light"
    return "qwen2.5:1.5b", "tiny"


def _choose_model_after_hw(hw, interactive=True):
    auto_model, auto_level = _auto_model_from_hw(hw)
    allow_x = auto_level == "high"
    print(_t("model_auto", m=auto_model))
    if not interactive:
        return auto_model

    hint = _t("model_pick_hint_high") if allow_x else _t("model_pick_hint")
    print(hint)
    c = input(_t("model_pick")).strip().lower()
    if not c or c in ("a", "auto"):
        return auto_model
    if c in ("1", "3", "7"):
        return MODEL_PRESETS[c]
    if allow_x and c in ("x", "12", "14"):
        return MODEL_PRESETS["x"]
    print(_t("model_pick_bad", c=c))
    return auto_model


def _benchmark_profile(hw, model_tag):
    """Dobiera dlugosc benchmarku do mocy komputera i wielkosci wybranego modelu."""
    size_b = _model_size_b(model_tag)
    has_dedicated = _is_dedicated_gpu(hw.get("gpu", ""))
    weak = (not has_dedicated) or int(hw.get("ram") or 0) < 16

    if size_b >= 12:
        return {
            "mode": "heavy",
            "model": model_tag,
            "num_predict": 160,
            "timeout": 420,
            "prompt": "Write a concise technical summary of local AI setup in 7 bullets.",
        }
    if size_b >= 7:
        return {
            "mode": "mid",
            "model": model_tag,
            "num_predict": 120 if not weak else 80,
            "timeout": 240 if not weak else 180,
            "prompt": "Write a concise story about the sea in 8 sentences.",
        }
    return {
        "mode": "quick",
        "model": model_tag,
        "num_predict": 64,
        "timeout": 120,
        "prompt": "Summarize local AI setup in 5 short bullet points.",
    }

# ---- CONFIG + INSTRUKCJA --------------------------------------------------
def save_cfg(hw=None, bench=None, model_tag=None):
    cfg = {
        "provider": "local",
        "runtime": "ollama",
        "model": model_tag or DEFAULT_MODEL_TAG,
    }
    if hw:
        cfg["gpu"] = hw.get("gpu", "")
        cfg["ram"] = hw.get("ram", 0)
        if hw.get("vram"):            # tylko gdy znane
            cfg["vram"] = hw["vram"]
    if bench:
        cfg["tokens_per_second"] = bench.get("tokens_per_second", 0)
    json.dump(cfg, open(CFG, "w"), indent=1)
    print(_t("cfg_saved", p=CFG))

def how_to_link():
    print(_t("how_link", host=OLLAMA_HOST))

# ---- SPRAWDZ KOMPUTER (per OS) --------------------------------------------
def check_pc():
    print(_t("pc_check"))
    hw = detect_hardware()
    print(_t("pc_ram", v=hw['ram']))
    print(_t("pc_gpu", v=hw['gpu']))
    print(_t("pc_vram", v=_vram_str(hw['vram'])))
    r = hw["ram"]
    ded = _is_dedicated_gpu(hw.get("gpu", ""))
    if   ded and r >= 16: print(_t("pc_rec7b"))
    elif r >= 16:         print(_t("pc_rec3b"))
    elif r >= 8:          print(_t("pc_recsmall"))
    else:                 print(_t("pc_recapi"))
    auto_model, _ = _auto_model_from_hw(hw)
    print(_t("pc_auto", m=auto_model))
    return hw

# ---- POPUP (PRZY ZAMKNIECIU 1-clicka; browser = zero zaleznosci) ----------
_POPUP_DONE = threading.Event()

def _popup_once():
    if _POPUP_DONE.is_set():
        return
    _POPUP_DONE.set()
    try:
        show_popup()
    except Exception as e:
        print(_t("popup_skip", e=e))

def show_popup():
    """Uniwersalny popup Locally4Me. Uzywa l4m_popup.py (ten sam we wszystkich
    1-clickach). Gdy pliku brak -> cisza, instalacja dziala dalej."""
    try:
        import l4m_popup
        l4m_popup.show(lang=getattr(_lang, "LANG", None), base_dir=HERE)
    except ImportError as e:
        print(_t("popup_skip", e=e))
    except Exception as e:
        print(_t("popup_skip", e=e))

# ---- PELNY PRZEBIEG -------------------------------------------------------
def full_run(online, interactive=True):
    ok = install_ollama_online() if online else install_ollama_usb()
    if not ok: print(_t("oll_fail")); return
    if not start_server(): print(_t("srv_fail")); return

    hw = detect_hardware()
    print(_t("hw_line", ram=hw['ram'], vram=_vram_str(hw['vram']), gpu=hw['gpu']))
    selected_model = _choose_model_after_hw(hw, interactive=interactive)
    print(_t("model_selected", m=selected_model))

    ok = load_model_online(selected_model) if online else load_model_usb(selected_model, allow_online_fallback=False)
    if (not ok) and (not online):
        auto_model, _ = _auto_model_from_hw(hw)
        if selected_model != auto_model:
            print(_t("model_fallback", m=auto_model))
            selected_model = auto_model
            ok = load_model_usb(selected_model, allow_online_fallback=False)
    if not ok: print(_t("mdl_fail")); return

    if not test(model_tag=selected_model): print(_t("test_fail"))

    profile = _benchmark_profile(hw, selected_model)
    print(_t("bench_mode", mode=profile["mode"], m=profile["model"],
             t=profile["num_predict"], s=profile["timeout"]))
    try:
        bench = benchmark(
            model=profile["model"],
            num_predict=profile["num_predict"],
            timeout=profile["timeout"],
            prompt=profile["prompt"],
        )
    except KeyboardInterrupt:
        print("\n" + _t("bench_cancel"))
        bench = None
    save_cfg(hw=hw, bench=bench, model_tag=selected_model)
    print(_t("done", m=selected_model))
    how_to_link()
    # popup NIE tutaj - dopiero przy zamknieciu (patrz main()).

def _wait_and_popup():
    """Popup przy zamknieciu (Enter) LUB po czasie bezczynnosci."""
    t = None
    if SHOW_POPUP:
        t = threading.Timer(POPUP_IDLE_SECONDS, _popup_once)
        t.daemon = True
        t.start()
    try:
        input(_t("enter_close"))
    except EOFError:
        pass
    if t:
        t.cancel()
    if SHOW_POPUP:
        _popup_once()

def main():
    if "--auto" in sys.argv:
        full_run(online="--online" in sys.argv, interactive=False)
    else:
        while True:
            choice = choose_with_countdown()
            if choice == "quit":
                return
            if choice == "dev":
                dev = os.path.join(HERE, "developer.py")
                if os.path.exists(dev):
                    subprocess.run([sys.executable, dev])
                else:
                    print(_t("no_dev"))
                continue
            if choice == "check":
                check_pc()
                continue
            if choice == "online":
                full_run(online=True)
                break
            full_run(online=False)
            break
    _wait_and_popup()

if __name__ == "__main__":
    main()
