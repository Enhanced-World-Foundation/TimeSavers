# wspolny modul jezyka EN/PL - baza EN, PL jako opcja. Zero zaleznosci.
import locale, os

def detect_lang():
    # priorytet: L4M_LANG -> zmienne systemowe -> locale API -> default EN
    env = os.environ.get("L4M_LANG", "").lower()
    if env in ("en", "pl"):
        return env
    # sklej kilka zrodel - getdefaultlocale bywa pusty/deprecated w nowym Pythonie
    probe = ""
    for var in ("LC_ALL", "LC_MESSAGES", "LANG", "LANGUAGE"):
        probe = os.environ.get(var, "")
        if probe:
            break
    if not probe:
        try:
            probe = (locale.getlocale()[0] or "") or (locale.getdefaultlocale()[0] or "")
        except Exception:
            probe = ""
    probe = probe.lower()
    return "pl" if probe.startswith("pl") or "pl_pl" in probe else "en"

LANG = detect_lang()

def set_lang(code):
    global LANG
    if code in ("en", "pl"):
        LANG = code

def t(key, **kw):
    s = STR.get(key, {}).get(LANG) or STR.get(key, {}).get("en") or key
    return s.format(**kw) if kw else s

STR = {
    # --- menu / countdown ---
    "title":       {"en": "A-Tool 1-Click LocalAI Installer",
                    "pl": "A-Tool 1-Click LocalAI Installer"},
    "nothing":     {"en": "  Do nothing = install from USB (offline).",
                    "pl": "  Nic nie rob = instalacja z USB (offline)."},
    "offline_hint": {"en": "  [Enter]/[1]=offline now",
                      "pl": "  [Enter]/[1]=offline teraz"},
    "keys":        {"en": "  [O]=online   [3]=check computer{dev}",
                    "pl": "  [O]=online   [3]=sprawdz komputer{dev}"},
    "dev_hint":    {"en": "   [D]=developer", "pl": "   [D]=developer"},
    "lang_key":    {"en": "  [L]=language (now: {lang})", "pl": "  [L]=jezyk (teraz: {lang})"},
    "quit_key":    {"en": "  [Q]=quit", "pl": "  [Q]=zakoncz"},
    "start_in":    {"en": "  Start in {s:2d} s ...  (press a key to choose)   ",
                    "pl": "  Start za {s:2d} s ...  (wcisnij klawisz aby wybrac)   "},
    "no_choice":   {"en": "\n  -> No choice. Installing from USB (offline).",
                    "pl": "\n  -> Brak wyboru. Instaluje z USB (offline)."},
    "no_dev":      {"en": "[!] No developer.py next to the program.",
                    "pl": "[!] Brak developer.py obok programu."},
    # --- server ---
    "srv_retry":   {"en": "[!] Server did not start in 25 s. Second try...",
                    "pl": "[!] Serwer nie wstal w 25 s. Druga proba..."},
    "srv_fail":    {"en": "[!] Server did not start. End.",
                    "pl": "[!] Serwer nie wstal. Koniec."},
    # --- ollama install ---
    "oll_have":    {"en": "[*] Ollama already present.", "pl": "[*] Ollama juz jest."},
    "oll_miss":    {"en": "[!] Missing {p} -> trying online.",
                    "pl": "[!] Brak {p} -> probuje online."},
    "oll_usb_win": {"en": "[*] Installing Ollama from USB (silent)...",
                    "pl": "[*] Instaluje Ollame z USB (cicho)..."},
    "oll_usb_mac": {"en": "[*] Mounting and installing Ollama from USB...",
                    "pl": "[*] Montuje i instaluje Ollame z USB..."},
    "oll_usb_lin": {"en": "[*] Unpacking Ollama from USB...",
                    "pl": "[*] Rozpakowuje Ollame z USB..."},
    "oll_online":  {"en": "[*] Installing Ollama online...",
                    "pl": "[*] Instaluje Ollame online..."},
    "oll_manual":  {"en": "[!] Failed. Download manually: https://ollama.com/download",
                    "pl": "[!] Nie udalo sie. Pobierz recznie: https://ollama.com/download"},
    "oll_fail":    {"en": "[!] Ollama failed. End.", "pl": "[!] Ollama nieudana. Koniec."},
    # --- model ---
    "mdl_have":    {"en": "[*] Model already loaded.", "pl": "[*] Model juz zaladowany."},
    "mdl_have2":   {"en": "[*] Model already present.", "pl": "[*] Model juz jest."},
    "mdl_reg":     {"en": "[*] Registering {n} from USB file...",
                    "pl": "[*] Rejestruje {n} z pliku USB..."},
    "mdl_pull":    {"en": "[*] Pulling {m} online...", "pl": "[*] Pobieram {m} online..."},
    "mdl_fail":    {"en": "[!] Model failed. End.", "pl": "[!] Model nieudany. Koniec."},
    "model_auto":  {"en": "[*] Auto-selected model from hardware: {m}",
                    "pl": "[*] Auto-wybor modelu po sprzecie: {m}"},
    "model_selected": {"en": "[*] Selected model: {m}",
                       "pl": "[*] Wybrany model: {m}"},
    "model_pick_hint": {"en": "[*] Manual override: [Enter]=auto  [1]=1.5b  [3]=3b  [7]=7b",
                        "pl": "[*] Reczny wybor: [Enter]=auto  [1]=1.5b  [3]=3b  [7]=7b"},
    "model_pick_hint_high": {"en": "[*] Manual override: [Enter]=auto  [1]=1.5b  [3]=3b  [7]=7b  [X]=14b",
                             "pl": "[*] Reczny wybor: [Enter]=auto  [1]=1.5b  [3]=3b  [7]=7b  [X]=14b"},
    "model_pick":  {"en": "  Choose model (optional): ",
                    "pl": "  Wybierz model (opcjonalnie): "},
    "model_pick_bad": {"en": "[!] Unknown choice '{c}' -> using auto model.",
                       "pl": "[!] Nieznany wybor '{c}' -> uzywam auto-modelu."},
    "model_fallback": {"en": "[!] Selected model unavailable offline. Falling back to auto model: {m}",
                       "pl": "[!] Wybrany model niedostepny offline. Powrot do auto-modelu: {m}"},
    # --- test / benchmark ---
    "test_run":    {"en": "[*] Response test...", "pl": "[*] Test odpowiedzi..."},
    "test_fail":   {"en": "[!] Test failed, trying benchmark anyway...",
                    "pl": "[!] Test nieudany, probuje benchmark mimo to..."},
    "bench_run":   {"en": "[*] Benchmark {m} (real metrics from Ollama)...",
                    "pl": "[*] Benchmark {m} (prawdziwe metryki z Ollama)..."},
    "bench_mode":  {"en": "[*] Benchmark mode: {mode} | model: {m} | tokens: {t} | timeout: {s}s",
                    "pl": "[*] Tryb benchmarku: {mode} | model: {m} | tokeny: {t} | timeout: {s}s"},
    "bench_fail":  {"en": "    [!] Benchmark failed (no API response).",
                    "pl": "    [!] Benchmark nieudany (brak odpowiedzi API)."},
    "bench_cancel": {"en": "[!] Benchmark interrupted by user. Continuing without speed score.",
                     "pl": "[!] Benchmark przerwany przez uzytkownika. Kontynuuje bez wyniku szybkosci."},
    "bench_tps":   {"en": "\n    >>> ~{tps:.1f} tok/s   [{v}]",
                    "pl": "\n    >>> ~{tps:.1f} tok/s   [{v}]"},
    "recommend":   {"en": "    >>> Recommendation: {rec}",
                    "pl": "    >>> Rekomendacja: {rec}"},
    "bench_saved": {"en": "[+] Benchmark saved: {p}", "pl": "[+] Zapisano benchmark: {p}"},
    "bench_nosave":{"en": "[!] benchmark.json not saved: {e}",
                    "pl": "[!] Nie zapisano benchmark.json: {e}"},
    "api_err":     {"en": "[!] API /generate error: {e}", "pl": "[!] API /generate blad: {e}"},
    # --- recommendations (use-case) ---
    "rec_excellent":{"en":"Local READY: mail triage, RAG, summaries, longer texts",
                     "pl":"Local READY: triage maili, RAG, streszczenia, dluzsze teksty"},
    "rec_good":    {"en":"Local READY: triage, classification, RAG; longer gen slower",
                    "pl":"Local READY: triage, klasyfikacja, RAG; dluzsze generacje wolniej"},
    "rec_ok":      {"en":"Local OK for short tasks: classification, tags; RAG consider API",
                    "pl":"Local OK do krotkich zadan: klasyfikacja, tagi; RAG rozwaz API"},
    "rec_slow":    {"en":"Slow: only rare short background tasks; interactive -> API",
                    "pl":"Wolno: tylko rzadkie krotkie zadania w tle; interaktywne -> API"},
    "rec_vslow":   {"en":"Too slow for 7B: use API (Groq) or smaller 3B model",
                    "pl":"Za wolno na 7B: uzyj API (Groq) lub mniejszy model 3B"},
    # --- hardware ---
    "hw_partial":  {"en": "[!] Hardware detection partial: {e}",
                    "pl": "[!] Wykrywanie sprzetu czesciowe: {e}"},
    "vram_na":     {"en": "n/a (no reliable source)", "pl": "n/a (brak pewnego zrodla)"},
    "cfg_saved":   {"en": "[+] Config saved: {p}", "pl": "[+] Zapisano config: {p}"},
    "pc_check":    {"en": "[*] Checking hardware...", "pl": "[*] Sprawdzam sprzet..."},
    "pc_ram":      {"en": "    RAM:  {v} GB", "pl": "    RAM:  {v} GB"},
    "pc_gpu":      {"en": "    GPU:  {v}", "pl": "    GPU:  {v}"},
    "pc_vram":     {"en": "    VRAM: {v}", "pl": "    VRAM: {v}"},
    "pc_rec7b":    {"en": "    Recommendation: Local 7B - fine",
                    "pl": "    Rekomendacja: Local 7B - spoko"},
    "pc_rec3b":    {"en": "    Recommendation: Local small model (3B)",
                    "pl": "    Rekomendacja: Local maly model (1.5B/3B)"},
    "pc_recsmall": {"en": "    Recommendation: small model or API if slow",
                    "pl": "    Rekomendacja: model 1.5B/3B lub API jesli wolno"},
    "pc_recapi":   {"en": "    Recommendation: API / metal AI server (weak hardware)",
                    "pl": "    Rekomendacja: API / metal serwer AI (slaby sprzet)"},
    "pc_auto":     {"en": "    Auto-model: {m}",
                    "pl": "    Auto-model: {m}"},
    "hw_line":     {"en": "[*] Hardware: RAM {ram} GB | VRAM {vram} | {gpu}",
                    "pl": "[*] Sprzet: RAM {ram} GB | VRAM {vram} | {gpu}"},
    # --- finish / popup ---
    "done":        {"en": "\n  INSTALLATION COMPLETE.  Model: {m}  Status: READY",
                    "pl": "\n  INSTALACJA ZAKONCZONA.  Model: {m}  Status: READY"},
    "popup_skip":  {"en": "[popup] skipped: {e}", "pl": "[popup] pominieto: {e}"},
    "enter_close": {"en": "\n[Enter] to close...", "pl": "\n[Enter] aby zamknac..."},
    "how_link":    {"en": """
------------------------------------------------------------
 DONE. How to connect to A-Tool (Inbox Reporter etc.):
   1. Copy the file  runtime.json  (next to the program)
      into your agent's folder.
   2. Keep Ollama running - it works in the background at
      {host}
   3. The agent will connect to the local model by itself.
 That's all. Nothing more to click.
------------------------------------------------------------""",
                    "pl": """
------------------------------------------------------------
 GOTOWE. Jak podpiac do A-Tool (Inbox Reporter itd.):
   1. Skopiuj plik  runtime.json  (lezy obok programu)
      do folderu swojego agenta.
   2. Zostaw Ollame wlaczona - dziala w tle na
      {host}
   3. Agent sam sie polaczy z lokalnym modelem.
 To wszystko. Nic wiecej nie klikaj.
------------------------------------------------------------"""},
}
